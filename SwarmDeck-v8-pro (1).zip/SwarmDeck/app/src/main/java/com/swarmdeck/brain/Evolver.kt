package com.swarmdeck.brain

import android.content.Context
import com.swarmdeck.Audit
import com.swarmdeck.Bus
import com.swarmdeck.Llm
import com.swarmdeck.Registry
import com.swarmdeck.Run
import com.swarmdeck.Store

/**
 * Self-improving swarm: agents that score poorly get a debated prompt rewrite, which is A/B tested
 * against the current prompt on real runs and only kept if it wins. Everything is logged and reversible.
 */
object Evolver {
    private const val DAY = 24L * 3600 * 1000
    private const val MAX_PER_PASS = 3

    /** Agents whose prompts may evolve. Phone operator and mission controller are safety-critical and never change. */
    private fun evolvable() = Registry.all().filter { it.id != "operator" && it.id != "desk" && it.id != "mission" && !it.id.startsWith("dyn_") }

    fun maybeDaily(c: Context) {
        val p = Store.p(c)
        if (!p.getBoolean("evolve_auto", true)) return
        val now = System.currentTimeMillis()
        if (now - p.getLong("brain_last_evolve", 0L) < DAY) return
        p.edit().putLong("brain_last_evolve", now).apply()
        val t = Thread {
            try {
                runOnce(c.applicationContext, Run(-5), false)
            } catch (_: Exception) {
            }
        }
        t.isDaemon = true
        t.start()
    }

    /** Records peer scores from a multi-agent run. Errors count as 0. Resolves A/B trials the moment they are decided. */
    fun recordRun(c: Context, runId: Int, answers: List<Pair<String, String>>, scores: Map<String, Int>) {
        BrainStore.ensureLoaded(c)
        val arm = runId and 1
        for ((id, text) in answers) {
            if (id == "operator" || id == "desk" || id == "mission" || id.startsWith("dyn_")) continue
            val sc = if (text.startsWith("ERR:")) 0 else (scores[id] ?: continue)
            val d = BrainStore.recordScore(c, id, arm, sc)
            if (d == Decision.PROMOTE) Bus.think("Evolution: ${com.swarmdeck.nameOf(id)} adopted an improved prompt")
            if (d == Decision.REJECT) Bus.think("Evolution: ${com.swarmdeck.nameOf(id)} kept its old prompt")
        }
    }

    fun runOnce(c: Context, run: Run, force: Boolean): String {
        BrainStore.ensureLoaded(c)
        val now = System.currentTimeMillis()
        val ask: (String, String) -> String = { sys, user -> run.check(); Llm.chat(c, run, "head", sys, user) }
        val lines = ArrayList<String>()
        var done = 0
        for (a in evolvable()) {
            if (done >= MAX_PER_PASS) break
            val s = BrainStore.stateOf(a.id) ?: continue
            if (!Evo.needsEvolution(s, now, if (force) 3 else Evo.MIN_RUNS)) continue
            val avg = String.format("%.1f", Evo.mean(s.baseScores))
            val weak = "average peer score $avg/10 over ${s.baseScores.size} runs"
            val current = Evo.promptFor(s, a.prompt, 0)
            val r = Debate.improvePrompt(ask, a.name, a.role, current, weak)
            val cand = r.candidate
            if (cand != null && BrainStore.startTrial(c, a.id, cand, weak)) {
                lines.add("🧪 ${a.name}: improved prompt is now in an A/B trial ($weak)")
            } else {
                lines.add("➖ ${a.name}: no safe improvement found ($weak)")
            }
            done++
        }
        Audit.log(c, "evolve", "pass done: $done agent(s) examined")
        return if (lines.isEmpty()) "Nothing to evolve yet. Agents need about ${Evo.MIN_RUNS} scored multi-agent runs and an average below ${Evo.WEAK_BELOW}." else lines.joinToString("\n")
    }

    fun statusText(c: Context): String {
        BrainStore.ensureLoaded(c)
        val auto = if (Store.p(c).getBoolean("evolve_auto", true)) "on" else "off"
        val sb = StringBuilder("### Swarm evolution (daily auto: $auto)\n")
        val all = BrainStore.snapshot()
        if (all.isEmpty()) sb.append("No scored runs yet. Use the swarm in multi-agent mode and scores will accumulate.\n")
        for (s in all.values) {
            val name = com.swarmdeck.nameOf(s.agentId)
            val ver = s.active?.let { "v${it.version}" } ?: "built-in"
            val base = if (s.baseScores.isEmpty()) "-" else String.format("%.1f", Evo.mean(s.baseScores))
            sb.append("- **$name**: prompt $ver, avg $base/10 (${s.baseScores.size} runs)")
            if (s.trial != null) sb.append(", trial v${s.trial.version}: ${s.trialScores.size}/${Evo.MIN_PER_ARM} runs")
            sb.append("\n")
        }
        sb.append("\nCommands: `evolve: now`, `evolve: rollback <agent>`, `evolve: on|off`")
        return sb.toString()
    }
}
