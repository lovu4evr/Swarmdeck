# SwarmDeck 8.0 - SwarmDeck Pro (real Google Play subscription)

## Personal mode (run it yourself, no Play Console)
In debug/test builds (the normal `Build APK` workflow) the SwarmDeck Pro page has a **Personal mode · ₹500 / month** plan: Subscribe -> Pro for 30 days, Renew adds 30 more days, Cancel ends it, expiry is checked on every app start. No money is charged; it only unlocks features on your own device. It is compiled to do nothing in release builds, so a published app cannot be unlocked this way.

**Free**: chat (Auto + Fast), up to 3 agents per question, memory, goals, terminal, tools, Phone Operator.
**Pro** unlocks: Autonomous Missions, All-Agents + Deep mode (up to 6 agents), Multi-device control (Desk Operator), Memory Graph & Decisions, Immersive mode, Agent Market, Swarm Lab (`sim`, `factory`, `evolve`).

Locks are enforced in the UI (lock icons, paywall) AND in the engine (`Brain.run`, command handlers, `Tools.exec`), so agents and typed commands cannot bypass them.

## Go live (this part cannot be done from code)
1. **Play Console**: create the app with package `com.swarmdeck` (one-time US$25 developer account). Complete the payments profile.
2. **Signing**: create an upload keystore (`keytool -genkeypair -v -keystore upload.jks -alias upload -keyalg RSA -keysize 2048 -validity 10000`). In GitHub -> Settings -> Secrets add `KEYSTORE_BASE64` (`base64 -w0 upload.jks`), `KEYSTORE_PASSWORD`, `KEY_ALIAS`, `KEY_PASSWORD`.
3. Run the workflow **Release AAB (Google Play)**, download `SwarmDeck-AAB`, upload the `.aab` to an **Internal testing** track (a subscription only becomes purchasable once a build with the billing permission is uploaded).
4. **Monetize -> Subscriptions -> Create subscription**: product id **`swarmdeck_pro`**; add base plans **`monthly`** and **`yearly`** (auto-renewing), set prices, optionally add a free-trial offer, then **Activate**.
5. Add your Google account under **License testers** and install from the internal-testing link. Test purchases are free and renew quickly. Sideloaded / debug APKs from the normal `Build APK` workflow cannot buy (Play returns "billing unavailable").
6. Debug builds have a "Debug: simulate Pro" switch on the SwarmDeck Pro page so you can test the unlocked features without Play. It does not exist in release builds.

## How it works
- `billing/BillingManager.kt`: Play Billing 7 client. Loads real localized prices, launches the purchase sheet, acknowledges purchases, and re-checks Google Play on every app start/resume (cancelled or refunded subscriptions are revoked on that check).
- `billing/Pro.kt`: entitlement + feature list. The last verified result is cached encrypted (Keystore) with a 72-hour offline grace period.
- `ui/ProScreen.kt`: paywall, restore purchase, manage subscription.
- Not included: server-side verification. A rooted device can tamper with local state; for stronger protection verify purchase tokens with the Google Play Developer API from your own backend.
- Required before public release: a privacy policy URL and Play's subscription disclosures (the paywall already shows the renewal/cancel text).

---

# SwarmDeck 7.0 - Phase 4: Multi-device control

Control your laptop/desktop from the phone, with the same Zero-Trust rules as everything else.

**Setup**
1. On the computer (same Wi-Fi or Tailscale): `pip install pyautogui pillow`, then `python companion/swarmdeck_companion.py`. It prints an address and an 8-character one-time code.
2. On the phone: menu -> **Devices** -> enter name, address, code -> Pair. (Or `device: pair <name> <host:port> <code>`.)
3. Give tasks with `desk: open notepad and type hello`, or just ask in chat; the **Desk Operator** agent appears once a computer is paired.

**What it can do**: screenshot (the model sees it), mouse move/click/double-click/scroll, type text, press keys, open an http(s) page, open allow-listed apps, read/write the clipboard. Parallel: several computers can be paired and the phone itself stays controllable through the existing Operator.
**What it never does**: run shell commands, open terminals / Run dialogs / lock-screen shortcuts, type secrets, contact non-local addresses.

**Security**
- The code never travels: key = PBKDF2(code, public salt); every request is HMAC-signed with timestamp + nonce (replay and tampering rejected, lock-out after 10 bad signatures, rate limit).
- The phone asks you before every computer action; the first screenshot per task and device needs approval too. Dangerous shortcuts, shell-like apps, secrets and bad URLs are blocked outright (checked on the phone AND on the computer).
- Kill switches: the phone's volume kill switch and `device: stop` pause every computer until you type `resume` in its companion window; Ctrl+C or moving the mouse to a screen corner stops it locally.
- Apps are an allow-list on the computer (`~/.swarmdeck_companion.json`, argv lists only). Traffic is signed, not encrypted: use trusted networks.

Commands: `device: list | pair | ping <name> | stop [name] | remove <name>`, `desk: <task>`.
Code: `device/` (+ `DeviceTest.kt`), `ui/DevicesScreen.kt`, `companion/` (+ `test_companion.py`, run with `python test_companion.py`).

---

# SwarmDeck 6.2 - Phase 3: Immersive UI + Memory Graph

**Immersive mode** (sidebar -> Immersive, or tap the small orb at the top-right of Chat): full-screen, system bars hidden, gesture + voice first.
- Tap the orb = start/stop listening, hold = stop the agent (or stop speaking). Swipe left/right = Swarm / Mission / Memory / Briefing. Swipe up = type, swipe down = close keyboard. One tiny button only (exit).
- **Holographic orb**: gold core, counter-rotating rings, hologram scanlines, listening waves; every active agent is an orbiting satellite with data packets flowing to the core.
- **Mission timeline**: quest line with XP bar, gold check = done, pulsing ring = active, red = failed.
- **Briefing**: proactive nudges from your goals and decisions (overdue, due soon, stalled, almost done, decisions to review). Tap one to hand it to your agents (goes through Zero-Trust like everything else).
- Liquid-gold look: the Backdrop glows now drift slowly.

**Memory graph / personal OS**
| Command | What it does |
|---|---|
| `decide: <title> because <reason>` | Records a decision, auto-linked to the goal it matches best |
| `decisions` / `decisions: done <id>` / `drop <id>` | Review and close decisions |
| `recall: <topic>` | Graph-aware recall: matches plus everything connected to them |
| `graph` | Size and top topics of the graph |
| `os` | Briefing from goals + open decisions |

Sidebar -> **Memory Graph**: force-directed map of facts, goals, decisions and topics (pinch, drag, tap a node to light up its links). Agents also get a read-only `graph_recall` tool. Decisions containing secrets are refused (same rule as memory).
Not automatic yet: extracting decisions from normal chat, and background notifications (briefing is shown on demand).

Code: `memgraph/`, `ui/Orb.kt`, `ui/Immersive.kt`, `ui/MissionTimeline.kt`, `ui/MemoryGraphScreen.kt`, `ui/viz/Layouts.kt` (+ `GraphTest.kt`, `LayoutsTest.kt`).

---

# SwarmDeck 6.1 - Phase 2: Zero-Trust

A gate in front of **every** tool call (`Tools.exec` -> `Guard.gate`). Four outcomes: run silently, run + log, ask approval (every time, never "trust this run"), or **block**.

| Command | What it does |
|---|---|
| `guard: status` / `log [n]` / `verify` | Mode, counters, last decisions, and a check that the log was not edited |
| `guard: strict` / `guard: normal` | Strict = every network access, file write, memory save, code run and media generation needs approval. There is no "off": blocks are permanent |
| `undo: list` / `last` / `run` / `<number>` | Roll back agent file writes and memory saves (`run` = everything the last agent run changed) |

Always blocked (cannot be approved): card numbers, API keys/tokens, passwords, OTP/CVV, SSN-like numbers typed by an agent, saved to memory, or sent out in a URL/search/media prompt; hidden files, path traversal, executable/installer files (`.apk .sh .jar ...`); JS/Python that reaches the network, storage or the JS bridge.
Asks first: overwriting a file, writing text that contains secrets (shown redacted). Phone and browser actions keep their own existing confirmations (no double prompts).
Safeguards: approvals are serialized, the gate fails closed on internal errors, the decision log is hash-chained (tamper-evident) and secrets are redacted before logging, undo can never write outside the sandbox.

Code: `app/src/main/java/com/swarmdeck/guard/` (+ `GuardTest.kt`). Hooks: `Tools.exec`, `Brain.run`.

---

# SwarmDeck 6.0 - Phase 1: Brain

New chat commands (no UI change needed):

| Command | What it does |
|---|---|
| `sim: <task>` / `sim 8: <task>` | **Parallel Reality Simulation**: 2-10 different approaches run in parallel, a judge scores them, the best is kept, the rest discarded (asks approval above 6 runs) |
| `factory: <goal>` | **Agent Factory**: designs a specialist, self-tests it (up to 2 refine rounds), deploys only after you approve. Read-only tools only (no phone, no file write, no code) |
| `factory: list` / `factory: remove <name>` | Manage factory agents (also deletable from the agents list) |
| `evolve: status` / `now` / `rollback <agent>` / `on` / `off` | **Self-improving swarm**: weak agents get a debated prompt rewrite (Proposer -> Critic -> Judge), A/B tested on real runs, kept only if it wins by 0.5+ points, otherwise discarded. One-step rollback. Runs automatically once a day |

Safety rules baked in: evolved/factory prompts pass `PromptGuard` (no override/bypass/secret wording, length-capped), tools are never changed by evolution, the phone Operator and Mission controller never evolve, every change is written to the audit log.

New code: `app/src/main/java/com/swarmdeck/brain/` (+ `BrainTest.kt`). Hooks: `Registry.all()` (Agents.kt), `Brain.run()` (Brain.kt), `MainActivity.onCreate`.
Scores come from the synthesizer's peer scores in multi-agent runs; errors count as 0.

---

# SwarmDeck Ultimate Edition 5.5 (Goated)

**Local-first multi-agent AI assistant for Android**

---

## 5.5 — Integration Complete

### Fully Wired in this version
- **ContextBuilder** integrated into `Brain.suf()` and `toolLoop` (Goals + active Missions + Paranoid Mode + RAG auto-injected)
- **Navigation** — Goals, Missions, Agent Market added to sidebar + page router
- **App Lock gate** — PIN + Biometric lock screen after splash (when enabled)
- **LockScreen** composable included

### All systems present
| System | Status |
|--------|--------|
| Long-term Goals + UI | ✅ |
| Mission Engine v2 + Checkpoints + UI | ✅ |
| Shareable Agents + UI | ✅ |
| Local RAG | ✅ |
| App Lock + Paranoid Mode | ✅ |
| Agent Performance Tracker | ✅ |
| ContextBuilder (auto context) | ✅ Wired into Brain |
| Unit tests | ✅ |

### Version
- versionName: **5.5-goated**
- versionCode: **11**

### Still optional / future
- Full-duplex voice
- Scheduled missions (WorkManager)
- AMOLED pure black theme toggle
- Deeper large-file split

Open in Android Studio → Sync → Run.
