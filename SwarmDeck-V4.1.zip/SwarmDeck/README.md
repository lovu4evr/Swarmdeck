# SwarmDeck V4.1

Android multi-agent assistant (Kotlin + Jetpack Compose). Local-first: chats and memory live in an on-device SQLite DB, encrypted with an Android-Keystore AES-GCM key; API keys are stored encrypted.

## Setup
1. Push to GitHub -> Actions builds the APK (unit tests run first, non-blocking). Or open in Android Studio.
2. Open the app -> Enter (no account). Settings -> add an OpenAI-compatible endpoint (https://…/v1) + key -> Save & test.

## What's new in 4.1
- No Google login (local profile). Cleartext HTTP blocked except localhost. Backups disabled. Debug keystore removed.
- Hands-free voice: auto-send after silence, mic muted while speaking, resumes after the answer, interrupt button, optional wake word.
- Real Mission engine: plan -> execute each step with tools -> verify -> retry/replan/block; pause/resume/cancel; persisted & resumable.
- Tool calling (native OpenAI tools, auto-fallback to prompt protocol): web_search, web_fetch, memory, sandbox files, phone.
- Phone control with observe-act loop, per-action approval (dialog or notification), sensitive-action detection, app allow/blocklist, password-field refusal, Volume-Down x3 / notification kill switch, audit log.
- Real model routing (head/synth/main + fallbacks), retry with backoff, token counter, multiple API profiles.
- SSE streaming, markdown + copyable code blocks, multiple chats, export/import, memory tab (search/pin/delete, keyword scoring, 5000 cap).
- Stop really cancels HTTP calls. Dynamic agents are validated, tool-less, session-scoped, max 5.

## Limits (honest)
- Not compiled or run by the author of this revision: first build may need small fixes.
- web_search scrapes DuckDuckGo HTML and may be blocked.
- Phone control reads the accessibility tree only (no screenshots/vision yet). Screen text goes to your API endpoint.
- Export files are plaintext.
