package com.swarmdeck

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import java.io.File
import java.util.concurrent.TimeUnit

object Term {
    val lines = mutableStateListOf("SwarmDeck terminal. Type help.")
    private var cwd: File? = null

    fun out(s: String) { Bus.ui { lines.add(s); while (lines.size > 400) lines.removeAt(0) } }

    fun exec(c: Context, cmd: String) {
        val t = cmd.trim()
        if (t.isEmpty()) return
        out("$ $t")
        Audit.log(c, "terminal", t)
        when {
            t == "clear" -> Bus.ui { lines.clear() }
            t == "help" -> out("help · clear · agents · status · history · stats · audit · memory [query] · ask <question> · cd <dir> · or any shell command (ls, pwd, date, uname -a, df)")
            t == "agents" -> out(Registry.all().joinToString("\n") {
                "${it.name} — ${it.role}" + (if (Store.p(c).getBoolean("off_${it.id}", false)) " (off)" else "") + (if (it.dynamic) " (dynamic)" else "")
            })
            t == "history" -> out("${Bus.turns.size} chat messages in this chat, ${Hist.list(c).size} chats saved")
            t == "stats" -> out("LLM calls: ${Bus.calls}   tokens: ${Bus.tokens}")
            t == "audit" -> out(Audit.tail(c, 40))
            t == "status" -> {
                val p = Store.p(c)
                val pr = Profiles.active(c)
                out("Profile: ${pr.name}\nAPI: ${pr.url}\nModel: ${p.getString("model", "auto")}\nMode: ${p.getString("mode", "auto")}\nPhone control: ${if (p.getBoolean("phone", false)) "on" else "off"}, service ${if (PhoneControl.inst != null) "connected" else "not connected"}\nMemories: ${Memory.all(c).size}")
            }
            t == "memory" || t.startsWith("memory ") -> {
                val q = t.removePrefix("memory").trim()
                val r = if (q.isEmpty()) Memory.all(c).take(10) else Memory.search(c, q, 10)
                out(if (r.isEmpty()) "(nothing found)" else r.joinToString("\n") { "• ${it.key}: ${it.value.take(120)}" })
            }
            t.startsWith("ask ") -> {
                if (Bus.running) { out("Agent is busy with a chat request."); return }
                out("…asking the swarm")
                Thread {
                    val r = try { Brain.run(c, Run(-1), t.removePrefix("ask ").trim(), Bus.turns.toList()) {} } catch (e: Exception) { Turn(false, "Error: ${e.message}") }
                    out(r.text)
                }.start()
            }
            t.startsWith("cd ") -> {
                val a = t.substring(3).trim()
                val d = File(if (a.startsWith("/")) a else (cwd ?: c.filesDir).path + "/" + a).canonicalFile
                if (d.isDirectory) { cwd = d; out(d.path) } else out("cd: no such directory")
            }
            else -> Thread { out(shell(c, t)) }.start()
        }
    }

    private fun shell(c: Context, cmd: String): String = try {
        val p = ProcessBuilder("sh", "-c", cmd).directory(cwd ?: c.filesDir).redirectErrorStream(true).start()
        val buf = StringBuilder()
        val rd = Thread { p.inputStream.bufferedReader().use { r -> var l = r.readLine(); while (l != null && buf.length < 6000) { buf.appendLine(l); l = r.readLine() } } }
        rd.start()
        if (!p.waitFor(15, TimeUnit.SECONDS)) { p.destroyForcibly(); buf.append("\n[timed out after 15s]") }
        rd.join(1000)
        buf.toString().trimEnd().ifEmpty { "(no output)" }
    } catch (e: Exception) {
        "error: ${e.message}"
    }
}
