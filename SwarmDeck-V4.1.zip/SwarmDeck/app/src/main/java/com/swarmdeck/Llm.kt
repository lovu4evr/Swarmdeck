package com.swarmdeck

import android.content.Context
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit

class CancelledException : RuntimeException("cancelled")
class LlmError(val code: Int, msg: String) : Exception(msg)
data class ChatMsg(val role: String, val content: String)
class Completion(val content: String, val toolCalls: JSONArray?)

/** One agent run. Cancelling it aborts in-flight HTTP calls and every loop that checks [check]. */
class Run(val id: Int) {
    @Volatile var cancelled = false
    @Volatile var trust = false          // user chose "allow safe actions for this run"
    @Volatile var thread: Thread? = null
    val calls: MutableSet<Call> = ConcurrentHashMap.newKeySet()

    fun cancel() {
        cancelled = true
        calls.forEach { try { it.cancel() } catch (_: Exception) {} }
        thread?.interrupt()
    }

    fun check() { if (cancelled) throw CancelledException() }
}

/** Real model routing: cheap model for planning/verifying, strong one for synthesis, with fallbacks. */
object ModelRouter {
    fun chain(c: Context, role: String): List<String> {
        val p = Store.p(c)
        val main = (p.getString("model", "auto") ?: "auto").ifBlank { "auto" }
        val special = when (role) {
            "head", "verify" -> p.getString("model_head", "")
            "synth" -> p.getString("model_synth", "")
            else -> ""
        } ?: ""
        val fb = (p.getString("model_fb", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
        return (listOf(special.trim().ifBlank { main }, main) + fb).distinct()
    }
}

object Llm {
    private val JSON_MT = "application/json".toMediaType()
    val http: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(20, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .build()

    private fun msg(role: String, content: String) = JSONObject().put("role", role).put("content", content)

    fun buildMessages(system: String, history: List<ChatMsg>, user: String): JSONArray {
        val a = JSONArray().put(msg("system", system))
        history.forEach { a.put(msg(it.role, it.content)) }
        return a.put(msg("user", user))
    }

    fun chat(c: Context, run: Run, role: String, system: String, user: String, history: List<ChatMsg> = emptyList()): String =
        complete(c, run, role, buildMessages(system, history, user), null).content

    private fun backoff(run: Run, n: Int) {
        try { Thread.sleep(1000L * n) } catch (_: InterruptedException) {}
        run.check()
    }

    /** Non-streaming completion with retry + backoff on 429/5xx/network errors and model fallback chain. */
    fun complete(c: Context, run: Run, role: String, msgs: JSONArray, tools: JSONArray?): Completion {
        var last: Exception = LlmError(0, "No model configured")
        for (model in ModelRouter.chain(c, role)) {
            var attempt = 0
            while (attempt < 3) {
                run.check()
                try {
                    return once(c, run, model, msgs, tools)
                } catch (e: CancelledException) {
                    throw e
                } catch (e: LlmError) {
                    last = e
                    if (e.code == 429 || e.code >= 500) { attempt++; backoff(run, attempt); continue }
                    if (e.code == 401 || e.code == 403 || e.code == 0) throw e
                    if (tools != null && (e.code == 400 || e.code == 422)) throw e
                    break
                } catch (e: IOException) {
                    run.check()
                    last = e
                    attempt++
                    backoff(run, attempt)
                }
            }
        }
        throw last
    }

    private fun request(c: Context, body: JSONObject): Request {
        val pr = Profiles.active(c)
        Parse.urlProblem(pr.url)?.let { throw LlmError(0, it) }
        return Request.Builder()
            .url(pr.url.trim().trimEnd('/') + "/chat/completions")
            .header("Authorization", "Bearer " + pr.key)
            .post(body.toString().toRequestBody(JSON_MT))
            .build()
    }

    private fun parse(t: String): Completion {
        val j = JSONObject(t)
        if (!j.has("choices")) throw LlmError(502, "Bad response: " + t.take(180))
        Stats.add(j.optJSONObject("usage"))
        val m = j.getJSONArray("choices").getJSONObject(0).getJSONObject("message")
        val content = if (m.isNull("content")) "" else m.optString("content", "")
        return Completion(content, m.optJSONArray("tool_calls"))
    }

    private fun once(c: Context, run: Run, model: String, msgs: JSONArray, tools: JSONArray?): Completion {
        val body = JSONObject().put("model", model).put("messages", msgs)
        if (tools != null && tools.length() > 0) body.put("tools", tools).put("tool_choice", "auto")
        val call = http.newCall(request(c, body))
        run.calls.add(call)
        try {
            return call.execute().use { r ->
                val t = r.body?.string() ?: ""
                if (!r.isSuccessful) throw LlmError(r.code, "HTTP ${r.code}: ${t.take(180)}")
                parse(t)
            }
        } finally {
            run.calls.remove(call)
        }
    }

    /** Streams tokens (SSE). Falls back to a normal completion if the endpoint can't stream. */
    fun stream(c: Context, run: Run, role: String, system: String, user: String, history: List<ChatMsg>, onDelta: (String) -> Unit): String {
        val msgs = buildMessages(system, history, user)
        val buf = StringBuilder()
        for (model in ModelRouter.chain(c, role)) {
            run.check()
            try {
                streamOnce(c, run, model, msgs) { d -> buf.append(d); onDelta(buf.toString()) }
                if (buf.isNotEmpty()) return buf.toString()
            } catch (e: CancelledException) {
                throw e
            } catch (e: LlmError) {
                if (e.code == 401 || e.code == 403 || e.code == 0) throw e
                if (buf.isNotEmpty()) return buf.toString()
            } catch (e: IOException) {
                run.check()
                if (buf.isNotEmpty()) return buf.toString()
            }
        }
        val full = complete(c, run, role, msgs, null).content
        onDelta(full)
        return full
    }

    private fun streamOnce(c: Context, run: Run, model: String, msgs: JSONArray, onDelta: (String) -> Unit) {
        val body = JSONObject().put("model", model).put("messages", msgs).put("stream", true)
        val call = http.newCall(request(c, body))
        run.calls.add(call)
        try {
            call.execute().use { r ->
                if (!r.isSuccessful) throw LlmError(r.code, "HTTP ${r.code}: ${(r.body?.string() ?: "").take(180)}")
                val src = r.body?.source() ?: return@use
                val ct = r.header("Content-Type") ?: ""
                if (!ct.contains("event-stream", true)) {
                    onDelta(parse(src.readUtf8()).content)
                    return@use
                }
                while (true) {
                    run.check()
                    val line = src.readUtf8Line() ?: break
                    if (!line.startsWith("data:")) continue
                    val d = line.removePrefix("data:").trim()
                    if (d == "[DONE]") break
                    if (d.isEmpty()) continue
                    try {
                        val ch = JSONObject(d).optJSONArray("choices")
                        if (ch != null && ch.length() > 0) {
                            val delta = ch.getJSONObject(0).optJSONObject("delta")
                            val txt = if (delta == null || delta.isNull("content")) "" else delta.optString("content", "")
                            if (txt.isNotEmpty()) onDelta(txt)
                        }
                    } catch (_: org.json.JSONException) {
                    }
                }
            }
        } finally {
            run.calls.remove(call)
        }
        Stats.add(null)
    }
}
