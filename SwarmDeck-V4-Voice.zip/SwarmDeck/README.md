# SwarmDeck V4.0 — Autonomous God Mode Agent

## V4 Features Implemented

0. **Continuous Voice Mode (best-effort)**  
   Mic button toggles continuous listening. Agent speaks status + final answers via TTS. Push-to-talk still available.

1. **Autonomous Mission System**  
   Toggle "🎯 Mission" → give one objective → AI plans steps and works through them.

2. **Dynamic Agent Creation**  
   Head Agent can spawn temporary specialist agents for unique tasks.

3. **Infinite Memory**  
   Local searchable memory. Important conclusions auto-saved. Searchable by keyword.

4. **Multi-Model Intelligence**  
   Structure ready for task-based model routing (configure models in Settings).

5. **Live Thinking Stream**  
   Real-time visibility into what the agent is thinking and which sub-agents are active.

6. **Phone Control** (permission-based)  
   Operator agent can OPEN / TAP / TYPE / SCROLL with Accessibility Service.

7. **Browser + Artist agents**  
   Ready for web research prompts and detailed image generation prompts.

8. **Workflow foundation**  
   Mission steps + memory + dynamic agents form the base for reusable workflows.

## Privacy
- All memory and chat stored locally on device
- API calls only to the endpoint **you** configure
- No silent data exfiltration

## Setup
1. Set your OpenAI-compatible URL + key in Settings
2. Enable Phone Control service if you want Operator actions
3. Use Mission mode for multi-step goals

---
SwarmDeck V4.0 • Missions. Memory. Dynamic Agents. Your rules.
