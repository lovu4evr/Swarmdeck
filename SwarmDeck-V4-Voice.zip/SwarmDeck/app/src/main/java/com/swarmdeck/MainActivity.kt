package com.swarmdeck
import android.Manifest
import android.app.Activity
import android.content.*
import android.os.*
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

// ── GOD-LIKE LIQUID GLASS THEME ──
// Deep celestial blue + warm cream + true liquid glass
val BG1 = Color(0xFF050B1A)          // Deep midnight navy
val BG2 = Color(0xFF0A162F)          // Slightly lifted navy
val EDGE = Color(0x55E8E4D9)         // Soft cream edge for glass
val ACC  = Color(0xFF3B82F6)         // Pure royal blue
val ACC2 = Color(0xFF60A5FA)         // Bright sky blue
val CREAM = Color(0xFFF5F0E6)        // Warm cream / ivory
val GOLD = Color(0xFFE8D5A3)         // Soft champagne gold
val COLORS = listOf(
  Color(0xFF3B82F6), // Planner - royal blue
  Color(0xFF60A5FA), // Researcher
  Color(0xFF93C5FD), // Creator
  Color(0xFF2563EB), // Coder
  Color(0xFF38BDF8), // Designer
  Color(0xFF818CF8), // Critic
  Color(0xFFF5F0E6), // Synthesizer - cream
  Color(0xFFE8D5A3)  // Operator - champagne
)
val SHAPE = RoundedCornerShape(24.dp)

// Liquid Glass modifier — multi-layer frosted glass with cream glow
fun Modifier.glass(shape: Shape = SHAPE): Modifier = this
  .clip(shape)
  .background(
    Brush.linearGradient(
      listOf(
        Color(0x28F5F0E6),   // soft cream top
        Color(0x18FFFFFF),
        Color(0x12A5C8FF)    // faint blue bottom
      )
    ),
    shape
  )
  .border(1.1.dp, EDGE, shape)

fun nameOf(id: String) = AGENTS.firstOrNull { it.id == id }?.name ?: id
fun colorOf(id: String) = COLORS[AGENTS.indexOfFirst { it.id == id }.coerceAtLeast(0) % COLORS.size]

@Composable
fun clearColors() = TextFieldDefaults.colors(
  focusedContainerColor = Color.Transparent,
  unfocusedContainerColor = Color.Transparent,
  focusedIndicatorColor = Color.Transparent,
  unfocusedIndicatorColor = Color.Transparent,
  focusedTextColor = CREAM,
  unfocusedTextColor = CREAM,
  cursorColor = ACC2
)

class MainActivity:ComponentActivity(){
 override fun onCreate(s:Bundle?){ super.onCreate(s)
  if(Bus.turns.isEmpty())Bus.turns.addAll(Hist.load(this))
  setContent{ MaterialTheme(colorScheme=darkColorScheme(primary=ACC,background=BG1,surface=BG2)){ App(this) } } }
}

@Composable fun Backdrop(content:@Composable BoxScope.()->Unit){
 Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BG1, BG2, Color(0xFF071022))))){
  // Soft celestial blue orbs
  Box(Modifier.offset((-100).dp,(-60).dp).size(480.dp).background(Brush.radialGradient(listOf(Color(0x443B82F6), Color.Transparent))))
  Box(Modifier.align(Alignment.BottomEnd).offset(100.dp,80.dp).size(420.dp).background(Brush.radialGradient(listOf(Color(0x3360A5FA), Color.Transparent))))
  // Subtle cream glow near center
  Box(Modifier.align(Alignment.Center).size(300.dp).background(Brush.radialGradient(listOf(Color(0x12F5F0E6), Color.Transparent))))
  content()
 }
}

@Composable fun App(act:Activity){
 var signed by remember{mutableStateOf(Store.p(act).getString("email","")!!.isNotEmpty())}
 val notif=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
 val micPerm=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
 LaunchedEffect(Unit){
   if(Build.VERSION.SDK_INT>=33)notif.launch(Manifest.permission.POST_NOTIFICATIONS)
   micPerm.launch(Manifest.permission.RECORD_AUDIO)
   Voice.init(act)
 }
 Backdrop{ if(!signed)Login(act){signed=true} else Main(act){signed=false} }
}

@Composable fun Login(act:Activity,done:()->Unit){
 val scope=rememberCoroutineScope(); var err by remember{mutableStateOf("")}
 Box(Modifier.fillMaxSize().padding(28.dp),Alignment.Center){
  Column(Modifier.glass().padding(32.dp),horizontalAlignment=Alignment.CenterHorizontally){
   Icon(Icons.Default.Hub,null,tint=ACC2,modifier=Modifier.size(72.dp))
   Spacer(Modifier.height(12.dp))
   Text("SWARMDECK",fontSize=32.sp,fontWeight=FontWeight.Bold,color=CREAM,letterSpacing=2.sp)
   Text("V4.0  ·  Autonomous Agent",fontSize=14.sp,color=ACC2,fontWeight=FontWeight.Medium)
   Spacer(Modifier.height(6.dp))
   Text("Missions · Memory · Continuous Voice · Dynamic Agents",color=Color(0xFFB8B0A0),textAlign=TextAlign.Center,fontSize=13.sp)
   Spacer(Modifier.height(28.dp))
   Button(
     {scope.launch{try{Auth.signIn(act);done()}catch(e:Exception){err=e.message?:"Sign-in failed"}}},
     Modifier.fillMaxWidth().height(54.dp),
     colors=ButtonDefaults.buttonColors(containerColor=ACC, contentColor=CREAM),
     shape=RoundedCornerShape(16.dp)
   ){ Text("Continue with Google",fontWeight=FontWeight.SemiBold) }
   if(err.isNotEmpty())Text(err,color=Color(0xFFFF8A8A),modifier=Modifier.padding(top=14.dp),textAlign=TextAlign.Center)
  }
 }
}

@Composable fun Main(act:Activity,out:()->Unit){
 var tab by remember{mutableIntStateOf(0)}
 Scaffold(containerColor=Color.Transparent,bottomBar={ Box(Modifier.padding(12.dp).glass(RoundedCornerShape(28.dp))){ NavigationBar(containerColor=Color.Transparent){
  listOf("Chat" to Icons.Default.Chat,"Agents" to Icons.Default.Groups,"Terminal" to Icons.Default.Terminal,"Settings" to Icons.Default.Settings).forEachIndexed{i,(n,ic)->
   NavigationBarItem(tab==i,{tab=i},{Icon(ic,n)},label={Text(n,fontSize=11.sp)}) } } } }){p->
  Box(Modifier.padding(p).fillMaxSize()){ when(tab){0->ChatTab(act);1->AgentsTab(act);2->TermTab(act);else->SettingsTab(act,out)} }
 }
}

@Composable fun ChatTab(c:Context){
 var input by remember{mutableStateOf("")}
 var mode by remember{mutableStateOf(Store.p(c).getString("mode","auto")!!)}
 val ls=rememberLazyListState()
 val mic=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
  r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{input=if(input.isBlank())it else "$input $it"} }
 LaunchedEffect(Bus.turns.size,Bus.status){ val n=ls.layoutInfo.totalItemsCount; if(n>0)ls.animateScrollToItem(n-1) }
 fun send(){
  val q=input.trim(); if(q.isEmpty()||Bus.running)return
  input=""; Bus.turns.add(Turn(true,q)); Hist.save(c,Bus.turns); Bus.running=true; Bus.status="Starting…"
  ContextCompat.startForegroundService(c,Intent(c,AgentService::class.java).putExtra("goal",q))
 }
 Column(Modifier.fillMaxSize().padding(horizontal=14.dp)){
  Row(Modifier.fillMaxWidth().padding(top=10.dp),verticalAlignment=Alignment.CenterVertically){
   Text("SwarmDeck 4.0",Modifier.weight(1f),color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
   IconButton({if(!Bus.running){Bus.turns.clear();Hist.save(c,Bus.turns)}}){Icon(Icons.Default.Add,"New chat",tint=ACC2)}
  }
  Row(Modifier.padding(vertical=6.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   listOf("auto" to "🧠 Auto","fast" to "⚡ Fast","all" to "🌐 All","mission" to "🎯 Mission").forEach{(m,l)->
    FilterChip(mode==m,{mode=m;Store.p(c).edit().putString("mode",m).apply();Bus.missionMode=(m=="mission")},{Text(l)}) }
  }
  LazyColumn(Modifier.weight(1f),state=ls){
   if(Bus.turns.isEmpty())item{ Column(Modifier.padding(vertical=24.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){
    Text("Ask anything.",color=Color.White,fontSize=26.sp,fontWeight=FontWeight.Bold)
    Text("The Head Agent picks the right experts, they answer in parallel, and the Ultimate Agent delivers the best answer.",color=Color.LightGray)
    listOf("Write a viral reel script about AI","Explain blockchain simply","Plan my study week").forEach{s->OutlinedButton({input=s},Modifier.fillMaxWidth()){Text(s)}} } }
   items(Bus.turns){t->Bubble(c,t)}
   if(Bus.running)item{
    Column(Modifier.fillMaxWidth().padding(vertical=8.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp)){
      Row(verticalAlignment=Alignment.CenterVertically){
        CircularProgressIndicator(Modifier.size(16.dp),strokeWidth=2.dp,color=ACC2)
        Spacer(Modifier.width(10.dp))
        Text(Bus.status.ifEmpty{"Thinking…"},color=CREAM,fontSize=13.sp,fontWeight=FontWeight.Medium)
      }
      if(Bus.subAgents.isNotEmpty()){
        Spacer(Modifier.height(6.dp))
        Text("Sub-agents: "+Bus.subAgents.joinToString(" · "),color=ACC2,fontSize=11.sp)
      }
      if(Bus.thinking.isNotEmpty()){
        Spacer(Modifier.height(8.dp))
        Bus.thinking.takeLast(6).forEach{ line ->
          Text("› $line",color=Color(0xFFB8B0A0),fontSize=11.sp)
        }
      }
    }
  }
  }
  Row(Modifier.fillMaxWidth().padding(vertical=10.dp).glass(RoundedCornerShape(28.dp)),verticalAlignment=Alignment.CenterVertically){
   TextField(input,{input=it},Modifier.weight(1f),placeholder={Text("Message SwarmDeck…")},maxLines=4,colors=clearColors(),
    keyboardOptions=KeyboardOptions(imeAction=ImeAction.Send),keyboardActions=KeyboardActions(onSend={send()}))
   IconButton({
     Voice.init(c)
     if(Voice.continuous){
       Voice.stopListening()
       Toast.makeText(c,"Continuous voice OFF",Toast.LENGTH_SHORT).show()
     } else {
       Voice.continuous = true
       Voice.startListening(c as Activity,
         onText = { spoken ->
           input = spoken
           // auto-send when continuous
           if(spoken.isNotBlank() && !Bus.running){
             // trigger send via state
             input = spoken
           }
         },
         onPart = { part -> input = part }
       )
       Toast.makeText(c,"Continuous voice ON — speak now",Toast.LENGTH_SHORT).show()
       Voice.speak("Listening")
     }
   }){Icon(if(Voice.continuous) Icons.Default.Mic else Icons.Default.Mic, "Voice", tint=if(Voice.continuous) Color(0xFF34D399) else ACC2)}
   IconButton({try{mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))}catch(e:Exception){Toast.makeText(c,"Voice input isn't available",Toast.LENGTH_SHORT).show()}}){Icon(Icons.Default.Mic,"Push to talk",tint=ACC2)}
   if(Bus.running)IconButton({Brain.stop=true;c.stopService(Intent(c,AgentService::class.java));Bus.running=false;Bus.status=""}){Icon(Icons.Default.Stop,"Stop",tint=Color(0xFFFF6B6B))}
   else IconButton({send()}){Icon(Icons.Default.Send,"Send",tint=ACC)}
  }
 }
}

@Composable fun Bubble(c:Context,t:Turn){
 var open by remember{mutableStateOf(false)}
 val sh=if(t.user)RoundedCornerShape(22.dp,22.dp,6.dp,22.dp) else RoundedCornerShape(22.dp,22.dp,22.dp,6.dp)
 Row(Modifier.fillMaxWidth().padding(vertical=6.dp),horizontalArrangement=if(t.user)Arrangement.End else Arrangement.Start){
  Column(Modifier.widthIn(max=330.dp).glass(sh).background(if(t.user)ACC.copy(alpha=0.35f) else Color.Transparent,sh).padding(14.dp)){
   if(!t.user){
    Row(verticalAlignment=Alignment.CenterVertically){
     Icon(Icons.Default.AutoAwesome,null,tint=ACC2,modifier=Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
     Text("Ultimate Agent",color=ACC2,fontSize=12.sp,fontWeight=FontWeight.Bold)
     if(t.winner.isNotEmpty()){Spacer(Modifier.width(8.dp));Text("⭐ ${nameOf(t.winner)}",color=GOLD,fontSize=12.sp)} }
    Spacer(Modifier.height(6.dp))
   }
   SelectionContainer{Text(t.text,color=Color.White,fontSize=15.sp)}
   if(!t.user){
    Row{
     TextButton({(c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("answer",t.text));Toast.makeText(c,"Copied",Toast.LENGTH_SHORT).show()}){Text("Copy")}
     TextButton({c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT,t.text),"Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))}){Text("Share")}
     if(t.answers.size>1)TextButton({open=!open}){Text("Agents (${t.answers.size})")}
    }
    if(open)t.answers.forEach{(id,s,n)->
     HorizontalDivider(color=EDGE,modifier=Modifier.padding(vertical=6.dp))
     Text(nameOf(id)+(if(n>0)"  ·  $n/10" else ""),color=colorOf(id),fontSize=12.sp,fontWeight=FontWeight.Bold)
     Text(s,color=Color(0xFFCBD5E1),fontSize=13.sp) }
   }
  }
 }
}

@Composable fun AgentsTab(c:Context){
 LazyColumn(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){
  item{Text("Agents",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold);Text("The Head Agent only picks from agents that are ON.",color=Color.LightGray,fontSize=13.sp)}
  items(AGENTS){a->
   var on by remember{mutableStateOf(!Store.p(c).getBoolean("off_${a.id}",false))}
   Row(Modifier.fillMaxWidth().glass().padding(16.dp),verticalAlignment=Alignment.CenterVertically){
    Box(Modifier.size(10.dp).clip(RoundedCornerShape(5.dp)).background(colorOf(a.id))); Spacer(Modifier.width(12.dp))
    Column(Modifier.weight(1f)){Text(a.name,color=Color.White,fontWeight=FontWeight.Bold);Text(a.role,color=Color.LightGray,fontSize=13.sp)}
    Switch(on,{on=it;Store.p(c).edit().putBoolean("off_${a.id}",!it).apply()}) } }
 }
}

@Composable fun TermTab(c:Context){
 var cmd by remember{mutableStateOf("")}
 val ls=rememberLazyListState()
 LaunchedEffect(Term.lines.size){ if(Term.lines.isNotEmpty())ls.animateScrollToItem(Term.lines.size-1) }
 Column(Modifier.fillMaxSize().padding(14.dp)){
  Text("Terminal",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
  LazyColumn(Modifier.weight(1f).fillMaxWidth().padding(vertical=10.dp).glass().padding(12.dp),state=ls){
   items(Term.lines){l->Text(l,color=if(l.startsWith("$ "))ACC2 else Color(0xFFE2E8F0),fontFamily=FontFamily.Monospace,fontSize=12.sp)} }
  Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(28.dp)),verticalAlignment=Alignment.CenterVertically){
   TextField(cmd,{cmd=it},Modifier.weight(1f),singleLine=true,placeholder={Text("ls · status · ask <question>")},colors=clearColors(),textStyle=androidx.compose.ui.text.TextStyle(fontFamily=FontFamily.Monospace),
    keyboardOptions=KeyboardOptions(imeAction=ImeAction.Send),keyboardActions=KeyboardActions(onSend={Term.exec(c,cmd);cmd=""}))
   IconButton({Term.exec(c,cmd);cmd=""}){Icon(Icons.Default.Send,"Run",tint=ACC)}
  }
 }
}

@Composable fun SettingsTab(c:Context,out:()->Unit){
 val p=Store.p(c); val scope=rememberCoroutineScope()
 var url by remember{mutableStateOf(p.getString("url","")!!)}
 var key by remember{mutableStateOf(p.getString("key","")!!)}
 var model by remember{mutableStateOf(p.getString("model","auto")!!)}
 var phone by remember{mutableStateOf(p.getBoolean("phone",false))}
 var status by remember{mutableStateOf("")}
 Column(Modifier.padding(14.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text("Settings",color=Color.White,fontSize=22.sp,fontWeight=FontWeight.Bold)
  Text("Signed in as ${p.getString("email","")}",color=Color.LightGray)
  OutlinedTextField(url,{url=it},Modifier.fillMaxWidth(),label={Text("FREELLMAPI base URL (ends in /v1)")},singleLine=true)
  OutlinedTextField(key,{key=it},Modifier.fillMaxWidth(),label={Text("API key")},singleLine=true,visualTransformation=PasswordVisualTransformation())
  OutlinedTextField(model,{model=it},Modifier.fillMaxWidth(),label={Text("Model")},singleLine=true)
  Button({p.edit().putString("url",url).putString("key",key).putString("model",model).apply();status="Testing…"
   scope.launch(Dispatchers.IO){status=try{"✓ "+Llm.chat(c,"Reply with OK","ping").take(40)}catch(e:Exception){"✗ ${e.message}"}}},Modifier.fillMaxWidth()){Text("Save & test connection")}
  Text(status,color=Color.LightGray)
  Row(verticalAlignment=Alignment.CenterVertically){Text("Let Operator control my phone",Modifier.weight(1f),color=Color.White);Switch(phone,{phone=it;p.edit().putBoolean("phone",it).apply()})}
  OutlinedButton({c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))},Modifier.fillMaxWidth()){Text("Enable phone-control service")}
  OutlinedButton({Bus.turns.clear();Hist.save(c,Bus.turns)},Modifier.fillMaxWidth()){Text("Clear chat history")}
  TextButton({p.edit().remove("email").apply();out()}){Text("Sign out")}
  Text("SwarmDeck 4.0",color=Color.Gray,fontSize=12.sp)
 }
}
