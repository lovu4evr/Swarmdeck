package com.swarmdeck
import android.content.Context
import android.os.*
import androidx.compose.runtime.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.util.concurrent.*
import java.util.UUID

const val SUF = " Be direct and useful. Reply in the same language as the user. Never invent personal data about the user. Respect privacy."

data class Agent(val id: String, val name: String, val role: String, val prompt: String, val dynamic: Boolean = false)

// Base permanent agents
val BASE_AGENTS = listOf(
  Agent("planner", "Planner", "Plans & step-by-step approaches", "You are Planner. Break the task into clear numbered steps."),
  Agent("researcher", "Researcher", "Facts, context & caveats", "You are Researcher. Give key facts, context and what is uncertain."),
  Agent("creator", "Creator", "Ideas, scripts & creative content", "You are Creator. Produce original, vivid ideas or content."),
  Agent("coder", "Coder", "Code & technical problems", "You are Coder. Give minimal correct code and short notes."),
  Agent("designer", "Designer", "Visual, UX & style direction", "You are Designer. Give visual and UX direction."),
  Agent("critic", "Critic", "Risks, flaws & what to avoid", "You are Critic. Point out risks and better alternatives."),
  Agent("synthesizer", "Synthesizer", "Balanced final answers", "You are Synthesizer. Produce a balanced, complete answer."),
  Agent("operator", "Operator", "Controls the phone", "You are Operator. For phone actions output lines starting with ACTION: then OPEN <app> | TAP <text> | TYPE <text> | BACK | HOME | SCROLL. If not a phone task reply NONE."),
  Agent("browser", "Browser", "Web research & browsing", "You are Browser. Describe exact search queries or URLs and what to extract. Prepare actions for user approval."),
  Agent("artist", "Artist", "Image generation prompts", "You are Artist. Write a highly detailed image generation prompt when the user wants an image."),
  Agent("mission", "Mission", "Autonomous multi-step goals", "You are Mission Controller. Break the objective into clear sequential steps. Mark each step as PENDING, RUNNING, DONE or BLOCKED.")
)

// Runtime list (base + dynamic)
var AGENTS = BASE_AGENTS.toMutableList()

data class Turn(
  val user: Boolean,
  val text: String,
  val winner: String = "",
  val answers: List<Triple<String, String, Int>> = emptyList(),
  val thinking: List<String> = emptyList(),
  val missionSteps: List<String> = emptyList()
)

data class MemoryItem(val id: String, val key: String, val value: String, val tags: String, val ts: Long)

object Store {
  fun p(c: Context) = c.getSharedPreferences("swarm", Context.MODE_PRIVATE)
}

object Hist {
  fun save(c: Context, l: List<Turn>) {
    val a = JSONArray()
    l.takeLast(100).forEach { t ->
      val x = JSONArray()
      t.answers.forEach { (i, s, n) -> x.put(JSONObject().put("i", i).put("s", s).put("n", n)) }
      a.put(JSONObject().put("u", t.user).put("t", t.text).put("w", t.winner).put("a", x))
    }
    Store.p(c).edit().putString("chat", a.toString()).apply()
  }
  fun load(c: Context): List<Turn> = try {
    val a = JSONArray(Store.p(c).getString("chat", "[]"))
    (0 until a.length()).map {
      val o = a.getJSONObject(it)
      val x = o.getJSONArray("a")
      Turn(o.getBoolean("u"), o.getString("t"), o.getString("w"),
        (0 until x.length()).map { j ->
          val q = x.getJSONObject(j)
          Triple(q.getString("i"), q.getString("s"), q.getInt("n"))
        })
    }
  } catch (e: Exception) { emptyList() }
}

// ── Infinite Memory (local, searchable) ──
object Memory {
  fun all(c: Context): List<MemoryItem> = try {
    val a = JSONArray(Store.p(c).getString("memory", "[]"))
    (0 until a.length()).map {
      val o = a.getJSONObject(it)
      MemoryItem(o.getString("id"), o.getString("key"), o.getString("value"),
        o.optString("tags", ""), o.optLong("ts", 0))
    }
  } catch (e: Exception) { emptyList() }

  fun save(c: Context, key: String, value: String, tags: String = "") {
    val list = all(c).toMutableList()
    val id = UUID.randomUUID().toString().take(8)
    list.add(0, MemoryItem(id, key, value, tags, System.currentTimeMillis()))
    val a = JSONArray()
    list.take(200).forEach {
      a.put(JSONObject().put("id", it.id).put("key", it.key).put("value", it.value)
        .put("tags", it.tags).put("ts", it.ts))
    }
    Store.p(c).edit().putString("memory", a.toString()).apply()
  }

  fun search(c: Context, q: String): List<MemoryItem> {
    val query = q.lowercase()
    return all(c).filter {
      it.key.lowercase().contains(query) ||
      it.value.lowercase().contains(query) ||
      it.tags.lowercase().contains(query)
    }.take(12)
  }

  fun delete(c: Context, id: String) {
    val list = all(c).filter { it.id != id }
    val a = JSONArray()
    list.forEach {
      a.put(JSONObject().put("id", it.id).put("key", it.key).put("value", it.value)
        .put("tags", it.tags).put("ts", it.ts))
    }
    Store.p(c).edit().putString("memory", a.toString()).apply()
  }
}

object Bus {
  val turns = mutableStateListOf<Turn>()
  var running by mutableStateOf(false)
  var status by mutableStateOf("")
  val thinking = mutableStateListOf<String>()
  var subAgents by mutableStateOf<List<String>>(emptyList())
  var missionMode by mutableStateOf(false)
  var missionSteps by mutableStateOf<List<String>>(emptyList())
  private val h = Handler(Looper.getMainLooper())
  fun ui(f: () -> Unit) { h.post { f() } }
  fun add(c: Context, t: Turn) { ui { turns.add(t); Hist.save(c, turns) } }
  fun think(msg: String) { ui { thinking.add(msg); if (thinking.size > 50) thinking.removeAt(0) } }
  fun clearThinking() { ui { thinking.clear(); subAgents = emptyList() } }
}

object Llm {
  private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()

  fun chat(c: Context, system: String, user: String, modelOverride: String? = null): String {
    val p = Store.p(c)
    val base = p.getString("url", "")!!.trim().trimEnd('/')
    if (base.isEmpty()) error("Set API base URL in Settings")
    val model = modelOverride ?: p.getString("model", "auto")!!
    val msgs = JSONArray()
      .put(JSONObject().put("role", "system").put("content", system))
      .put(JSONObject().put("role", "user").put("content", user))
    val body = JSONObject().put("model", model).put("messages", msgs)
    val req = Request.Builder()
      .url("$base/chat/completions")
      .header("Authorization", "Bearer " + p.getString("key", ""))
      .post(body.toString().toRequestBody("application/json".toMediaType()))
      .build()
    return http.newCall(req).execute().use { r ->
      val t = r.body?.string() ?: ""
      if (!r.isSuccessful) error("HTTP ${r.code}: ${t.take(180)}")
      JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
  }
}

// ── Multi-Model Intelligence (simple routing) ──
object ModelRouter {
  fun pick(task: String, preferred: String?): String? {
    if (!preferred.isNullOrBlank() && preferred != "auto") return preferred
    val t = task.lowercase()
    return when {
      t.contains("code") || t.contains("bug") || t.contains("function") -> null // use default / strong model
      t.contains("creative") || t.contains("story") || t.contains("write") -> null
      t.contains("quick") || t.contains("simple") -> null
      else -> null
    }
  }
}

// ── Dynamic Agent Creation ──
object DynamicAgents {
  fun create(c: Context, name: String, role: String, prompt: String): Agent {
    val id = "dyn_" + name.lowercase().replace(" ", "_").take(12)
    val agent = Agent(id, name, role, prompt, dynamic = true)
    if (AGENTS.none { it.id == id }) {
      AGENTS.add(agent)
      Bus.think("Created dynamic agent: $name")
    }
    return agent
  }

  fun reset() {
    AGENTS = BASE_AGENTS.toMutableList()
  }
}

object Brain {
  @Volatile var stop = false
  private val pool = Executors.newFixedThreadPool(6)

  fun run(c: Context, q: String, hist: List<Turn>, status: (String) -> Unit): Turn {
    stop = false
    Bus.clearThinking()
    val p = Store.p(c)
    val mode = p.getString("mode", "auto")!!
    val isMission = Bus.missionMode || q.lowercase().startsWith("mission:") || q.lowercase().startsWith("goal:")

    // Inject relevant memory
    val memHits = Memory.search(c, q.take(80))
    val memCtx = if (memHits.isNotEmpty()) {
      Bus.think("Recalled ${memHits.size} memories")
      "\n\nRelevant memories:\n" + memHits.joinToString("\n") { "- ${it.key}: ${it.value.take(200)}" }
    } else ""

    val enabled = AGENTS.filter { !p.getBoolean("off_${it.id}", false) }
    if (enabled.isEmpty()) return Turn(false, "All agents are off.")

    val ctx = hist.takeLast(8).joinToString("\n") {
      (if (it.user) "User: " else "Assistant: ") + it.text.take(700)
    }
    val prompt = (if (ctx.isEmpty()) "" else "Conversation so far:\n$ctx\n") + memCtx + "\nUser: $q"

    Bus.think("Analyzing request…")
    status("Thinking…")

    // Dynamic agent creation if needed
    if (mode != "fast" && (q.length > 40 || isMission)) {
      try {
        val need = Llm.chat(c,
          "You are Head Agent. If this task needs a specialist that does not exist in the current roster, reply with exactly:\nNEW_AGENT: Name | Role | Short system prompt\nOtherwise reply: NONE\nRoster: ${enabled.joinToString { it.name }}",
          q)
        if (need.contains("NEW_AGENT:")) {
          val part = need.substringAfter("NEW_AGENT:").trim().lines().first()
          val bits = part.split("|").map { it.trim() }
          if (bits.size >= 3) {
            val na = DynamicAgents.create(c, bits[0], bits[1], bits[2])
            Bus.think("Spawned specialist: ${na.name}")
          }
        }
      } catch (_: Exception) {}
    }

    val currentEnabled = AGENTS.filter { !p.getBoolean("off_${it.id}", false) }

    val picked: List<Agent> = if (mode == "all") {
      Bus.think("Mode: ALL agents")
      currentEnabled
    } else {
      Bus.think("Selecting specialists…")
      val max = if (mode == "fast") 2 else if (isMission) 6 else 5
      val roster = currentEnabled.joinToString("\n") { "${it.id}: ${it.role}" }
      val out = try {
        Llm.chat(c,
          "You are Head Agent of SwarmDeck V4. Choose best agents. Reply one line: AGENTS: id1, id2 (max $max). Use mission for multi-step goals, operator for phone, browser for web, artist for images.\nAgents:\n$roster",
          prompt)
      } catch (e: Exception) { "" }
      val line = out.lines().firstOrNull { it.contains("AGENTS", true) } ?: out
      val selected = currentEnabled.filter { Regex("\\b${it.id}\\b").containsMatchIn(line) }.take(max)
        .ifEmpty { currentEnabled.filter { it.id in listOf("synthesizer", "planner", "creator") }.take(max) }
      Bus.think("Selected: " + selected.joinToString { it.name })
      Bus.ui { Bus.subAgents = selected.map { it.name } }
      selected
    }

    // Mission planning
    var steps = emptyList<String>()
    if (isMission) {
      Bus.think("Building mission plan…")
      status("Planning mission…")
      try {
        val plan = Llm.chat(c,
          "You are Mission Controller. Break the objective into 4-8 clear sequential steps. Reply with numbered list only.",
          q)
        steps = plan.lines().filter { it.trim().matches(Regex("^\\d+[.).].*")) }.map { it.trim() }
        Bus.ui { Bus.missionSteps = steps }
        Bus.think("Mission has ${steps.size} steps")
      } catch (_: Exception) {}
    }

    status("Deploying: " + picked.joinToString { it.name })
    Bus.think("Deploying ${picked.size} agents…")

    val futures = picked.map { a ->
      a to pool.submit(Callable<String> {
        try {
          Bus.think("${a.name} working…")
          Llm.chat(c, a.prompt + SUF, prompt)
        } catch (e: Exception) { "ERR:" + (e.message ?: "failed") }
      })
    }

    val answers = futures.map { (a, f) ->
      a.id to try { f.get(150, TimeUnit.SECONDS) } catch (e: Exception) { "ERR:timeout" }
    }
    val ok = answers.filter { !it.second.startsWith("ERR:") }
    val good = ok.filter { !it.second.trim().equals("NONE", true) }.ifEmpty { ok }
    if (good.isEmpty()) return Turn(false, "Error: " + answers.first().second.removePrefix("ERR:"))

    var winner = good[0].first
    var text = good[0].second
    var ans = good.map { Triple(it.first, it.second, 0) }
    val thinkLog = Bus.thinking.toList()

    if (good.size > 1) {
      Bus.think("Synthesizing final answer…")
      status("Synthesizing…")
      val block = good.joinToString("\n\n") { "[${it.first}]\n${it.second}" }
      val out = try {
        Llm.chat(c,
          "You are Ultimate Agent. Score each 1-10, then write the single best final answer. Never mention agents inside FINAL. Same language as user.\nFormat:\nSCORES: id=score\nWINNER: id\nFINAL:\n<answer>",
          prompt + "\n\nAnswers:\n" + block)
      } catch (e: Exception) { "" }
      val w = Regex("WINNER:\\s*([\\w]+)").find(out)?.groupValues?.get(1)
      if (w != null && good.any { it.first == w }) winner = w
      val fi = out.indexOf("FINAL:")
      text = if (fi >= 0 && out.length > fi + 6) out.substring(fi + 6).trim()
             else good.first { it.first == winner }.second
      val sc = Regex("([\\w]+)\\s*=\\s*(\\d+)").findAll(out.substringBefore("WINNER"))
        .associate { it.groupValues[1] to it.groupValues[2].toInt() }
      ans = good.map { Triple(it.first, it.second, sc[it.first] ?: 0) }
      Bus.think("Winner: $winner")
    }

    // Auto-save important conclusions to memory
    if (text.length > 80 && !text.startsWith("Error")) {
      try {
        Memory.save(c, "Conclusion: ${q.take(40)}", text.take(400), "auto")
        Bus.think("Saved to Infinite Memory")
      } catch (_: Exception) {}
    }

    // Phone actions
    if (p.getBoolean("phone", false)) {
      val acts = good.firstOrNull { it.first == "operator" }?.second
        ?.lines()?.filter { it.trim().startsWith("ACTION:") }.orEmpty()
      if (acts.isNotEmpty()) {
        val res = ArrayList<String>()
        for (l in acts) {
          if (stop) break
          val cmd = l.substringAfter("ACTION:").trim()
          Bus.think("Phone: $cmd")
          status("Phone: $cmd")
          res.add(PhoneControl.run(cmd))
          Thread.sleep(1400)
        }
        text += "\n\n📱 " + res.joinToString(" · ")
      }
    }

    Bus.think("Done.")
    return Turn(false, text, winner, ans, thinkLog, steps)
  }
}
