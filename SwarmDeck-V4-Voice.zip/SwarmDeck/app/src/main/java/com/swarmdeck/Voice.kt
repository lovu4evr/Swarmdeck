package com.swarmdeck

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.widget.Toast
import java.util.Locale

/**
 * Best-effort Continuous Voice Mode for SwarmDeck V4.
 * - Push-to-talk + continuous session
 * - Speaks status and final answers
 * - Stops cleanly when user disables or leaves
 */
object Voice {
  private var tts: TextToSpeech? = null
  private var recognizer: SpeechRecognizer? = null
  @Volatile var continuous = false
  @Volatile var listening = false
  private var onResult: ((String) -> Unit)? = null
  private var onPartial: ((String) -> Unit)? = null

  fun init(ctx: Context) {
    if (tts == null) {
      tts = TextToSpeech(ctx.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          tts?.language = Locale.getDefault()
          tts?.setSpeechRate(1.0f)
        }
      }
    }
  }

  fun speak(text: String, flush: Boolean = true) {
    val s = text.take(400).trim()
    if (s.isEmpty()) return
    tts?.speak(s, if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "swarm")
  }

  fun stopSpeaking() {
    tts?.stop()
  }

  fun startListening(activity: Activity, onText: (String) -> Unit, onPart: ((String) -> Unit)? = null) {
    if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
      Toast.makeText(activity, "Speech recognition not available", Toast.LENGTH_SHORT).show()
      return
    }
    onResult = onText
    onPartial = onPart
    destroyRecognizer()
    recognizer = SpeechRecognizer.createSpeechRecognizer(activity).apply {
      setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
          listening = true
          Bus.ui { Bus.status = "Listening…" }
        }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {
          listening = false
        }
        override fun onError(error: Int) {
          listening = false
          // Restart if continuous mode is on (ignore common non-fatal errors)
          if (continuous && error != SpeechRecognizer.ERROR_CLIENT) {
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
              if (continuous) restart(activity)
            }, 600)
          }
        }
        override fun onResults(results: Bundle?) {
          listening = false
          val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
          if (!text.isNullOrEmpty()) {
            onResult?.invoke(text)
          }
          if (continuous) {
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
              if (continuous && !Bus.running) restart(activity)
            }, 500)
          }
        }
        override fun onPartialResults(partialResults: Bundle?) {
          val part = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
          if (!part.isNullOrEmpty()) onPartial?.invoke(part)
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
      })
    }
    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
    }
    try {
      recognizer?.startListening(intent)
    } catch (e: Exception) {
      Toast.makeText(activity, "Mic error: ${e.message}", Toast.LENGTH_SHORT).show()
    }
  }

  private fun restart(activity: Activity) {
    if (!continuous) return
    startListening(activity, onResult ?: { }, onPartial)
  }

  fun stopListening() {
    continuous = false
    listening = false
    try { recognizer?.stopListening() } catch (_: Exception) {}
    destroyRecognizer()
  }

  private fun destroyRecognizer() {
    try { recognizer?.destroy() } catch (_: Exception) {}
    recognizer = null
  }

  fun release() {
    stopListening()
    stopSpeaking()
    tts?.shutdown()
    tts = null
  }
}
