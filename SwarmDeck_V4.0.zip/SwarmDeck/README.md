# SwarmDeck V4.0 — Autonomous Multi-Agent OS for Android

## What's New & Fixed in V4.0 (Refactored Edition)

1. **Zero-Block Onboarding & Encrypted Secrets (`Auth.kt`, `Core.kt`)**
   - **Local-First Mode**: Works immediately without requiring a Google Web Client ID ("Continue Local-Only"). Optional Google Sign-In works when `GOOGLE_WEB_CLIENT_ID` is configured in `gradle.properties`.
   - **Encrypted Storage**: API keys, provider profiles, and auth tokens are stored in hardware-backed `EncryptedSharedPreferences` (`androidx.security:security-crypto`).
   - **HTTPS Enforcement**: Cleartext HTTP traffic is disabled by default (`usesCleartextTraffic="false"`), with optional localhost override for local LLMs.
   - **No Committed Keystores**: Removed hardcoded `debug.keystore` credentials from `build.gradle.kts`.

2. **True Continuous Voice Mode (`Voice.kt`)**
   - **Reactive Compose State**: `continuous`, `listening`, and `speaking` are backed by `mutableStateOf` with distinct icons (`RecordVoiceOver` vs `Mic`).
   - **Auto-Send on Silence**: Automatically dispatches prompts when you finish speaking.
   - **Echo Prevention (`UtteranceProgressListener`)**: Automatically mutes/pauses the microphone while TTS is speaking and resumes listening 450ms after TTS completes.
   - **Wake Word & Interrupt-to-Talk**: Optional wake-word filter (`"hey swarm"`) and instant TTS interruption.

3. **Real Step-by-Step Mission Engine (`Brain` in `Core.kt`)**
   - **Plan → Execute → Verify → Replan**: Generates structured sequential steps, executes each step individually with full tool access, verifies step output, dynamically replans on failure, enforces a configurable step budget, supports live **Pause / Resume**, and persists step statuses (`PENDING`, `RUNNING`, `DONE`, `BLOCKED`, `FAILED`) in SQLite and the chat UI.

4. **Observe-Act Phone Control Loop with Safety Guardrails (`Services.kt`)**
   - **Screen Hierarchy Observation**: `PhoneControl.dumpScreen()` inspects `AccessibilityNodeInfo` after every action and returns a structured, coordinate-tagged UI tree back to the agent.
   - **Expanded Actions**: `OPEN`, `TAP`, `LONG_PRESS`, `TYPE`, `SWIPE x1 y1 x2 y2`, `SCROLL`, `BACK`, `HOME`, `WAIT`, and `READ_SCREEN`.
   - **User Approval Gate, App Allowlist & Kill Switch**: Prompts the user via an in-app confirmation modal before sensitive actions, checks an app allowlist, and provides an instant Kill Switch.

5. **OpenAI Native Tool Calling (`Tools.kt`)**
   - Uses OpenAI's structured `tools` / `tool_calls` JSON format instead of fragile regex text parsing.
   - Built-in tools: `web_search`, `web_fetch`, `file_read`, `file_write`, `set_alarm`, `calendar_event`, `draft_message`, `spawn_agent`, `phone_action`, and `propose_memory`.
   - Sensitive tools (`draft_message`, `calendar_event`, `set_alarm`, `phone_action`) require explicit user confirmation in the UI.

6. **SSE Streaming, Markdown & Code Block Rendering (`Llm` & `MainActivity.kt`)**
   - Live Server-Sent Events (`stream: true`) token streaming into the chat UI.
   - Rich Markdown rendering with headers, bullet lists, bold/inline code, and fenced code blocks with one-tap **Copy Code** buttons.
   - **Hard Stop**: Cancels all in-flight OkHttp `Call` objects and thread pool `Future`s immediately.

7. **SQLite + FTS4 Memory Tab, Multi-Chat Sessions & Audit Log (`Database.kt`)**
   - Full-text search (`FTS4`) over memories with keyword tokenization, pinning, manual creation, deletion, and "Save to Memory?" confirmation prompts.
   - Multiple chat threads with JSON export/import and a persistent **Audit Log** of all phone, tool, and terminal operations.

8. **Real Multi-Model Routing, Rate-Limit Backoff & Cost Counter (`ModelRouter`)**
   - Routes head-agent/selector prompts to the Fast Model, complex synthesis/coding to the Strong Model, and visual tasks to the Vision Model.
   - Exponential backoff on HTTP `429` / `5xx` with automatic fallback and live token/USD cost tracking.
