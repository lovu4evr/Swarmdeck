package com.swarmdeck

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

val BG1 = Color(0xFF050B1A)
val BG2 = Color(0xFF0A162F)
val EDGE = Color(0x55E8E4D9)
val ACC = Color(0xFF3B82F6)
val ACC2 = Color(0xFF60A5FA)
val CREAM = Color(0xFFF5F0E6)
val GOLD = Color(0xFFE8D5A3)
val GREEN = Color(0xFF34D399)
val COLORS = listOf(
  Color(0xFF3B82F6),
  Color(0xFF60A5FA),
  Color(0xFF93C5FD),
  Color(0xFF2563EB),
  Color(0xFF38BDF8),
  Color(0xFF818CF8),
  Color(0xFFF5F0E6),
  Color(0xFFE8D5A3)
)
val SHAPE = RoundedCornerShape(24.dp)

fun Modifier.glass(shape: Shape = SHAPE): Modifier = this
  .clip(shape)
  .background(
    Brush.linearGradient(
      listOf(Color(0x28F5F0E6), Color(0x18FFFFFF), Color(0x12A5C8FF))
    ),
    shape
  )
  .border(1.1.dp, EDGE, shape)

fun nameOf(id: String) = Bus.agents.firstOrNull { it.id == id }?.name ?: id
fun colorOf(id: String) = COLORS[Bus.agents.indexOfFirst { it.id == id }.coerceAtLeast(0) % COLORS.size]

@Composable
fun clearColors() = TextFieldDefaults.colors(
  focusedContainerColor = Color.Transparent,
  unfocusedContainerColor = Color.Transparent,
  focusedIndicatorColor = Color.Transparent,
  unfocusedIndicatorColor = Color.Transparent,
  focusedTextColor = CREAM,
  unfocusedTextColor = CREAM,
  cursorColor = ACC2
)

class MainActivity : ComponentActivity() {
  override fun onCreate(s: Bundle?) {
    super.onCreate(s)
    Hist.ensureDefaultSession(this)
    if (Bus.turns.isEmpty()) Bus.turns.addAll(Hist.load(this))
    setContent {
      MaterialTheme(colorScheme = darkColorScheme(primary = ACC, background = BG1, surface = BG2)) {
        App(this)
      }
    }
  }

  override fun onDestroy() {
    if (isFinishing) Voice.release()
    super.onDestroy()
  }
}

@Composable
fun Backdrop(content: @Composable BoxScope.() -> Unit) {
  Box(
    Modifier
      .fillMaxSize()
      .background(Brush.verticalGradient(listOf(BG1, BG2, Color(0xFF071022))))
  ) {
    Box(
      Modifier
        .offset((-100).dp, (-60).dp)
        .size(480.dp)
        .background(Brush.radialGradient(listOf(Color(0x443B82F6), Color.Transparent)))
    )
    Box(
      Modifier
        .align(Alignment.BottomEnd)
        .offset(100.dp, 80.dp)
        .size(420.dp)
        .background(Brush.radialGradient(listOf(Color(0x3360A5FA), Color.Transparent)))
    )
    content()
  }
}

@Composable
fun App(act: Activity) {
  var signed by remember { mutableStateOf(Auth.isSignedIn(act)) }
  val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
  val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
  LaunchedEffect(Unit) {
    if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    micPerm.launch(Manifest.permission.RECORD_AUDIO)
    Voice.init(act)
  }

  // Global Tool / Phone Action Confirmation Modal
  val confirmReq = Bus.pendingConfirmation
  if (confirmReq != null) {
    AlertDialog(
      onDismissRequest = { confirmReq.future.complete(false) },
      containerColor = BG2,
      titleContentColor = CREAM,
      textContentColor = Color.LightGray,
      title = { Text("Approval Required: ${confirmReq.title}", fontWeight = FontWeight.Bold) },
      text = { Text(confirmReq.details) },
      confirmButton = {
        Button(
          onClick = { confirmReq.future.complete(true) },
          colors = ButtonDefaults.buttonColors(containerColor = ACC)
        ) { Text("Approve") }
      },
      dismissButton = {
        OutlinedButton(onClick = { confirmReq.future.complete(false) }) { Text("Deny") }
      }
    )
  }

  Backdrop {
    if (!signed) Login(act) { signed = true } else Main(act) { signed = false }
  }
}

@Composable
fun Login(act: Activity, done: () -> Unit) {
  val scope = rememberCoroutineScope()
  var err by remember { mutableStateOf("") }
  Box(Modifier.fillMaxSize().padding(28.dp), Alignment.Center) {
    Column(Modifier.glass().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(Icons.Default.Hub, null, tint = ACC2, modifier = Modifier.size(72.dp))
      Spacer(Modifier.height(12.dp))
      Text("SWARMDECK", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = CREAM, letterSpacing = 2.sp)
      Text("V4.0  ·  Autonomous Multi-Agent OS", fontSize = 14.sp, color = ACC2, fontWeight = FontWeight.Medium)
      Spacer(Modifier.height(8.dp))
      Text(
        "Missions · FTS Memory · Continuous Voice · Native Tools · Observe-Act Phone Loop",
        color = Color(0xFFB8B0A0),
        textAlign = TextAlign.Center,
        fontSize = 13.sp
      )
      Spacer(Modifier.height(26.dp))
      Button(
        onClick = {
          Auth.continueLocalOnly(act)
          done()
        },
        modifier = Modifier.fillMaxWidth().height(54.dp),
        colors = ButtonDefaults.buttonColors(containerColor = ACC, contentColor = CREAM),
        shape = RoundedCornerShape(16.dp)
      ) {
        Icon(Icons.Default.Shield, null)
        Spacer(Modifier.width(8.dp))
        Text("Continue Local-Only (Private)", fontWeight = FontWeight.SemiBold)
      }
      if (Auth.isGoogleConfigured()) {
        Spacer(Modifier.height(12.dp))
        OutlinedButton(
          onClick = {
            scope.launch {
              try {
                Auth.signInWithGoogle(act)
                done()
              } catch (e: Exception) {
                err = e.message ?: "Sign-in failed"
              }
            }
          },
          modifier = Modifier.fillMaxWidth().height(50.dp),
          shape = RoundedCornerShape(16.dp)
        ) {
          Text("Sign in with Google", color = CREAM)
        }
      }
      if (err.isNotEmpty()) {
        Text(err, color = Color(0xFFFF8A8A), modifier = Modifier.padding(top = 14.dp), textAlign = TextAlign.Center)
      }
    }
  }
}

@Composable
fun Main(act: Activity, out: () -> Unit) {
  var tab by remember { mutableIntStateOf(0) }
  Scaffold(
    containerColor = Color.Transparent,
    bottomBar = {
      Box(Modifier.padding(10.dp).glass(RoundedCornerShape(28.dp))) {
        NavigationBar(containerColor = Color.Transparent) {
          listOf(
            "Chat" to Icons.Default.Chat,
            "Memory" to Icons.Default.Memory,
            "Agents" to Icons.Default.Groups,
            "Terminal" to Icons.Default.Terminal,
            "Settings" to Icons.Default.Settings
          ).forEachIndexed { i, (n, ic) ->
            NavigationBarItem(
              selected = tab == i,
              onClick = { tab = i },
              icon = { Icon(ic, n) },
              label = { Text(n, fontSize = 10.sp) }
            )
          }
        }
      }
    }
  ) { p ->
    Box(Modifier.padding(p).fillMaxSize()) {
      when (tab) {
        0 -> ChatTab(act)
        1 -> MemoryTab(act)
        2 -> AgentsTab(act)
        3 -> TermTab(act)
        else -> SettingsTab(act, out)
      }
    }
  }
}

@Composable
fun ChatTab(c: Context) {
  var input by remember { mutableStateOf("") }
  var mode by remember { mutableStateOf(Store.p(c).getString("mode", "auto")!!) }
  var showSessions by remember { mutableStateOf(false) }
  val ls = rememberLazyListState()

  val pttLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
    r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { spoken ->
      input = if (input.isBlank()) spoken else "$input $spoken"
    }
  }

  LaunchedEffect(Bus.turns.size, Bus.status, Bus.streamingText) {
    val n = ls.layoutInfo.totalItemsCount
    if (n > 0) ls.animateScrollToItem(n - 1)
  }

  fun sendText(rawText: String = input) {
    val q = rawText.trim()
    if (q.isEmpty() || Bus.running) return
    input = ""
    Bus.turns.add(Turn(true, q))
    Hist.save(c, Bus.turns)
    Bus.running = true
    Bus.status = "Starting…"
    ContextCompat.startForegroundService(c, Intent(c, AgentService::class.java).putExtra("goal", q))
  }

  if (showSessions) {
    val sessions = remember(Bus.turns.size) { Hist.listSessions(c) }
    AlertDialog(
      onDismissRequest = { showSessions = false },
      containerColor = BG2,
      titleContentColor = CREAM,
      title = { Text("Chat Sessions") },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Button(
            onClick = {
              Hist.createSession(c, "New Session")
              Bus.turns.clear()
              showSessions = false
            },
            modifier = Modifier.fillMaxWidth()
          ) { Text("+ New Chat Session") }
          sessions.forEach { s ->
            Row(
              Modifier
                .fillMaxWidth()
                .glass(RoundedCornerShape(12.dp))
                .clickable {
                  Store.p(c).edit().putString("current_session", s.id).apply()
                  Bus.turns.clear()
                  Bus.turns.addAll(Hist.load(c, s.id))
                  showSessions = false
                }
                .padding(10.dp),
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(s.title, Modifier.weight(1f), color = CREAM, fontSize = 13.sp)
              IconButton(onClick = {
                Hist.deleteSession(c, s.id)
                val id = Hist.ensureDefaultSession(c)
                Bus.turns.clear()
                Bus.turns.addAll(Hist.load(c, id))
                showSessions = false
              }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFFF8A8A)) }
            }
          }
        }
      },
      confirmButton = { TextButton(onClick = { showSessions = false }) { Text("Close") } }
    )
  }

  Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
    Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
      Column(Modifier.weight(1f)) {
        Text("SwarmDeck 4.0", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
        Text(
          "Tokens: ${Bus.totalTokens} · Est: $%.4f".format(Bus.estimatedCostUsd),
          color = Color(0xFFB8B0A0),
          fontSize = 11.sp
        )
      }
      if (Voice.speaking) {
        TextButton(onClick = { Voice.interruptAndListen() }) {
          Icon(Icons.Default.VolumeOff, null, tint = GOLD)
          Spacer(Modifier.width(4.dp))
          Text("Interrupt TTS", color = GOLD, fontSize = 11.sp)
        }
      }
      IconButton(onClick = { showSessions = true }) { Icon(Icons.Default.Forum, "Sessions", tint = ACC2) }
      IconButton(onClick = {
        if (!Bus.running) {
          Hist.createSession(c, "New Chat")
          Bus.turns.clear()
        }
      }) { Icon(Icons.Default.Add, "New chat", tint = ACC2) }
    }

    Row(
      Modifier.padding(vertical = 6.dp).horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("auto" to "🧠 Auto", "fast" to "⚡ Fast", "all" to "🌐 All", "mission" to "🎯 Mission").forEach { (m, l) ->
        FilterChip(
          selected = mode == m,
          onClick = {
            mode = m
            Store.p(c).edit().putString("mode", m).apply()
            Bus.missionMode = (m == "mission")
          },
          label = { Text(l) }
        )
      }
    }

    // Memory Proposal Confirmation Chips
    if (Bus.memoryProposals.isNotEmpty()) {
      val prop = Bus.memoryProposals.first()
      Row(
        Modifier.fillMaxWidth().padding(bottom = 6.dp).glass(RoundedCornerShape(14.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        Icon(Icons.Default.BookmarkAdd, null, tint = GOLD, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(8.dp))
        Text("Save '${prop.key}' to Memory?", Modifier.weight(1f), color = CREAM, fontSize = 12.sp)
        TextButton(onClick = {
          Memory.save(c, prop.key, prop.value, prop.tags)
          Bus.memoryProposals.remove(prop)
          Toast.makeText(c, "Saved to FTS Memory", Toast.LENGTH_SHORT).show()
        }) { Text("Save", color = GREEN) }
        TextButton(onClick = { Bus.memoryProposals.remove(prop) }) { Text("Dismiss", color = Color.Gray) }
      }
    }

    LazyColumn(Modifier.weight(1f), state = ls) {
      if (Bus.turns.isEmpty()) {
        item {
          Column(Modifier.padding(vertical = 20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Ask or launch a Mission.", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text(
              "Specialists collaborate with native tools, real-time SSE streaming, FTS memory, and step-by-step mission verification.",
              color = Color.LightGray,
              fontSize = 13.sp
            )
            listOf(
              "Mission: Research top 3 Kotlin multiplatform libraries and save a summary file",
              "Write a clean Kotlin coroutine retry helper with exponential backoff",
              "Inspect my phone screen and tell me what app is open"
            ).forEach { s ->
              OutlinedButton(onClick = { input = s }, modifier = Modifier.fillMaxWidth()) { Text(s) }
            }
          }
        }
      }
      items(Bus.turns) { t -> Bubble(c, t) }

      if (Bus.running) {
        item {
          Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = ACC2)
              Spacer(Modifier.width(10.dp))
              Text(Bus.status.ifEmpty { "Thinking…" }, Modifier.weight(1f), color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.Medium)
              if (Bus.missionMode) {
                TextButton(onClick = { Bus.missionPaused = !Bus.missionPaused }) {
                  Text(if (Bus.missionPaused) "Resume" else "Pause", color = GOLD, fontSize = 12.sp)
                }
              }
            }
            if (Bus.subAgents.isNotEmpty()) {
              Spacer(Modifier.height(4.dp))
              Text("Active Specialists: " + Bus.subAgents.joinToString(" · "), color = ACC2, fontSize = 11.sp)
            }
            if (Bus.missionSteps.isNotEmpty()) {
              Spacer(Modifier.height(6.dp))
              Bus.missionSteps.forEach { st ->
                val badge = when (st.status) {
                  "DONE" -> "✅"
                  "RUNNING" -> "⏳"
                  "BLOCKED" -> "⚠️"
                  else -> "⬜"
                }
                Text("$badge Step ${st.index}: ${st.description}", color = CREAM, fontSize = 12.sp)
              }
            }
            if (Bus.streamingText.isNotEmpty()) {
              Spacer(Modifier.height(8.dp))
              HorizontalDivider(color = EDGE)
              Spacer(Modifier.height(6.dp))
              MarkdownText(c, Bus.streamingText)
            }
            if (Bus.thinking.isNotEmpty()) {
              Spacer(Modifier.height(8.dp))
              Bus.thinking.takeLast(5).forEach { line ->
                Text("› $line", color = Color(0xFFB8B0A0), fontSize = 11.sp)
              }
            }
          }
        }
      }
    }

    // Input Bar with Distinct Continuous Voice & Push-To-Talk Buttons
    Row(
      Modifier.fillMaxWidth().padding(vertical = 10.dp).glass(RoundedCornerShape(28.dp)),
      verticalAlignment = Alignment.CenterVertically
    ) {
      TextField(
        value = input,
        onValueChange = { input = it },
        modifier = Modifier.weight(1f),
        placeholder = { Text(if (Voice.listening) "Listening (auto-send)…" else "Message SwarmDeck…") },
        maxLines = 4,
        colors = clearColors(),
        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
        keyboardActions = KeyboardActions(onSend = { sendText() })
      )

      // Continuous Voice Toggle (RecordVoiceOver icon + Green active state + Auto-Send)
      IconButton(onClick = {
        Voice.init(c)
        if (Voice.continuous) {
          Voice.stopListening()
          Toast.makeText(c, "Continuous voice OFF", Toast.LENGTH_SHORT).show()
        } else {
          Voice.startContinuousSession(
            activity = c as Activity,
            onDispatch = { spoken ->
              input = spoken
              sendText(spoken)
            },
            onPart = { part -> input = part }
          )
          Toast.makeText(c, "Continuous voice ON — auto-sends on pause", Toast.LENGTH_SHORT).show()
        }
      }) {
        Icon(
          imageVector = Icons.Default.RecordVoiceOver,
          contentDescription = "Continuous Voice Mode",
          tint = if (Voice.continuous) GREEN else ACC2
        )
      }

      // Single-shot Push-to-Talk (MicOutline icon)
      IconButton(onClick = {
        try {
          pttLauncher.launch(
            Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
              .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
          )
        } catch (_: Exception) {
          Toast.makeText(c, "Push-to-talk unavailable", Toast.LENGTH_SHORT).show()
        }
      }) {
        Icon(Icons.Default.MicNone, "Push to talk", tint = Color.LightGray)
      }

      if (Bus.running) {
        IconButton(onClick = {
          Brain.cancelAll()
          c.stopService(Intent(c, AgentService::class.java))
          Bus.running = false
          Bus.status = ""
        }) {
          Icon(Icons.Default.StopCircle, "Hard Stop", tint = Color(0xFFFF6B6B))
        }
      } else {
        IconButton(onClick = { sendText() }) {
          Icon(Icons.Default.Send, "Send", tint = ACC)
        }
      }
    }
  }
}

@Composable
fun Bubble(c: Context, t: Turn) {
  var openDetails by remember { mutableStateOf(false) }
  var openThinking by remember { mutableStateOf(false) }
  val sh = if (t.user) RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp) else RoundedCornerShape(22.dp, 22.dp, 22.dp, 6.dp)
  Row(
    Modifier.fillMaxWidth().padding(vertical = 6.dp),
    horizontalArrangement = if (t.user) Arrangement.End else Arrangement.Start
  ) {
    Column(
      Modifier
        .widthIn(max = 345.dp)
        .glass(sh)
        .background(if (t.user) ACC.copy(alpha = 0.35f) else Color.Transparent, sh)
        .padding(14.dp)
    ) {
      if (!t.user) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.AutoAwesome, null, tint = ACC2, modifier = Modifier.size(16.dp))
          Spacer(Modifier.width(6.dp))
          Text("SwarmDeck", color = ACC2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
          if (t.winner.isNotEmpty()) {
            Spacer(Modifier.width(8.dp))
            Text("⭐ ${nameOf(t.winner)}", color = GOLD, fontSize = 12.sp)
          }
        }
        Spacer(Modifier.height(6.dp))
      }

      if (t.missionSteps.isNotEmpty()) {
        Column(
          Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(RoundedCornerShape(10.dp))
            .background(Color(0x22000000))
            .padding(8.dp)
        ) {
          Text("Mission Execution Plan:", color = GOLD, fontSize = 11.sp, fontWeight = FontWeight.Bold)
          t.missionSteps.forEach { st ->
            val icon = if (st.status == "DONE") "✅" else "⚠️"
            Text("$icon ${st.index}. ${st.description} [${st.status}]", color = CREAM, fontSize = 11.sp)
          }
        }
      }

      SelectionContainer {
        MarkdownText(c, t.text)
      }

      if (!t.user) {
        Row(Modifier.horizontalScroll(rememberScrollState())) {
          TextButton(onClick = {
            (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
              .setPrimaryClip(ClipData.newPlainText("answer", t.text))
            Toast.makeText(c, "Copied", Toast.LENGTH_SHORT).show()
          }) { Text("Copy", fontSize = 12.sp) }

          TextButton(onClick = {
            Memory.save(c, "Saved Answer", t.text.take(500), "pinned", pinned = true)
            Toast.makeText(c, "Pinned to Memory", Toast.LENGTH_SHORT).show()
          }) { Text("Pin", fontSize = 12.sp) }

          if (t.answers.size > 1) {
            TextButton(onClick = { openDetails = !openDetails }) {
              Text("Drafts (${t.answers.size})", fontSize = 12.sp)
            }
          }
          if (t.thinking.isNotEmpty()) {
            TextButton(onClick = { openThinking = !openThinking }) {
              Text("Logs (${t.thinking.size})", fontSize = 12.sp)
            }
          }
        }
        if (openDetails) {
          t.answers.forEach { (id, s, n) ->
            HorizontalDivider(color = EDGE, modifier = Modifier.padding(vertical = 6.dp))
            Text("${nameOf(id)} · $n/10", color = colorOf(id), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(s, color = Color(0xFFCBD5E1), fontSize = 12.sp)
          }
        }
        if (openThinking) {
          HorizontalDivider(color = EDGE, modifier = Modifier.padding(vertical = 6.dp))
          t.thinking.forEach { log ->
            Text("› $log", color = Color(0xFFB8B0A0), fontSize = 11.sp, fontFamily = FontFamily.Monospace)
          }
        }
      }
    }
  }
}

// ── Markdown & Fenced Code Block Renderer ──
@Composable
fun MarkdownText(c: Context, raw: String) {
  val segments = remember(raw) { raw.split("```") }
  Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
    segments.forEachIndexed { idx, seg ->
      if (idx % 2 == 1) {
        // Code block
        val firstNewline = seg.indexOf('\n')
        val lang = if (firstNewline in 1..20) seg.substring(0, firstNewline).trim() else "code"
        val code = if (firstNewline >= 0) seg.substring(firstNewline + 1).trimEnd() else seg
        Column(
          Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF030712))
            .border(1.dp, EDGE, RoundedCornerShape(12.dp))
            .padding(10.dp)
        ) {
          Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text(lang.uppercase(), color = ACC2, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            Text(
              "Copy Code",
              color = GOLD,
              fontSize = 11.sp,
              modifier = Modifier.clickable {
                (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                  .setPrimaryClip(ClipData.newPlainText("code", code))
                Toast.makeText(c, "Code copied", Toast.LENGTH_SHORT).show()
              }
            )
          }
          Spacer(Modifier.height(4.dp))
          Text(
            text = code,
            color = Color(0xFFE2E8F0),
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            modifier = Modifier.horizontalScroll(rememberScrollState())
          )
        }
      } else if (seg.isNotBlank()) {
        val annotated = remember(seg) {
          buildAnnotatedString {
            seg.lines().forEachIndexed { lineIdx, line ->
              if (lineIdx > 0) append("\n")
              when {
                line.startsWith("### ") -> {
                  withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = GOLD)) {
                    append(line.removePrefix("### "))
                  }
                }
                line.startsWith("## ") -> {
                  withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 17.sp, color = ACC2)) {
                    append(line.removePrefix("## "))
                  }
                }
                line.startsWith("# ") -> {
                  withStyle(SpanStyle(fontWeight = FontWeight.Bold, fontSize = 19.sp, color = CREAM)) {
                    append(line.removePrefix("# "))
                  }
                }
                else -> {
                  // Parse inline **bold** and `code`
                  var i = 0
                  while (i < line.length) {
                    if (line.startsWith("**", i)) {
                      val end = line.indexOf("**", i + 2)
                      if (end > i) {
                        withStyle(SpanStyle(fontWeight = FontWeight.Bold, color = Color.White)) {
                          append(line.substring(i + 2, end))
                        }
                        i = end + 2
                        continue
                      }
                    } else if (line[i] == '`') {
                      val end = line.indexOf('`', i + 1)
                      if (end > i) {
                        withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33FFFFFF), color = GOLD)) {
                          append(line.substring(i + 1, end))
                        }
                        i = end + 1
                        continue
                      }
                    }
                    append(line[i])
                    i++
                  }
                }
              }
            }
          }
        }
        Text(annotated, color = CREAM, fontSize = 15.sp)
      }
    }
  }
}


fun MemoryTab(c: Context) {
  var query by remember { mutableStateOf("") }
  var newKey by remember { mutableStateOf("") }
  var newVal by remember { mutableStateOf("") }
  var newTags by remember { mutableStateOf("") }
  var refreshTick by remember { mutableIntStateOf(0) }

  val memoryItems = remember(query, refreshTick) {
    if (query.isBlank()) Memory.all(c)
    else Memory.search(c, query)
  }

  Column(
    modifier = Modifier
      .fillMaxSize()
      .background(BG1)
      .padding(16.dp)
  ) {
    Text(
      "MATRIX MEMORY",
      color = GOLD,
      fontSize = 22.sp,
      fontWeight = FontWeight.Bold
    )

    Spacer(Modifier.height(12.dp))

    OutlinedTextField(
      value = query,
      onValueChange = { query = it },
      modifier = Modifier.fillMaxWidth(),
      label = { Text("Search memories") },
      singleLine = true
    )

    Spacer(Modifier.height(12.dp))

    OutlinedTextField(
      value = newKey,
      onValueChange = { newKey = it },
      modifier = Modifier.fillMaxWidth(),
      label = { Text("Memory title") },
      singleLine = true
    )

    Spacer(Modifier.height(8.dp))

    OutlinedTextField(
      value = newVal,
      onValueChange = { newVal = it },
      modifier = Modifier.fillMaxWidth(),
      label = { Text("Memory details") }
    )

    Spacer(Modifier.height(8.dp))

    OutlinedTextField(
      value = newTags,
      onValueChange = { newTags = it },
      modifier = Modifier.fillMaxWidth(),
      label = { Text("Tags (optional)") },
      singleLine = true
    )

    Spacer(Modifier.height(10.dp))

    Button(
      onClick = {
        if (newKey.isNotBlank() && newVal.isNotBlank()) {
          Memory.save(
            c,
            newKey.trim(),
            newVal.trim(),
            newTags.trim(),
            false
          )
          newKey = ""
          newVal = ""
          newTags = ""
          refreshTick++
        }
      },
      modifier = Modifier.fillMaxWidth()
    ) {
      Text("Save Memory")
    }

    Spacer(Modifier.height(12.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        "Saved Memories: ${memoryItems.size}",
        color = CREAM,
        fontWeight = FontWeight.Bold
      )

      TextButton(onClick = { refreshTick++ }) {
        Text("Refresh")
      }
    }

    LazyColumn(
      modifier = Modifier.weight(1f),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(memoryItems, key = { it.id }) { item ->
        Card(
          modifier = Modifier.fillMaxWidth(),
          colors = CardDefaults.cardColors(
            containerColor = BG2
          ),
          shape = RoundedCornerShape(14.dp)
        ) {
          Column(Modifier.padding(14.dp)) {
            Text(
              item.key,
              color = GOLD,
              fontWeight = FontWeight.Bold,
              fontSize = 16.sp
            )

            Spacer(Modifier.height(6.dp))

            Text(
              item.value,
              color = CREAM,
              fontSize = 14.sp
            )

            if (item.tags.isNotBlank()) {
              Spacer(Modifier.height(6.dp))
              Text(
                "Tags: ${item.tags}",
                color = ACC2,
                fontSize = 12.sp
              )
            }

            Spacer(Modifier.height(8.dp))

            Row(
              horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              TextButton(
                onClick = {
                  Memory.togglePin(c, item.id, !item.pinned)
                  refreshTick++
                }
              ) {
                Text(if (item.pinned) "Unpin" else "Pin")
              }

              TextButton(
                onClick = {
                  Memory.delete(c, item.id)
                  refreshTick++
                }
              ) {
                Text("Delete", color = Color(0xFFFF6B6B))
              }
            }
          }
        }
      }
    }
  }
}

