package com.swarmdeck

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.IBinder
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentService : Service() {
  override fun onBind(i: Intent?): IBinder? = null

  override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
    val goal = i?.getStringExtra("goal") ?: return START_NOT_STICKY
    val nm = getSystemService(NotificationManager::class.java)
    nm.createNotificationChannel(
      NotificationChannel("swarm", "SwarmDeck Execution", NotificationManager.IMPORTANCE_LOW)
    )
    startForeground(
      1,
      Notification.Builder(this, "swarm")
        .setContentTitle("SwarmDeck V4 is working")
        .setContentText(goal.take(60))
        .setSmallIcon(android.R.drawable.stat_notify_sync)
        .build()
    )
    Thread {
      val priorTurns = Hist.load(this).dropLast(1)
      val t = try {
        Brain.run(this, goal, priorTurns) { s -> Bus.ui { Bus.status = s } }
      } catch (e: Exception) {
        Turn(false, "Error: ${e.message}")
      }
      if (!Brain.stop) {
        Bus.add(this, t)
        try {
          Voice.init(this)
          if (Voice.continuous) {
            Voice.speak(t.text.take(380))
          } else {
            Voice.onAgentRunFinished()
          }
        } catch (_: Exception) {}
      }
      Bus.ui {
        Bus.status = ""
        Bus.running = false
      }
      stopSelf()
    }.start()
    return START_NOT_STICKY
  }

  override fun onDestroy() {
    Bus.ui { Bus.running = false }
    super.onDestroy()
  }
}

class PhoneControl : AccessibilityService() {
  override fun onServiceConnected() {
    inst = this
  }

  override fun onUnbind(i: Intent?): Boolean {
    inst = null
    return super.onUnbind(i)
  }

  override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
  override fun onInterrupt() {}

  // Hardware Volume-Down doubles as an emergency Phone Control Kill Switch while running
  override fun onKeyEvent(event: KeyEvent?): Boolean {
    if (event?.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_DOWN && Bus.running) {
      killSwitchTriggered = true
      Brain.cancelAll()
      Bus.think("KILL SWITCH triggered via Volume Down")
    }
    return super.onKeyEvent(event)
  }

  companion object {
    @Volatile var inst: PhoneControl? = null
    @Volatile var killSwitchTriggered: Boolean = false

    fun dumpScreen(): String {
      val s = inst ?: return "Accessibility Service not connected."
      val root = s.rootInActiveWindow ?: return "No active window available."
      val sb = StringBuilder()
      sb.appendLine("Package: ${root.packageName ?: "unknown"}")
      var count = 0
      fun walk(node: AccessibilityNodeInfo?, depth: Int) {
        if (node == null || count > 65) return
        val text = node.text?.toString()?.trim().orEmpty()
        val desc = node.contentDescription?.toString()?.trim().orEmpty()
        val clickable = node.isClickable
        val editable = node.isEditable
        val scrollable = node.isScrollable
        if (text.isNotEmpty() || desc.isNotEmpty() || clickable || editable) {
          val bounds = Rect()
          node.getBoundsInScreen(bounds)
          val flags = buildList {
            if (clickable) add("CLICK")
            if (editable) add("EDIT")
            if (scrollable) add("SCROLL")
          }.joinToString(",")
          val label = if (text.isNotEmpty()) text else desc
          sb.appendLine("${"  ".repeat(depth.coerceAtMost(6))}• [${flags.ifEmpty { "VIEW" }}] \"${label.take(60)}\" @(${bounds.centerX()},${bounds.centerY()})")
          count++
        }
        for (i in 0 until node.childCount) {
          walk(node.getChild(i), depth + 1)
        }
      }
      walk(root, 0)
      return sb.toString().ifBlank { "Screen is empty." }
    }

    fun executeWithObservation(c: Context, rawCmd: String): String {
      if (killSwitchTriggered) {
        return "ABORTED: Operator Kill Switch is active. Reset it in Settings."
      }
      val s = inst ?: return "Enable SwarmDeck Operator in Android Accessibility Settings first."
      val parts = rawCmd.trim().split(" ", limit = 2)
      val op = parts[0].uppercase()
      val arg = parts.getOrNull(1)?.trim() ?: ""

      // Sensitive actions require user confirmation if confirmation gate is enabled
      val requireConfirm = Store.p(c).getBoolean("phone_confirm", true)
      if (requireConfirm && op in setOf("OPEN", "TAP", "LONG_PRESS", "TYPE", "SWIPE")) {
        val approved = Bus.requestConfirmation("Operator Phone Action", "Allow Operator to execute:\n$op $arg")
        if (!approved) {
          AuditLog.record(c, "PHONE", rawCmd, "DENIED_BY_USER")
          return "User denied action: $rawCmd"
        }
      }

      val actionStatus = when (op) {
        "READ_SCREEN" -> "Observed current screen."

        "OPEN" -> {
          val allowlist = Store.p(c).getString("app_allowlist", "")!!.trim()
          if (allowlist.isNotEmpty()) {
            val allowed = allowlist.split(",").map { it.trim().lowercase() }.filter { it.isNotEmpty() }
            if (allowed.isNotEmpty() && allowed.none { arg.lowercase().contains(it) }) {
              return "Blocked by App Allowlist: '$arg' is not in [$allowlist]."
            }
          }
          val pm = s.packageManager
          val li = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            0
          ).firstOrNull { it.loadLabel(pm).toString().contains(arg, true) }
          if (li == null) {
            "App not found: $arg"
          } else {
            val launch = pm.getLaunchIntentForPackage(li.activityInfo.packageName)
            if (launch != null) {
              s.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
              Thread.sleep(900)
              "Opened $arg"
            } else "Cannot launch $arg"
          }
        }

        "TAP" -> {
          var n = s.rootInActiveWindow?.findAccessibilityNodeInfosByText(arg)?.firstOrNull()
          while (n != null && !n.isClickable) n = n.parent
          val ok = n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true
          Thread.sleep(500)
          if (ok) "Tapped '$arg'" else "Could not find clickable '$arg'"
        }

        "LONG_PRESS" -> {
          var n = s.rootInActiveWindow?.findAccessibilityNodeInfosByText(arg)?.firstOrNull()
          while (n != null && !n.isLongClickable && !n.isClickable) n = n.parent
          val ok = n?.performAction(AccessibilityNodeInfo.ACTION_LONG_CLICK) == true
          Thread.sleep(500)
          if (ok) "Long-pressed '$arg'" else "Could not long-press '$arg'"
        }

        "TYPE" -> {
          val f = s.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
          val b = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, arg)
          }
          val ok = f?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) == true
          if (ok) "Typed '$arg'" else "No focused input field found"
        }

        "SWIPE" -> {
          val coords = arg.split(Regex("\\s+")).mapNotNull { it.toFloatOrNull() }
          if (coords.size < 4) {
            "SWIPE requires 4 coordinates: x1 y1 x2 y2"
          } else {
            val path = Path().apply {
              moveTo(coords[0], coords[1])
              lineTo(coords[2], coords[3])
            }
            val gesture = GestureDescription.Builder()
              .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
              .build()
            s.dispatchGesture(gesture, null, null)
            Thread.sleep(500)
            "Swiped (${coords[0]},${coords[1]}) -> (${coords[2]},${coords[3]})"
          }
        }

        "BACK" -> {
          s.performGlobalAction(GLOBAL_ACTION_BACK)
          Thread.sleep(400)
          "Pressed Back"
        }

        "HOME" -> {
          s.performGlobalAction(GLOBAL_ACTION_HOME)
          Thread.sleep(400)
          "Pressed Home"
        }

        "SCROLL" -> {
          val ok = s.rootInActiveWindow?.let { scrollable(it) }
            ?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true
          Thread.sleep(500)
          if (ok) "Scrolled forward" else "No scrollable view found"
        }

        "WAIT" -> {
          val ms = arg.toLongOrNull()?.coerceIn(100L, 5000L) ?: 1000L
          Thread.sleep(ms)
          "Waited ${ms}ms"
        }

        else -> "Unknown phone command: $rawCmd"
      }

      val screenObservation = dumpScreen()
      val combined = "$actionStatus\n\n--- Observed Screen Tree ---\n$screenObservation"
      AuditLog.record(c, "PHONE", rawCmd, actionStatus)
      return combined
    }

    private fun scrollable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
      if (n.isScrollable) return n
      for (i in 0 until n.childCount) {
        n.getChild(i)?.let { child -> scrollable(child)?.let { return it } }
      }
      return null
    }
  }
}
