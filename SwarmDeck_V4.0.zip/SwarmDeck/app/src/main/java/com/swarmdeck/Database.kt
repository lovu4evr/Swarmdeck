package com.swarmdeck

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class ChatSession(val id: String, val title: String, val updatedAt: Long)

data class MissionStep(
  val index: Int,
  val description: String,
  val status: String = "PENDING", // PENDING, RUNNING, DONE, BLOCKED, FAILED
  val output: String = ""
)

data class MemoryItem(
  val id: String,
  val key: String,
  val value: String,
  val tags: String,
  val pinned: Boolean,
  val ts: Long
)

data class AuditEntry(
  val id: Long,
  val category: String, // PHONE, TOOL, TERMINAL, MISSION
  val action: String,
  val result: String,
  val ts: Long
)

class SwarmDbHelper(context: Context) : SQLiteOpenHelper(context.applicationContext, "swarmdeck_v4.db", null, 2) {
  override fun onCreate(db: SQLiteDatabase) {
    db.execSQL('''
      CREATE TABLE sessions (
        id TEXT PRIMARY KEY,
        title TEXT NOT NULL,
        updated_at INTEGER NOT NULL
      )
    '''.trimIndent())

    db.execSQL('''
      CREATE TABLE turns (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        session_id TEXT NOT NULL,
        is_user INTEGER NOT NULL,
        text TEXT NOT NULL,
        winner TEXT NOT NULL,
        answers_json TEXT NOT NULL,
        thinking_json TEXT NOT NULL,
        steps_json TEXT NOT NULL,
        ts INTEGER NOT NULL
      )
    '''.trimIndent())

    db.execSQL('''
      CREATE TABLE memories (
        id TEXT PRIMARY KEY,
        mkey TEXT NOT NULL,
        mval TEXT NOT NULL,
        tags TEXT NOT NULL,
        pinned INTEGER NOT NULL DEFAULT 0,
        ts INTEGER NOT NULL
      )
    '''.trimIndent())

    // FTS4 virtual table for fast keyword & phrase search over Infinite Memory
    db.execSQL('''
      CREATE VIRTUAL TABLE memories_fts USING fts4(
        id,
        mkey,
        mval,
        tags
      )
    '''.trimIndent())

    db.execSQL('''
      CREATE TABLE audit_log (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category TEXT NOT NULL,
        action TEXT NOT NULL,
        result TEXT NOT NULL,
        ts INTEGER NOT NULL
      )
    '''.trimIndent())
  }

  override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
    db.execSQL("DROP TABLE IF EXISTS sessions")
    db.execSQL("DROP TABLE IF EXISTS turns")
    db.execSQL("DROP TABLE IF EXISTS memories")
    db.execSQL("DROP TABLE IF EXISTS memories_fts")
    db.execSQL("DROP TABLE IF EXISTS audit_log")
    onCreate(db)
  }

  companion object {
    @Volatile private var instance: SwarmDbHelper? = null
    fun get(c: Context): SwarmDbHelper =
      instance ?: synchronized(this) {
        instance ?: SwarmDbHelper(c).also { instance = it }
      }
  }
}

object Hist {
  fun ensureDefaultSession(c: Context): String {
    val sessions = listSessions(c)
    if (sessions.isNotEmpty()) {
      val current = Store.p(c).getString("current_session", "") ?: ""
      if (sessions.any { it.id == current }) return current
      Store.p(c).edit().putString("current_session", sessions.first().id).apply()
      return sessions.first().id
    }
    return createSession(c, "Primary Mission Chat")
  }

  fun createSession(c: Context, title: String): String {
    val id = UUID.randomUUID().toString().take(10)
    val db = SwarmDbHelper.get(c).writableDatabase
    val cv = ContentValues().apply {
      put("id", id)
      put("title", title)
      put("updated_at", System.currentTimeMillis())
    }
    db.insertWithOnConflict("sessions", null, cv, SQLiteDatabase.CONFLICT_REPLACE)
    Store.p(c).edit().putString("current_session", id).apply()
    return id
  }

  fun deleteSession(c: Context, sessionId: String) {
    val db = SwarmDbHelper.get(c).writableDatabase
    db.delete("turns", "session_id = ?", arrayOf(sessionId))
    db.delete("sessions", "id = ?", arrayOf(sessionId))
  }

  fun listSessions(c: Context): List<ChatSession> {
    val db = SwarmDbHelper.get(c).readableDatabase
    val out = mutableListOf<ChatSession>()
    db.rawQuery("SELECT id, title, updated_at FROM sessions ORDER BY updated_at DESC", null).use { cur ->
      while (cur.moveToNext()) {
        out.add(ChatSession(cur.getString(0), cur.getString(1), cur.getLong(2)))
      }
    }
    return out
  }

  fun save(c: Context, turns: List<Turn>, sessionId: String = ensureDefaultSession(c)) {
    val db = SwarmDbHelper.get(c).writableDatabase
    db.beginTransaction()
    try {
      db.delete("turns", "session_id = ?", arrayOf(sessionId))
      val firstUser = turns.firstOrNull { it.user }?.text?.take(36)
      if (!firstUser.isNullOrBlank()) {
        val cvSession = ContentValues().apply {
          put("title", firstUser)
          put("updated_at", System.currentTimeMillis())
        }
        db.update("sessions", cvSession, "id = ?", arrayOf(sessionId))
      }
      turns.forEachIndexed { idx, t ->
        val ansArr = JSONArray()
        t.answers.forEach { (i, s, n) ->
          ansArr.put(JSONObject().put("i", i).put("s", s).put("n", n))
        }
        val thinkArr = JSONArray()
        t.thinking.forEach { thinkArr.put(it) }
        val stepsArr = JSONArray()
        t.missionSteps.forEach { step ->
          stepsArr.put(
            JSONObject()
              .put("index", step.index)
              .put("description", step.description)
              .put("status", step.status)
              .put("output", step.output)
          )
        }
        val cv = ContentValues().apply {
          put("session_id", sessionId)
          put("is_user", if (t.user) 1 else 0)
          put("text", t.text)
          put("winner", t.winner)
          put("answers_json", ansArr.toString())
          put("thinking_json", thinkArr.toString())
          put("steps_json", stepsArr.toString())
          put("ts", System.currentTimeMillis() + idx)
        }
        db.insert("turns", null, cv)
      }
      db.setTransactionSuccessful()
    } finally {
      db.endTransaction()
    }
  }

  fun load(c: Context, sessionId: String = ensureDefaultSession(c)): List<Turn> {
    val db = SwarmDbHelper.get(c).readableDatabase
    val out = mutableListOf<Turn>()
    db.rawQuery(
      "SELECT is_user, text, winner, answers_json, thinking_json, steps_json FROM turns WHERE session_id = ? ORDER BY ts ASC",
      arrayOf(sessionId)
    ).use { cur ->
      while (cur.moveToNext()) {
        val isUser = cur.getInt(0) == 1
        val text = cur.getString(1)
        val winner = cur.getString(2)
        val ansArr = JSONArray(cur.getString(3))
        val thinkArr = JSONArray(cur.getString(4))
        val stepsArr = JSONArray(cur.getString(5))
        val answers = (0 until ansArr.length()).map { j ->
          val q = ansArr.getJSONObject(j)
          Triple(q.getString("i"), q.getString("s"), q.getInt("n"))
        }
        val thinking = (0 until thinkArr.length()).map { j -> thinkArr.getString(j) }
        val steps = (0 until stepsArr.length()).map { j ->
          val s = stepsArr.getJSONObject(j)
          MissionStep(
            s.optInt("index", j + 1),
            s.optString("description", ""),
            s.optString("status", "DONE"),
            s.optString("output", "")
          )
        }
        out.add(Turn(isUser, text, winner, answers, thinking, steps))
      }
    }
    return out
  }

  fun exportAllJson(c: Context): String {
    val root = JSONObject()
    val sessionsArr = JSONArray()
    listSessions(c).forEach { s ->
      val sObj = JSONObject().put("id", s.id).put("title", s.title).put("updatedAt", s.updatedAt)
      val tArr = JSONArray()
      load(c, s.id).forEach { t ->
        tArr.put(JSONObject().put("user", t.user).put("text", t.text).put("winner", t.winner))
      }
      sObj.put("turns", tArr)
      sessionsArr.put(sObj)
    }
    root.put("sessions", sessionsArr)
    val memArr = JSONArray()
    Memory.all(c).forEach { m ->
      memArr.put(
        JSONObject()
          .put("id", m.id)
          .put("key", m.key)
          .put("value", m.value)
          .put("tags", m.tags)
          .put("pinned", m.pinned)
          .put("ts", m.ts)
      )
    }
    root.put("memories", memArr)
    return root.toString(2)
  }

  fun importAllJson(c: Context, json: String): Int {
    val root = JSONObject(json)
    var imported = 0
    val memArr = root.optJSONArray("memories")
    if (memArr != null) {
      for (i in 0 until memArr.length()) {
        val m = memArr.getJSONObject(i)
        Memory.save(c, m.getString("key"), m.getString("value"), m.optString("tags", ""), m.optBoolean("pinned", false))
        imported++
      }
    }
    return imported
  }
}

object Memory {
  private val STOP_WORDS = setOf(
    "the", "and", "for", "with", "that", "this", "from", "what", "how", "can", "you",
    "are", "was", "were", "will", "about", "into", "your", "have", "has", "not", "please"
  )

  fun extractKeywords(query: String): List<String> =
    query.lowercase()
      .replace(Regex("[^a-z0-9_\\s]"), " ")
      .split(Regex("\\s+"))
      .filter { it.length >= 3 && it !in STOP_WORDS }
      .distinct()
      .take(8)

  fun all(c: Context): List<MemoryItem> {
    val db = SwarmDbHelper.get(c).readableDatabase
    val out = mutableListOf<MemoryItem>()
    db.rawQuery("SELECT id, mkey, mval, tags, pinned, ts FROM memories ORDER BY pinned DESC, ts DESC", null).use { cur ->
      while (cur.moveToNext()) {
        out.add(
          MemoryItem(
            cur.getString(0),
            cur.getString(1),
            cur.getString(2),
            cur.getString(3),
            cur.getInt(4) == 1,
            cur.getLong(5)
          )
        )
      }
    }
    return out
  }

  fun save(c: Context, key: String, value: String, tags: String = "", pinned: Boolean = false): MemoryItem {
    val db = SwarmDbHelper.get(c).writableDatabase
    val id = UUID.randomUUID().toString().take(10)
    val ts = System.currentTimeMillis()
    val item = MemoryItem(id, key.trim(), value.trim(), tags.trim(), pinned, ts)
    db.beginTransaction()
    try {
      val cv = ContentValues().apply {
        put("id", item.id)
        put("mkey", item.key)
        put("mval", item.value)
        put("tags", item.tags)
        put("pinned", if (item.pinned) 1 else 0)
        put("ts", item.ts)
      }
      db.insertWithOnConflict("memories", null, cv, SQLiteDatabase.CONFLICT_REPLACE)

      val ftsCv = ContentValues().apply {
        put("id", item.id)
        put("mkey", item.key)
        put("mval", item.value)
        put("tags", item.tags)
      }
      db.insert("memories_fts", null, ftsCv)
      db.setTransactionSuccessful()
    } finally {
      db.endTransaction()
    }
    return item
  }

  fun togglePin(c: Context, id: String, pinned: Boolean) {
    val db = SwarmDbHelper.get(c).writableDatabase
    val cv = ContentValues().apply { put("pinned", if (pinned) 1 else 0) }
    db.update("memories", cv, "id = ?", arrayOf(id))
  }

  fun search(c: Context, rawQuery: String): List<MemoryItem> {
    val db = SwarmDbHelper.get(c).readableDatabase
    val keywords = extractKeywords(rawQuery)
    val pinnedItems = all(c).filter { it.pinned }.take(5)
    if (keywords.isEmpty()) return pinnedItems

    val ftsQuery = keywords.joinToString(" OR ") { "$it*" }
    val matchedIds = mutableSetOf<String>()
    try {
      db.rawQuery("SELECT id FROM memories_fts WHERE memories_fts MATCH ? LIMIT 15", arrayOf(ftsQuery)).use { cur ->
        while (cur.moveToNext()) {
          matchedIds.add(cur.getString(0))
        }
      }
    } catch (_: Exception) {
      // Fallback to keyword LIKE if FTS syntax is rejected
    }

    val allItems = all(c)
    val results = allItems.filter { item ->
      item.pinned || item.id in matchedIds || keywords.any { kw ->
        item.key.lowercase().contains(kw) ||
          item.value.lowercase().contains(kw) ||
          item.tags.lowercase().contains(kw)
      }
    }
    return results.take(12)
  }

  fun delete(c: Context, id: String) {
    val db = SwarmDbHelper.get(c).writableDatabase
    db.delete("memories", "id = ?", arrayOf(id))
    db.delete("memories_fts", "id = ?", arrayOf(id))
  }
}

object AuditLog {
  fun record(c: Context, category: String, action: String, result: String) {
    try {
      val db = SwarmDbHelper.get(c).writableDatabase
      val cv = ContentValues().apply {
        put("category", category)
        put("action", action.take(500))
        put("result", result.take(1000))
        put("ts", System.currentTimeMillis())
      }
      db.insert("audit_log", null, cv)
    } catch (_: Exception) {}
  }

  fun list(c: Context, limit: Int = 100): List<AuditEntry> {
    val db = SwarmDbHelper.get(c).readableDatabase
    val out = mutableListOf<AuditEntry>()
    db.rawQuery("SELECT id, category, action, result, ts FROM audit_log ORDER BY ts DESC LIMIT ?", arrayOf(limit.toString())).use { cur ->
      while (cur.moveToNext()) {
        out.add(AuditEntry(cur.getLong(0), cur.getString(1), cur.getString(2), cur.getString(3), cur.getLong(4)))
      }
    }
    return out
  }

  fun clear(c: Context) {
    SwarmDbHelper.get(c).writableDatabase.delete("audit_log", null, null)
  }
}
