package com.swarmdeck

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.lang.ref.WeakReference
import java.util.Locale

/**
 * True Continuous Voice Engine for SwarmDeck V4.0:
 * - Compose-backed state (`continuous`, `listening`, `speaking`) so UI icons update immediately
 * - Auto-sends recognized speech after silence
 * - Mutes mic during TTS playback (via UtteranceProgressListener) so the app never hears itself
 * - Automatically resumes listening after TTS finishes or after an agent run completes
 * - Supports optional wake word ("hey swarm") and interrupt-to-talk
 */
object Voice {
  private var tts: TextToSpeech? = null
  private var recognizer: SpeechRecognizer? = null
  private var activityRef: WeakReference<Activity>? = null
  private val mainHandler = Handler(Looper.getMainLooper())

  var continuous by mutableStateOf(false)
  var listening by mutableStateOf(false)
  var speaking by mutableStateOf(false)
  var wakeWordOnly by mutableStateOf(false)

  private var onFinalDispatch: ((String) -> Unit)? = null
  private var onPartialUpdate: ((String) -> Unit)? = null

  fun init(ctx: Context) {
    if (tts == null) {
      tts = TextToSpeech(ctx.applicationContext) { status ->
        if (status == TextToSpeech.SUCCESS) {
          tts?.language = Locale.getDefault()
          tts?.setSpeechRate(1.02f)
          tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) {
              Bus.ui {
                speaking = true
                pauseMicForTts()
              }
            }

            override fun onDone(utteranceId: String?) {
              Bus.ui {
                speaking = false
                if (continuous && !Bus.running) {
                  mainHandler.postDelayed({ resumeIfContinuous() }, 450)
                }
              }
            }

            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) {
              Bus.ui {
                speaking = false
                if (continuous && !Bus.running) {
                  mainHandler.postDelayed({ resumeIfContinuous() }, 450)
                }
              }
            }
          })
        }
      }
    }
  }

  fun speak(text: String, flush: Boolean = true) {
    val clean = text.replace(Regex("[#*`_~]"), "").take(420).trim()
    if (clean.isEmpty()) {
      onAgentRunFinished()
      return
    }
    pauseMicForTts()
    speaking = true
    val params = Bundle()
    tts?.speak(
      clean,
      if (flush) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD,
      params,
      "swarm_utt_${System.currentTimeMillis()}"
    )
  }

  fun interruptAndListen() {
    stopSpeaking()
    if (continuous) {
      mainHandler.postDelayed({ resumeIfContinuous() }, 200)
    }
  }

  fun stopSpeaking() {
    speaking = false
    try { tts?.stop() } catch (_: Exception) {}
  }

  private fun pauseMicForTts() {
    listening = false
    try { recognizer?.stopListening() } catch (_: Exception) {}
    destroyRecognizer()
  }

  fun onAgentRunFinished() {
    if (continuous && !speaking && !Bus.running) {
      mainHandler.postDelayed({ resumeIfContinuous() }, 450)
    }
  }

  fun startContinuousSession(
    activity: Activity,
    onDispatch: (String) -> Unit,
    onPart: (String) -> Unit
  ) {
    if (!SpeechRecognizer.isRecognitionAvailable(activity)) {
      Toast.makeText(activity, "Speech recognition not available on this device", Toast.LENGTH_SHORT).show()
      return
    }
    activityRef = WeakReference(activity)
    onFinalDispatch = onDispatch
    onPartialUpdate = onPart
    continuous = true
    stopSpeaking()
    startListeningInternal(activity)
  }

  private fun resumeIfContinuous() {
    val act = activityRef?.get() ?: return
    if (continuous && !speaking && !Bus.running && !listening) {
      startListeningInternal(act)
    }
  }

  private fun startListeningInternal(activity: Activity) {
    destroyRecognizer()
    recognizer = SpeechRecognizer.createSpeechRecognizer(activity).apply {
      setRecognitionListener(object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
          listening = true
        }

        override fun onBeginningOfSpeech() {
          if (speaking) stopSpeaking()
        }

        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}

        override fun onEndOfSpeech() {
          listening = false
        }

        override fun onError(error: Int) {
          listening = false
          if (continuous && !speaking && !Bus.running && error != SpeechRecognizer.ERROR_CLIENT) {
            mainHandler.postDelayed({ resumeIfContinuous() }, 650)
          }
        }

        override fun onResults(results: Bundle?) {
          listening = false
          val raw = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            ?.firstOrNull()?.trim().orEmpty()

          if (raw.isNotEmpty()) {
            val processed = if (wakeWordOnly) {
              val lower = raw.lowercase()
              if (lower.startsWith("hey swarm") || lower.startsWith("swarm")) {
                raw.replaceFirst(Regex("(?i)^(hey\\s+)?swarm[,:\\s]*"), "").trim()
              } else ""
            } else raw

            if (processed.isNotEmpty()) {
              onFinalDispatch?.invoke(processed)
              return
            }
          }
          if (continuous && !speaking && !Bus.running) {
            mainHandler.postDelayed({ resumeIfContinuous() }, 500)
          }
        }

        override fun onPartialResults(partialResults: Bundle?) {
          val part = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
          if (!part.isNullOrEmpty()) onPartialUpdate?.invoke(part)
        }

        override fun onEvent(eventType: Int, params: Bundle?) {}
      })
    }

    val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
      putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
      putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
      putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1400L)
      putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 2)
    }
    try {
      recognizer?.startListening(intent)
    } catch (e: Exception) {
      listening = false
      Toast.makeText(activity, "Mic error: ${e.message}", Toast.LENGTH_SHORT).show()
    }
  }

  fun stopListening() {
    continuous = false
    listening = false
    try { recognizer?.stopListening() } catch (_: Exception) {}
    destroyRecognizer()
  }

  private fun destroyRecognizer() {
    try { recognizer?.destroy() } catch (_: Exception) {}
    recognizer = null
  }

  fun release() {
    stopListening()
    stopSpeaking()
    tts?.shutdown()
    tts = null
  }
}
