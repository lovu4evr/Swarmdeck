package com.swarmdeck

import android.app.Activity
import android.content.Context
import androidx.credentials.CredentialManager
import androidx.credentials.GetCredentialRequest
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential

object Auth {
  fun isGoogleConfigured(): Boolean =
    BuildConfig.GOOGLE_WEB_CLIENT_ID.isNotBlank() &&
      BuildConfig.GOOGLE_WEB_CLIENT_ID != "REPLACE_ME"

  fun continueLocalOnly(c: Context) {
    Store.secure(c).edit()
      .putString("email", "local@device")
      .putString("name", "Local Operator")
      .putString("auth_mode", "local")
      .apply()
  }

  suspend fun signInWithGoogle(a: Activity) {
    if (!isGoogleConfigured()) {
      error("Google Web Client ID not configured in gradle.properties. Use 'Continue Local-Only' instead.")
    }
    val opt = GetGoogleIdOption.Builder()
      .setFilterByAuthorizedAccounts(false)
      .setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID)
      .build()
    val res = CredentialManager.create(a).getCredential(
      a,
      GetCredentialRequest.Builder().addCredentialOption(opt).build()
    )
    val c = GoogleIdTokenCredential.createFrom(res.credential.data)
    if (c.idToken.isBlank()) error("Received empty Google ID token")
    Store.secure(a).edit()
      .putString("email", c.id)
      .putString("name", c.displayName ?: "Operator")
      .putString("idToken", c.idToken)
      .putString("auth_mode", "google")
      .apply()
  }

  fun signOut(c: Context) {
    Store.secure(c).edit()
      .remove("email")
      .remove("name")
      .remove("idToken")
      .remove("auth_mode")
      .apply()
  }

  fun isSignedIn(c: Context): Boolean =
    !Store.secure(c).getString("email", "").isNullOrEmpty()
}
