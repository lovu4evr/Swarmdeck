package com.swarmdeck

import android.content.Context
import android.content.SharedPreferences
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import okhttp3.Call
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.Collections
import java.util.concurrent.Callable
import java.util.concurrent.CompletableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors
import java.util.concurrent.Future
import java.util.concurrent.TimeUnit

const val SUF = " Be direct and useful. Reply in the same language as the user. Never invent personal data about the user. Respect privacy."

data class Agent(
  val id: String,
  val name: String,
  val role: String,
  val prompt: String,
  val dynamic: Boolean = false
)

val BASE_AGENTS = listOf(
  Agent("planner", "Planner", "Plans & step-by-step approaches", "You are Planner. Break the task into clear numbered steps."),
  Agent("researcher", "Researcher", "Facts, context & caveats", "You are Researcher. Give key facts, context and what is uncertain."),
  Agent("creator", "Creator", "Ideas, scripts & creative content", "You are Creator. Produce original, vivid ideas or content."),
  Agent("coder", "Coder", "Code & technical problems", "You are Coder. Give minimal correct code in fenced code blocks and short notes."),
  Agent("designer", "Designer", "Visual, UX & style direction", "You are Designer. Give visual and UX direction."),
  Agent("critic", "Critic", "Risks, flaws & what to avoid", "You are Critic. Point out risks and better alternatives."),
  Agent("synthesizer", "Synthesizer", "Balanced final answers", "You are Synthesizer. Produce a balanced, complete answer."),
  Agent("operator", "Operator", "Controls the phone via observe-act loop", "You are Operator. Use the phone_action tool to inspect the screen (READ_SCREEN) and perform actions."),
  Agent("browser", "Browser", "Web research & browsing", "You are Browser. Use web_search and web_fetch tools to gather verified facts."),
  Agent("artist", "Artist", "Image generation prompts", "You are Artist. Write a highly detailed image generation prompt when the user wants an image."),
  Agent("mission", "Mission", "Autonomous multi-step goals", "You are Mission Controller. Break the objective into clear sequential steps and verify each step.")
)

data class Turn(
  val user: Boolean,
  val text: String,
  val winner: String = "",
  val answers: List<Triple<String, String, Int>> = emptyList(),
  val thinking: List<String> = emptyList(),
  val missionSteps: List<MissionStep> = emptyList()
)

data class ConfirmationRequest(
  val title: String,
  val details: String,
  val future: CompletableFuture<Boolean>
)

data class MemoryProposal(
  val key: String,
  val value: String,
  val tags: String
)

object Store {
  fun p(c: Context): SharedPreferences =
    c.getSharedPreferences("swarm_prefs", Context.MODE_PRIVATE)

  fun secure(c: Context): SharedPreferences = try {
    val masterKey = MasterKey.Builder(c.applicationContext)
      .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
      .build()
    EncryptedSharedPreferences.create(
      c.applicationContext,
      "swarm_secure_prefs",
      masterKey,
      EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
      EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )
  } catch (_: Exception) {
    // Fallback for Robolectric/unit test environments without AndroidKeyStore
    c.getSharedPreferences("swarm_secure_fallback", Context.MODE_PRIVATE)
  }
}

object Bus {
  val turns = mutableStateListOf<Turn>()
  val agents = mutableStateListOf<Agent>().apply { addAll(BASE_AGENTS) }
  var running by mutableStateOf(false)
  var missionPaused by mutableStateOf(false)
  var status by mutableStateOf("")
  var streamingText by mutableStateOf("")
  val thinking = mutableStateListOf<String>()
  var subAgents by mutableStateOf<List<String>>(emptyList())
  var missionMode by mutableStateOf(false)
  val missionSteps = mutableStateListOf<MissionStep>()
  var pendingConfirmation by mutableStateOf<ConfirmationRequest?>(null)
  val memoryProposals = mutableStateListOf<MemoryProposal>()

  // Token and USD cost counters
  var totalTokens by mutableIntStateOf(0)
  var estimatedCostUsd by mutableDoubleStateOf(0.0)

  private val h = Handler(Looper.getMainLooper())
  fun ui(f: () -> Unit) {
    if (Looper.myLooper() == Looper.getMainLooper()) f() else h.post { f() }
  }

  fun add(c: Context, t: Turn) {
    ui {
      turns.add(t)
      Hist.save(c, turns)
    }
  }

  fun think(msg: String) {
    ui {
      thinking.add(msg)
      if (thinking.size > 80) thinking.removeAt(0)
    }
  }

  fun clearThinking() {
    ui {
      thinking.clear()
      subAgents = emptyList()
      streamingText = ""
    }
  }

  fun requestConfirmation(title: String, details: String): Boolean {
    val fut = CompletableFuture<Boolean>()
    ui { pendingConfirmation = ConfirmationRequest(title, details, fut) }
    return try {
      fut.get(90, TimeUnit.SECONDS)
    } catch (_: Exception) {
      false
    } finally {
      ui { pendingConfirmation = null }
    }
  }

  fun proposeMemory(key: String, value: String, tags: String = "auto") {
    ui {
      if (memoryProposals.none { it.key == key }) {
        memoryProposals.add(MemoryProposal(key, value, tags))
      }
    }
  }
}

// ── Thread-Safe Validated Dynamic Agents ──
object DynamicAgents {
  private val dynamicList = CopyOnWriteArrayList<Agent>()

  fun all(): List<Agent> = BASE_AGENTS + dynamicList

  fun syncToUi() {
    val snapshot = all()
    Bus.ui {
      Bus.agents.clear()
      Bus.agents.addAll(snapshot)
    }
  }

  fun sanitize(input: String, maxLen: Int): String =
    input.replace(Regex("[\\r\\n\\t]+"), " ")
      .replace(Regex("(?i)(ignore previous|system prompt|override|jailbreak)"), "")
      .trim()
      .take(maxLen)

  fun create(rawName: String, rawRole: String, rawPrompt: String): Agent {
    val cleanName = sanitize(rawName, 28).ifEmpty { "Specialist" }
    val cleanRole = sanitize(rawRole, 80).ifEmpty { "Task Specialist" }
    val cleanPrompt = sanitize(rawPrompt, 320).ifEmpty { "You are a helpful domain specialist." }
    val id = "dyn_" + cleanName.lowercase().replace(Regex("[^a-z0-9]"), "_").take(14)
    val agent = Agent(id, cleanName, cleanRole, "You are $cleanName ($cleanRole). $cleanPrompt", dynamic = true)
    if (BASE_AGENTS.none { it.id == id } && dynamicList.none { it.id == id }) {
      dynamicList.add(agent)
      syncToUi()
      Bus.think("Spawned validated specialist: $cleanName")
    }
    return agent
  }

  fun reset() {
    dynamicList.clear()
    syncToUi()
  }
}

// ── Real Multi-Model Router ──
object ModelRouter {
  enum class Tier { FAST, DEFAULT, STRONG, VISION }

  fun pick(c: Context, task: String, tier: Tier = Tier.DEFAULT): String {
    val p = Store.p(c)
    val defaultModel = p.getString("model", "gpt-4o-mini")!!.ifBlank { "gpt-4o-mini" }
    val fastModel = p.getString("model_fast", "")!!.ifBlank { defaultModel }
    val strongModel = p.getString("model_strong", "")!!.ifBlank { defaultModel }
    val visionModel = p.getString("model_vision", "")!!.ifBlank { strongModel }

    val lower = task.lowercase()
    return when {
      tier == Tier.FAST -> fastModel
      tier == Tier.VISION || lower.contains("image") || lower.contains("screenshot") -> visionModel
      tier == Tier.STRONG ||
        lower.contains("code") ||
        lower.contains("bug") ||
        lower.contains("kotlin") ||
        lower.contains("python") ||
        lower.contains("architecture") ||
        lower.contains("synthesize") -> strongModel
      lower.length < 45 -> fastModel
      else -> defaultModel
    }
  }

  fun recordUsage(promptChars: Int, completionChars: Int, model: String) {
    val estTokens = ((promptChars + completionChars) / 4).coerceAtLeast(1)
    val ratePer1k = if (model.contains("mini") || model.contains("flash") || model.contains("haiku")) 0.0003 else 0.003
    val cost = (estTokens / 1000.0) * ratePer1k
    Bus.ui {
      Bus.totalTokens += estTokens
      Bus.estimatedCostUsd += cost
    }
  }
}

// ── OpenAI-Compatible Client with SSE Streaming, Tool Calling, Retry & Hard Cancel ──
object Llm {
  private val http = OkHttpClient.Builder()
    .connectTimeout(20, TimeUnit.SECONDS)
    .readTimeout(120, TimeUnit.SECONDS)
    .build()

  private val activeCalls = Collections.newSetFromMap(ConcurrentHashMap<Call, Boolean>())

  fun cancelAllCalls() {
    activeCalls.forEach { call ->
      try { call.cancel() } catch (_: Exception) {}
    }
    activeCalls.clear()
  }

  fun buildHistoryMessages(system: String, hist: List<Turn>, userPrompt: String, memCtx: String): JSONArray {
    val msgs = JSONArray()
    val fullSystem = if (memCtx.isBlank()) system else "$system\n\n$memCtx"
    msgs.put(JSONObject().put("role", "system").put("content", fullSystem))
    hist.takeLast(8).forEach { turn ->
      msgs.put(
        JSONObject()
          .put("role", if (turn.user) "user" else "assistant")
          .put("content", turn.text.take(1200))
      )
    }
    msgs.put(JSONObject().put("role", "user").put("content", userPrompt))
    return msgs
  }

  fun chat(
    c: Context,
    system: String,
    user: String,
    hist: List<Turn> = emptyList(),
    memCtx: String = "",
    tier: ModelRouter.Tier = ModelRouter.Tier.DEFAULT,
    enableTools: Boolean = false,
    streamToUi: Boolean = false
  ): String {
    val p = Store.p(c)
    val sec = Store.secure(c)
    val base = p.getString("url", "")!!.trim().trimEnd('/')
    if (base.isEmpty()) error("Set API base URL in Settings")
    val apiKey = sec.getString("key", "") ?: ""
    val primaryModel = ModelRouter.pick(c, "$system $user", tier)
    val fallbackModel = p.getString("model", "gpt-4o-mini")!!.ifBlank { primaryModel }

    val msgs = buildHistoryMessages(system, hist, user, memCtx)
    return executeWithRetry(c, base, apiKey, primaryModel, fallbackModel, msgs, enableTools, streamToUi)
  }

  private fun executeWithRetry(
    c: Context,
    base: String,
    apiKey: String,
    primaryModel: String,
    fallbackModel: String,
    messages: JSONArray,
    enableTools: Boolean,
    streamToUi: Boolean
  ): String {
    var lastErr: Exception? = null
    val modelsToTry = listOf(primaryModel, fallbackModel).distinct()

    for (model in modelsToTry) {
      for (attempt in 0..2) {
        if (Brain.stop) error("Cancelled by user")
        try {
          if (streamToUi && !enableTools) {
            return executeStreaming(base, apiKey, model, messages)
          } else {
            return executeStandardOrTools(c, base, apiKey, model, messages, enableTools)
          }
        } catch (e: Exception) {
          lastErr = e
          val msg = e.message ?: ""
          if (msg.contains("429") || msg.contains("500") || msg.contains("502") || msg.contains("503")) {
            val backoffMs = 900L * (1 shl attempt)
            Bus.think("Rate limit / server busy on $model, retrying in ${backoffMs}ms…")
            Thread.sleep(backoffMs)
            continue
          } else {
            break
          }
        }
      }
    }
    throw lastErr ?: RuntimeException("LLM request failed")
  }

  private fun executeStandardOrTools(
    c: Context,
    base: String,
    apiKey: String,
    model: String,
    messages: JSONArray,
    enableTools: Boolean
  ): String {
    val workingMessages = JSONArray(messages.toString())
    var rounds = 0

    while (rounds < 4) {
      rounds++
      val bodyObj = JSONObject()
        .put("model", model)
        .put("messages", workingMessages)
      if (enableTools) {
        bodyObj.put("tools", Tools.definitionsJson())
        bodyObj.put("tool_choice", "auto")
      }

      val req = Request.Builder()
        .url("$base/chat/completions")
        .header("Authorization", "Bearer $apiKey")
        .post(bodyObj.toString().toRequestBody("application/json".toMediaType()))
        .build()

      val call = http.newCall(req)
      activeCalls.add(call)
      try {
        call.execute().use { r ->
          val raw = r.body?.string() ?: ""
          if (!r.isSuccessful) {
            // If endpoint does not support tools, retry without tools
            if (enableTools && (r.code == 400 || r.code == 422)) {
              return executeStandardOrTools(c, base, apiKey, model, messages, enableTools = false)
            }
            error("HTTP ${r.code}: ${raw.take(200)}")
          }
          val msgObj = JSONObject(raw)
            .getJSONArray("choices")
            .getJSONObject(0)
            .getJSONObject("message")

          val toolCalls = msgObj.optJSONArray("tool_calls")
          if (enableTools && toolCalls != null && toolCalls.length() > 0) {
            workingMessages.put(msgObj)
            for (i in 0 until toolCalls.length()) {
              val tc = toolCalls.getJSONObject(i)
              val callId = tc.optString("id", "call_$i")
              val fn = tc.getJSONObject("function")
              val fnName = fn.getString("name")
              val fnArgs = fn.optString("arguments", "{}")
              Bus.think("Tool call: $fnName")
              val toolOutput = Tools.execute(c, fnName, fnArgs)
              workingMessages.put(
                JSONObject()
                  .put("role", "tool")
                  .put("tool_call_id", callId)
                  .put("name", fnName)
                  .put("content", toolOutput)
              )
            }
            continue
          }

          val content = msgObj.optString("content", "")
          ModelRouter.recordUsage(workingMessages.toString().length, content.length, model)
          return content
        }
      } finally {
        activeCalls.remove(call)
      }
    }
    return "Completed tool execution rounds."
  }

  private fun executeStreaming(
    base: String,
    apiKey: String,
    model: String,
    messages: JSONArray
  ): String {
    val bodyObj = JSONObject()
      .put("model", model)
      .put("messages", messages)
      .put("stream", true)

    val req = Request.Builder()
      .url("$base/chat/completions")
      .header("Authorization", "Bearer $apiKey")
      .post(bodyObj.toString().toRequestBody("application/json".toMediaType()))
      .build()

    val call = http.newCall(req)
    activeCalls.add(call)
    val sb = StringBuilder()
    try {
      call.execute().use { r ->
        if (!r.isSuccessful) {
          val errTxt = r.body?.string() ?: ""
          error("HTTP ${r.code}: ${errTxt.take(200)}")
        }
        val stream = r.body?.byteStream() ?: error("Empty stream")
        BufferedReader(InputStreamReader(stream)).use { reader ->
          var line: String? = reader.readLine()
          while (line != null) {
            if (Brain.stop) error("Cancelled by user")
            val trimmed = line.trim()
            if (trimmed.startsWith("data:")) {
              val data = trimmed.removePrefix("data:").trim()
              if (data == "[DONE]") break
              try {
                val chunk = JSONObject(data)
                val choices = chunk.optJSONArray("choices")
                if (choices != null && choices.length() > 0) {
                  val first = choices.getJSONObject(0)
                  val delta = first.optJSONObject("delta")
                  val token = delta?.optString("content", "")
                    ?: first.optJSONObject("message")?.optString("content", "")
                    ?: ""
                  if (token.isNotEmpty()) {
                    sb.append(token)
                    val snap = sb.toString()
                    Bus.ui { Bus.streamingText = snap }
                  }
                }
              } catch (_: Exception) {
                // Non-SSE JSON fallback if server ignored stream:true
                try {
                  val full = JSONObject(data)
                  val c0 = full.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                  sb.append(c0)
                } catch (_: Exception) {}
              }
            } else if (trimmed.startsWith("{") && sb.isEmpty()) {
              // Server returned regular non-SSE JSON response
              try {
                val full = JSONObject(trimmed)
                val c0 = full.getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
                sb.append(c0)
              } catch (_: Exception) {}
            }
            line = reader.readLine()
          }
        }
      }
    } finally {
      activeCalls.remove(call)
      Bus.ui { Bus.streamingText = "" }
    }
    val out = sb.toString()
    ModelRouter.recordUsage(messages.toString().length, out.length, model)
    return out
  }
}

// ── Autonomous Brain & Step-by-Step Mission Engine ──
object Brain {
  @Volatile var stop = false
  private val pool = Executors.newFixedThreadPool(6)
  private val activeFutures = CopyOnWriteArrayList<Future<*>>()

  fun cancelAll() {
    stop = true
    Bus.missionPaused = false
    Llm.cancelAllCalls()
    activeFutures.forEach { f ->
      try { f.cancel(true) } catch (_: Exception) {}
    }
    activeFutures.clear()
  }

  private fun waitIfPaused() {
    while (Bus.missionPaused && !stop) {
      Thread.sleep(250)
    }
  }

  fun run(c: Context, q: String, hist: List<Turn>, status: (String) -> Unit): Turn {
    stop = false
    Bus.clearThinking()
    val p = Store.p(c)
    val mode = p.getString("mode", "auto")!!
    val isMission = Bus.missionMode || mode == "mission" ||
      q.lowercase().startsWith("mission:") || q.lowercase().startsWith("goal:")

    // 1. Search FTS4 Memory using extracted keywords
    val memHits = Memory.search(c, q)
    val memCtx = if (memHits.isNotEmpty()) {
      Bus.think("Recalled ${memHits.size} FTS memories")
      "Relevant user memories:\n" + memHits.joinToString("\n") { "- ${it.key}: ${it.value.take(220)}" }
    } else ""

    val enabled = DynamicAgents.all().filter { !p.getBoolean("off_${it.id}", false) }
    if (enabled.isEmpty()) return Turn(false, "All agents are disabled in the Agents tab.")

    // 2. If Mission Mode is active, execute the Plan -> Execute -> Verify -> Replan Engine
    if (isMission) {
      return runMissionEngine(c, q, hist, memCtx, status)
    }

    Bus.think("Analyzing request…")
    status("Selecting specialists…")

    // 3. Pick specialist agents (cost-aware cap)
    val picked: List<Agent> = when (mode) {
      "fast" -> enabled.filter { it.id in listOf("synthesizer", "coder") }.take(1).ifEmpty { enabled.take(1) }
      "all" -> enabled.take(4)
      else -> {
        val maxAgents = 3
        val roster = enabled.joinToString("\n") { "${it.id}: ${it.role}" }
        val out = try {
          Llm.chat(
            c = c,
            system = "You are Head Agent. Choose up to $maxAgents best agents for the user's request. If a new specialist is required, call the spawn_agent tool first. Reply one line: AGENTS: id1, id2\nRoster:\n$roster",
            user = q,
            hist = hist,
            memCtx = memCtx,
            tier = ModelRouter.Tier.FAST,
            enableTools = true
          )
        } catch (_: Exception) { "" }
        val refreshed = DynamicAgents.all().filter { !p.getBoolean("off_${it.id}", false) }
        val line = out.lines().firstOrNull { it.contains("AGENTS", true) } ?: out
        refreshed.filter { Regex("\\b${it.id}\\b").containsMatchIn(line) }.take(maxAgents)
          .ifEmpty { refreshed.filter { it.id in listOf("synthesizer", "planner", "coder") }.take(2) }
      }
    }

    Bus.think("Selected: " + picked.joinToString { it.name })
    Bus.ui { Bus.subAgents = picked.map { it.name } }

    // Single-agent fast path with direct SSE streaming
    if (picked.size == 1) {
      val single = picked.first()
      status("${single.name} streaming…")
      val useTools = single.id in listOf("operator", "browser")
      val reply = Llm.chat(
        c = c,
        system = single.prompt + SUF,
        user = q,
        hist = hist,
        memCtx = memCtx,
        tier = if (single.id == "coder") ModelRouter.Tier.STRONG else ModelRouter.Tier.DEFAULT,
        enableTools = useTools,
        streamToUi = !useTools
      )
      maybeProposeMemory(q, reply)
      return Turn(false, reply, single.id, listOf(Triple(single.id, reply, 10)), Bus.thinking.toList())
    }

    // Parallel specialist execution
    status("Deploying: " + picked.joinToString { it.name })
    val futures = picked.map { a ->
      val fut = pool.submit(Callable<String> {
        if (stop) return@Callable "ERR:cancelled"
        try {
          Bus.think("${a.name} working…")
          val needsTools = a.id in listOf("operator", "browser")
          Llm.chat(
            c = c,
            system = a.prompt + SUF,
            user = q,
            hist = hist,
            memCtx = memCtx,
            tier = if (a.id == "coder") ModelRouter.Tier.STRONG else ModelRouter.Tier.DEFAULT,
            enableTools = needsTools
          )
        } catch (e: Exception) {
          "ERR:" + (e.message ?: "failed")
        }
      })
      activeFutures.add(fut)
      a to fut
    }

    val answers = futures.map { (a, f) ->
      a.id to try { f.get(120, TimeUnit.SECONDS) } catch (_: Exception) { "ERR:timeout or cancelled" }
    }
    activeFutures.clear()
    if (stop) return Turn(false, "Stopped by user.")

    val ok = answers.filter { !it.second.startsWith("ERR:") }
    val good = ok.filter { !it.second.trim().equals("NONE", true) }.ifEmpty { ok }
    if (good.isEmpty()) return Turn(false, "Error: " + answers.first().second.removePrefix("ERR:"))

    var winner = good[0].first
    var text = good[0].second
    var ans = good.map { Triple(it.first, it.second, 8) }

    if (good.size > 1) {
      Bus.think("Synthesizing final answer (streaming)…")
      status("Synthesizing…")
      val block = good.joinToString("\n\n") { "[${it.first}]\n${it.second}" }
      val out = Llm.chat(
        c = c,
        system = "You are Ultimate Agent. Score each specialist 1-10, pick WINNER, then write the single best complete answer under FINAL:. Never mention agent names inside FINAL. Format:\nSCORES: id=score\nWINNER: id\nFINAL:\n<markdown answer>",
        user = "User request: $q\n\nSpecialist drafts:\n$block",
        hist = hist,
        memCtx = memCtx,
        tier = ModelRouter.Tier.STRONG,
        streamToUi = true
      )
      val w = Regex("WINNER:\\s*([\\w]+)").find(out)?.groupValues?.get(1)
      if (w != null && good.any { it.first == w }) winner = w
      val fi = out.indexOf("FINAL:")
      text = if (fi >= 0 && out.length > fi + 6) out.substring(fi + 6).trim() else out
      val sc = Regex("([\\w]+)\\s*=\\s*(\\d+)").findAll(out.substringBefore("FINAL:"))
        .associate { it.groupValues[1] to it.groupValues[2].toInt() }
      ans = good.map { Triple(it.first, it.second, sc[it.first] ?: 8) }
    }

    maybeProposeMemory(q, text)
    Bus.think("Done.")
    return Turn(false, text, winner, ans, Bus.thinking.toList())
  }

  private fun runMissionEngine(
    c: Context,
    objective: String,
    hist: List<Turn>,
    memCtx: String,
    status: (String) -> Unit
  ): Turn {
    val budget = Store.p(c).getInt("mission_budget", 5).coerceIn(2, 8)
    Bus.think("Planning mission (budget: $budget steps)…")
    status("Planning mission…")
    AuditLog.record(c, "MISSION", "Start mission", objective)

    val rawPlan = Llm.chat(
      c = c,
      system = "You are Mission Controller. Break the user's objective into 2 to $budget concrete sequential steps. Reply ONLY with a numbered list (1. Step one).",
      user = objective,
      hist = hist,
      memCtx = memCtx,
      tier = ModelRouter.Tier.FAST
    )

    val initialSteps = rawPlan.lines()
      .map { it.trim() }
      .filter { it.matches(Regex("^\\d+[.).]\\s+.*")) }
      .take(budget)
      .mapIndexed { idx, line ->
        MissionStep(idx + 1, line.replace(Regex("^\\d+[.).]\\s+"), ""), "PENDING")
      }
      .ifEmpty { listOf(MissionStep(1, objective, "PENDING")) }
      .toMutableList()

    Bus.ui {
      Bus.missionSteps.clear()
      Bus.missionSteps.addAll(initialSteps)
    }

    val stepOutputs = mutableListOf<String>()
    var i = 0
    while (i < initialSteps.size && i < budget && !stop) {
      waitIfPaused()
      if (stop) break

      val current = initialSteps[i].copy(status = "RUNNING")
      initialSteps[i] = current
      syncSteps(initialSteps)
      status("Mission Step ${current.index}/${initialSteps.size}: ${current.description.take(40)}…")
      Bus.think("Running Step ${current.index}: ${current.description}")

      val prevContext = if (stepOutputs.isEmpty()) "None yet." else stepOutputs.joinToString("\n\n")
      val stepResult = try {
        Llm.chat(
          c = c,
          system = "You are executing Step ${current.index} of an autonomous mission. Use available tools (web_search, web_fetch, file_write, phone_action, etc.) if needed. Produce concrete results for this step.",
          user = "Overall Objective: $objective\nCompleted Steps:\n$prevContext\n\nCurrent Step ${current.index}: ${current.description}",
          hist = hist,
          memCtx = memCtx,
          tier = ModelRouter.Tier.STRONG,
          enableTools = true
        )
      } catch (e: Exception) {
        "STEP_ERROR: ${e.message}"
      }

      // Verify step & replan if blocked
      val verification = try {
        Llm.chat(
          c = c,
          system = "You are Mission Verifier. Did the step output achieve the step goal? Reply DONE if successful, or REPLAN: <revised step description> if it failed or needs a different approach.",
          user = "Step: ${current.description}\nOutput:\n${stepResult.take(1000)}",
          tier = ModelRouter.Tier.FAST
        )
      } catch (_: Exception) { "DONE" }

      if (stepResult.startsWith("STEP_ERROR:") || verification.uppercase().startsWith("REPLAN:")) {
        val revised = verification.substringAfter("REPLAN:", "").trim()
        if (revised.isNotEmpty() && initialSteps.size < budget) {
          initialSteps[i] = current.copy(status = "BLOCKED", output = stepResult.take(300))
          val replannedStep = MissionStep(initialSteps.size + 1, revised, "PENDING")
          initialSteps.add(i + 1, replannedStep)
          Bus.think("Replanned Step: $revised")
          syncSteps(initialSteps)
          i++
          continue
        }
      }

      initialSteps[i] = current.copy(status = "DONE", output = stepResult.take(600))
      stepOutputs.add("### Step ${current.index}: ${current.description}\n$stepResult")
      syncSteps(initialSteps)
      AuditLog.record(c, "MISSION", "Completed Step ${current.index}: ${current.description}", stepResult.take(300))
      i++
    }

    status("Compiling mission report…")
    val finalSummary = if (stop) {
      "Mission stopped by user.\n\n" + stepOutputs.joinToString("\n\n")
    } else {
      Llm.chat(
        c = c,
        system = "You are Mission Controller. Synthesize the completed mission steps into a clear, actionable final deliverable for the user.",
        user = "Objective: $objective\n\nStep Results:\n${stepOutputs.joinToString("\n\n")}",
        hist = hist,
        memCtx = memCtx,
        tier = ModelRouter.Tier.STRONG,
        streamToUi = true
      )
    }

    maybeProposeMemory("Mission: ${objective.take(36)}", finalSummary)
    return Turn(
      user = false,
      text = finalSummary,
      winner = "mission",
      answers = initialSteps.map { Triple("Step ${it.index} (${it.status})", it.output, 10) },
      thinking = Bus.thinking.toList(),
      missionSteps = initialSteps.toList()
    )
  }

  private fun syncSteps(steps: List<MissionStep>) {
    val copy = steps.toList()
    Bus.ui {
      Bus.missionSteps.clear()
      Bus.missionSteps.addAll(copy)
    }
  }

  private fun maybeProposeMemory(q: String, answer: String) {
    if (answer.length > 100 && !answer.startsWith("Error")) {
      Bus.proposeMemory("Topic: ${q.take(40)}", answer.take(360), "chat")
    }
  }
}
