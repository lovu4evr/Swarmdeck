package com.swarmdeck

import android.content.Context
import android.content.Intent
import android.provider.AlarmClock
import android.provider.CalendarContract
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

object Tools {
  private val http = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .build()

  fun definitionsJson(): JSONArray {
    val tools = JSONArray()

    fun addTool(name: String, desc: String, props: JSONObject, req: List<String>) {
      val params = JSONObject()
        .put("type", "object")
        .put("properties", props)
        .put("required", JSONArray(req))
      val fn = JSONObject()
        .put("name", name)
        .put("description", desc)
        .put("parameters", params)
      tools.put(JSONObject().put("type", "function").put("function", fn))
    }

    addTool(
      "web_search",
      "Search the web via DuckDuckGo Instant Answer / HTML snippets for up-to-date facts.",
      JSONObject().put("query", JSONObject().put("type", "string").put("description", "Search query")),
      listOf("query")
    )

    addTool(
      "web_fetch",
      "Fetch plain text content from an HTTPS URL.",
      JSONObject().put("url", JSONObject().put("type", "string").put("description", "HTTPS URL to read")),
      listOf("url")
    )

    addTool(
      "file_write",
      "Write text content to a sandboxed file inside the app workspace.",
      JSONObject()
        .put("filename", JSONObject().put("type", "string"))
        .put("content", JSONObject().put("type", "string")),
      listOf("filename", "content")
    )

    addTool(
      "file_read",
      "Read text content from a sandboxed file inside the app workspace.",
      JSONObject().put("filename", JSONObject().put("type", "string")),
      listOf("filename")
    )

    addTool(
      "set_alarm",
      "Set a system alarm (requires user approval).",
      JSONObject()
        .put("hour", JSONObject().put("type", "integer"))
        .put("minute", JSONObject().put("type", "integer"))
        .put("message", JSONObject().put("type", "string")),
      listOf("hour", "minute", "message")
    )

    addTool(
      "calendar_event",
      "Draft a calendar event intent (requires user approval).",
      JSONObject()
        .put("title", JSONObject().put("type", "string"))
        .put("description", JSONObject().put("type", "string")),
      listOf("title", "description")
    )

    addTool(
      "draft_message",
      "Draft an email/SMS/share message for user confirmation.",
      JSONObject()
        .put("recipient", JSONObject().put("type", "string"))
        .put("body", JSONObject().put("type", "string")),
      listOf("recipient", "body")
    )

    addTool(
      "spawn_agent",
      "Dynamically spawn a validated specialist agent for the current mission.",
      JSONObject()
        .put("name", JSONObject().put("type", "string"))
        .put("role", JSONObject().put("type", "string"))
        .put("prompt", JSONObject().put("type", "string")),
      listOf("name", "role", "prompt")
    )

    addTool(
      "phone_action",
      "Execute an Android Accessibility action: OPEN <app>, TAP <text>, LONG_PRESS <text>, TYPE <text>, SWIPE <x1> <y1> <x2> <y2>, SCROLL, BACK, HOME, WAIT <ms>, READ_SCREEN.",
      JSONObject()
        .put("command", JSONObject().put("type", "string").put("description", "Action command string")),
      listOf("command")
    )

    addTool(
      "propose_memory",
      "Propose an important fact or conclusion to save into user's long-term FTS memory.",
      JSONObject()
        .put("key", JSONObject().put("type", "string"))
        .put("value", JSONObject().put("type", "string"))
        .put("tags", JSONObject().put("type", "string")),
      listOf("key", "value")
    )

    return tools
  }

  fun execute(c: Context, name: String, argsJson: String): String {
    val args = try { JSONObject(argsJson) } catch (_: Exception) { JSONObject() }
    val result = try {
      when (name) {
        "web_search" -> {
          val q = args.optString("query", "")
          val url = "https://api.duckduckgo.com/?q=${URLEncoder.encode(q, "UTF-8")}&format=json&no_html=1"
          val req = Request.Builder().url(url).header("User-Agent", "SwarmDeck/4.0").build()
          http.newCall(req).execute().use { r ->
            val body = JSONObject(r.body?.string() ?: "{}")
            val abstractText = body.optString("AbstractText", "")
            val related = body.optJSONArray("RelatedTopics") ?: JSONArray()
            val snippets = mutableListOf<String>()
            if (abstractText.isNotBlank()) snippets.add(abstractText)
            for (i in 0 until minOf(5, related.length())) {
              val item = related.optJSONObject(i)
              val txt = item?.optString("Text", "") ?: ""
              if (txt.isNotBlank()) snippets.add("- $txt")
            }
            if (snippets.isEmpty()) "No instant answer found for '$q'." else snippets.joinToString("\n")
          }
        }

        "web_fetch" -> {
          val url = args.optString("url", "")
          if (!url.startsWith("https://")) return "Error: Only HTTPS URLs are allowed for security."
          val req = Request.Builder().url(url).header("User-Agent", "SwarmDeck/4.0").build()
          http.newCall(req).execute().use { r ->
            val raw = r.body?.string() ?: ""
            raw.replace(Regex("<script[^>]*>[\\s\\S]*?</script>", RegexOption.IGNORE_CASE), "")
              .replace(Regex("<style[^>]*>[\\s\\S]*?</style>", RegexOption.IGNORE_CASE), "")
              .replace(Regex("<[^>]+>"), " ")
              .replace(Regex("\\s+"), " ")
              .trim()
              .take(3500)
          }
        }

        "file_write" -> {
          val safeName = File(args.optString("filename", "note.txt")).name
          val content = args.optString("content", "")
          val file = File(c.filesDir, safeName)
          file.writeText(content)
          "Saved ${content.length} chars to sandbox file '$safeName'."
        }

        "file_read" -> {
          val safeName = File(args.optString("filename", "note.txt")).name
          val file = File(c.filesDir, safeName)
          if (!file.exists()) "File '$safeName' does not exist." else file.readText().take(4000)
        }

        "set_alarm" -> {
          val h = args.optInt("hour", 8)
          val m = args.optInt("minute", 0)
          val msg = args.optString("message", "SwarmDeck Alarm")
          if (!Bus.requestConfirmation("Set Alarm", "Set system alarm for %02d:%02d (%s)?".format(h, m, msg))) {
            "User declined setting alarm."
          } else {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
              putExtra(AlarmClock.EXTRA_HOUR, h)
              putExtra(AlarmClock.EXTRA_MINUTES, m)
              putExtra(AlarmClock.EXTRA_MESSAGE, msg)
              putExtra(AlarmClock.EXTRA_SKIP_UI, false)
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(intent)
            "Alarm intent launched for %02d:%02d."
          }
        }

        "calendar_event" -> {
          val title = args.optString("title", "SwarmDeck Event")
          val desc = args.optString("description", "")
          if (!Bus.requestConfirmation("Calendar Event", "Create calendar event '$title'?")) {
            "User declined calendar event."
          } else {
            val intent = Intent(Intent.ACTION_INSERT).apply {
              data = CalendarContract.Events.CONTENT_URI
              putExtra(CalendarContract.Events.TITLE, title)
              putExtra(CalendarContract.Events.DESCRIPTION, desc)
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(intent)
            "Opened Calendar event draft '$title'."
          }
        }

        "draft_message" -> {
          val to = args.optString("recipient", "")
          val body = args.optString("body", "")
          if (!Bus.requestConfirmation("Send / Share Message", "Recipient: $to\n\n$body")) {
            "User cancelled message draft."
          } else {
            val intent = Intent(Intent.ACTION_SEND).apply {
              type = "text/plain"
              putExtra(Intent.EXTRA_SUBJECT, "To: $to")
              putExtra(Intent.EXTRA_TEXT, body)
              addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            c.startActivity(Intent.createChooser(intent, "Send Message").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            "Message share sheet opened."
          }
        }

        "spawn_agent" -> {
          val ag = DynamicAgents.create(
            args.optString("name", "Specialist"),
            args.optString("role", "Task Specialist"),
            args.optString("prompt", "Provide accurate specialist analysis.")
          )
          "Spawned dynamic agent '${ag.name}' (${ag.id})."
        }

        "phone_action" -> {
          if (!Store.p(c).getBoolean("phone", false)) {
            "Phone control is disabled in Settings."
          } else {
            val cmd = args.optString("command", "READ_SCREEN")
            PhoneControl.executeWithObservation(c, cmd)
          }
        }

        "propose_memory" -> {
          val k = args.optString("key", "Fact")
          val v = args.optString("value", "")
          val tags = args.optString("tags", "agent")
          if (v.isNotBlank()) {
            Bus.proposeMemory(k, v, tags)
            "Proposed memory '$k' for user approval."
          } else "Empty memory ignored."
        }

        else -> "Unknown tool: $name"
      }
    } catch (e: Exception) {
      "Tool '$name' error: ${e.message}"
    }
    AuditLog.record(c, "TOOL", "$name($argsJson)", result)
    return result
  }
}
