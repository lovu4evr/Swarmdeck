package com.swarmdeck

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ── GOLD / BLACK "GOD MODE" THEME ──
val BG1 = Color(0xFF040404)
val BG2 = Color(0xFF0B0805)
val EDGE = Color(0x99F5B301)
val ACC = Color(0xFFF5B301)
val ACC2 = Color(0xFFFFD25A)
val CREAM = Color(0xFFF7F2E6)
val GOLD = Color(0xFFFFC93C)
val MUTED = Color(0xFFB9A98A)
val COLORS = listOf(Color(0xFFFFC93C), Color(0xFFF5B301), Color(0xFFFFD25A), Color(0xFFE09A00), Color(0xFFFFE08A), Color(0xFFC98A00), Color(0xFFF7F2E6), Color(0xFFFFB300))
val SHAPE = RoundedCornerShape(22.dp)
val GOLD_BRUSH = Brush.linearGradient(listOf(Color(0xFFFFE08A), Color(0xFFF5B301), Color(0xFF8A5A00), Color(0xFFFFC93C)))

fun Modifier.glass(shape: Shape = SHAPE): Modifier = this
    .clip(shape)
    .background(Brush.verticalGradient(listOf(Color(0xFF17120A), Color(0xFF080604))), shape)
    .border(1.2.dp, GOLD_BRUSH, shape)

fun colorOf(id: String) = COLORS[Registry.all().indexOfFirst { it.id == id }.coerceAtLeast(0) % COLORS.size]

@Composable
fun clearColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = CREAM, unfocusedTextColor = CREAM, cursorColor = ACC2
)

fun copyText(c: Context, t: String) {
    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("swarm", t))
    Toast.makeText(c, "Copied", Toast.LENGTH_SHORT).show()
}

/** Single entry point used by the send button, quick buttons AND hands-free voice. */
fun sendMessage(c: Context, text: String) {
    val q = text.trim()
    if (q.isEmpty() || Bus.running) return
    Bus.turns.add(Turn(true, q))
    Bus.persist(c)
    Bus.running = true
    Bus.status = "Starting…"
    Bus.stream = ""
    ContextCompat.startForegroundService(c.applicationContext, Intent(c.applicationContext, AgentService::class.java).putExtra("goal", q))
}

fun resumeMission(c: Context) {
    if (Bus.running) return
    Bus.running = true
    Bus.status = "Resuming mission…"
    Bus.stream = ""
    ContextCompat.startForegroundService(c.applicationContext, Intent(c.applicationContext, AgentService::class.java).putExtra("resume", true))
}

fun newChat(c: Context) {
    if (Bus.running) return
    Bus.persist(c)
    Hist.newChat(c)
    Bus.turns.clear()
    Registry.reset()
    Bus.mission = emptyList()
}

fun userName(c: Context): String = (Store.p(c).getString("name", "") ?: "").ifBlank { "Master" }

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Bus.app = applicationContext
        if (Bus.turns.isEmpty()) Bus.turns.addAll(Hist.load(this))
        Voice.onFinal = { q -> sendMessage(applicationContext, q) }
        Voice.attach(this)
        Voice.init(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACC, background = BG1, surface = BG2, onPrimary = Color.Black)) { Root(this) } }
    }

    override fun onStart() { super.onStart(); Bus.activity = java.lang.ref.WeakReference(this); LiveBrowser.rehost(); Voice.onActivityStart(this) }
    override fun onStop() { super.onStop(); Voice.onActivityStop() }
    override fun onDestroy() { super.onDestroy(); LiveBrowser.release(); if (isFinishing) Voice.release() }
}

@Composable
fun Backdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF020202), Color(0xFF0A0703), Color(0xFF040404))))) {
        Box(Modifier.offset((-120).dp, (-80).dp).size(460.dp).background(Brush.radialGradient(listOf(Color(0x33F5B301), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomEnd).offset(120.dp, 100.dp).size(420.dp).background(Brush.radialGradient(listOf(Color(0x22F5B301), Color.Transparent))))
        content()
    }
}

@Composable
fun Root(act: Activity) {
    var splash by rememberSaveable { mutableStateOf(true) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(splash) {
        if (!splash) {
            if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
            micPerm.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    Backdrop { if (splash) Splash { splash = false } else Shell(act) }
    Bus.confirm?.let { ConfirmDialog(it) }
}

@Composable
fun Splash(done: () -> Unit) {
    val prog = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        prog.animateTo(1f, tween(2600, easing = LinearEasing))
        delay(250)
        done()
    }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        Image(painterResource(R.drawable.splash_top), null, Modifier.fillMaxWidth().align(Alignment.TopCenter), contentScale = ContentScale.FillWidth)
        Box(Modifier.fillMaxWidth().height(120.dp).align(Alignment.Center).offset(y = (-40).dp).background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black))))
        Column(Modifier.fillMaxSize().padding(horizontal = 24.dp).navigationBarsPadding(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
            Row {
                Text("SWARM", style = TextStyle(brush = Brush.linearGradient(listOf(Color.White, Color(0xFFA8A8A8))), fontSize = 40.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
                Text("DECK", style = TextStyle(brush = GOLD_BRUSH, fontSize = 40.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
            }
            Text("V5.0", color = GOLD, fontSize = 22.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Spacer(Modifier.height(10.dp))
            Text("Missions. Memory. Dynamic Agents.\nYour Rules.", color = CREAM, fontSize = 15.sp, textAlign = TextAlign.Center)
            Spacer(Modifier.height(14.dp))
            Row(Modifier.glass(RoundedCornerShape(14.dp)).padding(horizontal = 18.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("∞  ", color = GOLD, fontSize = 18.sp)
                Text("AUTONOMOUS GOD MODE AGENT", color = GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.sp)
            }
            Spacer(Modifier.height(18.dp))
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    CircularProgressIndicator(progress = { prog.value }, modifier = Modifier.size(38.dp), color = GOLD, trackColor = Color(0x33F5B301), strokeWidth = 4.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Initializing Swarm Intelligence…", color = CREAM, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                        Text("Loading your AI command center", color = MUTED, fontSize = 12.sp)
                    }
                }
                Spacer(Modifier.height(12.dp))
                LinearProgressIndicator(progress = { prog.value }, modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = GOLD, trackColor = Color(0x33F5B301))
            }
            Spacer(Modifier.height(14.dp))
            Text("“One Mind. Infinite Possibilities.”", color = GOLD, fontSize = 13.sp, fontStyle = FontStyle.Italic)
            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
fun ConfirmDialog(req: ConfirmReq) {
    AlertDialog(
        onDismissRequest = { Confirm.answer(req.id, 0) },
        containerColor = BG2,
        title = { Text(if (req.risky) "⚠ Sensitive action" else "Approve action", color = CREAM) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(req.title, color = GOLD, fontWeight = FontWeight.Bold)
                Text(req.detail, color = MUTED, fontSize = 13.sp)
                Button({ Confirm.answer(req.id, 1) }, Modifier.fillMaxWidth()) { Text("Allow once") }
                if (!req.risky) OutlinedButton({ Confirm.answer(req.id, 2) }, Modifier.fillMaxWidth()) { Text("Allow safe actions this run") }
                OutlinedButton({ Confirm.answer(req.id, 0) }, Modifier.fillMaxWidth()) { Text("Deny", color = Color(0xFFFF8A8A)) }
                Text("Tip: press Volume Down 3× to stop the agent instantly.", color = MUTED, fontSize = 11.sp)
            }
        },
        confirmButton = {}
    )
}

// ───────────────────────── Shell: drawer sidebar + header + pages ─────────────────────────
val NAV = listOf(
    Triple("chat", "Chat", Icons.Default.Chat), Triple("agents", "Agents", Icons.Default.SmartToy),
    Triple("memory", "Memory", Icons.Default.Storage), Triple("terminal", "Terminal", Icons.Default.Terminal),
    Triple("tools", "Tools", Icons.Default.Build), Triple("phone", "Phone Operator", Icons.Default.Phone),
    Triple("settings", "Settings", Icons.Default.Settings), Triple("profile", "Profile", Icons.Default.Person)
)

@Composable
fun Shell(act: Activity) {
    var page by rememberSaveable { mutableStateOf("chat") }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    BackHandler(drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(page != "chat" && !drawer.isOpen) { page = "chat" }
    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF070503), modifier = Modifier.width(290.dp)) {
                Sidebar(page) { p -> page = p; scope.launch { drawer.close() } }
            }
        }
    ) {
        Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding()) {
            TopHeader(act, { scope.launch { drawer.open() } }) { page = "settings" }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                when (page) {
                    "chat" -> ChatPage(act) { page = it }
                    "agents" -> AgentsTab(act)
                    "memory" -> MemoryTab(act)
                    "terminal" -> TermTab(act)
                    "tools" -> ToolsTab(act)
                    "phone" -> PhoneTab(act) { page = it }
                    "settings" -> SettingsTab(act)
                    else -> ProfileTab(act)
                }
            }
        }
    }
}

@Composable
fun Sidebar(page: String, go: (String) -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Image(painterResource(R.drawable.logo), "SwarmDeck", Modifier.size(96.dp).clip(CircleShape).border(1.5.dp, GOLD_BRUSH, CircleShape))
            Spacer(Modifier.height(6.dp))
            Text("SWARMDECK", style = TextStyle(brush = GOLD_BRUSH, fontSize = 20.sp, fontWeight = FontWeight.Black, letterSpacing = 1.sp))
            Text("V5.0", color = CREAM, fontSize = 12.sp)
        }
        Spacer(Modifier.height(8.dp))
        NAV.forEach { (id, label, icon) ->
            val sel = page == id
            Row(
                Modifier.fillMaxWidth().then(if (sel) Modifier.glass(RoundedCornerShape(16.dp)) else Modifier).clip(RoundedCornerShape(16.dp))
                    .clickable { go(id) }.padding(horizontal = 14.dp, vertical = 13.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(icon, label, tint = if (sel) GOLD else ACC, modifier = Modifier.size(24.dp))
                Spacer(Modifier.width(14.dp))
                Text(label, color = if (sel) GOLD else CREAM, fontSize = 16.sp, fontWeight = if (sel) FontWeight.Bold else FontWeight.Medium)
            }
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).clickable { go("memory") }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("∞", color = GOLD, fontSize = 30.sp)
            Spacer(Modifier.width(10.dp))
            Column {
                Text("Long-term Memory", color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                Text("Always Learning…", color = MUTED, fontSize = 11.sp)
            }
        }
        Image(painterResource(R.drawable.orb), null, Modifier.fillMaxWidth().height(110.dp).clip(RoundedCornerShape(18.dp)), contentScale = ContentScale.Crop)
    }
}

// ───────────────────────── Header ─────────────────────────
@Composable
fun TopHeader(c: Context, openMenu: () -> Unit, openSettings: () -> Unit) {
    val p = Store.p(c)
    @Suppress("UNUSED_VARIABLE") val ver = Registry.version
    val active = Registry.all().count { !p.getBoolean("off_${it.id}", false) && (it.id != "operator" || p.getBoolean("phone", false)) }
    val configured = remember(Bus.running, Bus.calls) { Profiles.active(c).url.isNotBlank() }
    val green = Color(0xFF34D399)
    val (dot, label) = when {
        Bus.running -> GOLD to "Working…"
        configured -> green to "Online"
        else -> Color(0xFFFF8A8A) to "Set API key"
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 4.dp, vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(openMenu) { Icon(Icons.Default.Menu, "Menu", tint = GOLD) }
        Image(painterResource(R.drawable.logo), null, Modifier.size(34.dp).clip(CircleShape).border(1.dp, GOLD_BRUSH, CircleShape))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text("SwarmDeck", style = TextStyle(brush = GOLD_BRUSH, fontSize = 19.sp, fontWeight = FontWeight.Black, fontStyle = FontStyle.Italic))
            Text("V5.0 • Autonomous God Mode", color = ACC2, fontSize = 9.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(8.dp).clip(CircleShape).background(dot))
                Spacer(Modifier.width(4.dp))
                Text(label, color = dot, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            }
            Text("$active Agents Active", color = MUTED, fontSize = 9.sp)
        }
        IconButton({
            if (Voice.continuous) { Voice.stopContinuous(); Toast.makeText(c, "Hands-free voice OFF", Toast.LENGTH_SHORT).show() }
            else { Voice.startContinuous(c as Activity); Toast.makeText(c, "Hands-free voice ON - just talk", Toast.LENGTH_SHORT).show() }
        }) { Icon(Icons.Default.GraphicEq, "Hands-free voice", tint = if (Voice.listening) green else if (Voice.continuous) GOLD else MUTED) }
        IconButton(openSettings) { Icon(Icons.Default.Settings, "Settings", tint = GOLD) }
    }
}

@Composable
fun Pill(icon: ImageVector, label: String, active: Boolean = false, onClick: () -> Unit) {
    val sh = RoundedCornerShape(24.dp)
    Row(
        Modifier.clip(sh).then(if (active) Modifier.background(GOLD_BRUSH, sh) else Modifier.glass(sh)).clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = if (active) Color.Black else GOLD, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(6.dp))
        Text(label, color = if (active) Color.Black else CREAM, fontSize = 13.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
fun BotAvatar(size: Int = 34) =
    Image(painterResource(R.drawable.logo), null, Modifier.size(size.dp).clip(CircleShape).border(1.dp, GOLD_BRUSH, CircleShape), contentScale = ContentScale.Crop)

@Composable
fun UserAvatar() = Box(Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF1B1710)).border(1.dp, Color(0x66F7F2E6), CircleShape), Alignment.Center) {
    Icon(Icons.Default.Person, null, tint = CREAM, modifier = Modifier.size(22.dp))
}

// ───────────────────────── Chat page ─────────────────────────
@Composable
fun HeadCard(c: Context) {
    val p = Store.p(c)
    var mode by remember { mutableStateOf(p.getString("mode", "auto") ?: "auto") }
    var menu by remember { mutableStateOf(false) }
    val label = when (mode) { "fast" -> "Fast"; "mission" -> "Mission"; "all" -> "All Agents"; else -> "Multi-Model" }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
        BotAvatar(44)
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Head Agent", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                Text("  👑", fontSize = 15.sp)
            }
            Text("Your AI Swarm Commander", color = MUTED, fontSize = 12.sp)
        }
        Box {
            Pill(Icons.Default.AutoAwesome, label) { menu = true }
            DropdownMenu(menu, { menu = false }, containerColor = BG2) {
                listOf("auto" to "🧠 Auto - Head picks agents", "fast" to "⚡ Fast - one agent", "all" to "🌐 All agents", "mission" to "🎯 Mission - multi-step").forEach { (m, l) ->
                    DropdownMenuItem({ Text(l + if (mode == m) "  ✓" else "", color = CREAM) }, { mode = m; p.edit().putString("mode", m).apply(); menu = false })
                }
                HorizontalDivider(color = EDGE)
                val active = Profiles.active(c).name
                Profiles.all(c).forEach { pr ->
                    DropdownMenuItem({ Text("API: ${pr.name}" + if (pr.name == active) "  ✓" else "", color = GOLD) }, { Profiles.setActive(c, pr.name); menu = false })
                }
            }
        }
    }
}

@Composable
fun ChatPage(c: Context, goto: (String) -> Unit) {
    var input by remember { mutableStateOf("") }
    var showChats by remember { mutableStateOf(false) }
    var showMission by remember { mutableStateOf(false) }
    var showAgent by remember { mutableStateOf(false) }
    var showAudit by remember { mutableStateOf(false) }
    var more by remember { mutableStateOf(false) }
    var deep by remember { mutableStateOf(Store.p(c).getBoolean("deep", false)) }
    var tick by remember { mutableIntStateOf(0) }
    val ls = rememberLazyListState()
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input = if (input.isBlank()) it else "$input $it" }
    }
    val savedMission = remember(Bus.running, Bus.turns.size, tick) { if (Bus.running) null else Mission.saved(c) }
    LaunchedEffect(Bus.turns.size, Bus.status, Bus.stream.length / 40) {
        val n = ls.layoutInfo.totalItemsCount
        if (n > 0) ls.scrollToItem(n - 1)
    }
    fun send() { val q = input.trim(); if (q.isNotEmpty() && !Bus.running) { input = ""; sendMessage(c, q) } }

    if (showChats) ChatsDialog(c) { showChats = false }
    if (showAudit) AuditDialog(c) { showAudit = false }
    if (showMission) MissionDialog(c, input) { started -> if (started) input = ""; showMission = false }
    if (showAgent) AgentDialog { showAgent = false }

    Column(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
        HeadCard(c)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Image(painterResource(R.drawable.bg_hornet), null, Modifier.align(Alignment.BottomEnd).size(260.dp).alpha(0.22f), contentScale = ContentScale.Crop)
            LazyColumn(Modifier.fillMaxSize(), state = ls) {
                if (Bus.turns.isEmpty() && !Bus.running) item { WelcomeBubble(c, goto) { showMission = true } }
                if (savedMission != null) item {
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("Unfinished mission", color = GOLD, fontWeight = FontWeight.Bold)
                        Text(savedMission.first.take(120), color = CREAM, fontSize = 13.sp)
                        Text("${savedMission.second.count { it.status == "DONE" }}/${savedMission.second.size} steps done", color = MUTED, fontSize = 12.sp)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button({ resumeMission(c) }) { Text("Resume") }
                            OutlinedButton({ Mission.clear(c); tick++ }) { Text("Discard") }
                        }
                    }
                }
                items(Bus.turns) { t -> Bubble(c, t) }
                if (Bus.running && Bus.stream.isNotEmpty()) item { Bubble(c, Turn(false, Bus.stream), live = true) }
                if (Bus.liveActive) item { LiveCard() }
                if (Bus.running) item { RunningCard() }
            }
        }
        if (Voice.continuous && (Voice.listening || Voice.partial.isNotEmpty())) {
            Text("🎤 " + Voice.partial.ifEmpty { "Listening…" }, color = Color(0xFF34D399), fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        } else if (Voice.continuous && Voice.speaking) {
            Text("🔊 Speaking… tap the speaker to interrupt", color = GOLD, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(52.dp).glass(CircleShape).clickable {
                if (Voice.speaking) Voice.stopSpeaking()
                try { mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)) }
                catch (e: Exception) { Toast.makeText(c, "Voice input isn't available", Toast.LENGTH_SHORT).show() }
            }, Alignment.Center) { Icon(if (Voice.speaking) Icons.Default.VolumeOff else Icons.Default.Mic, "Voice", tint = GOLD) }
            Spacer(Modifier.width(8.dp))
            TextField(
                input, { input = it }, Modifier.weight(1f).glass(RoundedCornerShape(26.dp)), placeholder = { Text("Type your message or use voice…", color = MUTED) },
                maxLines = 4, colors = clearColors(), keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { send() })
            )
            Spacer(Modifier.width(8.dp))
            Box(Modifier.size(52.dp).clip(CircleShape).background(GOLD_BRUSH).clickable { if (Bus.running) Brain.stopAll("Stop button") else send() }, Alignment.Center) {
                Icon(if (Bus.running) Icons.Default.Stop else Icons.Default.Send, if (Bus.running) "Stop" else "Send", tint = Color.Black)
            }
        }
        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Pill(Icons.Default.Bolt, "Quick Mission") {
                if (input.isNotBlank() && !Bus.running) { val q = input; input = ""; sendMessage(c, "mission: $q") } else showMission = true
            }
            Pill(Icons.Default.Psychology, "Think Deep", active = deep) {
                deep = !deep; Store.p(c).edit().putBoolean("deep", deep).apply()
                Toast.makeText(c, if (deep) "Deep thinking ON (up to 6 agents, careful reasoning)" else "Deep thinking OFF", Toast.LENGTH_SHORT).show()
            }
            Pill(Icons.Default.AutoFixHigh, "Create Agent") { showAgent = true }
            Box {
                Pill(Icons.Default.Apps, "More") { more = true }
                DropdownMenu(more, { more = false }, containerColor = BG2) {
                    @Composable fun item(t: String, f: () -> Unit) = DropdownMenuItem({ Text(t, color = CREAM) }, { more = false; f() })
                    item("➕  New chat") { newChat(c) }
                    item("🕘  Chat history") { showChats = true }
                    item("📤  Share chat") {
                        val txt = Bus.turns.joinToString("\n\n") { (if (it.user) "You: " else "SwarmDeck: ") + it.text }
                        if (txt.isBlank()) Toast.makeText(c, "Nothing to share yet", Toast.LENGTH_SHORT).show()
                        else c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, txt), "Share chat").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                    }
                    item("📊  Usage stats") { Toast.makeText(c, "${Bus.calls} calls · ${Bus.tokens} tokens", Toast.LENGTH_LONG).show() }
                    item("🧾  Audit log") { showAudit = true }
                    item("🛠  Tools") { goto("tools") }
                }
            }
        }
    }
}

@Composable
fun WelcomeBubble(c: Context, goto: (String) -> Unit, openMission: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        BotAvatar()
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f, fill = false).glass(RoundedCornerShape(22.dp, 22.dp, 22.dp, 6.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("Welcome back, ${userName(c)}! 👑", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text("I'm your SwarmDeck Head Agent, ready to deploy your AI swarm. Here's what I can do for you:", color = CREAM, fontSize = 14.sp)
            listOf<Pair<String, () -> Unit>>(
                "Plan multi-step missions" to openMission,
                "Activate specialized agents" to { goto("agents") },
                "Access long-term memory" to { goto("memory") },
                "Automate your phone" to { goto("phone") },
                "Run terminal commands" to { goto("terminal") },
                "And much more…" to { goto("tools") }
            ).forEach { (t, f) ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable { f() }.padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = GOLD, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(10.dp))
                    Text(t, color = CREAM, fontSize = 14.sp)
                }
            }
            Text("What's your next mission? 🎯", color = Color.White, fontSize = 14.sp, modifier = Modifier.padding(top = 4.dp))
        }
    }
}

@Composable
fun RunningCard() {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        BotAvatar()
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f, fill = false).glass(RoundedCornerShape(22.dp, 22.dp, 22.dp, 6.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = GOLD)
                Spacer(Modifier.width(10.dp))
                Text(Bus.status.ifEmpty { "Thinking…" }, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                if (Bus.mission.isNotEmpty()) IconButton({ Bus.missionPaused = !Bus.missionPaused }) {
                    Icon(if (Bus.missionPaused) Icons.Default.PlayArrow else Icons.Default.Pause, "Pause/Resume mission", tint = GOLD)
                }
            }
            if (Bus.subAgents.isNotEmpty()) Text("Sub-agents: " + Bus.subAgents.joinToString(" · "), color = ACC2, fontSize = 11.sp)
            Bus.thinking.takeLast(3).forEach {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.CheckCircle, null, tint = Color(0xFF34D399), modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(it, color = CREAM, fontSize = 12.sp)
                }
            }
            if (Bus.mission.isNotEmpty()) {
                Text("Mission: ${Bus.missionObjective.take(80)}", color = GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Bus.mission.forEach { s ->
                    val ic = when (s.status) { "DONE" -> "✓"; "BLOCKED" -> "✗"; "RUNNING" -> "▶"; "RETRY" -> "↻"; else -> "○" }
                    Text("$ic ${s.text.take(90)}", color = if (s.status == "DONE") Color(0xFF34D399) else if (s.status == "BLOCKED") Color(0xFFFF8A8A) else CREAM, fontSize = 12.sp)
                }
                val frac = Bus.mission.count { it.status == "DONE" }.toFloat() / Bus.mission.size
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LinearProgressIndicator(progress = { frac }, modifier = Modifier.weight(1f).height(6.dp).clip(CircleShape), color = GOLD, trackColor = Color(0x33F5B301))
                    Text("  ${(frac * 100).toInt()}%", color = GOLD, fontSize = 12.sp)
                }
            } else {
                LinearProgressIndicator(Modifier.fillMaxWidth().height(6.dp).clip(CircleShape), color = GOLD, trackColor = Color(0x33F5B301))
            }
        }
    }
}

@Composable
fun MissionDialog(c: Context, initial: String, close: (Boolean) -> Unit) {
    var t by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = { close(false) }, containerColor = BG2, title = { Text("Quick Mission", color = CREAM) },
        text = { OutlinedTextField(t, { t = it }, Modifier.fillMaxWidth(), label = { Text("Describe your mission") }, minLines = 3) },
        confirmButton = { TextButton({ if (t.isNotBlank() && !Bus.running) { sendMessage(c, "mission: ${t.trim()}"); close(true) } }) { Text("Start", color = GOLD) } },
        dismissButton = { TextButton({ close(false) }) { Text("Cancel") } }
    )
}

@Composable
fun AgentDialog(close: () -> Unit) {
    val c = LocalContextCompat()
    var n by remember { mutableStateOf("") }
    var r by remember { mutableStateOf("") }
    var pr by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = close, containerColor = BG2, title = { Text("Create Agent", color = CREAM) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(n, { n = it }, label = { Text("Name") }, singleLine = true)
                OutlinedTextField(r, { r = it }, label = { Text("Role (one line)") }, singleLine = true)
                OutlinedTextField(pr, { pr = it }, label = { Text("Instructions (10+ chars)") }, minLines = 2)
                Text("Lasts for this chat. Custom agents never get phone or tools.", color = MUTED, fontSize = 11.sp)
            }
        },
        confirmButton = {
            TextButton({
                val a = Registry.addDynamic(n, r, pr)
                if (a == null) Toast.makeText(c, "Rejected: needs a name, role, 10+ chars, no unsafe words, max 5 agents", Toast.LENGTH_LONG).show()
                else { Toast.makeText(c, "Agent ${a.name} created", Toast.LENGTH_SHORT).show(); close() }
            }) { Text("Create", color = GOLD) }
        },
        dismissButton = { TextButton(close) { Text("Cancel") } }
    )
}

@Composable
fun LocalContextCompat(): Context = androidx.compose.ui.platform.LocalContext.current

@Composable
fun ChatsDialog(c: Context, close: () -> Unit) {
    var list by remember { mutableStateOf(Hist.list(c)) }
    AlertDialog(
        onDismissRequest = close, containerColor = BG2,
        title = { Text("Chats", color = CREAM) },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                if (list.isEmpty()) item { Text("No saved chats yet.", color = MUTED) }
                items(list) { ci ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TextButton({
                            if (!Bus.running) {
                                Bus.persist(c); Hist.setCurrent(c, ci.id)
                                Bus.turns.clear(); Bus.turns.addAll(Hist.load(c, ci.id)); close()
                            }
                        }, Modifier.weight(1f)) { Text(ci.title.ifEmpty { "(untitled)" }, maxLines = 1, color = CREAM) }
                        IconButton({
                            if (!Bus.running) {
                                val wasCurrent = ci.id == Hist.currentId(c)
                                Hist.delete(c, ci.id)
                                if (wasCurrent) newChat(c)
                                list = Hist.list(c)
                            }
                        }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFFF8A8A)) }
                    }
                }
            }
        },
        confirmButton = { TextButton(close) { Text("Close") } }
    )
}

@Composable
fun Bubble(c: Context, t: Turn, live: Boolean = false) {
    var open by remember { mutableStateOf(false) }
    var think by remember { mutableStateOf(false) }
    val sh = if (t.user) RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp) else RoundedCornerShape(22.dp, 22.dp, 22.dp, 6.dp)
    val time = remember(t.ts) { if (t.ts > 0) SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(t.ts)) else "" }
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = if (t.user) Arrangement.End else Arrangement.Start, verticalAlignment = Alignment.Top) {
        if (!t.user) { BotAvatar(); Spacer(Modifier.width(8.dp)) }
        Column(Modifier.weight(1f, fill = false).glass(sh).padding(14.dp)) {
            if (!t.user) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = GOLD, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
                    Text(if (live) "Ultimate Agent · writing…" else "Ultimate Agent", color = GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (t.winner.isNotEmpty() && t.winner != "mission") { Spacer(Modifier.width(8.dp)); Text("⭐ ${nameOf(t.winner)}", color = ACC2, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (t.user) SelectionContainer { Text(t.text, color = Color.White, fontSize = 15.sp) }
            else SelectionContainer { MdText(c, t.text) }
            if (!t.user && t.missionSteps.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = EDGE)
                Text("Mission steps", color = GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                t.missionSteps.forEach { Text(it, color = Color(0xFFE5DCC8), fontSize = 12.sp) }
            }
            if (!t.user && !live) {
                Row {
                    TextButton({ copyText(c, t.text) }) { Text("Copy", color = ACC2) }
                    TextButton({ c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.text), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Share", color = ACC2) }
                    TextButton({
                        Bus.background { Memory.save(c, "From chat: " + t.text.take(40), t.text.take(1500)) }
                        Toast.makeText(c, "Saved to memory", Toast.LENGTH_SHORT).show()
                    }) { Text("Save", color = ACC2) }
                }
                Row {
                    if (t.answers.size > 1) TextButton({ open = !open }) { Text("Agents (${t.answers.size})", color = ACC2) }
                    if (t.thinking.isNotEmpty()) TextButton({ think = !think }) { Text("Thinking", color = ACC2) }
                }
                if (think) t.thinking.forEach { Text("› $it", color = MUTED, fontSize = 11.sp) }
                if (open) t.answers.forEach { (id, s, n) ->
                    HorizontalDivider(color = EDGE, modifier = Modifier.padding(vertical = 6.dp))
                    Text(nameOf(id) + (if (n > 0) "  ·  $n/10" else ""), color = colorOf(id), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(s, color = Color(0xFFE5DCC8), fontSize = 13.sp)
                }
            }
            if (time.isNotEmpty() && !live) Text(time + if (t.user) "  ✓✓" else "", color = if (t.user) Color(0xFF7DD3FC) else MUTED, fontSize = 10.sp, modifier = Modifier.align(Alignment.End).padding(top = 4.dp))
        }
        if (t.user) { Spacer(Modifier.width(8.dp)); UserAvatar() }
    }
}
