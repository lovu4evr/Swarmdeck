# SwarmDeck
Eight free AI agents (Planner, Researcher, Creator, Coder, Designer, Critic, Synthesizer, Operator) on one OpenAI-compatible API. Google sign-in, voice input, background mode, phone control.

## Setup
1. Google Cloud Console > Credentials: create an OAuth **Web** client and an **Android** client (package `com.swarmdeck`, SHA-1 `08:FE:2B:FC:FD:A2:92:24:A3:6D:FA:41:D2:34:62:19:B6:E7:ED:36` from `app/debug.keystore`).
2. GitHub repo > Settings > Secrets > Actions: add `GOOGLE_WEB_CLIENT_ID` (the Web client ID).
3. Push to `main`. Download the APK from the Actions run (Artifacts). Tag `v1.0` to publish it as a Release.
4. In the app: Settings > FREELLMAPI URL (ends in `/v1`), key, model > Save & test.
5. Phone control: Settings > Enable phone-control service > turn on SwarmDeck.
