package com.swarmdeck
import android.accessibilityservice.AccessibilityService
import android.app.*
import android.content.Intent
import android.os.*
import android.view.accessibility.*

class AgentService:Service(){
 override fun onBind(i:Intent?):IBinder?=null
 override fun onStartCommand(i:Intent?,f:Int,id:Int):Int{
  val goal=i?.getStringExtra("goal")?:return START_NOT_STICKY
  getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("swarm","Swarm",NotificationManager.IMPORTANCE_LOW))
  startForeground(1,Notification.Builder(this,"swarm").setContentTitle("SwarmDeck is working").setContentText(goal.take(60)).setSmallIcon(android.R.drawable.stat_notify_sync).build())
  Handler(Looper.getMainLooper()).post{Bus.running=true}
  Thread{ Swarm.run(this,goal){a,t->Bus.post(a,t)}; stopSelf() }.start()
  return START_NOT_STICKY
 }
 override fun onDestroy(){ Swarm.stop=true; Handler(Looper.getMainLooper()).post{Bus.running=false} }
}

class PhoneControl:AccessibilityService(){
 override fun onServiceConnected(){inst=this}
 override fun onUnbind(i:Intent?):Boolean{inst=null;return super.onUnbind(i)}
 override fun onAccessibilityEvent(e:AccessibilityEvent?){}
 override fun onInterrupt(){}
 companion object{
  var inst:PhoneControl?=null
  fun run(cmd:String):String{
   val s=inst?:return "Enable the phone-control service first"
   val parts=cmd.trim().split(" ",limit=2); val op=parts[0].uppercase(); val arg=parts.getOrNull(1)?:""
   return when(op){
    "OPEN"->{
     val pm=s.packageManager
     val li=pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),0).firstOrNull{it.loadLabel(pm).toString().contains(arg,true)}
     if(li==null)"App not found: $arg" else{ s.startActivity(pm.getLaunchIntentForPackage(li.activityInfo.packageName)!!.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "Opened $arg" }
    }
    "TAP"->{
     var n=s.rootInActiveWindow?.findAccessibilityNodeInfosByText(arg)?.firstOrNull()
     while(n!=null&&!n.isClickable)n=n.parent
     if(n?.performAction(AccessibilityNodeInfo.ACTION_CLICK)==true)"Tapped $arg" else "Couldn't tap $arg"
    }
    "TYPE"->{
     val f=s.rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
     val b=Bundle().apply{putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,arg)}
     if(f?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT,b)==true)"Typed text" else "No text field focused"
    }
    "BACK"->{s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK);"Went back"}
    "HOME"->{s.performGlobalAction(AccessibilityService.GLOBAL_ACTION_HOME);"Went home"}
    "SCROLL"->{s.rootInActiveWindow?.let{scrollable(it)}?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD);"Scrolled"}
    else->"Unknown action: $cmd"
   }
  }
  private fun scrollable(n:AccessibilityNodeInfo):AccessibilityNodeInfo?{
   if(n.isScrollable)return n
   for(i in 0 until n.childCount){ n.getChild(i)?.let{c->scrollable(c)?.let{r->return r}} }
   return null
  }
 }
}
