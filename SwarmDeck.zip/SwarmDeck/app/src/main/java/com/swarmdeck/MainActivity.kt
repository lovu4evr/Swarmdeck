package com.swarmdeck
import android.Manifest
import android.app.Activity
import android.content.*
import android.os.*
import android.provider.Settings
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.*
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

val BG=Color(0xFF0B0F1A); val CARD=Color(0xFF151B2E); val ACC=Color(0xFF7C5CFF)
val COLORS=listOf(Color(0xFFFF3B5C),Color(0xFF7C5CFF),Color(0xFF22D3EE),Color(0xFFFBBF24),Color(0xFF34D399),Color(0xFFF472B6),Color(0xFFFB923C),Color(0xFF60A5FA))
data class Msg(val agent:String,val text:String)
object Bus{
 val msgs=mutableStateListOf<Msg>(); var running by mutableStateOf(false)
 fun post(a:String,t:String){ Handler(Looper.getMainLooper()).post{
  val i=msgs.lastIndex
  if(i>=0&&msgs[i].agent==a&&msgs[i].text=="…thinking")msgs[i]=Msg(a,t) else msgs.add(Msg(a,t)) } }
}

class MainActivity:ComponentActivity(){
 override fun onCreate(s:Bundle?){ super.onCreate(s)
  setContent{ MaterialTheme(colorScheme=darkColorScheme(primary=ACC,background=BG,surface=CARD)){ App(this) } } }
}

@Composable fun App(act:Activity){
 var signed by remember{mutableStateOf(Store.p(act).getString("email","")!!.isNotEmpty())}
 val notif=rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()){}
 LaunchedEffect(Unit){ if(Build.VERSION.SDK_INT>=33)notif.launch(Manifest.permission.POST_NOTIFICATIONS) }
 if(!signed)Login(act){signed=true} else Main(act){signed=false}
}

@Composable fun Login(act:Activity,done:()->Unit){
 val scope=rememberCoroutineScope(); var err by remember{mutableStateOf("")}
 Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BG,Color(0xFF1B1140)))).padding(32.dp),Arrangement.Center,Alignment.CenterHorizontally){
  Icon(Icons.Default.Hub,null,tint=ACC,modifier=Modifier.size(72.dp))
  Text("SwarmDeck",fontSize=34.sp,fontWeight=FontWeight.Bold,color=Color.White)
  Text("Many free AI agents. One API. Your phone.",color=Color.Gray,textAlign=TextAlign.Center)
  Spacer(Modifier.height(32.dp))
  Button({scope.launch{ try{Auth.signIn(act);done()}catch(e:Exception){err=e.message?:"Sign-in failed"} }},Modifier.fillMaxWidth().height(52.dp)){Text("Continue with Google")}
  if(err.isNotEmpty())Text(err,color=Color(0xFFFF6B6B),modifier=Modifier.padding(top=12.dp),textAlign=TextAlign.Center)
 }
}

@Composable fun Main(act:Activity,out:()->Unit){
 var tab by remember{mutableIntStateOf(0)}
 Scaffold(containerColor=BG,bottomBar={ NavigationBar(containerColor=CARD){
  listOf("Swarm" to Icons.Default.AutoAwesome,"Agents" to Icons.Default.Groups,"Settings" to Icons.Default.Settings).forEachIndexed{i,(n,ic)->
   NavigationBarItem(tab==i,{tab=i},{Icon(ic,n)},label={Text(n)}) } }}){p->
  Box(Modifier.padding(p).fillMaxSize()){ when(tab){0->SwarmTab(act);1->AgentsTab(act);else->SettingsTab(act,out)} }
 }
}

@Composable fun SwarmTab(c:Context){
 var goal by remember{mutableStateOf("")}
 var micErr by remember{mutableStateOf("")}
 val mic=rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()){r->
  r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let{goal=if(goal.isBlank())it else "$goal $it"} }
 Column(Modifier.fillMaxSize().padding(16.dp)){
  OutlinedTextField(goal,{goal=it},Modifier.fillMaxWidth(),label={Text("Give the swarm a goal")},
   trailingIcon={ IconButton({ micErr=""
    try{ mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM).putExtra(RecognizerIntent.EXTRA_PROMPT,"Speak your goal")) }
    catch(e:Exception){ micErr="Voice input isn't available on this device" } }){ Icon(Icons.Default.Mic,"Voice input",tint=ACC) } })
  if(micErr.isNotEmpty())Text(micErr,color=Color(0xFFFF6B6B))
  Row(Modifier.padding(vertical=8.dp),horizontalArrangement=Arrangement.spacedBy(8.dp)){
   Button({ if(goal.isNotBlank()){ Bus.msgs.clear(); ContextCompat.startForegroundService(c,Intent(c,AgentService::class.java).putExtra("goal",goal)) } },enabled=!Bus.running){Text("Launch (keeps running in background)")}
   OutlinedButton({ Swarm.stop=true; c.stopService(Intent(c,AgentService::class.java)) },enabled=Bus.running){Text("Stop")}
  }
  LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){ items(Bus.msgs){m->
   val i=AGENTS.indexOfFirst{it.id==m.agent}
   Card(colors=CardDefaults.cardColors(CARD)){Column(Modifier.padding(14.dp)){
    Text(AGENTS[i].name,color=COLORS[i%COLORS.size],fontWeight=FontWeight.Bold); Text(m.text,color=Color.White) }} }}
 }
}

@Composable fun AgentsTab(c:Context){
 LazyColumn(Modifier.padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ items(AGENTS){a->
  var on by remember{mutableStateOf(!Store.p(c).getBoolean("off_${a.id}",false))}
  Card(colors=CardDefaults.cardColors(CARD)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){
   Column(Modifier.weight(1f)){Text(a.name,color=Color.White,fontWeight=FontWeight.Bold);Text(a.role,color=Color.Gray)}
   Switch(on,{on=it;Store.p(c).edit().putBoolean("off_${a.id}",!it).apply()}) }} }}
}

@Composable fun SettingsTab(c:Context,out:()->Unit){
 val p=Store.p(c); val scope=rememberCoroutineScope()
 var url by remember{mutableStateOf(p.getString("url","")!!)}
 var key by remember{mutableStateOf(p.getString("key","")!!)}
 var model by remember{mutableStateOf(p.getString("model","auto")!!)}
 var phone by remember{mutableStateOf(p.getBoolean("phone",false))}
 var status by remember{mutableStateOf("")}
 Column(Modifier.padding(16.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(10.dp)){
  Text("Signed in as ${p.getString("email","")}",color=Color.Gray)
  OutlinedTextField(url,{url=it},Modifier.fillMaxWidth(),label={Text("FREELLMAPI base URL (ends in /v1)")},singleLine=true)
  OutlinedTextField(key,{key=it},Modifier.fillMaxWidth(),label={Text("API key")},singleLine=true,visualTransformation=PasswordVisualTransformation())
  OutlinedTextField(model,{model=it},Modifier.fillMaxWidth(),label={Text("Model")},singleLine=true)
  Button({ p.edit().putString("url",url).putString("key",key).putString("model",model).apply(); status="Testing…"
   scope.launch(Dispatchers.IO){ status=try{"✓ "+Llm.chat(c,"Reply with OK","ping").take(40)}catch(e:Exception){"✗ ${e.message}"} } },Modifier.fillMaxWidth()){Text("Save & test connection")}
  Text(status,color=Color.Gray)
  Row(verticalAlignment=Alignment.CenterVertically){Text("Let Operator control my phone",Modifier.weight(1f),color=Color.White);Switch(phone,{phone=it;p.edit().putBoolean("phone",it).apply()})}
  OutlinedButton({c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))},Modifier.fillMaxWidth()){Text("Enable phone-control service")}
  TextButton({p.edit().remove("email").apply();out()}){Text("Sign out")}
 }
}
