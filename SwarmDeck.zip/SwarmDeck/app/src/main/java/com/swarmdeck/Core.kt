package com.swarmdeck
import android.content.Context
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.util.concurrent.TimeUnit

data class Agent(val id:String,val name:String,val role:String,val prompt:String)
val AGENTS=listOf(
 Agent("planner","Planner","Breaks goals into steps","You are Planner. Break the goal into 3-5 short numbered steps."),
 Agent("researcher","Researcher","Facts, angles, context","You are Researcher. List the key facts, angles and pitfalls relevant to the goal and plan."),
 Agent("creator","Creator","Bold ideas & content","You are Creator. Produce original, vivid ideas or content for the goal, following the plan."),
 Agent("coder","Coder","Code & technical solutions","You are Coder. If the goal needs code or technical steps, give a minimal working solution; otherwise say what tools or tech would help."),
 Agent("designer","Designer","Look, feel & UX","You are Designer. Suggest visual and UX direction (style, layout, colors, tone) that fits the goal."),
 Agent("critic","Critic","Finds flaws, fixes them","You are Critic. Review the work so far; list flaws and concrete fixes, briefly."),
 Agent("synthesizer","Synthesizer","Merges it into one answer","You are Synthesizer. Merge the best of everything so far into one clear final answer."),
 Agent("operator","Operator","Controls your phone","You are Operator. If phone actions would help, output one per line, each starting with 'ACTION: ' then one of: OPEN <app name> | TAP <visible text> | TYPE <text> | BACK | HOME | SCROLL. If none help, write NONE.")
)
object Store{ fun p(c:Context)=c.getSharedPreferences("swarm",Context.MODE_PRIVATE) }

object Llm{
 private val http=OkHttpClient.Builder().readTimeout(90,TimeUnit.SECONDS).build()
 fun chat(c:Context,system:String,user:String):String{
  val p=Store.p(c); val base=p.getString("url","")!!.trim().trimEnd('/')
  if(base.isEmpty()) error("Set your FREELLMAPI base URL in Settings")
  val msgs=JSONArray().put(JSONObject().put("role","system").put("content",system)).put(JSONObject().put("role","user").put("content",user))
  val body=JSONObject().put("model",p.getString("model","auto")).put("messages",msgs)
  val req=Request.Builder().url("$base/chat/completions").header("Authorization","Bearer "+p.getString("key","")).post(body.toString().toRequestBody("application/json".toMediaType())).build()
  return http.newCall(req).execute().use{r->
   val t=r.body?.string()?:""
   if(!r.isSuccessful) error("HTTP ${r.code}: ${t.take(160)}")
   JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
  }
 }
}

object Swarm{
 @Volatile var stop=false
 fun run(c:Context,goal:String,say:(String,String)->Unit){
  stop=false; var ctx="Goal: $goal"
  for(a in AGENTS){
   if(stop)break
   if(Store.p(c).getBoolean("off_${a.id}",false))continue
   say(a.id,"…thinking")
   val out=try{Llm.chat(c,a.prompt+(if(a.id=="operator")"" else " Keep it under 150 words."),ctx)}catch(e:Exception){"Error: ${e.message}"}
   say(a.id,out); ctx+="\n\n[${a.name}]\n$out"
   if(a.id=="operator"&&Store.p(c).getBoolean("phone",false)){
    for(l in out.lines().filter{it.trim().startsWith("ACTION:")}){
     if(stop)break
     say("operator","▶ "+PhoneControl.run(l.substringAfter("ACTION:").trim())); Thread.sleep(1500)
    }
   }
  }
 }
}
