plugins{id("com.android.application");id("org.jetbrains.kotlin.android")}
android{
 namespace="com.swarmdeck"; compileSdk=34
 defaultConfig{applicationId="com.swarmdeck";minSdk=26;targetSdk=34;versionCode=1;versionName="1.0"
  buildConfigField("String","GOOGLE_WEB_CLIENT_ID","\"${project.findProperty("GOOGLE_WEB_CLIENT_ID")?:"REPLACE_ME"}\"")}
 signingConfigs{ if(file("debug.keystore").exists()) getByName("debug"){storeFile=file("debug.keystore");storePassword="android";keyAlias="androiddebugkey";keyPassword="android"} }
 buildFeatures{compose=true;buildConfig=true}
 composeOptions{kotlinCompilerExtensionVersion="1.5.14"}
 compileOptions{sourceCompatibility=JavaVersion.VERSION_17;targetCompatibility=JavaVersion.VERSION_17}
 kotlinOptions{jvmTarget="17"}
}
dependencies{
 implementation(platform("androidx.compose:compose-bom:2024.06.00"))
 implementation("androidx.compose.material3:material3")
 implementation("androidx.compose.material:material-icons-extended")
 implementation("androidx.activity:activity-compose:1.9.0")
 implementation("androidx.credentials:credentials:1.2.2")
 implementation("androidx.credentials:credentials-play-services-auth:1.2.2")
 implementation("com.google.android.libraries.identity.googleid:googleid:1.1.1")
 implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
