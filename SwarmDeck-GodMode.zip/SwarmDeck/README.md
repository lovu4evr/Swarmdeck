# SwarmDeck — God Mode AI Agent

Eight specialized AI agents (Planner, Researcher, Creator, Coder, Designer, Critic, Synthesizer, Operator) that collaborate on any OpenAI-compatible API to produce one ultimate answer.

**Theme:** Pure liquid glass · Deep celestial blue · Warm cream

## Features
- Multi-agent swarm with smart routing
- Google Sign-In
- Voice input
- Terminal tab
- Phone control service
- Background mode
- Beautiful liquid-glass UI

## Setup
1. Google Cloud Console > Credentials: create an OAuth **Web** client and an **Android** client (package `com.swarmdeck`, SHA-1 from `app/debug.keystore`).
2. GitHub repo > Settings > Secrets > Actions: add `GOOGLE_WEB_CLIENT_ID`.
3. Push to `main`. Download the APK from the Actions Artifacts.
4. In the app: Settings > set your OpenAI-compatible base URL (ends in `/v1`), API key, model > Save & test.
5. Phone control: Settings > Enable phone-control service.

## Theme
- Background: Deep midnight navy
- Accents: Royal blue + sky blue
- Text & highlights: Warm cream / ivory
- Surfaces: Multi-layer liquid glass with soft cream edges

---
SwarmDeck • Eight minds. One divine answer.
