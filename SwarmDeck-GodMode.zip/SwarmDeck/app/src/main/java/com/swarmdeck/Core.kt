package com.swarmdeck
import android.content.Context
import android.os.*
import androidx.compose.runtime.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.util.concurrent.*

const val SUF=" Be direct, under 200 words. Reply in the same language as the user."
data class Agent(val id:String,val name:String,val role:String,val prompt:String)
val AGENTS=listOf(
 Agent("planner","Planner","Plans & step-by-step approaches","You are Planner. Answer the user's message with a clear step-by-step plan or structured approach."),
 Agent("researcher","Researcher","Facts, context & caveats","You are Researcher. Answer with key facts, context and caveats. Say when you are unsure."),
 Agent("creator","Creator","Ideas, scripts & creative content","You are Creator. Answer with original, vivid ideas or content."),
 Agent("coder","Coder","Code & technical problems","You are Coder. Answer technical questions with minimal correct code and brief notes."),
 Agent("designer","Designer","Visual, UX & style direction","You are Designer. Answer with visual, UX and style direction."),
 Agent("critic","Critic","Risks, flaws & what to avoid","You are Critic. Answer the message, then point out risks or mistakes to avoid."),
 Agent("synthesizer","Synthesizer","Balanced everyday answers","You are Synthesizer. Give a balanced, complete, well-organized answer."),
 Agent("operator","Operator","Controls your phone","You are Operator. You can control the user's Android phone. If the message asks for a phone action, output one per line 'ACTION: ' then OPEN <app name> | TAP <visible text> | TYPE <text> | BACK | HOME | SCROLL, then one short sentence. If it is not a phone task, reply only: NONE")
)
data class Turn(val user:Boolean,val text:String,val winner:String="",val answers:List<Triple<String,String,Int>> = emptyList())
object Store{ fun p(c:Context)=c.getSharedPreferences("swarm",Context.MODE_PRIVATE) }

object Hist{
 fun save(c:Context,l:List<Turn>){
  val a=JSONArray()
  l.takeLast(60).forEach{t->
   val x=JSONArray(); t.answers.forEach{(i,s,n)->x.put(JSONObject().put("i",i).put("s",s).put("n",n))}
   a.put(JSONObject().put("u",t.user).put("t",t.text).put("w",t.winner).put("a",x)) }
  Store.p(c).edit().putString("chat",a.toString()).apply()
 }
 fun load(c:Context):List<Turn> = try{
  val a=JSONArray(Store.p(c).getString("chat","[]"))
  (0 until a.length()).map{ val o=a.getJSONObject(it); val x=o.getJSONArray("a")
   Turn(o.getBoolean("u"),o.getString("t"),o.getString("w"),(0 until x.length()).map{j->val q=x.getJSONObject(j);Triple(q.getString("i"),q.getString("s"),q.getInt("n"))}) }
 }catch(e:Exception){emptyList()}
}

object Bus{
 val turns=mutableStateListOf<Turn>()
 var running by mutableStateOf(false)
 var status by mutableStateOf("")
 private val h=Handler(Looper.getMainLooper())
 fun ui(f:()->Unit){h.post{f()}}
 fun add(c:Context,t:Turn){ui{turns.add(t);Hist.save(c,turns)}}
}

object Llm{
 private val http=OkHttpClient.Builder().readTimeout(90,TimeUnit.SECONDS).build()
 private fun once(c:Context,system:String,user:String):String{
  val p=Store.p(c); val base=p.getString("url","")!!.trim().trimEnd('/')
  if(base.isEmpty()) error("Set your FREELLMAPI base URL in Settings")
  val msgs=JSONArray().put(JSONObject().put("role","system").put("content",system)).put(JSONObject().put("role","user").put("content",user))
  val body=JSONObject().put("model",p.getString("model","auto")).put("messages",msgs)
  val req=Request.Builder().url("$base/chat/completions").header("Authorization","Bearer "+p.getString("key","")).post(body.toString().toRequestBody("application/json".toMediaType())).build()
  return http.newCall(req).execute().use{r->
   val t=r.body?.string()?:""
   if(!r.isSuccessful) error("HTTP ${r.code}: ${t.take(160)}")
   JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
  }
 }
 fun chat(c:Context,system:String,user:String):String = try{once(c,system,user)}catch(e:Exception){Thread.sleep(1200);once(c,system,user)}
}

object Brain{
 @Volatile var stop=false
 private val pool=Executors.newFixedThreadPool(4)
 fun run(c:Context,q:String,hist:List<Turn>,status:(String)->Unit):Turn{
  stop=false
  val p=Store.p(c); val mode=p.getString("mode","auto")!!
  val enabled=AGENTS.filter{!p.getBoolean("off_${it.id}",false)}
  if(enabled.isEmpty())return Turn(false,"All agents are off. Turn some on in the Agents tab.")
  val ctx=hist.takeLast(6).joinToString("\n"){(if(it.user)"User: " else "Assistant: ")+it.text.take(600)}
  val prompt=(if(ctx.isEmpty())"" else "Conversation so far:\n$ctx\n\n")+"User: $q"
  val picked:List<Agent> = if(mode=="all")enabled else{
   status("Head Agent is choosing experts…")
   val max=if(mode=="fast")2 else 4
   val roster=enabled.joinToString("\n"){"${it.id}: ${it.role}"}
   val out=try{Llm.chat(c,"You are the Head Agent. Choose which agents should answer the user's message. Choose 1 agent for simple chat, up to $max for hard tasks. Choose operator only when the user wants an action done on their phone. Agents:\n$roster\nReply with ONE line only: AGENTS: id1, id2",prompt)}catch(e:Exception){""}
   val line=out.lines().firstOrNull{it.contains("AGENTS",true)}?:out
   enabled.filter{Regex("\\b${it.id}\\b").containsMatchIn(line)}.take(max)
    .ifEmpty{enabled.filter{it.id=="synthesizer"||it.id=="creator"}.ifEmpty{enabled.take(1)}.take(max)}
  }
  status("Working: "+picked.joinToString(", "){it.name})
  val futures=picked.map{a->a to pool.submit(Callable<String>{try{Llm.chat(c,a.prompt+SUF,prompt)}catch(e:Exception){"ERR:"+(e.message?:"failed")}})}
  val answers=futures.map{(a,f)->a.id to try{f.get(150,TimeUnit.SECONDS)}catch(e:Exception){"ERR:timeout"}}
  val ok=answers.filter{!it.second.startsWith("ERR:")}
  val good=ok.filter{!it.second.trim().equals("NONE",true)}.ifEmpty{ok}
  if(good.isEmpty())return Turn(false,"Error: "+answers.first().second.removePrefix("ERR:"))
  var winner=good[0].first; var text=good[0].second; var ans=good.map{Triple(it.first,it.second,0)}
  if(good.size>1){
   status("Ultimate Agent is judging ${good.size} answers…")
   val block=good.joinToString("\n\n"){"[${it.first}]\n${it.second}"}
   val out=try{Llm.chat(c,"You are the Ultimate Agent. You get a user's message and answers from several expert agents. Score each answer 1-10 for accuracy, usefulness and clarity. Then write the single best final answer for the user: take the strongest answer or merge the best parts, and fix mistakes. Never mention agents or scores inside the final answer. Reply in the same language as the user. Use exactly this format:\nSCORES: id=score, id=score\nWINNER: id\nFINAL:\n<final answer>",prompt+"\n\nAgent answers:\n"+block)}catch(e:Exception){""}
   val w=Regex("WINNER:\\s*([a-z]+)").find(out)?.groupValues?.get(1)
   if(w!=null&&good.any{it.first==w})winner=w
   val fi=out.indexOf("FINAL:")
   val win=winner
   text=if(fi>=0&&out.length>fi+6)out.substring(fi+6).trim() else good.first{it.first==win}.second
   val sc=Regex("([a-z]+)\\s*=\\s*(\\d+)").findAll(out.substringBefore("WINNER")).associate{it.groupValues[1] to it.groupValues[2].toInt()}
   ans=good.map{Triple(it.first,it.second,sc[it.first]?:0)}
  }
  if(p.getBoolean("phone",false)){
   val acts=good.firstOrNull{it.first=="operator"}?.second?.lines()?.filter{it.trim().startsWith("ACTION:")}.orEmpty()
   if(acts.isNotEmpty()){
    val res=ArrayList<String>()
    for(l in acts){ if(stop)break; status("Phone: "+l.trim()); res.add(PhoneControl.run(l.substringAfter("ACTION:").trim())); Thread.sleep(1500) }
    text+="\n\n📱 "+res.joinToString(" · ")
   }
  }
  return Turn(false,text,winner,ans)
 }
}
