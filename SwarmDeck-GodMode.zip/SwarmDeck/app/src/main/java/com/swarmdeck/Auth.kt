package com.swarmdeck
import android.app.Activity
import androidx.credentials.*
import com.google.android.libraries.identity.googleid.*

object Auth{
 suspend fun signIn(a:Activity){
  if(BuildConfig.GOOGLE_WEB_CLIENT_ID=="REPLACE_ME") error("Add your Google Web Client ID (see README)")
  val opt=GetGoogleIdOption.Builder().setFilterByAuthorizedAccounts(false).setServerClientId(BuildConfig.GOOGLE_WEB_CLIENT_ID).build()
  val res=CredentialManager.create(a).getCredential(a,GetCredentialRequest.Builder().addCredentialOption(opt).build())
  val c=GoogleIdTokenCredential.createFrom(res.credential.data)
  Store.p(a).edit().putString("email",c.id).putString("name",c.displayName?:"").putString("idToken",c.idToken).apply()
 }
}
