package com.swarmdeck
import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import java.io.File
import java.util.concurrent.TimeUnit

object Term{
 val lines=mutableStateListOf("SwarmDeck terminal. Type help.")
 private var cwd:File?=null
 fun out(s:String){Bus.ui{lines.add(s);while(lines.size>400)lines.removeAt(0)}}
 fun exec(c:Context,cmd:String){
  val t=cmd.trim(); if(t.isEmpty())return
  out("$ $t")
  when{
   t=="clear"->Bus.ui{lines.clear()}
   t=="help"->out("help · clear · agents · status · history · ask <question> · cd <dir> · or any shell command (ls, pwd, date, uname -a, df, ping -c 2 host)")
   t=="agents"->out(AGENTS.joinToString("\n"){"${it.name} — ${it.role}"+(if(Store.p(c).getBoolean("off_${it.id}",false))" (off)" else "")})
   t=="history"->out("${Bus.turns.size} chat messages saved")
   t=="status"->{val p=Store.p(c); out("API: ${p.getString("url","")}\nModel: ${p.getString("model","auto")}\nMode: ${p.getString("mode","auto")}\nPhone control: ${if(p.getBoolean("phone",false))"on" else "off"}, service ${if(PhoneControl.inst!=null)"connected" else "not connected"}\nChat messages: ${Bus.turns.size}")}
   t.startsWith("ask ")->{out("…asking the swarm"); Thread{val r=try{Brain.run(c,t.removePrefix("ask ").trim(),Hist.load(c)){}}catch(e:Exception){Turn(false,"Error: ${e.message}")}; out(r.text)}.start()}
   t.startsWith("cd ")->{val a=t.substring(3).trim(); val d=File(if(a.startsWith("/"))a else (cwd?:c.filesDir).path+"/"+a).canonicalFile; if(d.isDirectory){cwd=d;out(d.path)}else out("cd: no such directory")}
   else->Thread{out(shell(c,t))}.start()
  }
 }
 private fun shell(c:Context,cmd:String):String=try{
  val p=ProcessBuilder("sh","-c",cmd).directory(cwd?:c.filesDir).redirectErrorStream(true).start()
  val buf=StringBuilder()
  val rd=Thread{p.inputStream.bufferedReader().use{r->var l=r.readLine();while(l!=null&&buf.length<6000){buf.appendLine(l);l=r.readLine()}}}
  rd.start()
  if(!p.waitFor(15,TimeUnit.SECONDS)){p.destroyForcibly();buf.append("\n[timed out after 15s]")}
  rd.join(1000)
  buf.toString().trimEnd().ifEmpty{"(no output)"}
 }catch(e:Exception){"error: ${e.message}"}
}
