package com.swarmdeck
import android.content.Context
import android.os.*
import androidx.compose.runtime.*
import okhttp3.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.*
import java.util.concurrent.*

const val SUF = " Be direct and useful. Reply in the same language as the user. Never invent personal data about the user."

data class Agent(val id: String, val name: String, val role: String, val prompt: String)

val AGENTS = listOf(
  Agent("planner", "Planner", "Plans & step-by-step approaches", "You are Planner. Break the task into clear numbered steps."),
  Agent("researcher", "Researcher", "Facts, context & caveats", "You are Researcher. Give key facts, context and what is uncertain."),
  Agent("creator", "Creator", "Ideas, scripts & creative content", "You are Creator. Produce original, vivid ideas or content."),
  Agent("coder", "Coder", "Code & technical problems", "You are Coder. Give minimal correct code and short notes."),
  Agent("designer", "Designer", "Visual, UX & style direction", "You are Designer. Give visual and UX direction."),
  Agent("critic", "Critic", "Risks, flaws & what to avoid", "You are Critic. Point out risks and better alternatives."),
  Agent("synthesizer", "Synthesizer", "Balanced final answers", "You are Synthesizer. Produce a balanced, complete answer."),
  Agent("operator", "Operator", "Controls the phone", "You are Operator. For phone actions output lines starting with ACTION: then OPEN <app> | TAP <text> | TYPE <text> | BACK | HOME | SCROLL. If not a phone task reply NONE."),
  Agent("browser", "Browser", "Web research & browsing", "You are Browser. When the user needs live web info, describe the exact search or URL to open and what to extract."),
  Agent("artist", "Artist", "Image generation prompts", "You are Artist. Write a highly detailed image generation prompt when the user wants an image created.")
)

data class Turn(
  val user: Boolean,
  val text: String,
  val winner: String = "",
  val answers: List<Triple<String, String, Int>> = emptyList(),
  val thinking: List<String> = emptyList()
)

object Store {
  fun p(c: Context) = c.getSharedPreferences("swarm", Context.MODE_PRIVATE)
}

object Hist {
  fun save(c: Context, l: List<Turn>) {
    val a = JSONArray()
    l.takeLast(80).forEach { t ->
      val x = JSONArray()
      t.answers.forEach { (i, s, n) -> x.put(JSONObject().put("i", i).put("s", s).put("n", n)) }
      a.put(JSONObject().put("u", t.user).put("t", t.text).put("w", t.winner).put("a", x))
    }
    Store.p(c).edit().putString("chat", a.toString()).apply()
  }
  fun load(c: Context): List<Turn> = try {
    val a = JSONArray(Store.p(c).getString("chat", "[]"))
    (0 until a.length()).map {
      val o = a.getJSONObject(it)
      val x = o.getJSONArray("a")
      Turn(o.getBoolean("u"), o.getString("t"), o.getString("w"),
        (0 until x.length()).map { j ->
          val q = x.getJSONObject(j)
          Triple(q.getString("i"), q.getString("s"), q.getInt("n"))
        })
    }
  } catch (e: Exception) { emptyList() }
}

object Bus {
  val turns = mutableStateListOf<Turn>()
  var running by mutableStateOf(false)
  var status by mutableStateOf("")
  val thinking = mutableStateListOf<String>()          // live thinking stream
  var subAgents by mutableStateOf<List<String>>(emptyList())
  private val h = Handler(Looper.getMainLooper())
  fun ui(f: () -> Unit) { h.post { f() } }
  fun add(c: Context, t: Turn) { ui { turns.add(t); Hist.save(c, turns) } }
  fun think(msg: String) { ui { thinking.add(msg); if (thinking.size > 40) thinking.removeAt(0) } }
  fun clearThinking() { ui { thinking.clear(); subAgents = emptyList() } }
}

object Llm {
  private val http = OkHttpClient.Builder().readTimeout(120, TimeUnit.SECONDS).build()

  private fun once(c: Context, system: String, user: String): String {
    val p = Store.p(c)
    val base = p.getString("url", "")!!.trim().trimEnd('/')
    if (base.isEmpty()) error("Set API base URL in Settings")
    val msgs = JSONArray()
      .put(JSONObject().put("role", "system").put("content", system))
      .put(JSONObject().put("role", "user").put("content", user))
    val body = JSONObject()
      .put("model", p.getString("model", "auto"))
      .put("messages", msgs)
    val req = Request.Builder()
      .url("$base/chat/completions")
      .header("Authorization", "Bearer " + p.getString("key", ""))
      .post(body.toString().toRequestBody("application/json".toMediaType()))
      .build()
    return http.newCall(req).execute().use { r ->
      val t = r.body?.string() ?: ""
      if (!r.isSuccessful) error("HTTP ${r.code}: ${t.take(180)}")
      JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").getString("content")
    }
  }

  fun chat(c: Context, system: String, user: String): String =
    try { once(c, system, user) } catch (e: Exception) {
      Thread.sleep(1000); once(c, system, user)
    }
}

object Brain {
  @Volatile var stop = false
  private val pool = Executors.newFixedThreadPool(6)

  fun run(c: Context, q: String, hist: List<Turn>, status: (String) -> Unit): Turn {
    stop = false
    Bus.clearThinking()
    val p = Store.p(c)
    val mode = p.getString("mode", "auto")!!
    val enabled = AGENTS.filter { !p.getBoolean("off_${it.id}", false) }
    if (enabled.isEmpty()) return Turn(false, "All agents are off. Enable some in Agents tab.")

    val ctx = hist.takeLast(8).joinToString("\n") {
      (if (it.user) "User: " else "Assistant: ") + it.text.take(700)
    }
    val prompt = (if (ctx.isEmpty()) "" else "Conversation so far:\n$ctx\n\n") + "User: $q"

    // ── Thinking Stream + Sub-agent selection ──
    Bus.think("Analyzing request…")
    status("Thinking…")

    val picked: List<Agent> = if (mode == "all") {
      Bus.think("Mode: ALL agents")
      enabled
    } else {
      Bus.think("Head Agent selecting specialists…")
      val max = if (mode == "fast") 2 else 5
      val roster = enabled.joinToString("\n") { "${it.id}: ${it.role}" }
      val out = try {
        Llm.chat(c,
          "You are Head Agent of SwarmDeck V3. Choose the best agents for this task. " +
          "Reply with one line only: AGENTS: id1, id2, ... (max $max). " +
          "Use operator only for phone actions, browser for web needs, artist for image generation.\nAgents:\n$roster",
          prompt)
      } catch (e: Exception) { "" }
      val line = out.lines().firstOrNull { it.contains("AGENTS", true) } ?: out
      val selected = enabled.filter { Regex("\\b${it.id}\\b").containsMatchIn(line) }.take(max)
        .ifEmpty { enabled.filter { it.id == "synthesizer" || it.id == "creator" }.ifEmpty { enabled.take(1) }.take(max) }
      Bus.think("Selected: " + selected.joinToString { it.name })
      Bus.ui { Bus.subAgents = selected.map { it.name } }
      selected
    }

    status("Deploying: " + picked.joinToString { it.name })
    Bus.think("Deploying ${picked.size} sub-agents…")

    // Run sub-agents in parallel
    val futures = picked.map { a ->
      a to pool.submit(Callable<String> {
        try {
          Bus.think("${a.name} is working…")
          Llm.chat(c, a.prompt + SUF, prompt)
        } catch (e: Exception) {
          "ERR:" + (e.message ?: "failed")
        }
      })
    }

    val answers = futures.map { (a, f) ->
      a.id to try { f.get(150, TimeUnit.SECONDS) } catch (e: Exception) { "ERR:timeout" }
    }
    val ok = answers.filter { !it.second.startsWith("ERR:") }
    val good = ok.filter { !it.second.trim().equals("NONE", true) }.ifEmpty { ok }
    if (good.isEmpty()) return Turn(false, "Error: " + answers.first().second.removePrefix("ERR:"))

    var winner = good[0].first
    var text = good[0].second
    var ans = good.map { Triple(it.first, it.second, 0) }
    val thinkLog = Bus.thinking.toList()

    if (good.size > 1) {
      Bus.think("Ultimate Agent synthesizing ${good.size} answers…")
      status("Synthesizing final answer…")
      val block = good.joinToString("\n\n") { "[${it.first}]\n${it.second}" }
      val out = try {
        Llm.chat(c,
          "You are the Ultimate Agent. Score each answer 1-10, then write the single best final answer. " +
          "Never mention agents or scores inside FINAL. Same language as user.\n" +
          "Format:\nSCORES: id=score, id=score\nWINNER: id\nFINAL:\n<answer>",
          prompt + "\n\nAgent answers:\n" + block)
      } catch (e: Exception) { "" }
      val w = Regex("WINNER:\\s*([a-z]+)").find(out)?.groupValues?.get(1)
      if (w != null && good.any { it.first == w }) winner = w
      val fi = out.indexOf("FINAL:")
      text = if (fi >= 0 && out.length > fi + 6) out.substring(fi + 6).trim()
             else good.first { it.first == winner }.second
      val sc = Regex("([a-z]+)\\s*=\\s*(\\d+)").findAll(out.substringBefore("WINNER"))
        .associate { it.groupValues[1] to it.groupValues[2].toInt() }
      ans = good.map { Triple(it.first, it.second, sc[it.first] ?: 0) }
      Bus.think("Winner: ${nameOf(winner)}")
    }

    // Phone actions
    if (p.getBoolean("phone", false)) {
      val acts = good.firstOrNull { it.first == "operator" }?.second
        ?.lines()?.filter { it.trim().startsWith("ACTION:") }.orEmpty()
      if (acts.isNotEmpty()) {
        val res = ArrayList<String>()
        for (l in acts) {
          if (stop) break
          val cmd = l.substringAfter("ACTION:").trim()
          Bus.think("Phone action: $cmd")
          status("Phone: $cmd")
          res.add(PhoneControl.run(cmd))
          Thread.sleep(1400)
        }
        text += "\n\n📱 " + res.joinToString(" · ")
      }
    }

    Bus.think("Done.")
    return Turn(false, text, winner, ans, thinkLog)
  }
}
