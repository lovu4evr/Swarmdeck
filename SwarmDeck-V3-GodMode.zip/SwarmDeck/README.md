# SwarmDeck V3.0 — God Mode Agent

Personal multi-agent AI that lives on your phone.

## V3.0 Features
- **Live Thinking Stream** — See exactly what the agent is thinking in real time
- **Sub-Agent Deployment** — Head Agent spawns specialist agents for each task
- **10 Agents**: Planner, Researcher, Creator, Coder, Designer, Critic, Synthesizer, Operator, Browser, Artist
- **Phone Control** (Accessibility) — Open apps, tap, type, scroll with permission
- **Voice input**
- **Liquid Glass UI** — Deep blue + cream god-like theme
- **Local-first privacy** — Personal data stays on device unless you explicitly send it

## Setup
1. Google Cloud OAuth (Web + Android client for package `com.swarmdeck`)
2. Add secret `GOOGLE_WEB_CLIENT_ID` in GitHub Actions
3. Push → download APK from Artifacts
4. In app: Settings → set OpenAI-compatible URL + key + model
5. Enable Phone Control service for Operator actions

## Privacy
- No automatic data upload
- API calls only go to the endpoint **you** configure
- Chat history stored locally on device

---
SwarmDeck V3.0 • Sub-agents. Live thinking. Your phone. Your rules.
