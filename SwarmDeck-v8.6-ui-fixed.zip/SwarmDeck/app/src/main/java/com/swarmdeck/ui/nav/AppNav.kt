package com.swarmdeck.ui.nav

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalDrawerSheet
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.swarmdeck.ACC
import com.swarmdeck.AgentsTab
import com.swarmdeck.ChatPage
import com.swarmdeck.MemoryTab
import com.swarmdeck.PhoneTab
import com.swarmdeck.ProfileTab
import com.swarmdeck.SettingsTab
import com.swarmdeck.Sidebar
import com.swarmdeck.TermTab
import com.swarmdeck.ToolsTab
import com.swarmdeck.TopHeader
import com.swarmdeck.ui.AgentMarketScreen
import com.swarmdeck.ui.BackupScreen
import com.swarmdeck.ui.DevicesScreen
import com.swarmdeck.ui.DiagnosticsScreen
import com.swarmdeck.ui.GoalsScreen
import com.swarmdeck.ui.HunterScreen
import com.swarmdeck.ui.LocalModelsScreen
import com.swarmdeck.ui.MemoryGraphScreen
import com.swarmdeck.ui.MiniOrb
import com.swarmdeck.ui.MissionsScreen
import com.swarmdeck.ui.OnboardingScreen
import com.swarmdeck.ui.PrivacyScreen
import com.swarmdeck.ui.ProGate
import com.swarmdeck.ui.ProScreen
import com.swarmdeck.billing.Pro
import com.swarmdeck.billing.ProFeature
import kotlinx.coroutines.launch

data class NavItem(val route: String, val label: String, val icon: ImageVector)

val MAIN_NAV = listOf(
    NavItem(Routes.CHAT, "Chat", Icons.Default.Chat),
    NavItem(Routes.AGENTS, "Agents", Icons.Default.SmartToy),
    NavItem(Routes.GOALS, "Goals", Icons.Default.Flag),
    NavItem(Routes.MISSIONS, "Missions", Icons.Default.AccountTree),
    NavItem(Routes.MARKET, "Agent Market", Icons.Default.Storefront),
    NavItem(Routes.MEMORY, "Memory", Icons.Default.Storage),
    NavItem(Routes.MEMGRAPH, "Memory Graph", Icons.Default.Hub),
    NavItem(Routes.DEVICES, "Devices", Icons.Default.Devices),
    NavItem(Routes.RESOURCES, "Resource Hunter", Icons.Default.Explore),
    NavItem(Routes.LOCAL_MODELS, "Local models", Icons.Default.Memory),
    NavItem(Routes.IMMERSIVE, "Immersive", Icons.Default.AutoAwesome),
    NavItem(Routes.TERMINAL, "Terminal", Icons.Default.Terminal),
    NavItem(Routes.TOOLS, "Tools", Icons.Default.Build),
    NavItem(Routes.PHONE, "Phone Operator", Icons.Default.Phone),
    NavItem(Routes.PRO, "SwarmDeck Pro", Icons.Default.Star),
    NavItem(Routes.DIAGNOSTICS, "Diagnostics", Icons.Default.BugReport),
    NavItem(Routes.BACKUP, "Backup", Icons.Default.CloudUpload),
    NavItem(Routes.PRIVACY, "Privacy", Icons.Default.Info),
    NavItem(Routes.SETTINGS, "Settings", Icons.Default.Settings),
    NavItem(Routes.PROFILE, "Profile", Icons.Default.Person)
)

@Composable
fun AppShell(act: Activity, startRoute: String = Routes.CHAT, onImmersive: () -> Unit) {
    val nav = rememberNavController()
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val entry by nav.currentBackStackEntryAsState()
    val page = entry?.destination?.route ?: startRoute

    fun go(route: String) {
        scope.launch { drawer.close() }
        when {
            route == Routes.IMMERSIVE && !Pro.active ->
                nav.navigate(Routes.PRO_IMMERSIVE) { launchSingleTop = true }
            route == Routes.IMMERSIVE && Pro.active -> onImmersive()
            else -> nav.navigate(route) {
                launchSingleTop = true
                restoreState = true
                popUpTo(Routes.CHAT) { saveState = true }
            }
        }
    }

    BackHandler(drawer.isOpen) { scope.launch { drawer.close() } }
    BackHandler(page != Routes.CHAT && !drawer.isOpen) {
        if (!nav.popBackStack()) go(Routes.CHAT)
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xFF070503), modifier = Modifier.width(290.dp)) {
                Sidebar(page) { go(it) }
            }
        }
    ) {
        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            TopHeader(act, { scope.launch { drawer.open() } }) { go(Routes.SETTINGS) }
            Box(Modifier.weight(1f).fillMaxWidth()) {
                NavHost(navController = nav, startDestination = startRoute, modifier = Modifier.fillMaxSize()) {
                    composable(Routes.CHAT) { ChatPage(act) { go(it) } }
                    composable(Routes.AGENTS) { AgentsTab(act) }
                    composable(Routes.GOALS) { GoalsScreen(act) { go(Routes.CHAT) } }
                    composable(Routes.MISSIONS) {
                        ProGate(act, ProFeature.MISSIONS, { go(Routes.CHAT) }) {
                            MissionsScreen(act) { go(Routes.CHAT) }
                        }
                    }
                    composable(Routes.MARKET) {
                        ProGate(act, ProFeature.MARKET, { go(Routes.CHAT) }) {
                            AgentMarketScreen(act) { go(Routes.CHAT) }
                        }
                    }
                    composable(Routes.MEMORY) { MemoryTab(act) }
                    composable(Routes.MEMGRAPH) {
                        ProGate(act, ProFeature.MEMGRAPH, { go(Routes.CHAT) }) {
                            MemoryGraphScreen(act) { go(Routes.CHAT) }
                        }
                    }
                    composable(Routes.DEVICES) {
                        ProGate(act, ProFeature.DEVICES, { go(Routes.CHAT) }) {
                            DevicesScreen(act) { go(Routes.CHAT) }
                        }
                    }
                    composable(Routes.RESOURCES) { HunterScreen(act) { go(Routes.CHAT) } }
                    composable(Routes.LOCAL_MODELS) { LocalModelsScreen(act) { go(Routes.CHAT) } }
                    composable(Routes.TERMINAL) { TermTab(act) }
                    composable(Routes.TOOLS) { ToolsTab(act) }
                    composable(Routes.PHONE) { PhoneTab(act) { go(it) } }
                    composable(Routes.PRO) { ProScreen(act, null) { go(Routes.CHAT) } }
                    composable(Routes.PRO_IMMERSIVE) {
                        ProScreen(act, ProFeature.IMMERSIVE) { go(Routes.CHAT) }
                    }
                    composable(Routes.SETTINGS) { SettingsTab(act) }
                    composable(Routes.PROFILE) { ProfileTab(act) }
                    composable(Routes.DIAGNOSTICS) { DiagnosticsScreen(act) { go(Routes.CHAT) } }
                    composable(Routes.BACKUP) { BackupScreen(act) { go(Routes.CHAT) } }
                    composable(Routes.PRIVACY) { PrivacyScreen(act) { go(Routes.CHAT) } }
                    composable(Routes.ONBOARDING) {
                        OnboardingScreen(act) { go(Routes.CHAT) }
                    }
                }
                if (page == Routes.CHAT) {
                    MiniOrb(Modifier.align(Alignment.TopEnd).padding(8.dp)) {
                        if (Pro.active) onImmersive() else go(Routes.PRO_IMMERSIVE)
                    }
                }
            }
        }
    }
}
