package com.swarmdeck.memgraph

import org.junit.Assert.*
import org.junit.Test

class GraphTest {
    private val DAY = 86_400_000L
    private val NOW = 100 * DAY

    private fun fact(id: String, key: String, value: String, ts: Long = 1L, pinned: Boolean = false) = FactIn(id, key, value, ts, pinned)
    private fun goal(id: String, title: String, desc: String = "", status: String = "ACTIVE", prio: Int = 2, prog: Float = 0f, upd: Long = NOW, due: Long? = null) =
        GoalIn(id, title, desc, status, prio, prog, upd, due)

    private fun sample(): MemGraph = GraphBuilder.build(
        listOf(
            fact("1", "pune rent", "rent in pune is 15000"),
            fact("2", "pune flat", "looking for a flat in pune near office"),
            fact("3", "guitar", "practice guitar daily")
        ),
        listOf(goal("g1", "Move to Pune", "find flat near office budget rent")),
        listOf(Decision("d1", 5L, "Move to Pune", "rent is lower", "g1", "OPEN"))
    )

    // ── Keywords ──
    @Test
    fun keywordsDropStopwordsAndShortWords() {
        val k = Keywords.of("Move to Pune because rent is lower")
        assertTrue(k.containsAll(listOf("move", "pune", "rent", "lower")))
        assertFalse(k.contains("because"))
        assertFalse(k.contains("is"))
        assertTrue(Keywords.of("kya hai ye").isEmpty())
    }

    // ── Builder ──
    @Test
    fun buildCreatesTopicsAndLinks() {
        val g = sample()
        assertNotNull(g.node("t:pune"))
        assertNotNull(g.node("f:1"))
        assertNotNull(g.node("g:g1"))
        assertNotNull(g.node("d:d1"))
        assertTrue(g.edges.any { it.kind == EdgeKind.SERVES && it.a == "d:d1" && it.b == "g:g1" })
        fun related(a: String, b: String) = g.edges.any { it.kind == EdgeKind.RELATED && ((it.a == a && it.b == b) || (it.a == b && it.b == a)) }
        assertTrue(related("f:1", "g:g1"))
        assertTrue(related("f:2", "g:g1"))
        assertFalse(related("f:1", "f:2"))
        assertTrue(g.neighbors("g:g1").map { it.id }.containsAll(listOf("f:1", "f:2")))
    }

    @Test
    fun unrelatedFactStaysUnlinked() {
        val g = sample()
        assertTrue(g.neighbors("f:3").isEmpty())
    }

    @Test
    fun buildCapsFactsAndKeepsPinnedOnes() {
        val facts = (1..300).map { fact("f$it", "k$it", "v$it", ts = it.toLong()) } + fact("old", "pinned note", "keep me", ts = 0L, pinned = true)
        val g = GraphBuilder.build(facts, emptyList(), emptyList())
        assertEquals(250, g.nodes.count { it.type == NodeType.FACT })
        assertNotNull(g.node("f:old"))
    }

    @Test
    fun guessGoalNeedsTwoSharedKeywordsAndActiveGoal() {
        val goals = listOf(goal("g1", "Move to Pune", "find flat near office budget rent"))
        assertEquals("g1", GraphBuilder.guessGoal("Move to Pune because flat rent is lower", goals))
        assertNull(GraphBuilder.guessGoal("Learn guitar this year", goals))
        assertNull(GraphBuilder.guessGoal("Move to Pune because flat rent is lower", listOf(goal("g1", "Move to Pune", "flat rent", status = "COMPLETED"))))
    }

    // ── Recall ──
    @Test
    fun recallFindsMatchesAndWhatIsConnectedToThem() {
        val hits = GraphQuery.recall(sample(), "rent")
        val ids = hits.map { it.node.id }
        assertEquals("g:g1", ids.first())
        assertTrue(ids.containsAll(listOf("f:1", "f:2")))
        assertFalse(ids.contains("f:3"))
        assertTrue(GraphQuery.contextText(hits).contains("[GOAL] Move to Pune"))
    }

    @Test
    fun recallHandlesNoMatchAndEmptyQuery() {
        assertTrue(GraphQuery.recall(sample(), "kya hai").isEmpty())
        val one = GraphQuery.recall(sample(), "guitar")
        assertEquals(listOf("f:3"), one.map { it.node.id })
        assertEquals("(nothing found in the memory graph)", GraphQuery.contextText(emptyList()))
    }

    // ── Proactive ──
    @Test
    fun proactiveRulesFireForOverdueDueSoonStalledAndAlmostDone() {
        val goals = listOf(
            goal("a", "Tax filing", due = NOW - DAY, prog = 0.2f),
            goal("b", "Passport", due = NOW + 2 * DAY, prog = 0.3f),
            goal("c", "Thesis", prog = 0.95f),
            goal("d", "Guitar", upd = NOW - 8 * DAY),
            goal("e", "Fresh goal"),
            goal("f", "Old finished", status = "COMPLETED", upd = NOW - 30 * DAY)
        )
        val decisions = listOf(
            Decision("x", NOW - 15 * DAY, "Switch phone plan", "cheaper", null, "OPEN"),
            Decision("y", NOW - 15 * DAY, "Old closed", "", null, "DONE"),
            Decision("z", NOW - 3 * DAY, "Too recent", "", null, "OPEN")
        )
        val s = Proactive.suggestions(goals, decisions, NOW)
        val titles = s.map { it.title }
        assertTrue(titles.any { it.startsWith("Overdue: Tax filing") })
        assertTrue(titles.any { it.startsWith("Due in 2 day(s): Passport") })
        assertTrue(titles.any { it.startsWith("Almost done: Thesis") })
        assertTrue(titles.any { it.startsWith("Stalled for 8 days: Guitar") })
        assertTrue(titles.any { it.startsWith("Review decision: Switch phone plan") })
        assertEquals(5, titles.size)
        assertFalse(titles.any { it.contains("Fresh goal") || it.contains("Old finished") || it.contains("Old closed") || it.contains("Too recent") })
        assertEquals(s.sortedBy { it.level }.map { it.level }, s.map { it.level })
    }

    @Test
    fun proactiveIsCappedAtSix() {
        val goals = (1..10).map { goal("g$it", "Goal $it", due = NOW - DAY) }
        assertEquals(6, Proactive.suggestions(goals, emptyList(), NOW).size)
    }

    // ── Decisions ──
    @Test
    fun decisionTextSplitsOnFirstSplitter() {
        assertEquals("Move to Pune" to "rent is lower", DecisionText.split("Move to Pune because rent is lower"))
        assertEquals("Buy a laptop" to "purana slow hai", DecisionText.split("Buy a laptop kyunki purana slow hai"))
        assertEquals("Quit job" to "burnout", DecisionText.split("Quit job | burnout"))
        assertEquals("Just do it" to "", DecisionText.split("Just do it"))
        assertEquals("A" to "B | C", DecisionText.split("A because B | C"))
    }

    @Test
    fun decisionJsonRoundTrip() {
        val l = listOf(Decision("1", 5L, "T", "R", null, "OPEN"), Decision("2", 6L, "T2", "", "g1", "DONE"))
        assertEquals(l, DecisionJson.fromJson(DecisionJson.toJson(l)))
        assertTrue(DecisionJson.fromJson("not json").isEmpty())
        assertTrue(DecisionJson.fromJson("").isEmpty())
    }
}
