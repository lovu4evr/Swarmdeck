package com.swarmdeck.hunter

import org.junit.Assert.*
import org.junit.Test

/** Pure-JVM tests for the ResourceRepo contract (MemoryRepo). SqliteRepo needs instrumented/Robolectric. */
class ResourceRepoTest {

    private fun sample(id: String = "test-1") = Resource(
        id = id,
        provider = "example.com",
        name = "Example Free Tier",
        category = Category.AI_API,
        officialUrl = "https://example.com/pricing",
        docsUrl = "https://example.com/docs",
        source = "test",
        firstSeen = 1_700_000_000_000L
    )

    @Test
    fun memoryRepo_put_get_all_delete() {
        val repo = MemoryRepo()
        assertTrue(repo.all().isEmpty())
        val r = sample()
        repo.put(r)
        assertEquals(1, repo.all().size)
        assertEquals(r.id, repo.get(r.id)?.id)
        assertTrue(repo.delete(r.id))
        assertNull(repo.get(r.id))
        assertFalse(repo.delete(r.id))
    }

    @Test
    fun memoryRepo_events_capped() {
        val repo = MemoryRepo()
        repeat(MemoryRepo.MAX_EVENTS + 50) { i ->
            repo.addEvent(HunterEvent(System.currentTimeMillis(), "id", "kind", "detail $i", i % 3 == 0))
        }
        val ev = repo.events(MemoryRepo.MAX_EVENTS + 10)
        assertTrue(ev.size <= MemoryRepo.MAX_EVENTS)
    }

    @Test
    fun memoryRepo_overwrite_preserves_id() {
        val repo = MemoryRepo()
        val a = sample("x")
        repo.put(a)
        val b = a.copy(name = "Updated Name")
        repo.put(b)
        assertEquals(1, repo.all().size)
        assertEquals("Updated Name", repo.get("x")?.name)
    }
}
