package com.swarmdeck.hunter

import org.junit.Assert.*
import org.junit.Test

class CatalogIoTest {
    @Test
    fun export_import_roundtrip() {
        val repo = MemoryRepo()
        val r = Resource(
            id = "ex-1",
            provider = "example.com",
            name = "Example",
            category = Category.AI_API,
            officialUrl = "https://example.com/",
            source = "test",
            firstSeen = 1L
        )
        repo.put(r)
        val json = CatalogIo.exportJson(repo, includeEvents = false)
        val repo2 = MemoryRepo()
        val (added, updated) = CatalogIo.importJson(repo2, json)
        assertEquals(1, added)
        assertEquals(0, updated)
        assertEquals("Example", repo2.get("ex-1")?.name)
    }

    @Test
    fun setup_steps_contain_url() {
        val r = Resource(
            id = "x",
            provider = "p",
            name = "n",
            category = Category.DEV_TOOL,
            officialUrl = "https://example.com/app",
            firstSeen = 1L
        )
        val s = SetupSteps.forResource(r)
        assertTrue(s.contains("https://example.com/app"))
        assertTrue(s.contains("never signs up"))
    }
}
