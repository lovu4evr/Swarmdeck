package com.swarmdeck.device

import com.swarmdeck.guard.Risk
import com.swarmdeck.guard.RiskClassifier
import org.json.JSONObject
import org.junit.Assert.*
import org.junit.Test

class DeviceTest {
    private fun o(vararg kv: Pair<String, Any>): JSONObject {
        val j = JSONObject()
        kv.forEach { j.put(it.first, it.second) }
        return j
    }

    // ── crypto: known answers computed by swarmdeck_companion.py ──
    private val salt = ByteArray(16) { it.toByte() }

    @Test
    fun keyAndSignatureMatchThePythonCompanion() {
        val key = DeviceCrypto.deriveKey("ABCD2345", salt)
        assertEquals("1b6dc146ff7d025a4317cb1744d244368b5cff52d0b2a834f02da70f93a81207", DeviceCrypto.hex(key))
        val sig = DeviceCrypto.sign(key, 1700000000L, "0123456789abcdef", "{\"action\":\"ping\",\"args\":{}}".toByteArray(Charsets.UTF_8))
        assertEquals("3a6efd1908f8ec7fa899d07cf83a6ada0aa3580e3a3ff2913de261e8cadab457", sig)
    }

    @Test
    fun codeNormalizationMatchesCompanion() {
        assertEquals("0110", DeviceCrypto.normalizeCode("oIl0"))
        val a = DeviceCrypto.hex(DeviceCrypto.deriveKey("abcd2345 ", salt))
        assertEquals("1b6dc146ff7d025a4317cb1744d244368b5cff52d0b2a834f02da70f93a81207", a)
    }

    @Test
    fun hexAndNonce() {
        val b = byteArrayOf(0, 1, 127, -1)
        assertEquals("00017fff", DeviceCrypto.hex(b))
        assertArrayEquals(b, DeviceCrypto.fromHex("00017fff"))
        val n1 = DeviceCrypto.newNonce()
        assertEquals(32, n1.length)
        assertTrue(n1.all { it in '0'..'9' || it in 'a'..'f' })
        assertNotEquals(n1, DeviceCrypto.newNonce())
    }

    // ── MiniHttp reply parsing (mirrored and verified against the real companion by test_companion.py) ──
    private fun reply(raw: String, max: Int = 1000) =
        MiniHttp.readReply(java.io.ByteArrayInputStream(raw.toByteArray(Charsets.ISO_8859_1)), max)

    @Test
    fun miniHttpReadsContentLengthAndToEndReplies() {
        val r = reply("HTTP/1.0 200 OK\r\nContent-Type: application/json\r\nContent-Length: 11\r\n\r\n{\"ok\":true}")
        assertEquals(200, r.status)
        assertEquals("{\"ok\":true}", String(r.body, Charsets.UTF_8))
        val r2 = reply("HTTP/1.1 401 Unauthorized\r\nServer: x\r\n\r\nbody until close")
        assertEquals(401, r2.status)
        assertEquals("body until close", String(r2.body, Charsets.UTF_8))
        val r3 = reply("HTTP/1.0 200 OK\nContent-Length: 2\n\nhi")
        assertEquals("hi", String(r3.body, Charsets.UTF_8))
    }

    @Test
    fun miniHttpRejectsBadReplies() {
        val bad = listOf(
            "",
            "garbage\r\n\r\n",
            "HTTP/1.1 abc OK\r\n\r\n",
            "HTTP/1.1 200 OK\r\nTransfer-Encoding: chunked\r\n\r\n5\r\nhello\r\n0\r\n\r\n",
            "HTTP/1.1 200 OK\r\nContent-Length: 2000\r\n\r\nx",
            "HTTP/1.1 200 OK\r\nContent-Length: 10\r\n\r\nabc",
            "HTTP/1.1 200 OK\r\nContent-Length: 1"
        )
        for (raw in bad) {
            try {
                reply(raw)
                fail("expected IOException for: $raw")
            } catch (_: java.io.IOException) {
            }
        }
    }

    // ── rules ──
    @Test
    fun comboParsingMatchesCompanion() {
        assertEquals(listOf("ctrl", "c"), DeviceRules.parseCombo("Ctrl + C").first)
        assertEquals(listOf("win", "alt", "esc"), DeviceRules.parseCombo("CMD+Option+Esc").first)
        assertEquals(listOf("f12"), DeviceRules.parseCombo("F12").first)
        for (bad in listOf("", "ctrl+", "a+b+c+d+e", "ctrl+ñ", "ctrl+f13", "ctrl+f0")) {
            assertNull(bad, DeviceRules.parseCombo(bad).first)
            assertNotNull(bad, DeviceRules.parseCombo(bad).second)
        }
    }

    @Test
    fun dangerousCombosAreBlocked() {
        for (c in listOf("win+r", "cmd+space", "Windows+R", "ctrl+alt+delete", "ctrl+shift+esc", "alt+f4", "win", "super", "ctrl+alt+t", "alt+F2")) {
            val t = DeviceRules.parseCombo(c).first!!
            assertNotNull(c, DeviceRules.comboBlocked(t))
        }
        for (c in listOf("ctrl+c", "ctrl+shift+t", "enter", "f5", "alt+tab")) {
            assertNull(c, DeviceRules.comboBlocked(DeviceRules.parseCombo(c).first!!))
        }
        assertEquals("the Start menu / launcher", DeviceRules.comboBlocked(listOf("win")))
    }

    @Test
    fun onlyLocalNetworkHostsAreAllowed() {
        for (h in listOf("192.168.1.5", "10.0.0.2", "172.16.0.1", "172.31.255.255", "127.0.0.1", "169.254.1.1", "100.64.0.1", "100.127.1.1", "localhost", "my-laptop.local")) {
            assertTrue(h, DeviceRules.isPrivateHost(h))
        }
        for (h in listOf("8.8.8.8", "172.32.0.1", "172.15.0.1", "100.128.0.1", "100.63.0.1", "192.169.1.1", "example.com", "evil.local.com", "256.1.1.1", "1.2.3", "192.168.1.1.1", "", ".local", "::1")) {
            assertFalse(h, DeviceRules.isPrivateHost(h))
        }
    }

    @Test
    fun endpointParsing() {
        assertEquals("192.168.1.5" to 8765, DeviceRules.parseEndpoint("192.168.1.5:8765"))
        assertEquals("192.168.1.5" to 9000, DeviceRules.parseEndpoint("http://192.168.1.5:9000/"))
        assertEquals("laptop.local" to 8765, DeviceRules.parseEndpoint("laptop.local"))
        for (bad in listOf("", "192.168.1.5:0", "192.168.1.5:70000", "192.168.1.5:abc", "user@host", "a b", "host/path", "bad_host:1", ":8765")) {
            assertNull(bad, DeviceRules.parseEndpoint(bad))
        }
    }

    @Test
    fun appNamesThatLookLikeShellsAreRejected() {
        for (n in listOf("PowerShell", "Windows Terminal", "System Settings", "cmd", "Task Manager")) assertNotNull(n, DeviceRules.blockedApp(n))
        for (n in listOf("Notepad", "Calculator", "TextEdit")) assertNull(n, DeviceRules.blockedApp(n))
    }

    @Test
    fun buildArgsValidatesEveryAction() {
        fun ok(action: String, vararg kv: Pair<String, Any>) = DeviceRules.buildArgs(action, o(*kv))
        val click = ok("click", "x" to "640", "y" to 360, "double" to true).first!!
        assertEquals(640, click.getInt("x"))
        assertEquals("left", click.getString("button"))
        assertTrue(click.getBoolean("double"))
        assertNull(ok("click", "x" to 1).first)
        assertNull(ok("click", "x" to 10001, "y" to 1).first)
        assertNull(ok("click", "x" to 1, "y" to 1, "button" to "middle").first)
        assertEquals(-5, ok("scroll", "amount" to -5).first!!.getInt("amount"))
        assertNull(ok("scroll", "amount" to 99).first)
        assertEquals("hi\nthere", ok("type", "text" to "hi\nthere").first!!.getString("text"))
        assertNull(ok("type", "text" to "héllo").first)
        assertNull(ok("type", "text" to "x".repeat(501)).first)
        assertEquals("ctrl+c", ok("key", "combo" to "Ctrl+C").first!!.getString("combo"))
        assertTrue(ok("key", "combo" to "win+r").second!!.startsWith("blocked key combination"))
        assertNotNull(ok("open_url", "url" to "https://example.com/a").first)
        assertNull(ok("open_url", "url" to "ftp://x").first)
        assertNull(ok("open_url", "url" to "file:///etc/passwd").first)
        assertEquals("Notepad", ok("open_app", "app" to "Notepad").first!!.getString("name"))
        assertNull(ok("open_app", "app" to "powershell").first)
        assertNull(ok("open_app", "app" to "a;b").first)
        assertNull(ok("clipboard_set", "text" to "").first)
        assertNull(ok("shell", "cmd" to "ls").first)
        assertNotNull(ok("ping").first)
    }

    @Test
    fun devicesJsonRoundTrip() {
        val l = listOf(PairedDevice("Laptop", "192.168.1.5", 8765, "ab12", "Windows", 5L), PairedDevice("Desk", "desk.local", 9000, "cd34", "Linux", 6L))
        assertEquals(l, DevicesJson.fromJson(DevicesJson.toJson(l)))
        assertTrue(DevicesJson.fromJson("nope").isEmpty())
        assertTrue(DevicesJson.fromJson("").isEmpty())
    }

    // ── Zero-Trust classification of device tools ──
    private fun act(vararg kv: Pair<String, Any>) = RiskClassifier.assess("device_act", o(*kv))

    @Test
    fun listIsSafeAndScreenAlwaysAsks() {
        assertEquals(Risk.SAFE, RiskClassifier.assess("device_list", JSONObject()).risk)
        val s = RiskClassifier.assess("device_screen", o("device" to "Laptop"))
        assertEquals(Risk.CONFIRM, s.risk)
        assertTrue(s.reasons.first().contains("private content"))
        assertEquals(Risk.BLOCK, RiskClassifier.assess("device_screen", o("device" to " ")).risk)
    }

    @Test
    fun actionsAskEveryTimeWithAReadableTitle() {
        val c = act("device" to "Laptop", "action" to "click", "x" to 10, "y" to 20)
        assertEquals(Risk.CONFIRM, c.risk)
        assertEquals("Laptop: left-click at (10, 20)", c.title)
        assertEquals("Laptop: double-right-click at (1, 2)", act("device" to "Laptop", "action" to "click", "x" to 1, "y" to 2, "button" to "right", "double" to true).title)
        val t = act("device" to "Laptop", "action" to "type", "text" to "hello world")
        assertEquals(Risk.CONFIRM, t.risk)
        assertEquals("hello world", t.preview)
        assertEquals(Risk.CONFIRM, act("device" to "Laptop", "action" to "key", "combo" to "ctrl+s").risk)
        assertEquals(Risk.CONFIRM, act("device" to "Laptop", "action" to "open_url", "url" to "https://example.com").risk)
        assertEquals(Risk.CONFIRM, act("device" to "Laptop", "action" to "open_app", "app" to "Notepad").risk)
        val clip = act("device" to "Laptop", "action" to "clipboard_get")
        assertEquals(Risk.CONFIRM, clip.risk)
        assertTrue(clip.reasons.any { it.contains("clipboard") })
    }

    @Test
    fun checkingTheConnectionIsSilent() {
        assertEquals(Risk.SAFE, act("device" to "Laptop", "action" to "ping").risk)
        assertEquals(Risk.SAFE, act("device" to "Laptop", "action" to "screen_info").risk)
    }

    @Test
    fun secretsShellsAndDangerousShortcutsAreBlocked() {
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "type", "text" to "card 4111 1111 1111 1111").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "clipboard_set", "text" to "my password is hunter2xyz").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "key", "combo" to "win+r").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "open_app", "app" to "cmd").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "open_url", "url" to "https://x.com/?k=sk-abcdefghijklmnopqrstuvwxyz123456").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "open_url", "url" to "https://x.com/?" + "q".repeat(400)).risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "open_url", "url" to "file:///etc/passwd").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "format_disk").risk)
        assertEquals(Risk.BLOCK, act("device" to "Laptop", "action" to "click").risk)
        assertEquals(Risk.BLOCK, act("action" to "click", "x" to 1, "y" to 1).risk)
    }

    @Test
    fun secretsInTypedTextNeverReachThePreview() {
        val a = act("device" to "Laptop", "action" to "type", "text" to "hello")
        assertFalse(a.preview.contains("4111"))
        assertTrue(RiskClassifier.blockMessage(act("device" to "Laptop", "action" to "key", "combo" to "win+r")).startsWith("BLOCKED by Zero-Trust"))
    }
}
