package com.swarmdeck.ui

import com.swarmdeck.ui.viz.ForceLayout
import com.swarmdeck.ui.viz.P2
import com.swarmdeck.ui.viz.SwarmLayout
import com.swarmdeck.ui.viz.TimelineModel
import org.junit.Assert.*
import org.junit.Test
import kotlin.math.hypot

class LayoutsTest {
    private fun dist(m: Map<String, P2>, a: String, b: String) = hypot(m.getValue(a).x - m.getValue(b).x, m.getValue(a).y - m.getValue(b).y)

    // ── SwarmLayout ──
    @Test
    fun satellitesOrbitOnTiltedRings() {
        val s = SwarmLayout.satellites(4, 0f, 100f)
        assertEquals(4, s.size)
        assertEquals(100f, s[0].x, 0.01f)
        assertEquals(0f, s[0].y, 0.01f)
        assertEquals(0f, s[1].x, 0.01f)
        assertEquals(39.6f, s[1].y, 0.01f)
        assertTrue(s.all { it.depth in 0f..1f })
    }

    @Test
    fun satellitesMoveOverTimeAndHandleZero() {
        assertTrue(SwarmLayout.satellites(0, 1f, 100f).isEmpty())
        val a = SwarmLayout.satellites(3, 0f, 100f)
        val b = SwarmLayout.satellites(3, 5f, 100f)
        assertNotEquals(a[0].x, b[0].x, 0.001f)
    }

    // ── ForceLayout ──
    @Test
    fun layoutIsBoundedDeterministicAndFinite() {
        val ids = listOf("a", "b", "c", "d", "e", "f")
        val edges = listOf("a" to "b", "b" to "c", "c" to "d", "d" to "e")
        val p1 = ForceLayout.layout(ids, edges, 1000f, 1000f)
        val p2 = ForceLayout.layout(ids, edges, 1000f, 1000f)
        assertEquals(p1, p2)
        assertEquals(6, p1.size)
        assertTrue(p1.values.all { it.x in 23.99f..976.01f && it.y in 23.99f..976.01f && !it.x.isNaN() && !it.y.isNaN() })
    }

    @Test
    fun connectedNodesEndUpCloserThanUnconnectedOnes() {
        val linked = ForceLayout.layout(listOf("a", "b"), listOf("a" to "b"), 1000f, 1000f)
        val free = ForceLayout.layout(listOf("a", "b"), emptyList(), 1000f, 1000f)
        assertTrue(dist(linked, "a", "b") < dist(free, "a", "b"))
    }

    @Test
    fun layoutEdgeCases() {
        assertTrue(ForceLayout.layout(emptyList(), emptyList(), 1000f, 1000f).isEmpty())
        assertEquals(mapOf("x" to P2(500f, 500f)), ForceLayout.layout(listOf("x"), emptyList(), 1000f, 1000f))
        val withUnknownEdge = ForceLayout.layout(listOf("a", "b"), listOf("a" to "zzz", "a" to "a"), 1000f, 1000f)
        assertEquals(2, withUnknownEdge.size)
    }

    // ── TimelineModel ──
    @Test
    fun firstUnfinishedStepIsActiveWhileRunning() {
        assertEquals(listOf(2, 2, 1, 0), TimelineModel.states(listOf("DONE", "DONE", "PENDING", "PENDING"), true))
        assertEquals(listOf(2, 2, 0, 0), TimelineModel.states(listOf("DONE", "DONE", "PENDING", "PENDING"), false))
        assertEquals(listOf(2, 1, 0), TimelineModel.states(listOf("DONE", "RUNNING", "PENDING"), true))
        assertEquals(listOf(3, 0), TimelineModel.states(listOf("FAILED", "PENDING"), false))
    }

    @Test
    fun progressAndXp() {
        val st = listOf(TimelineModel.DONE, TimelineModel.DONE, TimelineModel.ACTIVE, TimelineModel.PENDING)
        assertEquals(0.625f, TimelineModel.progress(st), 0.0001f)
        assertEquals(62, TimelineModel.xp(st))
        assertEquals(0f, TimelineModel.progress(emptyList()), 0f)
        assertEquals(100, TimelineModel.xp(listOf(TimelineModel.DONE, TimelineModel.DONE)))
    }
}
