package com.swarmdeck

import com.swarmdeck.billing.ProLogic
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ProTest {
    private val hour = 60L * 60 * 1000

    @Test fun freshProCacheIsTrusted() = assertTrue(ProLogic.cachedEntitled(true, 1_000_000L, 1_000_000L + hour))

    @Test fun cacheExpiresAfterGrace() {
        assertTrue(ProLogic.cachedEntitled(true, 1_000_000L, 1_000_000L + 72 * hour))
        assertFalse(ProLogic.cachedEntitled(true, 1_000_000L, 1_000_000L + 72 * hour + 1))
    }

    @Test fun clockMovedBackIsRejected() = assertFalse(ProLogic.cachedEntitled(true, 5_000_000L, 1_000_000L))

    @Test fun notProOrNeverVerifiedIsNotEntitled() {
        assertFalse(ProLogic.cachedEntitled(false, 1_000_000L, 1_000_001L))
        assertFalse(ProLogic.cachedEntitled(true, 0L, 1_000_001L))
    }

    @Test fun serializeRoundTrip() {
        assertEquals(true to 123L, ProLogic.parse(ProLogic.serialize(true, 123L)))
        assertEquals(false to 9L, ProLogic.parse(ProLogic.serialize(false, 9L)))
        assertNull(ProLogic.parse(""))
        assertNull(ProLogic.parse("1|x"))
        assertNull(ProLogic.parse("2|5"))
        assertNull(ProLogic.parse("1|5|6"))
    }

    @Test fun periodLabels() {
        assertEquals("month", ProLogic.periodLabel("P1M"))
        assertEquals("year", ProLogic.periodLabel("P1Y"))
        assertEquals("7 days", ProLogic.periodLabel("P7D"))
        assertEquals("3 months", ProLogic.periodLabel("P3M"))
        assertEquals("weird", ProLogic.periodLabel("weird"))
    }
}

class ProLocalTest {
    private val day = ProLogic.DAY_MS

    @Test fun localWindow() {
        assertTrue(ProLogic.localActive(1_000L, 1_000L + 30 * day, 1_000L + day))
        assertFalse(ProLogic.localActive(1_000L, 1_000L + 30 * day, 1_000L + 30 * day))   // expired exactly at end
        assertFalse(ProLogic.localActive(5_000L, 9_000L, 1_000L))                          // clock moved back
        assertFalse(ProLogic.localActive(0L, 9_000L, 1_000L))
    }

    @Test fun renewAddsToRemainingTime() {
        val now = 10 * day
        assertEquals(now + 30 * day, ProLogic.extendUntil(0L, now))                // fresh or expired
        assertEquals(now + 5 * day + 30 * day, ProLogic.extendUntil(now + 5 * day, now)) // early renewal keeps the 5 days
    }
}
