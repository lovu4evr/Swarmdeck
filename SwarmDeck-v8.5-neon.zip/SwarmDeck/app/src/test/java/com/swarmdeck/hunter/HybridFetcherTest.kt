package com.swarmdeck.hunter

import org.junit.Assert.*
import org.junit.Test

class HybridFetcherTest {
    @Test
    fun spa_markers_detected() {
        assertTrue(HybridFetcher.looksLikeSpa("""<div id="__next"><script>x</script><script>y</script></div>"""))
        assertTrue(HybridFetcher.looksLikeSpa("""<div id="root"></div>"""))
        assertTrue(HybridFetcher.looksLikeSpa("short"))
    }

    @Test
    fun large_static_html_not_spa() {
        val body = "<html><body>" + ("pricing free tier 1000 requests per day ".repeat(400)) + "</body></html>"
        assertFalse(HybridFetcher.looksLikeSpa(body))
    }
}
