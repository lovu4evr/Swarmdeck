package com.swarmdeck.ui.nav

/**
 * Navigation destinations. String routes stay compatible with the existing sidebar
 * while [NavHost] becomes the single source of truth for back stack and deep links.
 */
object Routes {
    const val CHAT = "chat"
    const val AGENTS = "agents"
    const val GOALS = "goals"
    const val MISSIONS = "missions"
    const val MARKET = "market"
    const val MEMORY = "memory"
    const val MEMGRAPH = "memgraph"
    const val DEVICES = "devices"
    const val RESOURCES = "resources"
    const val IMMERSIVE = "immersive"
    const val TERMINAL = "terminal"
    const val TOOLS = "tools"
    const val PHONE = "phone"
    const val PRO = "pro"
    const val PRO_IMMERSIVE = "pro_immersive"
    const val SETTINGS = "settings"
    const val PROFILE = "profile"
    const val DIAGNOSTICS = "diagnostics"
    const val ONBOARDING = "onboarding"
    const val PRIVACY = "privacy"
    const val LOCAL_MODELS = "local_models"
    const val BACKUP = "backup"

    /** Pages gated behind SwarmDeck Pro in the sidebar. */
    val PRO_PAGES = setOf(MISSIONS, MARKET, MEMGRAPH, DEVICES, IMMERSIVE)

    fun isProPage(route: String) = route in PRO_PAGES
}
