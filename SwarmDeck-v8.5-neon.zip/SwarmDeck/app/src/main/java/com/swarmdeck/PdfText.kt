package com.swarmdeck

import java.io.ByteArrayOutputStream
import java.util.zip.Inflater

/** Dependency-free PDF text extractor (Flate streams, Tj/TJ operators, ToUnicode maps). Works for most text PDFs, not scans. */
object PdfText {
    fun looksLikeText(t: String): Boolean = t.length >= 200 && t.count { it.isLetter() }.toDouble() / t.length > 0.5

    private fun inflate(b: ByteArray): ByteArray? = try {
        val inf = Inflater()
        inf.setInput(b)
        val bo = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (!inf.finished()) {
            val n = inf.inflate(buf)
            if (n == 0 && (inf.needsInput() || inf.needsDictionary())) break
            bo.write(buf, 0, n)
            if (bo.size() > 8_000_000) break
        }
        inf.end()
        if (bo.size() == 0) null else bo.toByteArray()
    } catch (e: Exception) {
        null
    }

    fun extract(bytes: ByteArray, maxChars: Int = 14000): String {
        val s = String(bytes, Charsets.ISO_8859_1)
        val streams = ArrayList<String>()
        var from = 0
        var count = 0
        while (count < 400) {
            val k = s.indexOf("stream", from)
            if (k < 0) break
            from = k + 6
            if (k >= 3 && s.startsWith("end", k - 3)) continue
            var st = k + 6
            if (st < s.length && s[st] == '\r') st++
            if (st < s.length && s[st] == '\n') st++
            val e = s.indexOf("endstream", st)
            if (e < 0) break
            val raw = bytes.copyOfRange(st, e)
            streams.add(String(inflate(raw) ?: raw, Charsets.ISO_8859_1))
            from = e + 9
            count++
        }
        val cmap = HashMap<Int, String>()
        streams.filter { it.contains("beginbfchar") || it.contains("beginbfrange") }.forEach { parseCmap(it, cmap) }
        val sb = StringBuilder()
        for (st in streams) {
            if (st.contains("beginbfchar") || st.contains("beginbfrange")) continue
            if (!(st.contains("BT") && st.contains("ET"))) continue
            val t = textFromContent(st, cmap)
            if (t.isNotBlank()) sb.append(t).append("\n\n")
            if (sb.length > maxChars * 2) break
        }
        return sb.toString().replace(Regex("[ \\t]+"), " ").replace(Regex("\\n{3,}"), "\n\n").trim().take(maxChars)
    }

    private fun hexToStr(h: String): String = h.chunked(4).mapNotNull { it.toIntOrNull(16) }.joinToString("") { it.toChar().toString() }

    private fun parseCmap(t: String, out: MutableMap<Int, String>) {
        Regex("beginbfchar([\\s\\S]*?)endbfchar").findAll(t).forEach { m ->
            Regex("<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>").findAll(m.groupValues[1]).forEach { p ->
                val src = p.groupValues[1].toIntOrNull(16)
                if (src != null) out[src] = hexToStr(p.groupValues[2])
            }
        }
        Regex("beginbfrange([\\s\\S]*?)endbfrange").findAll(t).forEach { m ->
            Regex("<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>\\s*<([0-9A-Fa-f]+)>").findAll(m.groupValues[1]).forEach { p ->
                val lo = p.groupValues[1].toIntOrNull(16)
                val hi = p.groupValues[2].toIntOrNull(16)
                val base = p.groupValues[3].toIntOrNull(16)
                if (lo != null && hi != null && base != null && hi >= lo && hi - lo < 512) {
                    for (c in lo..hi) out[c] = (base + (c - lo)).toChar().toString()
                }
            }
        }
    }

    private fun mapBytes(s: String, cmap: Map<Int, String>): String {
        if (cmap.isEmpty()) return s.filter { it == '\n' || it == '\t' || it.code >= 32 }
        val sb = StringBuilder()
        for (ch in s) {
            val m = cmap[ch.code]
            if (m != null) sb.append(m) else if (ch.code >= 32) sb.append(ch)
        }
        return sb.toString()
    }

    private fun hexString(h0: String, cmap: Map<Int, String>): String {
        val h = h0.filter { it.isLetterOrDigit() }
        if (h.isEmpty()) return ""
        val sb = StringBuilder()
        val step = if (cmap.isNotEmpty() && h.length % 4 == 0) 4 else 2
        var k = 0
        while (k + step <= h.length) {
            val code = h.substring(k, k + step).toIntOrNull(16)
            if (code != null) {
                val m = cmap[code]
                if (m != null) sb.append(m) else if (code >= 32) sb.append(code.toChar())
            }
            k += step
        }
        return sb.toString()
    }

    private fun textFromContent(c: String, cmap: Map<Int, String>): String {
        val out = StringBuilder()
        val n = c.length
        var i = 0
        var inArr = false
        while (i < n) {
            val ch = c[i]
            if (ch == '(') {
                val sb = StringBuilder()
                var depth = 1
                i++
                while (i < n && depth > 0) {
                    val d = c[i]
                    if (d == '\\' && i + 1 < n) {
                        val e = c[i + 1]
                        if (e in '0'..'7') {
                            var j = i + 1
                            var v = 0
                            var k = 0
                            while (j < n && k < 3 && c[j] in '0'..'7') { v = v * 8 + (c[j] - '0'); j++; k++ }
                            sb.append((v and 0xFF).toChar())
                            i = j
                        } else {
                            when (e) {
                                'n' -> sb.append('\n')
                                'r' -> sb.append('\r')
                                't' -> sb.append('\t')
                                else -> sb.append(e)
                            }
                            i += 2
                        }
                    } else {
                        if (d == '(') depth++ else if (d == ')') depth--
                        if (depth > 0) sb.append(d)
                        i++
                    }
                }
                out.append(mapBytes(sb.toString(), cmap))
            } else if (ch == '<' && i + 1 < n && c[i + 1] != '<') {
                val e = c.indexOf('>', i)
                if (e < 0) i = n else { out.append(hexString(c.substring(i + 1, e), cmap)); i = e + 1 }
            } else if (ch == '[') { inArr = true; i++ }
            else if (ch == ']') { inArr = false; i++ }
            else if (ch == '-' || ch.isDigit()) {
                var j = i + 1
                while (j < n && (c[j].isDigit() || c[j] == '.')) j++
                if (inArr && ch == '-') {
                    val v = c.substring(i, j).toDoubleOrNull()
                    if (v != null && v < -200) out.append(' ')
                }
                i = j
            } else if (ch.isLetter()) {
                var j = i + 1
                while (j < n && (c[j].isLetterOrDigit() || c[j] == '*')) j++
                when (c.substring(i, j)) {
                    "T*", "ET" -> out.append('\n')
                    "Td", "TD", "Tm" -> out.append(' ')
                }
                i = j
            } else i++
        }
        return out.toString()
    }
}
