package com.swarmdeck.brain

import org.json.JSONObject

/** Pulls the first balanced JSON object out of a model reply (handles ``` fences and chatter). Pure JVM. */
object LlmJson {
    fun extractObject(text: String): JSONObject? {
        val s = text.replace("```json", "").replace("```", "")
        var start = s.indexOf('{')
        while (start >= 0) {
            val end = matching(s, start)
            if (end > start) {
                try {
                    return JSONObject(s.substring(start, end + 1))
                } catch (_: Exception) {
                }
            }
            start = s.indexOf('{', start + 1)
        }
        return null
    }

    private fun matching(s: String, start: Int): Int {
        var depth = 0
        var inStr = false
        var esc = false
        for (i in start until s.length) {
            val ch = s[i]
            if (inStr) {
                if (esc) {
                    esc = false
                } else if (ch == '\\') {
                    esc = true
                } else if (ch == '"') {
                    inStr = false
                }
            } else {
                if (ch == '"') {
                    inStr = true
                } else if (ch == '{') {
                    depth++
                } else if (ch == '}') {
                    depth--
                    if (depth == 0) return i
                }
            }
        }
        return -1
    }
}
