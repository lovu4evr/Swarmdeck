package com.swarmdeck.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.core.*
import com.swarmdeck.mission.MissionEngine

private val Gold = Color(0xFFD4AF37)
private val DarkBg = Color(0xFF0D0D0D)
private val CardBg = Color(0xFF1A1A1A)

@Composable
fun MissionsScreen(context: android.content.Context, onBack: () -> Unit) {
    var missions by remember { mutableStateOf(MissionEngine.list(context)) }
    var showCreate by remember { mutableStateOf(false) }
    var objective by remember { mutableStateOf("") }

    fun refresh() { missions = MissionEngine.list(context) }

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }
            Text("Missions", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null, tint = Gold) }
        }

        if (missions.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No missions yet.\nCreate one to get started.", color = Color.Gray)
            }
        } else {
            LazyColumn(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(missions, key = { it.id }) { m ->
                    MissionCard(m,
                        onStart = { MissionEngine.start(context, m.id); refresh() },
                        onPause = { MissionEngine.pause(context, m.id); refresh() },
                        onResume = { MissionEngine.resume(context, m.id); refresh() },
                        onCancel = { MissionEngine.cancel(context, m.id); refresh() },
                        onApprove = { cp ->
                            MissionEngine.approveCheckpoint(context, m.id, cp.id)
                            refresh()
                        }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("New Mission", color = Gold) },
            text = {
                OutlinedTextField(
                    objective, { objective = it },
                    label = { Text("Objective") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (objective.isNotBlank()) {
                        MissionEngine.createSmart(context, objective)
                        objective = ""
                        showCreate = false
                        refresh()
                    }
                }) { Text("Create", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } },
            containerColor = CardBg
        )
    }
}

@Composable
private fun MissionCard(
    m: MissionV2,
    onStart: () -> Unit,
    onPause: () -> Unit,
    onResume: () -> Unit,
    onCancel: () -> Unit,
    onApprove: (MissionCheckpoint) -> Unit
) {
    val statusColor = when (m.status) {
        MissionStatus.RUNNING -> Color(0xFF4CAF50)
        MissionStatus.WAITING_APPROVAL -> Color(0xFFFF9800)
        MissionStatus.COMPLETED -> Gold
        MissionStatus.FAILED, MissionStatus.CANCELLED -> Color.Red
        else -> Color.Gray
    }
    val progress = MissionEngine.progress(m)

    Card(
        Modifier.fillMaxWidth().border(1.dp, statusColor.copy(0.4f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(CardBg),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(m.objective, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2)
            Spacer(Modifier.height(6.dp))
            Text(m.status.name, color = statusColor, fontSize = 12.sp)
            Spacer(Modifier.height(6.dp))
            LinearProgressIndicator(progress = { progress }, Modifier.fillMaxWidth().height(6.dp), color = statusColor, trackColor = Color.DarkGray)
            Spacer(Modifier.height(8.dp))

            // Checkpoints
            m.checkpoints.forEach { cp ->
                val cpColor = when (cp.status) {
                    CheckpointStatus.COMPLETED -> Color(0xFF4CAF50)
                    CheckpointStatus.RUNNING -> Gold
                    CheckpointStatus.WAITING_APPROVAL -> Color(0xFFFF9800)
                    CheckpointStatus.FAILED -> Color.Red
                    else -> Color.Gray
                }
                Row(Modifier.padding(vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("• ${cp.title}", color = cpColor, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    if (cp.status == CheckpointStatus.WAITING_APPROVAL) {
                        TextButton(onClick = { onApprove(cp) }) {
                            Text("Approve", color = Gold, fontSize = 11.sp)
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Row {
                when (m.status) {
                    MissionStatus.PLANNING -> TextButton(onClick = onStart) { Text("Start", color = Gold, fontSize = 12.sp) }
                    MissionStatus.RUNNING -> TextButton(onClick = onPause) { Text("Pause", color = Gold, fontSize = 12.sp) }
                    MissionStatus.PAUSED, MissionStatus.WAITING_APPROVAL -> TextButton(onClick = onResume) { Text("Resume", color = Gold, fontSize = 12.sp) }
                    else -> {}
                }
                if (m.status != MissionStatus.COMPLETED && m.status != MissionStatus.CANCELLED) {
                    TextButton(onClick = onCancel) { Text("Cancel", color = Color.Red.copy(0.8f), fontSize = 12.sp) }
                }
            }
        }
    }
}
