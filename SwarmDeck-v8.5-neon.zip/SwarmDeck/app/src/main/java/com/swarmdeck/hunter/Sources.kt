package com.swarmdeck.hunter

import org.json.JSONArray
import org.json.JSONObject

data class SourceResult(val source: String, val found: List<Resource>, val error: String = "")

/** A place the Hunter can discover resources from. A failing source never stops the others. */
interface Source {
    val name: String
    fun discover(f: Fetcher, now: Long): SourceResult
}

/**
 * Starting points: official provider sites only. A seed carries NO free-tier claims - quotas, limits and restrictions are
 * filled in only when the Verifier reads the official page. If a URL here is wrong or moves, verification flags it.
 */
object SeedCatalog {
    private fun s(
        provider: String, name: String, cat: Category, official: String, docs: String,
        local: Boolean = false, account: Boolean? = null, now: Long
    ): Resource = Resource(
        id = Ids.of(provider, name), provider = provider, name = name, category = cat,
        officialUrl = official, docsUrl = docs, source = "seed", local = local, needsAccount = account,
        firstSeen = now
    )

    fun all(now: Long): List<Resource> = listOf(
        // Free AI API providers
        s("Google AI Studio", "Gemini API", Category.AI_API, "https://ai.google.dev/", "https://ai.google.dev/gemini-api/docs/pricing", account = true, now = now),
        s("Groq", "GroqCloud API", Category.AI_API, "https://groq.com/", "https://console.groq.com/docs/rate-limits", account = true, now = now),
        s("OpenRouter", "OpenRouter free models", Category.AI_API, "https://openrouter.ai/", "https://openrouter.ai/docs/api-reference/limits", account = true, now = now),
        s("Mistral AI", "La Plateforme free tier", Category.AI_API, "https://mistral.ai/", "https://mistral.ai/pricing", account = true, now = now),
        s("Cohere", "Cohere trial API keys", Category.AI_API, "https://cohere.com/", "https://docs.cohere.com/docs/rate-limits", account = true, now = now),
        s("NVIDIA", "NVIDIA NIM API catalog", Category.AI_API, "https://build.nvidia.com/", "https://docs.api.nvidia.com/", account = true, now = now),
        s("GitHub", "GitHub Models", Category.AI_API, "https://github.com/marketplace?type=models", "https://docs.github.com/en/github-models", account = true, now = now),
        s("Cerebras", "Cerebras Inference", Category.AI_API, "https://www.cerebras.ai/", "https://inference-docs.cerebras.ai/support/rate-limits", account = true, now = now),
        s("SambaNova", "SambaNova Cloud", Category.AI_API, "https://sambanova.ai/", "https://docs.sambanova.ai/", account = true, now = now),
        // Free inference
        s("Cloudflare", "Workers AI", Category.INFERENCE, "https://developers.cloudflare.com/workers-ai/", "https://developers.cloudflare.com/workers-ai/platform/pricing/", account = true, now = now),
        s("Hugging Face", "Inference Providers", Category.INFERENCE, "https://huggingface.co/", "https://huggingface.co/docs/inference-providers/pricing", account = true, now = now),
        // Open-source LLMs (individual models are discovered from the Hugging Face API)
        s("Hugging Face", "Open-weight models hub", Category.OPEN_LLM, "https://huggingface.co/models", "https://huggingface.co/docs/hub/models-the-hub", account = false, now = now),
        // Free cloud hosting
        s("Cloudflare", "Pages", Category.HOSTING, "https://pages.cloudflare.com/", "https://developers.cloudflare.com/pages/platform/limits/", account = true, now = now),
        s("Netlify", "Free plan", Category.HOSTING, "https://www.netlify.com/", "https://www.netlify.com/pricing/", account = true, now = now),
        s("Vercel", "Hobby plan", Category.HOSTING, "https://vercel.com/", "https://vercel.com/pricing", account = true, now = now),
        s("GitHub", "Pages", Category.HOSTING, "https://pages.github.com/", "https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits", account = true, now = now),
        s("Render", "Free instances", Category.HOSTING, "https://render.com/", "https://render.com/pricing", account = true, now = now),
        s("Oracle Cloud", "Always Free", Category.HOSTING, "https://www.oracle.com/cloud/free/", "https://www.oracle.com/cloud/free/", account = true, now = now),
        s("Google Cloud", "Free program", Category.HOSTING, "https://cloud.google.com/free", "https://cloud.google.com/free/docs/free-cloud-features", account = true, now = now),
        s("Hugging Face", "Spaces", Category.HOSTING, "https://huggingface.co/spaces", "https://huggingface.co/docs/hub/spaces-overview", account = true, now = now),
        // Free databases
        s("Supabase", "Free plan", Category.DATABASE, "https://supabase.com/", "https://supabase.com/pricing", account = true, now = now),
        s("Neon", "Free plan", Category.DATABASE, "https://neon.tech/", "https://neon.tech/pricing", account = true, now = now),
        s("MongoDB", "Atlas free cluster", Category.DATABASE, "https://www.mongodb.com/atlas", "https://www.mongodb.com/pricing", account = true, now = now),
        s("Turso", "Free plan", Category.DATABASE, "https://turso.tech/", "https://turso.tech/pricing", account = true, now = now),
        s("Cloudflare", "D1", Category.DATABASE, "https://developers.cloudflare.com/d1/", "https://developers.cloudflare.com/d1/platform/pricing/", account = true, now = now),
        s("Upstash", "Free plan", Category.DATABASE, "https://upstash.com/", "https://upstash.com/pricing", account = true, now = now),
        s("SQLite", "Embedded database", Category.DATABASE, "https://www.sqlite.org/", "https://www.sqlite.org/copyright.html", local = true, account = false, now = now),
        // Free developer tools
        s("GitHub", "Actions and Codespaces free quota", Category.DEV_TOOL, "https://github.com/features/actions", "https://github.com/pricing", account = true, now = now),
        s("Sentry", "Developer plan", Category.DEV_TOOL, "https://sentry.io/", "https://sentry.io/pricing/", account = true, now = now),
        s("Termux", "Android terminal", Category.DEV_TOOL, "https://termux.dev/", "https://github.com/termux/termux-app", local = true, account = false, now = now),
        // Open-source automation
        s("n8n", "Self-hosted workflow automation", Category.AUTOMATION, "https://n8n.io/", "https://docs.n8n.io/sustainable-use-license/", local = true, account = false, now = now),
        s("Node-RED", "Flow-based automation", Category.AUTOMATION, "https://nodered.org/", "https://nodered.org/about/", local = true, account = false, now = now),
        s("Activepieces", "Open-source automation", Category.AUTOMATION, "https://www.activepieces.com/", "https://github.com/activepieces/activepieces", local = true, account = false, now = now),
        // Free datasets
        s("Hugging Face", "Datasets hub", Category.DATASET, "https://huggingface.co/datasets", "https://huggingface.co/docs/datasets/index", account = false, now = now),
        s("Kaggle", "Datasets", Category.DATASET, "https://www.kaggle.com/datasets", "https://www.kaggle.com/terms", account = true, now = now),
        s("Common Crawl", "Web crawl archive", Category.DATASET, "https://commoncrawl.org/", "https://commoncrawl.org/terms-of-use", account = false, now = now),
        s("Data.gov", "US open data", Category.DATASET, "https://data.gov/", "https://data.gov/about/", account = false, now = now),
        s("Wikimedia", "Database dumps", Category.DATASET, "https://dumps.wikimedia.org/", "https://dumps.wikimedia.org/legal.html", account = false, now = now),
        // Local / offline AI
        s("Ollama", "Local model runner", Category.LOCAL_MODEL, "https://ollama.com/", "https://ollama.com/library", local = true, account = false, now = now),
        s("llama.cpp", "CPU/GPU inference engine", Category.LOCAL_MODEL, "https://github.com/ggml-org/llama.cpp", "https://github.com/ggml-org/llama.cpp", local = true, account = false, now = now),
        s("LM Studio", "Desktop model runner", Category.LOCAL_MODEL, "https://lmstudio.ai/", "https://lmstudio.ai/", local = true, account = false, now = now),
        s("Google", "MediaPipe LLM Inference (on-device)", Category.LOCAL_MODEL, "https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference", "https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference", local = true, account = false, now = now),
        s("MLC", "MLC LLM (on-device)", Category.LOCAL_MODEL, "https://llm.mlc.ai/", "https://llm.mlc.ai/docs/", local = true, account = false, now = now),
        s("Jan", "Offline assistant", Category.LOCAL_MODEL, "https://jan.ai/", "https://github.com/janhq/jan", local = true, account = false, now = now)
    )
}

/** Built-in list entry point: the seed catalog as a Source (no network). */
class SeedSource : Source {
    override val name = "seed"
    override fun discover(f: Fetcher, now: Long): SourceResult = SourceResult(name, SeedCatalog.all(now))
}

/**
 * OpenRouter's public model list (no key needed). A model is "free" only when OpenRouter itself lists both its prompt and
 * completion price as exactly 0. Because the data comes from the provider's own API the record starts VERIFIED, and
 * re-verification checks the model is still listed as free.
 */
class OpenRouterSource(private val maxModels: Int = 15) : Source {
    override val name = "openrouter"

    override fun discover(f: Fetcher, now: Long): SourceResult {
        val res = f.get(MODELS_URL, 3_000_000L)
        if (!res.ok) return SourceResult(name, emptyList(), "HTTP ${res.status} ${res.error}".trim())
        return try {
            SourceResult(name, parse(res.body, now, maxModels))
        } catch (e: Exception) {
            SourceResult(name, emptyList(), "bad response: ${e.message}")
        }
    }

    companion object {
        const val MODELS_URL = "https://openrouter.ai/api/v1/models"
        const val API_BASE = "https://openrouter.ai/api/v1"

        fun isFree(pricing: JSONObject?): Boolean {
            if (pricing == null) return false
            val p = pricing.optString("prompt", "").toDoubleOrNull()
            val c = pricing.optString("completion", "").toDoubleOrNull()
            return p != null && c != null && p == 0.0 && c == 0.0
        }

        /** All model ids OpenRouter currently lists as free. */
        fun freeIds(body: String): Set<String> {
            val data = JSONObject(body).optJSONArray("data") ?: throw IllegalArgumentException("no data array")
            val out = HashSet<String>()
            for (i in 0 until data.length()) {
                val m = data.optJSONObject(i) ?: continue
                if (isFree(m.optJSONObject("pricing"))) out.add(m.optString("id", ""))
            }
            out.remove("")
            return out
        }

        fun parse(body: String, now: Long, max: Int): List<Resource> {
            val data = JSONObject(body).optJSONArray("data") ?: throw IllegalArgumentException("no data array")
            val out = ArrayList<Resource>()
            for (i in 0 until data.length()) {
                val m = data.optJSONObject(i) ?: continue
                if (!isFree(m.optJSONObject("pricing"))) continue
                val id = Sanitize.clean(m.optString("id", ""), 120)
                if (id.isEmpty()) continue
                val title = Sanitize.clean(m.optString("name", id), 120)
                val ctx = m.optInt("context_length", 0)
                out.add(
                    Resource(
                        id = Ids.of("OpenRouter", id), provider = "OpenRouter", name = id, category = Category.INFERENCE,
                        officialUrl = "https://openrouter.ai/models", docsUrl = MODELS_URL, apiBase = API_BASE,
                        source = name_(), freeTier = "Free model: OpenRouter lists prompt and completion price as 0.",
                        models = listOf(id), restrictions = listOf("Free models share rate limits; see the provider limits entry for details."),
                        needsAccount = true, contextLen = ctx, quality = Quality.score("$id $title", ctx),
                        status = VStatus.VERIFIED, evidence = "openrouter /api/v1/models: pricing.prompt=0 and pricing.completion=0",
                        firstSeen = now, lastChecked = now, lastVerified = now
                    )
                )
            }
            return out.sortedByDescending { it.quality }.take(max)
        }

        private fun name_() = "openrouter"
    }
}

private val PERMISSIVE = setOf("apache-2.0", "mit", "bsd-3-clause", "bsd-2-clause", "cc0-1.0", "unlicense", "cc-by-4.0", "isc", "mpl-2.0")

/** Hugging Face public API: downloadable open-weight models (GGUF = runs offline on a phone/PC) and datasets. */
class HuggingFaceSource(private val perQuery: Int = 10) : Source {
    override val name = "huggingface"

    override fun discover(f: Fetcher, now: Long): SourceResult {
        val all = ArrayList<Resource>()
        val errors = ArrayList<String>()
        val queries = listOf(
            Triple("gguf", "https://huggingface.co/api/models?pipeline_tag=text-generation&filter=gguf&sort=downloads&direction=-1&limit=$perQuery", Category.LOCAL_MODEL),
            Triple("model", "https://huggingface.co/api/models?pipeline_tag=text-generation&sort=likes&direction=-1&limit=$perQuery", Category.OPEN_LLM),
            Triple("dataset", "https://huggingface.co/api/datasets?sort=downloads&direction=-1&limit=$perQuery", Category.DATASET)
        )
        for ((kind, url, cat) in queries) {
            val res = f.get(url, 2_000_000L)
            if (!res.ok) { errors.add("$kind: HTTP ${res.status} ${res.error}".trim()); continue }
            try {
                all.addAll(parse(res.body, cat, now, perQuery))
            } catch (e: Exception) {
                errors.add("$kind: bad response")
            }
        }
        return SourceResult(name, all, if (all.isEmpty()) errors.joinToString("; ") else "")
    }

    companion object {
        fun parse(body: String, cat: Category, now: Long, max: Int): List<Resource> {
            val arr = JSONArray(body)
            val out = ArrayList<Resource>()
            for (i in 0 until arr.length()) {
                if (out.size >= max) break
                val m = arr.optJSONObject(i) ?: continue
                if (m.optBoolean("private", false)) continue
                val id = Sanitize.clean(m.optString("id", ""), 120)
                if (id.isEmpty()) continue
                val tags = m.optJSONArray("tags")
                var license = ""
                if (tags != null) for (k in 0 until tags.length()) {
                    val t = tags.optString(k, "")
                    if (t.startsWith("license:")) license = t.removePrefix("license:").lowercase()
                }
                val g = m.opt("gated")
                val gated = g != null && g != false && g.toString() != "false" && g != JSONObject.NULL
                val restrictions = ArrayList<String>()
                if (license.isEmpty()) restrictions.add("License not declared on the model page")
                else if (license !in PERMISSIVE) restrictions.add("License: ${Sanitize.clean(license, 40)} - check commercial-use terms")
                if (gated) restrictions.add("Gated: you must accept the publisher's terms on the website yourself")
                val isData = cat == Category.DATASET
                val path = if (isData) "datasets/$id" else id
                val downloads = m.optLong("downloads", 0L)
                out.add(
                    Resource(
                        id = Ids.of("Hugging Face", id), provider = "Hugging Face", name = id, category = cat,
                        officialUrl = "https://huggingface.co/$path",
                        docsUrl = "https://huggingface.co/api/" + (if (isData) "datasets/" else "models/") + id,
                        source = "huggingface",
                        freeTier = if (isData) "Public dataset, free to download" + (if (license.isNotEmpty()) " (license: ${Sanitize.clean(license, 40)})" else "")
                        else "Open weights, free to download" + (if (license.isNotEmpty()) " (license: ${Sanitize.clean(license, 40)})" else ""),
                        models = if (isData) emptyList() else listOf(id), restrictions = restrictions,
                        needsAccount = gated, local = cat == Category.LOCAL_MODEL,
                        quality = if (isData) 0.0 else Quality.score(id, 0, downloads),
                        status = VStatus.VERIFIED, evidence = "huggingface.co public API listing",
                        firstSeen = now, lastChecked = now, lastVerified = now
                    )
                )
            }
            return out
        }
    }
}

/** GitHub search API (unauthenticated): popular open-source automation tools and local-LLM runtimes. Archived repos are skipped. */
class GithubSource(private val perQuery: Int = 8) : Source {
    override val name = "github"

    override fun discover(f: Fetcher, now: Long): SourceResult {
        val all = ArrayList<Resource>()
        val errors = ArrayList<String>()
        val queries = listOf(
            Pair("https://api.github.com/search/repositories?q=topic:workflow-automation+stars:%3E3000&sort=stars&order=desc&per_page=$perQuery", Category.AUTOMATION),
            Pair("https://api.github.com/search/repositories?q=topic:local-llm+stars:%3E3000&sort=stars&order=desc&per_page=$perQuery", Category.LOCAL_MODEL)
        )
        for ((url, cat) in queries) {
            val res = f.get(url, 1_500_000L)
            if (!res.ok) { errors.add("HTTP ${res.status} ${res.error}".trim()); continue }
            try {
                all.addAll(parse(res.body, cat, now, perQuery))
            } catch (e: Exception) {
                errors.add("bad response")
            }
        }
        return SourceResult(name, all, if (all.isEmpty()) errors.joinToString("; ") else "")
    }

    companion object {
        fun parse(body: String, cat: Category, now: Long, max: Int): List<Resource> {
            val items = JSONObject(body).optJSONArray("items") ?: throw IllegalArgumentException("no items")
            val out = ArrayList<Resource>()
            for (i in 0 until items.length()) {
                if (out.size >= max) break
                val m = items.optJSONObject(i) ?: continue
                if (m.optBoolean("archived", false) || m.optBoolean("disabled", false)) continue
                val full = Sanitize.clean(m.optString("full_name", ""), 120)
                if (full.isEmpty() || !full.contains('/')) continue
                val spdx = m.optJSONObject("license")?.optString("spdx_id", "") ?: ""
                val lic = spdx.lowercase()
                val restrictions = ArrayList<String>()
                if (spdx.isEmpty() || spdx == "NOASSERTION") restrictions.add("License unclear: read the repository license before use")
                else if (lic !in PERMISSIVE) restrictions.add("License: ${Sanitize.clean(spdx, 40)} - check terms (copyleft or source-available)")
                restrictions.add("Free to self-host; your own compute, hosting and maintenance costs still apply")
                val stars = m.optLong("stargazers_count", 0L)
                out.add(
                    Resource(
                        id = Ids.of("GitHub", full), provider = "GitHub", name = full, category = cat,
                        officialUrl = "https://github.com/$full", docsUrl = "https://api.github.com/repos/$full",
                        source = "github", freeTier = "Open-source" + (if (spdx.isNotEmpty() && spdx != "NOASSERTION") " (${Sanitize.clean(spdx, 40)})" else "") + ", free to self-host",
                        restrictions = restrictions, needsAccount = false, local = true,
                        quality = Quality.score(full, 0, stars),
                        status = VStatus.VERIFIED, evidence = "api.github.com repository search: not archived",
                        firstSeen = now, lastChecked = now, lastVerified = now
                    )
                )
            }
            return out
        }
    }
}

fun defaultSources(): List<Source> = listOf(SeedSource(), OpenRouterSource(), HuggingFaceSource(), GithubSource())
