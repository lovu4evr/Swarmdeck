package com.swarmdeck.hunter

import com.swarmdeck.Parse
import org.json.JSONObject
import java.security.MessageDigest
import java.time.LocalDate
import java.time.ZoneOffset

/** What the text of an official page says about free usage. Everything here is extracted by fixed patterns: page text is never obeyed. */
data class Analysis(
    val freeMentioned: Boolean,
    val permanentFree: Boolean,
    val trialOnly: Boolean,
    val endedPhrase: Boolean,
    val cardRequired: Boolean?,
    val quotas: List<String>,
    val rpm: Int,
    val rpd: Int,
    val restrictions: List<String>,
    val expiresAt: Long,
    val snippets: List<String>
) {
    /** Stable fingerprint of the policy facts (not of the whole page, which changes for unrelated reasons). */
    fun signature(): String {
        val raw = listOf(permanentFree, trialOnly, endedPhrase, cardRequired).joinToString(",") + "|" +
            quotas.sorted().joinToString(";") + "|" + restrictions.sorted().joinToString(";") + "|" + expiresAt
        return sha256(raw).take(24)
    }

    companion object {
        fun sha256(s: String): String =
            MessageDigest.getInstance("SHA-256").digest(s.toByteArray(Charsets.UTF_8)).joinToString("") { "%02x".format(it) }
    }
}

object FreeTierAnalyzer {
    private val FREE = Regex("(?i)\\bfree(?: tier| plan| forever| usage| to use| of charge| credits?| access| requests?| tokens?| api)?\\b|\\$0\\b|\\balways[- ]free\\b")
    private val OPEN = Regex("(?i)open[- ]source|apache(?: license)?(?: 2\\.0)?|\\bmit license\\b|free software|\\bgpl\\b|public domain|source[- ]available|fair[- ]code")
    private val PERMANENT = Regex("(?i)free (?:tier|plan|forever)|always[- ]free|forever[- ]free|free (?:usage|requests|calls|tokens|api|access|of charge)|free[^.]{0,40}per (?:month|day|minute)|per (?:month|day|minute)[^.]{0,30}free")
    private val TRIAL = Regex("(?i)free trial|trial credits?|\\$\\d+(?:\\.\\d+)? (?:in )?(?:free )?credits?")
    private val ENDED = Regex("(?i)free (?:tier|plan|access)[^.]{0,40}(?:has ended|is discontinued|was discontinued|no longer (?:available|offered)|sunset|retired)|no longer offers? (?:a )?free")
    private val NO_CARD = Regex("(?i)no credit card|without (?:a )?credit card|no payment (?:method|information|details)")
    private val CARD = Regex("(?i)credit card (?:is )?required|requires? (?:a )?credit card|payment method (?:is )?required|add a payment method")

    private val REQ = Regex("(?i)(\\d[\\d,]*(?:\\.\\d+)?\\s?[km]?)\\s*(?:requests?|reqs?|calls?|queries|messages)\\s*(?:/|per|a|each)\\s*(second|sec|minute|min|hour|day|month)")
    private val TOK = Regex("(?i)(\\d[\\d,]*(?:\\.\\d+)?\\s?[kmb]?)\\s*tokens?\\s*(?:/|per|a|each)\\s*(minute|min|day|month)")
    private val RPM = Regex("(?i)(\\d[\\d,]*)\\s*rpm\\b")
    private val RPD = Regex("(?i)(\\d[\\d,]*)\\s*rpd\\b")
    private val STORE = Regex("(?i)(\\d[\\d,]*(?:\\.\\d+)?)\\s?(MB|GB|TB)\\s+(?:of\\s+)?(storage|database|bandwidth|memory|ram|egress)")

    private val MONTHS = mapOf("jan" to 1, "feb" to 2, "mar" to 3, "apr" to 4, "may" to 5, "jun" to 6, "jul" to 7, "aug" to 8, "sep" to 9, "oct" to 10, "nov" to 11, "dec" to 12)
    private val DATE_TEXT = Regex("(?i)(?:expires?|expiring|ends?|valid|available|free)\\s+(?:on|until|through|till|by)\\s+(jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?\\s+(\\d{1,2})(?:st|nd|rd|th)?,?\\s+(\\d{4})")
    private val DATE_ISO = Regex("(?i)(?:expires?|ends?|valid|available|free)\\s+(?:on|until|through|till|by)\\s+(\\d{4})-(\\d{2})-(\\d{2})")

    private val RESTRICTIONS: List<Pair<String, Regex>> = listOf(
        "Non-commercial use only" to Regex("(?i)non-?commercial|personal use only|research (?:use )?only"),
        "Student / educational eligibility" to Regex("(?i)(?:free|available) (?:for|to) (?:verified )?(?:students|educators|education)"),
        "Waitlist, invite-only or beta access" to Regex("(?i)waitlist|invite[- ]only|early access|\\bbeta\\b"),
        "Region restrictions apply" to Regex("(?i)not available in (?:the )?(?:eu|uk|eea|europe)|(?:us|u\\.s\\.) (?:residents|only)"),
        "Phone verification required" to Regex("(?i)phone (?:number )?verification|verify (?:your )?phone"),
        "Fair-use limits apply" to Regex("(?i)fair[- ]use"),
        "Prompts or data may be used to improve products" to Regex("(?i)(?:data|prompts?|content) (?:may be|is|are) (?:used|retained)[^.]{0,40}(?:train|improve)"),
        "Projects or instances pause after inactivity" to Regex("(?i)(?:paused|suspended|spun down|sleep)[^.]{0,30}(?:inactiv|\\d+ days?)")
    )

    private fun num(raw: String): Double? {
        val t = raw.trim().lowercase().replace(",", "").replace(" ", "")
        if (t.isEmpty()) return null
        val mult = when (t.last()) { 'k' -> 1_000.0; 'm' -> 1_000_000.0; 'b' -> 1_000_000_000.0; else -> 1.0 }
        val d = (if (mult != 1.0) t.dropLast(1) else t).toDoubleOrNull() ?: return null
        return d * mult
    }

    private fun fmt(d: Double): String = when {
        d >= 1_000_000 && d % 1_000_000.0 == 0.0 -> "${(d / 1_000_000).toLong()}M"
        d >= 1000 && d % 1000.0 == 0.0 -> "${(d / 1000).toLong()}k"
        d == Math.floor(d) -> d.toLong().toString()
        else -> d.toString()
    }

    private fun unit(u: String): String = when (u.lowercase()) { "second", "sec" -> "sec"; "minute", "min" -> "min"; else -> u.lowercase() }

    fun analyze(text: String, now: Long): Analysis {
        val freeHits = FREE.findAll(text).take(60).toList()
        val openHit = OPEN.containsMatchIn(text)
        val snippets = ArrayList<String>()
        var lastEnd = -1000
        for (m in freeHits) {
            if (snippets.size >= 5) break
            if (m.range.first - lastEnd < 160) continue
            val from = maxOf(0, m.range.first - 80)
            val to = minOf(text.length, m.range.last + 160)
            snippets.add(Sanitize.clean(text.substring(from, to), 240))
            lastEnd = m.range.last
        }
        if (snippets.isEmpty() && openHit) OPEN.find(text)?.let { m ->
            snippets.add(Sanitize.clean(text.substring(maxOf(0, m.range.first - 80), minOf(text.length, m.range.last + 160)), 240))
        }
        val quotas = ArrayList<String>()
        var rpm = 0L
        var rpd = 0L
        fun low(cur: Long, v: Long) = if (v <= 0L) cur else if (cur == 0L) v else minOf(cur, v)
        for (m in REQ.findAll(text).take(30)) {
            val n = num(m.groupValues[1]) ?: continue
            val u = unit(m.groupValues[2])
            quotas.add("${fmt(n)} requests/$u")
            when (u) {
                "sec" -> rpm = low(rpm, (n * 60).toLong())
                "min" -> rpm = low(rpm, n.toLong())
                "day" -> rpd = low(rpd, n.toLong())
                "hour" -> rpd = low(rpd, (n * 24).toLong())
                "month" -> rpd = low(rpd, (n / 30).toLong())
            }
        }
        for (m in RPM.findAll(text).take(10)) { val n = num(m.groupValues[1]) ?: continue; quotas.add("${fmt(n)} requests/min"); rpm = low(rpm, n.toLong()) }
        for (m in RPD.findAll(text).take(10)) { val n = num(m.groupValues[1]) ?: continue; quotas.add("${fmt(n)} requests/day"); rpd = low(rpd, n.toLong()) }
        for (m in TOK.findAll(text).take(10)) { val n = num(m.groupValues[1]) ?: continue; quotas.add("${fmt(n)} tokens/${unit(m.groupValues[2])}") }
        STORE.find(text)?.let { m -> quotas.add("${m.groupValues[1]} ${m.groupValues[2].uppercase()} ${m.groupValues[3].lowercase()}") }
        val distinctQuotas = quotas.distinct().take(6)

        val ended = ENDED.containsMatchIn(text)
        val permanent = PERMANENT.containsMatchIn(text) || (openHit && freeHits.isNotEmpty())
        val trialMention = TRIAL.containsMatchIn(text)
        val card: Boolean? = if (NO_CARD.containsMatchIn(text)) false else if (CARD.containsMatchIn(text)) true else null
        val restrictions = RESTRICTIONS.filter { it.second.containsMatchIn(text) }.map { it.first }

        return Analysis(
            freeMentioned = freeHits.isNotEmpty() || openHit,
            permanentFree = permanent && !ended,
            trialOnly = trialMention && !permanent,
            endedPhrase = ended,
            cardRequired = card,
            quotas = distinctQuotas,
            rpm = rpm.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            rpd = rpd.coerceAtMost(Int.MAX_VALUE.toLong()).toInt(),
            restrictions = restrictions,
            expiresAt = expiry(text),
            snippets = snippets
        )
    }

    /** Latest "expires/until <date>" found, as end-of-day UTC; 0 if none. */
    fun expiry(text: String): Long {
        var best = 0L
        fun take(y: Int, mo: Int, d: Int) {
            try {
                val ms = LocalDate.of(y, mo, d).atTime(23, 59, 59).toInstant(ZoneOffset.UTC).toEpochMilli()
                if (ms > best) best = ms
            } catch (_: Exception) {
            }
        }
        for (m in DATE_TEXT.findAll(text).take(10)) {
            val mo = MONTHS[m.groupValues[1].lowercase().take(3)] ?: continue
            take(m.groupValues[3].toInt(), mo, m.groupValues[2].toInt())
        }
        for (m in DATE_ISO.findAll(text).take(10)) take(m.groupValues[1].toInt(), m.groupValues[2].toInt(), m.groupValues[3].toInt())
        return best
    }
}

class Outcome(val resource: Resource, val events: List<HunterEvent>)

/**
 * Checks one resource against its OFFICIAL page or API, never against anything else.
 *  - API listings (OpenRouter) and public registries (Hugging Face, GitHub): confirm the item still exists / is still free.
 *  - Provider pages: confirm free-tier wording, extract quotas and restrictions, detect policy changes.
 * A page is trusted only if, after redirects, it is still on a domain the catalog lists for that resource.
 * Page text is analysed with fixed patterns and never treated as instructions.
 */
class Verifier(private val fetcher: Fetcher, private val clock: () -> Long = { System.currentTimeMillis() }) {

    fun verify(r: Resource, cache: MutableMap<String, FetchResult>): Outcome {
        val now = clock()
        return when (r.source) {
            "openrouter" -> verifyListing(r, cache, now)
            "huggingface", "github" -> verifyExists(r, cache, now)
            else -> verifyPage(r, cache, now)
        }
    }

    private fun fetch(url: String, cache: MutableMap<String, FetchResult>, max: Long): FetchResult = cache.getOrPut(url) { fetcher.get(url, max) }

    private fun smooth(prev: Long, now: Long): Long = if (now <= 0L) prev else if (prev <= 0L) now else (prev * 2 + now) / 3

    private fun failed(r: Resource, res: FetchResult, now: Long): Outcome {
        val fails = r.failCount + 1
        val gone = res.error.isEmpty() && (res.status == 404 || res.status == 410)
        val wasGood = r.status == VStatus.VERIFIED || r.status == VStatus.CHANGED
        val st = when {
            gone && fails >= GONE_AFTER -> VStatus.DISCONTINUED
            wasGood && fails < 2 -> r.status           // one failed check is not enough to drop a good record
            else -> VStatus.UNREACHABLE
        }
        val why = if (res.error.isNotEmpty()) res.error else "HTTP ${res.status}"
        val ev = ArrayList<HunterEvent>()
        if (st == VStatus.DISCONTINUED && r.status != VStatus.DISCONTINUED) {
            ev.add(HunterEvent(now, r.id, "discontinued", "${r.provider} ${r.name}: the official page is gone ($why) on $fails consecutive checks", true))
        } else if (st == VStatus.UNREACHABLE && r.status != VStatus.UNREACHABLE && wasGood) {
            ev.add(HunterEvent(now, r.id, "unreachable", "${r.provider} ${r.name}: official page unreachable ($why) on $fails consecutive checks", true))
        }
        return Outcome(r.copy(status = st, failCount = fails, lastChecked = now, note = Sanitize.clean("Check failed: $why", 160)), ev)
    }

    private fun trusted(r: Resource, finalUrl: String): Boolean {
        val fh = UrlSafety.hostOf(finalUrl)
        return listOf(r.officialUrl, r.docsUrl, r.signupUrl).filter { it.isNotBlank() }.any { UrlSafety.sameSite(fh, UrlSafety.hostOf(it)) }
    }

    private fun verifyListing(r: Resource, cache: MutableMap<String, FetchResult>, now: Long): Outcome {
        val url = r.docsUrl.ifBlank { OpenRouterSource.MODELS_URL }
        val res = fetch(url, cache, 3_000_000L)
        if (!res.ok) return failed(r, res, now)
        val ids = try {
            OpenRouterSource.freeIds(res.body)
        } catch (e: Exception) {
            return failed(r, res.copy(error = "unreadable listing"), now)
        }
        if (r.name in ids) {
            return Outcome(r.copy(status = VStatus.VERIFIED, failCount = 0, lastChecked = now, lastVerified = now, latencyMs = smooth(r.latencyMs, res.ms), note = ""), emptyList())
        }
        val fails = r.failCount + 1
        val gone = fails >= 2
        val ev = ArrayList<HunterEvent>()
        if (gone && r.status != VStatus.DISCONTINUED) ev.add(HunterEvent(now, r.id, "discontinued", "${r.provider} ${r.name} is no longer listed as free", true))
        return Outcome(
            r.copy(status = if (gone) VStatus.DISCONTINUED else r.status, failCount = fails, lastChecked = now, note = "Not in the provider's free list on this check"),
            ev
        )
    }

    private fun verifyExists(r: Resource, cache: MutableMap<String, FetchResult>, now: Long): Outcome {
        val url = r.docsUrl.ifBlank { r.officialUrl }
        UrlSafety.check(url)?.let { return Outcome(r.copy(lastChecked = now, note = "Not checked: $it"), emptyList()) }
        val res = fetch(url, cache, 400_000L)
        if (!res.ok) return failed(r, res, now)
        if (r.source == "github") {
            val archived = try { JSONObject(res.body).optBoolean("archived", false) } catch (e: Exception) { false }
            if (archived) {
                val ev = if (r.status != VStatus.DISCONTINUED) listOf(HunterEvent(now, r.id, "discontinued", "${r.name} was archived by its owner", true)) else emptyList()
                return Outcome(r.copy(status = VStatus.DISCONTINUED, lastChecked = now, note = "Repository archived"), ev)
            }
        }
        return Outcome(r.copy(status = VStatus.VERIFIED, failCount = 0, lastChecked = now, lastVerified = now, latencyMs = smooth(r.latencyMs, res.ms), note = ""), emptyList())
    }

    private fun verifyPage(r: Resource, cache: MutableMap<String, FetchResult>, now: Long): Outcome {
        val url = r.docsUrl.ifBlank { r.officialUrl }
        UrlSafety.check(url)?.let { return Outcome(r.copy(status = VStatus.UNVERIFIED, lastChecked = now, note = Sanitize.clean("Not checked: $it", 160)), emptyList()) }
        var res = fetch(url, cache, 700_000L)
        if (!res.ok) return failed(r, res, now)
        val wasGood = r.status == VStatus.VERIFIED || r.status == VStatus.CHANGED
        if (!trusted(r, res.finalUrl)) {
            val host = UrlSafety.hostOf(res.finalUrl)
            val ev = if (wasGood) listOf(HunterEvent(now, r.id, "redirect", "${r.provider} ${r.name}: official page now redirects to $host, which is not a listed domain", true)) else emptyList()
            return Outcome(r.copy(status = VStatus.UNVERIFIED, lastChecked = now, note = Sanitize.clean("Redirected to unlisted domain $host; not trusted", 160)), ev)
        }
        var text = Parse.stripHtml(res.body, 120_000)
        var a = FreeTierAnalyzer.analyze(text, now)
        // JS headless pass: SPA / empty-quota pages — re-fetch with WebView-rendered text
        if ((!a.permanentFree || a.quotas.isEmpty()) && !cache.containsKey("$url#js")) {
            try {
                val jsKey = "$url#js"
                val rendered = fetcher.getRendered(url, 700_000L)
                cache[jsKey] = rendered
                if (rendered.ok && rendered.body.length > 200) {
                    val jsText = Parse.stripHtml(rendered.body, 120_000)
                    val a2 = FreeTierAnalyzer.analyze(jsText, now)
                    if (a2.permanentFree || a2.quotas.size > a.quotas.size || a2.freeMentioned && !a.freeMentioned) {
                        res = rendered
                        text = jsText
                        a = a2
                    }
                }
            } catch (_: Exception) { /* keep static analysis */ }
        }
        val sig = a.signature()
        val ev = ArrayList<HunterEvent>()
        val status: VStatus
        var note = ""
        when {
            a.endedPhrase -> {
                status = VStatus.CHANGED
                note = "The official page says a free tier ended - review before relying on it"
                if (r.status != VStatus.CHANGED) ev.add(HunterEvent(now, r.id, "ended", "${r.provider} ${r.name}: the official page mentions the free tier has ended", true))
            }
            a.trialOnly -> {
                note = "Only trial credits mentioned, not a permanent free tier"
                if (wasGood) {
                    status = VStatus.CHANGED
                    if (r.status == VStatus.VERIFIED) ev.add(HunterEvent(now, r.id, "removed", "${r.provider} ${r.name}: the official page now mentions only trial credits", true))
                } else status = VStatus.UNVERIFIED
            }
            !a.permanentFree -> {
                note = if (a.freeMentioned) "Free wording found but no clear permanent free-tier statement" else "No free-tier wording found on the official page"
                if (wasGood) {
                    status = VStatus.CHANGED
                    if (r.status == VStatus.VERIFIED) ev.add(HunterEvent(now, r.id, "removed", "${r.provider} ${r.name}: a clear free-tier statement no longer appears on the official page", true))
                } else status = VStatus.UNVERIFIED
            }
            else -> {
                if (wasGood && r.contentHash.isNotEmpty() && r.contentHash != sig) {
                    status = VStatus.CHANGED
                    ev.add(HunterEvent(now, r.id, "changed", "${r.provider} ${r.name}: free-tier policy changed. " + diff(r, a), true))
                } else status = VStatus.VERIFIED
            }
        }
        val good = status == VStatus.VERIFIED || status == VStatus.CHANGED
        val restrictions = ArrayList(a.restrictions)
        if (a.trialOnly) restrictions.add("Trial credits only - not a permanent free tier")
        val updated = r.copy(
            status = status, lastChecked = now, lastVerified = if (good) now else r.lastVerified, failCount = 0,
            freeTier = if (a.freeMentioned) Sanitize.clean(a.snippets.firstOrNull() ?: "", 240) else r.freeTier,
            quotas = if (a.freeMentioned) a.quotas else r.quotas,
            rpm = if (a.freeMentioned) a.rpm else r.rpm,
            rpd = if (a.freeMentioned) a.rpd else r.rpd,
            restrictions = if (a.freeMentioned) restrictions else r.restrictions,
            needsCard = a.cardRequired ?: r.needsCard,
            expiresAt = if (a.freeMentioned) a.expiresAt else r.expiresAt,
            evidence = Sanitize.clean(a.snippets.joinToString(" ... "), 600),
            contentHash = sig, latencyMs = smooth(r.latencyMs, res.ms), note = note
        )
        return Outcome(updated, ev)
    }

    private fun diff(old: Resource, a: Analysis): String {
        val added = a.quotas.filter { it !in old.quotas }
        val removed = old.quotas.filter { it !in a.quotas }
        val parts = ArrayList<String>()
        if (added.isNotEmpty()) parts.add("now: " + added.joinToString(", "))
        if (removed.isNotEmpty()) parts.add("was: " + removed.joinToString(", "))
        return if (parts.isEmpty()) "Terms or restrictions changed; read the official page." else parts.joinToString("; ")
    }

    companion object {
        /** Consecutive 404/410 answers needed before a service is called discontinued. */
        const val GONE_AFTER = 3
    }
}
