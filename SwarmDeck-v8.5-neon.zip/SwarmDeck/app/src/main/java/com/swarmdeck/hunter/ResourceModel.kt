package com.swarmdeck.hunter

import com.swarmdeck.guard.SecretScan
import org.json.JSONArray
import org.json.JSONObject

/** What kind of free resource a record describes. */
enum class Category(val label: String) {
    AI_API("Free AI API"),
    OPEN_LLM("Open-source LLM"),
    INFERENCE("Free inference"),
    HOSTING("Free hosting"),
    DATABASE("Free database"),
    DEV_TOOL("Developer tool"),
    DATASET("Dataset"),
    AUTOMATION("Automation tool"),
    LOCAL_MODEL("Local / offline model");

    /** True when MATRIX can use it as a source of model answers. */
    val isModelSource: Boolean get() = this == AI_API || this == OPEN_LLM || this == INFERENCE || this == LOCAL_MODEL

    companion object {
        fun parse(s: String): Category? {
            val k = s.trim().lowercase().replace(Regex("[\\s-]+"), "_")
            if (k.isEmpty()) return null
            values().firstOrNull { it.name.lowercase() == k }?.let { return it }
            return when (k) {
                "ai", "api", "apis", "ai_api", "llm_api" -> AI_API
                "llm", "llms", "open", "open_source", "open_llm" -> OPEN_LLM
                "inference", "serving" -> INFERENCE
                "host", "hosting", "cloud" -> HOSTING
                "db", "database", "databases" -> DATABASE
                "tool", "tools", "dev", "devtool", "dev_tool" -> DEV_TOOL
                "data", "dataset", "datasets" -> DATASET
                "automation", "workflow", "workflows" -> AUTOMATION
                "local", "offline", "local_model", "local_models" -> LOCAL_MODEL
                else -> null
            }
        }
    }
}

/**
 * Verification state. OUTDATED and EXPIRED are never stored: they are derived from timestamps by [Resource.effective],
 * so a record can go stale without anything having to rewrite it.
 */
enum class VStatus(val label: String) {
    UNVERIFIED("Unverified"),
    VERIFIED("Verified"),
    CHANGED("Policy changed"),
    OUTDATED("Outdated"),
    EXPIRED("Expired"),
    UNREACHABLE("Unreachable"),
    DISCONTINUED("Discontinued");

    companion object {
        fun parse(s: String): VStatus = values().firstOrNull { it.name == s } ?: UNVERIFIED
    }
}

/** One catalogued free resource. Holds public facts only: never keys, never credentials. */
data class Resource(
    val id: String,
    val provider: String,
    val name: String,
    val category: Category,
    val officialUrl: String,
    val docsUrl: String = "",
    val signupUrl: String = "",
    val apiBase: String = "",
    val source: String = "seed",          // seed | openrouter | huggingface | github | user
    val freeTier: String = "",
    val quotas: List<String> = emptyList(),
    val rpm: Int = 0,                      // lowest requests/minute found on the official page (0 = unknown)
    val rpd: Int = 0,                      // lowest requests/day found (0 = unknown)
    val models: List<String> = emptyList(),
    val restrictions: List<String> = emptyList(),
    val needsAccount: Boolean? = null,
    val needsCard: Boolean? = null,
    val local: Boolean = false,
    val contextLen: Int = 0,
    val quality: Double = 0.0,             // 0..10 heuristic (parameter count, context, popularity)
    val latencyMs: Long = 0,               // smoothed response time of the last official-page / API check
    val status: VStatus = VStatus.UNVERIFIED,
    val evidence: String = "",             // short excerpt from the official page that justified the status
    val contentHash: String = "",          // signature of the policy facts, used to detect changes
    val expiresAt: Long = 0,
    val failCount: Int = 0,
    val firstSeen: Long = 0,
    val lastChecked: Long = 0,
    val lastVerified: Long = 0,
    val note: String = ""
) {
    fun effective(now: Long): VStatus {
        if (expiresAt > 0L && expiresAt < now && status != VStatus.DISCONTINUED) return VStatus.EXPIRED
        val seen = if (lastVerified > 0) lastVerified else lastChecked
        if ((status == VStatus.VERIFIED || status == VStatus.CHANGED) && seen > 0 && now - seen > STALE_MS) return VStatus.OUTDATED
        return status
    }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("provider", provider).put("name", name).put("category", category.name)
        .put("officialUrl", officialUrl).put("docsUrl", docsUrl).put("signupUrl", signupUrl).put("apiBase", apiBase)
        .put("source", source).put("freeTier", freeTier).put("quotas", JSONArray(quotas))
        .put("rpm", rpm).put("rpd", rpd).put("models", JSONArray(models)).put("restrictions", JSONArray(restrictions))
        .put("needsAccount", if (needsAccount == null) JSONObject.NULL else needsAccount)
        .put("needsCard", if (needsCard == null) JSONObject.NULL else needsCard)
        .put("local", local).put("contextLen", contextLen).put("quality", quality).put("latencyMs", latencyMs)
        .put("status", status.name).put("evidence", evidence).put("contentHash", contentHash)
        .put("expiresAt", expiresAt).put("failCount", failCount).put("firstSeen", firstSeen)
        .put("lastChecked", lastChecked).put("lastVerified", lastVerified).put("note", note)

    companion object {
        const val STALE_MS = 30L * 24 * 3600 * 1000

        private fun strings(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it, "") }.filter { it.isNotEmpty() }
        private fun tri(o: JSONObject, k: String): Boolean? = if (!o.has(k) || o.isNull(k)) null else o.optBoolean(k)

        fun fromJson(o: JSONObject): Resource = Resource(
            id = o.getString("id"),
            provider = o.optString("provider", ""),
            name = o.optString("name", ""),
            category = Category.parse(o.optString("category", "")) ?: Category.DEV_TOOL,
            officialUrl = o.optString("officialUrl", ""),
            docsUrl = o.optString("docsUrl", ""),
            signupUrl = o.optString("signupUrl", ""),
            apiBase = o.optString("apiBase", ""),
            source = o.optString("source", "seed"),
            freeTier = o.optString("freeTier", ""),
            quotas = strings(o.optJSONArray("quotas")),
            rpm = o.optInt("rpm", 0),
            rpd = o.optInt("rpd", 0),
            models = strings(o.optJSONArray("models")),
            restrictions = strings(o.optJSONArray("restrictions")),
            needsAccount = tri(o, "needsAccount"),
            needsCard = tri(o, "needsCard"),
            local = o.optBoolean("local", false),
            contextLen = o.optInt("contextLen", 0),
            quality = o.optDouble("quality", 0.0),
            latencyMs = o.optLong("latencyMs", 0L),
            status = VStatus.parse(o.optString("status", "")),
            evidence = o.optString("evidence", ""),
            contentHash = o.optString("contentHash", ""),
            expiresAt = o.optLong("expiresAt", 0L),
            failCount = o.optInt("failCount", 0),
            firstSeen = o.optLong("firstSeen", 0L),
            lastChecked = o.optLong("lastChecked", 0L),
            lastVerified = o.optLong("lastVerified", 0L),
            note = o.optString("note", "")
        )
    }
}

/** Something worth telling the user about (policy change, discontinued service, ...). */
data class HunterEvent(val ts: Long, val rid: String, val kind: String, val detail: String, val important: Boolean)

object Ids {
    fun slug(s: String): String = s.lowercase().replace(Regex("[^a-z0-9]+"), "-").trim('-').take(80)

    fun of(provider: String, name: String): String {
        val p = slug(provider)
        val n = slug(name)
        return if (n.isEmpty() || n == p) p else "$p/$n"
    }
}

/** Text that came from a website is untrusted: strip control characters, redact secrets, cap the length. */
object Sanitize {
    fun clean(s: String, max: Int): String {
        val noCtl = s.map { if (it.isISOControl() && it != ' ') ' ' else it }.joinToString("")
        val collapsed = noCtl.replace(Regex("\\s+"), " ").trim()
        return SecretScan.redact(collapsed).take(max)
    }
}

/** Parameter count parsed from a model name ("llama-3.3-70b-instruct" -> 70.0, "mixtral-8x7b" -> 56.0). 0.0 = unknown. */
object ParamSize {
    private val MOE = Regex("(?<![a-z0-9.])(\\d+)x(\\d+(?:\\.\\d+)?)b(?![a-z])", RegexOption.IGNORE_CASE)
    private val PLAIN = Regex("(?<![a-z0-9.])(\\d+(?:\\.\\d+)?)b(?![a-z])", RegexOption.IGNORE_CASE)

    fun billions(name: String): Double {
        MOE.find(name)?.let { m ->
            val a = m.groupValues[1].toDoubleOrNull() ?: 0.0
            val b = m.groupValues[2].toDoubleOrNull() ?: 0.0
            if (a > 0 && b > 0) return a * b
        }
        PLAIN.find(name)?.let { m -> return m.groupValues[1].toDoubleOrNull() ?: 0.0 }
        return 0.0
    }
}

/** Transparent quality heuristic (0..10). It is an estimate from public signals, not a benchmark. */
object Quality {
    fun score(name: String, contextLen: Int, popularity: Long = 0L): Double {
        val b = ParamSize.billions(name)
        val params = if (b > 0.0) Math.log10(b) * 3.2 else 4.0
        val ctx = if (contextLen > 4096) Math.log(contextLen / 4096.0) / Math.log(2.0) * 0.4 else 0.0
        val pop = if (popularity > 1L) Math.log10(popularity.toDouble()) * 0.25 else 0.0
        return (params.coerceIn(0.0, 8.0) + ctx.coerceIn(0.0, 2.0) + pop.coerceIn(0.0, 1.5)).coerceIn(0.0, 10.0)
    }
}
