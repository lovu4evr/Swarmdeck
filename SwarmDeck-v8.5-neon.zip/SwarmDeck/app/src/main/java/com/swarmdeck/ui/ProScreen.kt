package com.swarmdeck.ui

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MUTED
import com.swarmdeck.billing.BillingManager
import com.swarmdeck.billing.Pro
import com.swarmdeck.billing.ProFeature
import com.swarmdeck.glass
import kotlinx.coroutines.launch

/** Shows [content] when Pro is active, otherwise the paywall for [feature]. */
@Composable
fun ProGate(act: Activity, feature: ProFeature, onBack: () -> Unit, content: @Composable () -> Unit) {
    if (Pro.active) content() else ProScreen(act, feature, onBack)
}

@Composable
fun ProScreen(act: Activity, feature: ProFeature?, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        BillingManager.init(act)
        if (BillingManager.plans.isEmpty()) BillingManager.loadProducts()
        BillingManager.refresh()
    }
    val plans = BillingManager.plans
    val status = BillingManager.status
    var dbg by remember { mutableStateOf(Pro.debugOverride(act)) }
    var tick by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("SwarmDeck Pro", color = GOLD, fontSize = 26.sp, fontWeight = FontWeight.Black)
        if (feature != null && !Pro.active) {
            Text("🔒 ${feature.title} needs SwarmDeck Pro", color = CREAM, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }
        if (Pro.active) {
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(14.dp)) {
                Text("✅ SwarmDeck Pro is active", color = GOLD, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("All features below are unlocked.", color = MUTED, fontSize = 12.sp)
            }
        }
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("What Pro unlocks", color = CREAM, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            ProFeature.values().forEach { f ->
                Column {
                    Text("✦ ${f.title}", color = if (f == feature) GOLD else CREAM, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    Text(f.blurb, color = MUTED, fontSize = 12.sp)
                }
            }
        }
        if (!Pro.active) {
            if (plans.isEmpty()) {
                Text(if (BillingManager.loading) "Loading plans from Google Play…" else status.ifBlank { "No plans loaded." }, color = MUTED, fontSize = 12.sp)
                OutlinedButton({ scope.launch { BillingManager.loadProducts(); BillingManager.refresh() } }, Modifier.fillMaxWidth()) { Text("Retry", color = GOLD) }
            } else plans.forEach { pl ->
                Button(
                    { BillingManager.buy(act, pl) }, Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = GOLD, contentColor = Color.Black)
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Subscribe · ${pl.price} / ${pl.period}", fontWeight = FontWeight.Bold)
                        if (pl.trial != null) Text("${pl.trial} free trial", fontSize = 11.sp)
                    }
                }
            }
            if (plans.isNotEmpty() && status.isNotBlank()) Text(status, color = MUTED, fontSize = 12.sp)
        } else if (status.isNotBlank()) Text(status, color = MUTED, fontSize = 12.sp)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ BillingManager.restore() }) { Text("Restore purchase", color = GOLD) }
            if (Pro.active && !dbg) OutlinedButton({ BillingManager.manageSubscription(act) }) { Text("Manage", color = GOLD) }
        }
        Text(
            "Payment is charged to your Google Play account. The subscription renews automatically until you cancel it in Google Play → Payments & subscriptions. Cancelling keeps Pro until the end of the paid period.",
            color = MUTED, fontSize = 11.sp
        )
        if (Pro.isDebuggable(act)) {
            val until = remember(tick, Pro.active) { Pro.localUntil(act) }
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Personal mode · ${Pro.LOCAL_PRICE} / month", color = GOLD, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("For running SwarmDeck yourself without Google Play. No payment is collected: it only simulates the plan on this device. Works in test (debug) builds only; release builds use Google Play.", color = MUTED, fontSize = 11.sp)
                if (until > 0L) {
                    Text("Active until ${java.text.DateFormat.getDateInstance().format(java.util.Date(until))}", color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        { Pro.startLocal(act); tick++; Toast.makeText(act, "Pro active for ${Pro.LOCAL_DAYS} more days", Toast.LENGTH_SHORT).show() },
                        colors = ButtonDefaults.buttonColors(containerColor = GOLD, contentColor = Color.Black)
                    ) { Text(if (until > 0L) "Renew +${Pro.LOCAL_DAYS} days" else "Subscribe · ${Pro.LOCAL_PRICE}/month", fontWeight = FontWeight.Bold) }
                    if (until > 0L) OutlinedButton({ Pro.cancelLocal(act); tick++ }) { Text("Cancel", color = GOLD) }
                }
            }
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Debug: simulate Pro", color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                        Text("Test builds only. Lets you try the unlocked features without Google Play. Absent in release builds.", color = MUTED, fontSize = 11.sp)
                    }
                    Spacer(Modifier.width(8.dp))
                    Switch(dbg, { dbg = it; Pro.setDebugOverride(act, it); Toast.makeText(act, if (it) "Pro simulated" else "Simulation off", Toast.LENGTH_SHORT).show() })
                }
            }
        }
        TextButton(onBack) { Text("Back", color = MUTED) }
        Spacer(Modifier.height(8.dp))
    }
}
