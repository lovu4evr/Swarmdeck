package com.swarmdeck.agents

import android.content.Context
import com.swarmdeck.Vault
import com.swarmdeck.core.ShareableAgent
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Shareable Agents – export / import / marketplace foundation
 * SwarmDeck 5.3
 */
object AgentMarket {

    private const val PREF = "swarmdeck_agents_v1"
    private const val KEY_CUSTOM = "custom_agents_enc"

    fun listCustom(c: Context): List<ShareableAgent> {
        val raw = Vault.dec(prefs(c).getString(KEY_CUSTOM, "") ?: "")
        if (raw.isBlank()) return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull {
                try { ShareableAgent.fromJson(arr.getJSONObject(it)) } catch (_: Exception) { null }
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveCustom(c: Context, agent: ShareableAgent) {
        val all = listCustom(c).toMutableList()
        val idx = all.indexOfFirst { it.id == agent.id }
        if (idx >= 0) all[idx] = agent else all.add(agent)
        persist(c, all)
    }

    fun deleteCustom(c: Context, id: String) {
        persist(c, listCustom(c).filter { it.id != id })
    }

    /** Export single agent as pretty JSON string (for sharing) */
    fun export(agent: ShareableAgent): String {
        return agent.toJson().toString(2)
    }

    /** Export multiple agents */
    fun exportAll(agents: List<ShareableAgent>): String {
        val arr = JSONArray()
        agents.forEach { arr.put(it.toJson()) }
        return JSONObject().put("swarmdeck_agents", arr).put("version", "5.3").toString(2)
    }

    /** Import from JSON string. Returns number of agents imported. */
    fun import(c: Context, json: String): Result<Int> {
        return try {
            val trimmed = json.trim()
            val agents = mutableListOf<ShareableAgent>()

            when {
                trimmed.startsWith("{") -> {
                    val obj = JSONObject(trimmed)
                    if (obj.has("swarmdeck_agents")) {
                        val arr = obj.getJSONArray("swarmdeck_agents")
                        for (i in 0 until arr.length()) {
                            agents += ShareableAgent.fromJson(arr.getJSONObject(i))
                        }
                    } else {
                        // single agent
                        agents += ShareableAgent.fromJson(obj)
                    }
                }
                trimmed.startsWith("[") -> {
                    val arr = JSONArray(trimmed)
                    for (i in 0 until arr.length()) {
                        agents += ShareableAgent.fromJson(arr.getJSONObject(i))
                    }
                }
                else -> return Result.failure(IllegalArgumentException("Invalid agent JSON"))
            }

            // Basic safety: reject agents that try to override safety
            val safe = agents.filter { a ->
                val p = a.systemPrompt.lowercase()
                !p.contains("ignore previous") &&
                !p.contains("disregard all") &&
                !p.contains("you are now") &&
                a.name.isNotBlank() && a.systemPrompt.length < 12000
            }

            safe.forEach { saveCustom(c, it.copy(id = it.id.ifBlank { UUID.randomUUID().toString() })) }
            Result.success(safe.size)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    fun create(
        c: Context,
        name: String,
        role: String,
        systemPrompt: String,
        tools: List<String> = emptyList(),
        description: String = "",
        author: String = ""
    ): ShareableAgent {
        val a = ShareableAgent(
            id = UUID.randomUUID().toString(),
            name = name.trim(),
            role = role.trim().ifBlank { "assistant" },
            systemPrompt = systemPrompt.trim(),
            tools = tools,
            description = description.trim(),
            author = author.trim()
        )
        saveCustom(c, a)
        return a
    }

    private fun persist(c: Context, agents: List<ShareableAgent>) {
        val arr = JSONArray()
        agents.forEach { arr.put(it.toJson()) }
        prefs(c).edit().putString(KEY_CUSTOM, Vault.enc(arr.toString())).apply()
    }

    private fun prefs(c: Context) = c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
