package com.swarmdeck.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.agents.AgentMarket
import com.swarmdeck.core.ShareableAgent

private val Gold = Color(0xFFD4AF37)
private val DarkBg = Color(0xFF0D0D0D)
private val CardBg = Color(0xFF1A1A1A)

@Composable
fun AgentMarketScreen(context: Context, onBack: () -> Unit) {
    var agents by remember { mutableStateOf(AgentMarket.listCustom(context)) }
    var showCreate by remember { mutableStateOf(false) }
    var showImport by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf("") }
    var role by remember { mutableStateOf("assistant") }
    var prompt by remember { mutableStateOf("") }
    var importJson by remember { mutableStateOf("") }

    fun refresh() { agents = AgentMarket.listCustom(context) }

    Column(Modifier.fillMaxSize().background(DarkBg)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null, tint = Gold) }
            Text("Agent Market", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showImport = true }) { Icon(Icons.Default.Download, null, tint = Gold) }
            IconButton(onClick = { showCreate = true }) { Icon(Icons.Default.Add, null, tint = Gold) }
        }

        if (agents.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No custom agents.\nCreate or import one.", color = Color.Gray)
            }
        } else {
            LazyColumn(Modifier.padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(agents, key = { it.id }) { a ->
                    AgentCard(a,
                        onExport = {
                            val json = AgentMarket.export(a)
                            val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                            cm.setPrimaryClip(ClipData.newPlainText("agent", json))
                            Toast.makeText(context, "Agent JSON copied", Toast.LENGTH_SHORT).show()
                        },
                        onDelete = {
                            AgentMarket.deleteCustom(context, a.id)
                            refresh()
                        }
                    )
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }

    if (showCreate) {
        AlertDialog(
            onDismissRequest = { showCreate = false },
            title = { Text("Create Agent", color = Gold) },
            text = {
                Column {
                    OutlinedTextField(name, { name = it }, label = { Text("Name") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(role, { role = it }, label = { Text("Role") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(prompt, { prompt = it }, label = { Text("System Prompt") }, modifier = Modifier.fillMaxWidth(), minLines = 4)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (name.isNotBlank() && prompt.isNotBlank()) {
                        AgentMarket.create(context, name, role, prompt)
                        name = ""; role = "assistant"; prompt = ""
                        showCreate = false
                        refresh()
                    }
                }) { Text("Create", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { showCreate = false }) { Text("Cancel") } },
            containerColor = CardBg
        )
    }

    if (showImport) {
        AlertDialog(
            onDismissRequest = { showImport = false },
            title = { Text("Import Agents", color = Gold) },
            text = {
                OutlinedTextField(importJson, { importJson = it }, label = { Text("Paste JSON") }, modifier = Modifier.fillMaxWidth(), minLines = 5)
            },
            confirmButton = {
                TextButton(onClick = {
                    val result = AgentMarket.import(context, importJson)
                    result.onSuccess {
                        Toast.makeText(context, "Imported $it agent(s)", Toast.LENGTH_SHORT).show()
                        importJson = ""
                        showImport = false
                        refresh()
                    }.onFailure {
                        Toast.makeText(context, "Import failed: ${it.message}", Toast.LENGTH_LONG).show()
                    }
                }) { Text("Import", color = Gold) }
            },
            dismissButton = { TextButton(onClick = { showImport = false }) { Text("Cancel") } },
            containerColor = CardBg
        )
    }
}

@Composable
private fun AgentCard(a: ShareableAgent, onExport: () -> Unit, onDelete: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().border(1.dp, Gold.copy(0.3f), RoundedCornerShape(12.dp)),
        colors = CardDefaults.cardColors(CardBg),
        shape = RoundedCornerShape(12.dp)
    ) {
        Column(Modifier.padding(14.dp)) {
            Text(a.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 16.sp)
            Text(a.role, color = Gold, fontSize = 12.sp)
            if (a.description.isNotBlank()) {
                Spacer(Modifier.height(4.dp))
                Text(a.description, color = Color.Gray, fontSize = 13.sp, maxLines = 2)
            }
            Spacer(Modifier.height(6.dp))
            Text(a.systemPrompt.take(120) + if (a.systemPrompt.length > 120) "…" else "", color = Color.LightGray, fontSize = 12.sp, maxLines = 3)
            Spacer(Modifier.height(8.dp))
            Row {
                TextButton(onClick = onExport) { Text("Export", color = Gold, fontSize = 12.sp) }
                TextButton(onClick = onDelete) { Text("Delete", color = Color.Red.copy(0.8f), fontSize = 12.sp) }
            }
        }
    }
}
