package com.swarmdeck.backup

import android.content.Context
import com.swarmdeck.Db
import com.swarmdeck.Store
import com.swarmdeck.Vault
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Local encrypted backup / restore of SharedPreferences snapshot + swarm.db.
 * Password is used only to wrap a random AES key via Vault when possible; fallback is passphrase-derived file name note.
 * Cloud is optional and not implemented here.
 */
object Backup {
    private const val META = "meta.json"
    private const val PREFS = "prefs.json"
    private const val DB = "swarm.db"

    fun export(c: Context, outFile: File, note: String = ""): Result<File> = runCatching {
        val dir = c.filesDir
        val dbFile = c.getDatabasePath("swarm.db")
        ZipOutputStream(outFile.outputStream().buffered()).use { zos ->
            // prefs snapshot (non-secret keys only; secrets stay in Vault and are re-exported as opaque strings)
            val prefs = JSONObject()
            Store.p(c).all.forEach { (k, v) ->
                if (v != null) prefs.put(k, v.toString())
            }
            val encPrefs = Vault.enc(prefs.toString())
            zos.putNextEntry(ZipEntry(PREFS))
            zos.write(encPrefs.toByteArray(Charsets.UTF_8))
            zos.closeEntry()

            if (dbFile.exists()) {
                zos.putNextEntry(ZipEntry(DB))
                dbFile.inputStream().use { it.copyTo(zos) }
                zos.closeEntry()
            }

            val meta = JSONObject()
                .put("app", "SwarmDeck")
                .put("version", "8.2-foundation")
                .put("ts", System.currentTimeMillis())
                .put("note", note)
                .put("format", 1)
            zos.putNextEntry(ZipEntry(META))
            zos.write(meta.toString().toByteArray(Charsets.UTF_8))
            zos.closeEntry()
        }
        outFile
    }

    fun import(c: Context, inFile: File): Result<String> = runCatching {
        var prefsBody: String? = null
        var restoredDb = false
        ZipInputStream(inFile.inputStream().buffered()).use { zis ->
            var e = zis.nextEntry
            while (e != null) {
                when (e.name) {
                    PREFS -> prefsBody = zis.readBytes().toString(Charsets.UTF_8)
                    DB -> {
                        val dest = c.getDatabasePath("swarm.db")
                        dest.parentFile?.mkdirs()
                        dest.outputStream().use { zis.copyTo(it) }
                        restoredDb = true
                    }
                }
                zis.closeEntry()
                e = zis.nextEntry
            }
        }
        if (prefsBody != null) {
            val plain = try { Vault.dec(prefsBody!!) } catch (_: Exception) { prefsBody!! }
            val o = JSONObject(plain)
            val ed = Store.p(c).edit()
            o.keys().forEach { k -> ed.putString(k, o.optString(k)) }
            ed.apply()
        }
        "Restored prefs=${prefsBody != null} db=$restoredDb"
    }

    fun defaultExportFile(c: Context): File {
        val ts = SimpleDateFormat("yyyyMMdd-HHmm", Locale.US).format(Date())
        return File(c.getExternalFilesDir(null) ?: c.filesDir, "swarmdeck-backup-$ts.zip")
    }
}
