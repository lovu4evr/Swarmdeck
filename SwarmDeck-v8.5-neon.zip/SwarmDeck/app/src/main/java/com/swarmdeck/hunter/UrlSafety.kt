package com.swarmdeck.hunter

/**
 * Every address the Hunter touches passes through here. https only, no credentials in URLs, no private or internal
 * hosts (SSRF), and a "same site" test so a redirect to somewhere unexpected is never trusted. Pure JVM.
 */
object UrlSafety {
    private val TWO_PART_SUFFIXES = setOf("co.uk", "org.uk", "com.au", "co.in", "com.br", "co.jp", "co.nz", "com.cn")

    fun hostOf(url: String): String = try {
        java.net.URI(url.trim()).host?.lowercase() ?: ""
    } catch (e: Exception) {
        ""
    }

    fun isBlockedHost(host: String): Boolean {
        val h = host.lowercase().trim('.')
        if (h.isEmpty()) return true
        if (h == "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".lan")) return true
        if (h.contains(':')) return true                       // IPv6 literals are not needed for any catalogued service
        if (h in setOf("metadata.google.internal", "metadata", "metadata.google.com")) return true
        val parts = h.split(".")
        if (parts.size == 4 && parts.all { it.toIntOrNull() != null }) {
            val a = parts[0].toInt()
            val b = parts[1].toInt()
            if (a == 0 || a == 10 || a == 127) return true
            if (a == 192 && b == 168) return true
            if (a == 172 && b in 16..31) return true
            if (a == 169 && b == 254) return true
            if (a == 100 && b in 64..127) return true
        }
        return false
    }

    /** Null when the URL may be requested, otherwise the reason it may not. */
    fun check(url: String): String? {
        val u = url.trim()
        if (!u.startsWith("https://")) return "only https:// URLs are allowed"
        val uri = try {
            java.net.URI(u)
        } catch (e: Exception) {
            return "invalid URL"
        }
        if (uri.userInfo != null) return "URL embeds credentials"
        val host = uri.host ?: return "URL has no host"
        if (isBlockedHost(host)) return "private or internal host ($host) is not allowed"
        return null
    }

    fun registrable(host: String): String {
        val p = host.lowercase().trim('.').split(".")
        if (p.size <= 2) return p.joinToString(".")
        val last2 = p.takeLast(2).joinToString(".")
        return if (last2 in TWO_PART_SUFFIXES) p.takeLast(3).joinToString(".") else last2
    }

    fun sameSite(a: String, b: String): Boolean = a.isNotEmpty() && b.isNotEmpty() && registrable(a) == registrable(b)
}
