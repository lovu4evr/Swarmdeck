package com.swarmdeck.ui

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MUTED

@Composable
fun PrivacyScreen(act: Activity, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Privacy & data safety", color = GOLD, fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Text(PRIVACY_BODY, color = CREAM, fontSize = 13.sp)
        TextButton(onClick = onBack) { Text("Back", color = GOLD) }
    }
}

/** Play Console data-safety oriented summary (draft). Align with actual behaviour before publishing. */
const val PRIVACY_BODY = """
SwarmDeck is designed to keep your data on your device by default.

What the app processes
• Chat messages, agent replies, goals and memory you create — stored in on-device SQLite and preferences.
• Optional API keys and endpoint URLs you enter — stored encrypted with the Android Keystore (Vault).
• Optional voice input (microphone) — processed for speech recognition; audio is not stored by SwarmDeck.
• Optional screen-control accessibility — only after you enable the service and approve each action.
• Resource Hunter fetches public web pages you choose to scan/verify; page text is redacted for secrets before storage.
• Crash/error log (Diagnostics) is local-only and off by default.

What is shared
• Network requests only go to endpoints you configure (your LLM provider) and to public URLs for search, model lists, and Resource Hunter verification.
• Google Play Billing (subscriptions) uses Google’s billing libraries; purchase state is cached encrypted on device.
• No analytics SDK is bundled in this codebase. No advertising ID collection is implemented here.

Data deletion
• Uninstall removes app storage. Backup files you export are under your control; delete them manually.
• “Clear” on Diagnostics removes the local error log.

Children
• Not directed at children under 13.

Contact
• Update this section with your support email before Play publication.

This text is a draft generated from the app’s code paths. Review with legal counsel before submitting the Play data-safety form.
"""
