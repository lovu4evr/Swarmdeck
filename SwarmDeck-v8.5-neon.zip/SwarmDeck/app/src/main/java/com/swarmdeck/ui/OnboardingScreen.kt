package com.swarmdeck.ui

import android.app.Activity
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.*

@Composable
fun OnboardingScreen(act: Activity, onDone: () -> Unit) {
    var step by remember { mutableStateOf(0) }
    val total = 4
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("Welcome to SwarmDeck", color = GOLD, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Step ${step + 1} of $total", color = MUTED, fontSize = 12.sp)
        when (step) {
            0 -> {
                Text("Your private swarm of agents", color = CREAM, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "SwarmDeck runs specialists on your phone. Chat is free; Pro unlocks missions, multi-device, memory graph and more. " +
                        "Nothing signs up for paid services without your explicit action.",
                    color = MUTED, fontSize = 14.sp
                )
            }
            1 -> {
                Text("Connect a model provider", color = CREAM, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Open Settings and add an API profile (URL + key) for OpenAI-compatible endpoints, or use Resource Hunter to find free tiers. " +
                        "You can keep multiple profiles and switch anytime.",
                    color = MUTED, fontSize = 14.sp
                )
                PrefField(act, "name", "What should we call you?", "Master")
            }
            2 -> {
                Text("Safety & permissions", color = CREAM, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "• Microphone: optional voice input.\n" +
                        "• Notifications: Resource Hunter alerts (Android 13+ asks once).\n" +
                        "• Accessibility (Phone Operator): optional; every action needs your approval.\n" +
                        "• Network: only endpoints you configure and public pages you hunt.",
                    color = MUTED, fontSize = 14.sp
                )
            }
            else -> {
                Text("You're ready", color = CREAM, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "Use the menu for Resource Hunter, Terminal, and Pro features. " +
                        "Diagnostics and Backup live in the sidebar when you need them.",
                    color = MUTED, fontSize = 14.sp
                )
            }
        }
        Spacer(Modifier.weight(1f))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            if (step > 0) TextButton(onClick = { step-- }) { Text("Back", color = CREAM) }
            else Spacer(Modifier.width(8.dp))
            Button(onClick = {
                if (step < total - 1) step++ else onDone()
            }) { Text(if (step < total - 1) "Next" else "Start", color = androidx.compose.ui.graphics.Color.Black) }
        }
    }
}
