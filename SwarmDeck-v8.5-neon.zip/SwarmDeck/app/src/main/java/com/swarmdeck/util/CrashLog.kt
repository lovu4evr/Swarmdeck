package com.swarmdeck.util

import android.content.Context
import com.swarmdeck.Store
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Opt-in, local-first crash / error reporting.
 * Nothing is sent off-device unless the user later opts into a cloud path (not implemented here).
 */
object CrashLog {
    private const val PREF = "crash_log_enabled"
    private const val MAX_BYTES = 256 * 1024

    fun isEnabled(c: Context): Boolean = Store.p(c).getBoolean(PREF, false)

    fun setEnabled(c: Context, on: Boolean) {
        Store.p(c).edit().putBoolean(PREF, on).apply()
    }

    fun record(c: Context, tag: String, t: Throwable) {
        if (!isEnabled(c)) return
        try {
            val dir = File(c.filesDir, "crashlogs").also { if (!it.exists()) it.mkdirs() }
            val f = File(dir, "errors.log")
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val line = "$ts [$tag] ${t.javaClass.simpleName}: ${t.message}\n${t.stackTraceToString().take(2000)}\n---\n"
            f.appendText(line)
            if (f.length() > MAX_BYTES) {
                val keep = f.readText().takeLast(MAX_BYTES / 2)
                f.writeText(keep)
            }
        } catch (_: Exception) { /* never throw from logger */ }
    }

    fun recent(c: Context, maxLines: Int = 80): String {
        return try {
            val f = File(c.filesDir, "crashlogs/errors.log")
            if (!f.exists()) return "(no local errors recorded)"
            f.readLines().takeLast(maxLines).joinToString("\n")
        } catch (e: Exception) {
            "(read failed: ${e.message})"
        }
    }

    fun clear(c: Context) {
        try { File(c.filesDir, "crashlogs/errors.log").delete() } catch (_: Exception) {}
    }
}
