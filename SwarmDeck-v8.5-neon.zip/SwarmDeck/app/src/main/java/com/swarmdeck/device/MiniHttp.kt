package com.swarmdeck.device

import java.io.BufferedInputStream
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.io.InputStream
import java.net.InetSocketAddress
import java.net.Socket

/**
 * Tiny HTTP/1.1 client over a plain socket. Android blocks cleartext HTTP through HttpURLConnection/OkHttp for every
 * address except the few listed in network_security_config.xml, and a home computer has an arbitrary LAN IP. A raw socket
 * is not subject to that policy, so the app-wide "no cleartext" rule stays in place for everything else.
 * Replies must carry Content-Length (or end at connection close); chunked replies are rejected. Pure JVM.
 */
object MiniHttp {
    class Reply(val status: Int, val body: ByteArray)

    fun request(
        host: String,
        port: Int,
        method: String,
        path: String,
        headers: Map<String, String>,
        body: ByteArray?,
        connectMs: Int,
        readMs: Int,
        maxBody: Int
    ): Reply {
        Socket().use { s ->
            s.connect(InetSocketAddress(host, port), connectMs)
            s.soTimeout = readMs
            val head = StringBuilder()
            head.append(method).append(' ').append(path).append(" HTTP/1.1\r\n")
            head.append("Host: ").append(host).append(':').append(port).append("\r\n")
            head.append("Connection: close\r\n")
            for ((k, v) in headers) {
                if (k.contains('\r') || k.contains('\n') || v.contains('\r') || v.contains('\n')) throw IOException("bad header")
                head.append(k).append(": ").append(v).append("\r\n")
            }
            if (body != null) head.append("Content-Length: ").append(body.size).append("\r\n")
            head.append("\r\n")
            val out = s.getOutputStream()
            out.write(head.toString().toByteArray(Charsets.ISO_8859_1))
            if (body != null) out.write(body)
            out.flush()
            return readReply(BufferedInputStream(s.getInputStream()), maxBody)
        }
    }

    fun readReply(input: InputStream, maxBody: Int): Reply {
        val statusLine = readLine(input) ?: throw IOException("empty reply")
        val parts = statusLine.split(" ", limit = 3)
        if (parts.size < 2 || !parts[0].startsWith("HTTP/")) throw IOException("not an HTTP reply")
        val status = parts[1].toIntOrNull() ?: throw IOException("bad status line")
        var len = -1
        var chunked = false
        while (true) {
            val line = readLine(input) ?: throw IOException("truncated headers")
            if (line.isEmpty()) break
            val i = line.indexOf(':')
            if (i > 0) {
                val k = line.substring(0, i).trim().lowercase()
                val v = line.substring(i + 1).trim()
                if (k == "content-length") len = v.toIntOrNull() ?: -1
                if (k == "transfer-encoding" && v.lowercase().contains("chunked")) chunked = true
            }
        }
        if (chunked) throw IOException("chunked replies are not supported")
        val body = if (len >= 0) {
            if (len > maxBody) throw IOException("reply too large")
            readExactly(input, len)
        } else {
            readToEnd(input, maxBody)
        }
        return Reply(status, body)
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (true) {
            val b = input.read()
            if (b < 0) return if (sb.isEmpty()) null else sb.toString()
            if (b == '\n'.code) return sb.toString().trimEnd('\r')
            if (sb.length > 8192) throw IOException("header line too long")
            sb.append(b.toChar())
        }
    }

    private fun readExactly(input: InputStream, n: Int): ByteArray {
        val buf = ByteArray(n)
        var off = 0
        while (off < n) {
            val r = input.read(buf, off, n - off)
            if (r < 0) throw IOException("truncated reply body")
            off += r
        }
        return buf
    }

    private fun readToEnd(input: InputStream, max: Int): ByteArray {
        val out = ByteArrayOutputStream()
        val buf = ByteArray(8192)
        while (true) {
            val r = input.read(buf)
            if (r < 0) break
            if (out.size() + r > max) throw IOException("reply too large")
            out.write(buf, 0, r)
        }
        return out.toByteArray()
    }
}
