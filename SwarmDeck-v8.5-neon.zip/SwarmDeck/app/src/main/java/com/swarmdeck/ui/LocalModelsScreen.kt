package com.swarmdeck.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.*
import com.swarmdeck.hunter.HunterHub

data class LocalModelHint(
    val name: String,
    val minRamMb: Int,
    val note: String,
    val url: String
)

private val CATALOG = listOf(
    LocalModelHint("Gemma 2B / Phi-3 mini class", 4096, "Fits many phones; good for drafts offline.", "https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference"),
    LocalModelHint("Llama 3 8B Q4 (llama.cpp / Ollama)", 8192, "Needs ~6–8 GB free RAM; desktop preferred.", "https://ollama.com/library"),
    LocalModelHint("MediaPipe LLM (on-device)", 4096, "Official Google on-device path.", "https://ai.google.dev/edge/mediapipe/solutions/genai/llm_inference"),
    LocalModelHint("MLC LLM", 6144, "Cross-platform on-device runtime.", "https://llm.mlc.ai/"),
    LocalModelHint("LM Studio / Jan (desktop)", 8192, "Not on phone; use Desk Operator if paired.", "https://lmstudio.ai/")
)

@Composable
fun LocalModelsScreen(act: Activity, onBack: () -> Unit) {
    val ram = remember { HunterHub.deviceRamMb(act) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Local / offline models", color = GOLD, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(
            "Detected device RAM: ${if (ram > 0) "$ram MB" else "unknown"}. " +
                "SwarmDeck does not embed a full GGUF runtime yet; these links open official download pages. " +
                "Resource Hunter can also match offline options.",
            color = MUTED, fontSize = 12.sp
        )
        CATALOG.forEach { m ->
            val fits = ram <= 0 || ram >= m.minRamMb
            Card(
                colors = CardDefaults.cardColors(containerColor = BG2),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(m.name, color = if (fits) GOLD else MUTED, fontWeight = FontWeight.SemiBold)
                    Text(m.note, color = CREAM, fontSize = 12.sp)
                    Text("Suggested min RAM: ${m.minRamMb} MB · ${if (fits) "may fit" else "likely tight"}", color = MUTED, fontSize = 11.sp)
                    TextButton(onClick = {
                        try {
                            act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(m.url)))
                        } catch (_: Exception) {}
                    }) { Text("Open official page", color = ACC) }
                }
            }
        }
        TextButton(onClick = onBack) { Text("Back", color = GOLD) }
    }
}
