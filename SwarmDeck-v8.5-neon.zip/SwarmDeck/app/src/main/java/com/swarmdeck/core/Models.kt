package com.swarmdeck.core

import org.json.JSONArray
import org.json.JSONObject

/** Core data models for SwarmDeck 5.3 */

data class Turn(
    val id: String = java.util.UUID.randomUUID().toString(),
    val user: Boolean,
    val text: String,
    val winner: String = "",
    val answers: List<Triple<String, String, Int>> = emptyList(),
    val thinking: List<String> = emptyList(),
    val missionSteps: List<String> = emptyList(),
    val ts: Long = System.currentTimeMillis(),
    val note: String = "",
    val parentId: String? = null,          // for branching conversations
    val toolCalls: List<ToolCallLog> = emptyList()
)

data class ToolCallLog(
    val name: String,
    val args: String,
    val result: String,
    val durationMs: Long,
    val success: Boolean
)

data class Goal(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val status: GoalStatus = GoalStatus.ACTIVE,
    val priority: Int = 3,                 // 1 = highest
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val dueAt: Long? = null,
    val tags: List<String> = emptyList(),
    val progress: Float = 0f,              // 0.0 - 1.0
    val linkedMissionIds: List<String> = emptyList()
)

enum class GoalStatus { ACTIVE, COMPLETED, PAUSED, CANCELLED }

data class MissionCheckpoint(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val description: String = "",
    val status: CheckpointStatus = CheckpointStatus.PENDING,
    val requiresApproval: Boolean = false,
    val result: String = "",
    val startedAt: Long? = null,
    val completedAt: Long? = null
)

enum class CheckpointStatus { PENDING, RUNNING, WAITING_APPROVAL, COMPLETED, FAILED, SKIPPED }

data class MissionV2(
    val id: String = java.util.UUID.randomUUID().toString(),
    val objective: String,
    val checkpoints: List<MissionCheckpoint> = emptyList(),
    val status: MissionStatus = MissionStatus.PLANNING,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val goalId: String? = null,
    val agentIds: List<String> = emptyList()
)

enum class MissionStatus { PLANNING, RUNNING, PAUSED, WAITING_APPROVAL, COMPLETED, FAILED, CANCELLED }

data class ShareableAgent(
    val id: String,
    val name: String,
    val role: String,
    val systemPrompt: String,
    val tools: List<String> = emptyList(),
    val temperature: Float = 0.7f,
    val version: String = "1.0",
    val author: String = "",
    val description: String = "",
    val tags: List<String> = emptyList()
) {
    fun toJson(): JSONObject = JSONObject().apply {
        put("id", id)
        put("name", name)
        put("role", role)
        put("systemPrompt", systemPrompt)
        put("tools", JSONArray(tools))
        put("temperature", temperature.toDouble())
        put("version", version)
        put("author", author)
        put("description", description)
        put("tags", JSONArray(tags))
    }

    companion object {
        fun fromJson(o: JSONObject): ShareableAgent = ShareableAgent(
            id = o.optString("id", java.util.UUID.randomUUID().toString()),
            name = o.getString("name"),
            role = o.optString("role", "assistant"),
            systemPrompt = o.getString("systemPrompt"),
            tools = o.optJSONArray("tools")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            } ?: emptyList(),
            temperature = o.optDouble("temperature", 0.7).toFloat(),
            version = o.optString("version", "1.0"),
            author = o.optString("author", ""),
            description = o.optString("description", ""),
            tags = o.optJSONArray("tags")?.let { arr ->
                (0 until arr.length()).map { arr.getString(it) }
            } ?: emptyList()
        )
    }
}

data class MemoryItemV2(
    val id: String = java.util.UUID.randomUUID().toString(),
    val key: String,
    val value: String,
    val tags: List<String> = emptyList(),
    val ts: Long = System.currentTimeMillis(),
    val pinned: Boolean = false,
    val importance: Float = 0.5f,          // 0.0 - 1.0
    val source: String = "user",           // user / agent / mission / feedback
    val embedding: FloatArray? = null
)

data class AppSettings(
    val paranoidMode: Boolean = false,
    val appLockEnabled: Boolean = false,
    val biometricLock: Boolean = true,
    val maxToolCallsPerRun: Int = 80,
    val autoCritic: Boolean = true,
    val memoryEnabled: Boolean = true,
    val semanticMemory: Boolean = false,
    val theme: String = "gold",            // gold / amoled / system
    val voiceFullDuplex: Boolean = false
)
