package com.swarmdeck.hunter

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import com.swarmdeck.CancelledException
import com.swarmdeck.Run
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/**
 * Headless WebView pass: loads a page on the main thread, lets JavaScript run, then reads
 * `document.body.innerText` (and a slice of innerHTML for structure). Used when static HTTP
 * HTML has no usable free-tier / quota text (SPA / client-rendered pricing tables).
 *
 * Read-only: no form posts, no cookies persisted beyond the temporary WebView instance.
 */
class WebViewFetcher(
    private val appContext: Context,
    private val run: Run? = null,
    private val timeoutMs: Long = 18_000L,
    private val settleMs: Long = 1_800L
) {
    data class Rendered(
        val status: Int,
        val finalUrl: String,
        val text: String,
        val htmlSnippet: String,
        val ms: Long,
        val error: String = ""
    ) {
        val ok: Boolean get() = error.isEmpty() && status in 200..299 && text.isNotBlank()
        fun asFetchResult(maxChars: Int = 200_000): FetchResult =
            FetchResult(status, finalUrl, (text + "\n" + htmlSnippet).take(maxChars), ms, error)
    }

    fun render(url: String): Rendered {
        UrlSafety.check(url)?.let { return Rendered(0, url, "", "", 0, "blocked: $it") }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            // Never block the UI thread with a latch waiting on itself
            return Rendered(0, url, "", "", 0, "webview fetch must not run on main thread")
        }
        run?.check()
        val t0 = System.nanoTime()
        fun ms() = (System.nanoTime() - t0) / 1_000_000L

        val result = AtomicReference<Rendered?>(null)
        val done = CountDownLatch(1)
        val cancelled = AtomicBoolean(false)

        Handler(Looper.getMainLooper()).post {
            try {
                @SuppressLint("SetJavaScriptEnabled")
                val wv = WebView(appContext.applicationContext)
                wv.settings.javaScriptEnabled = true
                wv.settings.domStorageEnabled = true
                wv.settings.blockNetworkImage = true
                wv.settings.cacheMode = WebSettings.LOAD_NO_CACHE
                wv.settings.userAgentString = HttpFetcher.UA + " WebView"
                // Do not allow file / content access
                wv.settings.allowFileAccess = false
                wv.settings.allowContentAccess = false

                val bridge = JsBridge(cancelled, result, done, url) { ms() }
                wv.addJavascriptInterface(bridge, "SwarmHunter")

                wv.webViewClient = object : WebViewClient() {
                    private var finished = false

                    override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                        val u = request?.url?.toString() ?: return false
                        if (UrlSafety.check(u) != null) {
                            result.set(Rendered(0, u, "", "", ms(), "blocked navigation"))
                            cancelled.set(true)
                            done.countDown()
                            return true
                        }
                        return false
                    }

                    override fun onReceivedError(view: WebView?, request: WebResourceRequest?, error: WebResourceError?) {
                        if (request?.isForMainFrame == true) {
                            result.set(Rendered(0, url, "", "", ms(), error?.description?.toString() ?: "webview error"))
                            done.countDown()
                        }
                    }

                    override fun onPageFinished(view: WebView?, finishedUrl: String?) {
                        if (finished || cancelled.get()) return
                        finished = true
                        // Let SPA frameworks paint quotas, then extract text
                        Handler(Looper.getMainLooper()).postDelayed({
                            if (cancelled.get()) return@postDelayed
                            try {
                                view?.evaluateJavascript(EXTRACT_JS, null)
                            } catch (e: Exception) {
                                result.set(Rendered(0, finishedUrl ?: url, "", "", ms(), e.message ?: "js error"))
                                done.countDown()
                            }
                        }, settleMs)
                    }
                }

                wv.loadUrl(url)
            } catch (e: Exception) {
                result.set(Rendered(0, url, "", "", ms(), e.message ?: "webview init failed"))
                done.countDown()
            }
        }

        val ok = try {
            done.await(timeoutMs, TimeUnit.MILLISECONDS)
        } catch (_: InterruptedException) {
            cancelled.set(true)
            false
        }

        if (!ok) {
            cancelled.set(true)
            return result.get() ?: Rendered(0, url, "", "", ms(), "webview timeout")
        }
        return result.get() ?: Rendered(0, url, "", "", ms(), "no result")
    }

    companion object {
        /**
         * Pull visible text + a limited HTML snippet. Quotas often live in text nodes or data tables
         * filled by JS after first paint.
         */
        private const val EXTRACT_JS = """
            (function(){
              try {
                var t = (document.body && (document.body.innerText || document.body.textContent)) || '';
                var h = (document.body && document.body.innerHTML) ? document.body.innerHTML.substring(0, 40000) : '';
                var href = location.href || '';
                SwarmHunter.deliver(t, h, href);
              } catch (e) {
                SwarmHunter.deliver('', '', location.href || '');
              }
            })();
        """
    }

    /** Named bridge so @JavascriptInterface is retained on release builds. */
    class JsBridge(
        private val cancelled: AtomicBoolean,
        private val result: AtomicReference<Rendered?>,
        private val done: CountDownLatch,
        private val fallbackUrl: String,
        private val ms: () -> Long
    ) {
        @JavascriptInterface
        fun deliver(text: String?, html: String?, href: String?) {
            if (cancelled.get()) return
            val body = (text ?: "").take(180_000)
            val snip = (html ?: "").take(40_000)
            val finalU = (href ?: fallbackUrl).ifBlank { fallbackUrl }
            val bad = UrlSafety.check(finalU)
            result.set(
                if (bad != null) Rendered(0, finalU, "", "", ms(), "blocked redirect: $bad")
                else Rendered(200, finalU, body, snip, ms())
            )
            done.countDown()
        }
    }
}

/**
 * Static HTTP first; optional WebView pass when the HTML looks client-rendered or analysis found no free tier.
 */
class HybridFetcher(
    private val http: Fetcher,
    private val appContext: Context?,
    private val run: Run? = null
) : Fetcher {
    override fun get(url: String, maxBytes: Long): FetchResult = http.get(url, maxBytes)

    /** Always try WebView when Context is available so SPA pricing tables can be read. */
    override fun getRendered(url: String, maxBytes: Long): FetchResult {
        val static = http.get(url, maxBytes)
        if (appContext == null) return static
        if (!static.ok) return static
        // Fast path: large static HTML that does not look like a SPA — keep HTTP body
        if (!looksLikeSpa(static.body) && static.body.length > 12_000) return static
        return try {
            val rendered = WebViewFetcher(appContext, run).render(url)
            if (rendered.ok && rendered.text.length > 200) rendered.asFetchResult(maxBytes.toInt().coerceAtMost(250_000))
            else static
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            static
        }
    }

    companion object {
        fun looksLikeSpa(html: String): Boolean {
            val h = html.lowercase()
            if (h.length < 1500) return true
            val markers = listOf(
                "id=\"__next\"", "id=\"root\"", "id=\"app\"", "ng-app", "data-reactroot",
                "__NEXT_DATA__", "window.__INITIAL", "spa-", "client-side"
            )
            if (markers.any { it in h }) return true
            // Very little visible text vs script bulk
            val scripts = h.split("<script").size
            val textish = h.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim().length
            return scripts > 8 && textish < 800
        }
    }
}
