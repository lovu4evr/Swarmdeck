package com.swarmdeck.cost

import android.content.Context
import com.swarmdeck.Profile
import com.swarmdeck.Profiles
import java.util.concurrent.ConcurrentHashMap

/**
 * Tracks failing provider endpoints and rotates to the next saved profile after errors,
 * with a cooldown so a flaky host is skipped briefly.
 */
object ProviderFailover {
    private val coolUntil = ConcurrentHashMap<String, Long>()
    private const val COOL_MS = 5 * 60_000L

    fun markFail(url: String) {
        val key = url.trim().trimEnd('/')
        if (key.isNotEmpty()) coolUntil[key] = System.currentTimeMillis() + COOL_MS
    }

    fun isCool(url: String): Boolean {
        val key = url.trim().trimEnd('/')
        val until = coolUntil[key] ?: return false
        if (System.currentTimeMillis() >= until) {
            coolUntil.remove(key)
            return false
        }
        return true
    }

    /** Active profile if healthy; otherwise first non-cooled profile with a URL. */
    fun pick(c: Context): Profile {
        val active = Profiles.active(c)
        if (active.url.isNotBlank() && !isCool(active.url)) return active
        for (pr in Profiles.all(c)) {
            if (pr.url.isNotBlank() && !isCool(pr.url)) return pr
        }
        return active
    }
}
