package com.swarmdeck.brain

import android.content.Context
import com.swarmdeck.Agent
import com.swarmdeck.Audit
import com.swarmdeck.Store
import com.swarmdeck.Vault

/** Encrypted persistence + in-memory cache for evolved prompts and factory-built agents. */
object BrainStore {
    private const val K_EVO = "brain_evo_enc"
    private const val K_FAC = "brain_fac_enc"

    @Volatile private var evo: Map<String, AgentEvo> = emptyMap()
    @Volatile private var fac: List<AgentSpec> = emptyList()
    @Volatile private var loaded = false

    @Synchronized
    fun ensureLoaded(c: Context) {
        if (loaded) return
        val p = Store.p(c)
        evo = EvoJson.fromJson(Vault.dec(p.getString(K_EVO, "") ?: ""))
        fac = AgentSpecJson.fromJson(Vault.dec(p.getString(K_FAC, "") ?: ""))
        loaded = true
    }

    private fun saveEvo(c: Context) {
        Store.p(c).edit().putString(K_EVO, Vault.enc(EvoJson.toJson(evo))).apply()
    }

    private fun saveFac(c: Context) {
        Store.p(c).edit().putString(K_FAC, Vault.enc(AgentSpecJson.toJson(fac))).apply()
    }

    /** Built-in agents with their evolved prompt applied (tools are never touched). */
    fun overlay(base: List<Agent>, arm: Int): List<Agent> {
        val m = evo
        if (m.isEmpty()) return base
        return base.map { a ->
            val s = m[a.id]
            if (s == null) a else a.copy(prompt = Evo.promptFor(s, a.prompt, arm))
        }
    }

    fun factoryAgents(arm: Int): List<Agent> {
        val m = evo
        return fac.map { s ->
            val id = AgentFactory.idFor(s.name)
            Agent(id, s.name, s.role, Evo.promptFor(m[id], s.prompt, arm), dynamic = true, tools = s.tools)
        }
    }

    fun factorySpecs(): List<AgentSpec> = fac
    fun stateOf(id: String): AgentEvo? = evo[id]
    fun snapshot(): Map<String, AgentEvo> = evo

    @Synchronized
    fun recordScore(c: Context, agentId: String, arm: Int, score: Int): Decision {
        val cur = evo[agentId] ?: AgentEvo(agentId)
        var next = Evo.record(cur, arm, score)
        val d = Evo.decide(next)
        if (d != Decision.WAIT) {
            val t = next.trial
            next = Evo.apply(next, d, System.currentTimeMillis())
            Audit.log(c, "evolve", "$agentId trial v${t?.version ?: 0}: $d")
        }
        evo = evo + (agentId to next)
        saveEvo(c)
        return d
    }

    @Synchronized
    fun startTrial(c: Context, agentId: String, prompt: String, reason: String): Boolean {
        val cur = evo[agentId] ?: AgentEvo(agentId)
        if (cur.trial != null) return false
        val next = Evo.startTrial(cur, prompt, reason, System.currentTimeMillis())
        evo = evo + (agentId to next)
        saveEvo(c)
        Audit.log(c, "evolve", "$agentId new candidate prompt v${next.trial?.version ?: 0} (A/B trial)")
        return true
    }

    @Synchronized
    fun rollback(c: Context, agentId: String): Boolean {
        val cur = evo[agentId] ?: return false
        if (cur.active == null && cur.trial == null) return false
        evo = evo + (agentId to Evo.rollback(cur))
        saveEvo(c)
        Audit.log(c, "evolve", "$agentId rolled back")
        return true
    }

    @Synchronized
    fun addFactory(c: Context, spec: AgentSpec): Boolean {
        if (fac.size >= AgentFactory.MAX_AGENTS) return false
        val id = AgentFactory.idFor(spec.name)
        if (fac.any { AgentFactory.idFor(it.name) == id }) return false
        fac = fac + spec
        saveFac(c)
        Audit.log(c, "factory", "deployed ${spec.name} tools=${spec.tools.joinToString()}")
        return true
    }

    @Synchronized
    fun removeFactory(c: Context, id: String) {
        val before = fac.size
        fac = fac.filter { AgentFactory.idFor(it.name) != id }
        if (fac.size != before) {
            evo = evo - id
            saveFac(c)
            saveEvo(c)
            Audit.log(c, "factory", "removed $id")
        }
    }
}
