package com.swarmdeck.hunter

import com.swarmdeck.CancelledException
import com.swarmdeck.Llm
import com.swarmdeck.Run
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.IOException
import java.util.concurrent.TimeUnit

data class FetchResult(val status: Int, val finalUrl: String, val body: String, val ms: Long, val error: String = "") {
    val ok: Boolean get() = error.isEmpty() && status in 200..299
}

/** The only door to the network for the Hunter. Tests plug in a fake; the app plugs in [HttpFetcher] / [HybridFetcher]. */
interface Fetcher {
    fun get(url: String, maxBytes: Long = 600_000L): FetchResult

    /**
     * Prefer a JS-rendered body when available (WebView). Default = [get].
     * Used by [Verifier] when static HTML yields no free-tier / quota text.
     */
    fun getRendered(url: String, maxBytes: Long = 700_000L): FetchResult = get(url, maxBytes)
}

/** Read-only GET with safety checks on the request AND on the final URL after redirects. Never sends credentials. */
class HttpFetcher(private val run: Run? = null, private val client: OkHttpClient = defaultClient()) : Fetcher {
    override fun get(url: String, maxBytes: Long): FetchResult {
        UrlSafety.check(url)?.let { return FetchResult(0, url, "", 0, "blocked: $it") }
        val t0 = System.nanoTime()
        fun ms() = (System.nanoTime() - t0) / 1_000_000L
        val req = Request.Builder().url(url)
            .header("User-Agent", UA)
            .header("Accept", "text/html,application/json;q=0.9,*/*;q=0.5")
            .get().build()
        val call = client.newCall(req)
        run?.calls?.add(call)
        return try {
            run?.check()
            call.execute().use { r ->
                val finalUrl = r.request.url.toString()
                val bad = UrlSafety.check(finalUrl)
                if (bad != null) {
                    FetchResult(r.code, finalUrl, "", ms(), "blocked redirect: $bad")
                } else {
                    val src = r.body?.source()
                    val text = if (src == null) "" else {
                        src.request(maxBytes)
                        src.buffer.readUtf8(minOf(src.buffer.size, maxBytes))
                    }
                    FetchResult(r.code, finalUrl, text, ms())
                }
            }
        } catch (e: CancelledException) {
            throw e
        } catch (e: IOException) {
            run?.check()
            FetchResult(0, url, "", ms(), e.message ?: "network error")
        } finally {
            run?.calls?.remove(call)
        }
    }

    companion object {
        const val UA = "SwarmDeck-ResourceHunter/8 (read-only; https://github.com/)"
        fun defaultClient(): OkHttpClient = Llm.http.newBuilder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(25, TimeUnit.SECONDS)
            .callTimeout(40, TimeUnit.SECONDS)
            .build()
    }
}

/** Retry limit: network errors, 429 and 5xx are retried with a growing delay; blocked URLs and 4xx are never retried. */
class RetryingFetcher(
    private val inner: Fetcher,
    private val maxAttempts: Int = 3,
    private val baseDelayMs: Long = 800L,
    private val sleep: (Long) -> Unit = { try { Thread.sleep(it) } catch (_: InterruptedException) {} }
) : Fetcher {
    var attemptsMade = 0
        private set

    override fun get(url: String, maxBytes: Long): FetchResult {
        val limit = maxAttempts.coerceIn(1, 5)
        var last = FetchResult(0, url, "", 0, "not attempted")
        var n = 0
        while (n < limit) {
            n++
            attemptsMade++
            last = inner.get(url, maxBytes)
            val retry = (last.error.isNotEmpty() && !last.error.startsWith("blocked")) || last.status == 429 || last.status >= 500
            if (!retry || n >= limit) return last
            sleep(baseDelayMs * n)
        }
        return last
    }

    override fun getRendered(url: String, maxBytes: Long): FetchResult = inner.getRendered(url, maxBytes)
}
