package com.swarmdeck.hunter

data class ScanReport(val added: Int, val updated: Int, val errors: Map<String, String>)
data class VerifyReport(val checked: Int, val verified: Int, val problems: Int, val events: List<HunterEvent>)

/** Orchestrates discovery, verification, storage and matching. Pure JVM: network and database are injected. */
class Hunter(
    val repo: ResourceRepo,
    private val fetcher: Fetcher,
    private val clock: () -> Long = { System.currentTimeMillis() },
    private val log: (String, String) -> Unit = { _, _ -> },
    private val pause: (Long) -> Unit = { try { Thread.sleep(it) } catch (_: InterruptedException) {} }
) {
    fun seed(): Int {
        var n = 0
        for (r in SeedCatalog.all(clock())) if (repo.get(r.id) == null) { repo.put(r); n++ }
        return n
    }

    fun scan(sources: List<Source> = defaultSources(), check: () -> Unit = {}): ScanReport {
        var added = 0
        var updated = 0
        val errors = LinkedHashMap<String, String>()
        for (s in sources) {
            check()
            val res = try { s.discover(fetcher, clock()) } catch (e: com.swarmdeck.CancelledException) { throw e } catch (e: Exception) { SourceResult(s.name, emptyList(), e.message ?: "failed") }
            if (res.error.isNotEmpty()) { errors[s.name] = res.error; log("scan_error", "${s.name}: ${res.error}") }
            for (r in res.found) {
                val old = repo.get(r.id)
                repo.put(Merge.merge(old, r))
                if (old == null) added++ else updated++
            }
        }
        log("scan", "added $added, updated $updated, ${errors.size} source error(s)")
        return ScanReport(added, updated, errors)
    }

    /** Verifies the least recently checked records first, at most [max] per pass. */
    fun verify(ids: Collection<String>? = null, max: Int = 60, check: () -> Unit = {}): VerifyReport {
        val targets = repo.all().filter { ids == null || it.id in ids }.sortedBy { it.lastChecked }.take(max)
        val cache = HashMap<String, FetchResult>()
        val verifier = Verifier(fetcher, clock)
        val events = ArrayList<HunterEvent>()
        var good = 0
        var bad = 0
        for (r in targets) {
            check()
            val before = cache.size
            val out = verifier.verify(r, cache)
            repo.put(out.resource)
            for (e in out.events) { repo.addEvent(e); events.add(e); log("event_${e.kind}", e.detail) }
            if (out.resource.status == VStatus.VERIFIED) good++ else if (out.resource.status != VStatus.CHANGED) bad++
            if (cache.size > before) pause(250)
        }
        log("verify", "checked ${targets.size}: $good verified, $bad not verified, ${events.size} event(s)")
        return VerifyReport(targets.size, good, bad, events)
    }

    fun dashboard(): Dashboard = DashboardCalc.compute(repo.all(), clock())

    fun recommend(need: Need): Recommendation = Matcher.recommend(repo.all(), need, clock())

    /** A user-supplied official URL. It starts UNVERIFIED and is only ever read, never signed up to. */
    fun addUser(name: String, category: Category, url: String): Pair<Resource?, String> {
        val bad = UrlSafety.check(url)
        if (bad != null) return null to "Not added: $bad."
        val n = Sanitize.clean(name, 60)
        if (n.isEmpty()) return null to "Not added: give it a name."
        val host = UrlSafety.hostOf(url)
        val r = Resource(Ids.of(host, n), host, n, category, url.trim(), docsUrl = url.trim(), source = "user", firstSeen = clock())
        repo.put(Merge.merge(repo.get(r.id), r))
        log("add", "${r.id} $url")
        return repo.get(r.id) to ""
    }

    fun remove(id: String): Boolean = repo.delete(id)
}
