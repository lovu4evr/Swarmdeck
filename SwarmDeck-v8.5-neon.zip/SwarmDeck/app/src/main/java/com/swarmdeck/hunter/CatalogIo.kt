package com.swarmdeck.hunter

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Export / import the resource catalog as JSON (resources only; events optional). */
object CatalogIo {
    fun exportJson(repo: ResourceRepo, includeEvents: Boolean = false): String {
        val root = JSONObject()
        root.put("format", 1)
        root.put("app", "SwarmDeck-Hunter")
        root.put("ts", System.currentTimeMillis())
        val arr = JSONArray()
        repo.all().forEach { arr.put(it.toJson()) }
        root.put("resources", arr)
        if (includeEvents) {
            val ev = JSONArray()
            repo.events(500).forEach {
                ev.put(JSONObject()
                    .put("ts", it.ts).put("rid", it.rid).put("kind", it.kind)
                    .put("detail", it.detail).put("important", it.important))
            }
            root.put("events", ev)
        }
        return root.toString(2)
    }

    fun importJson(repo: ResourceRepo, json: String): Pair<Int, Int> {
        val root = JSONObject(json)
        val arr = root.optJSONArray("resources") ?: return 0 to 0
        var added = 0
        var updated = 0
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val r = try { Resource.fromJson(o) } catch (_: Exception) { continue }
            val old = repo.get(r.id)
            repo.put(if (old == null) r else Merge.merge(old, r))
            if (old == null) added++ else updated++
        }
        return added to updated
    }

    fun defaultFile(c: Context): File =
        File(c.getExternalFilesDir(null) ?: c.filesDir, "hunter-catalog.json")
}

/** Per-provider watch list + simple limit samples for trend sparklines. */
object WatchTrends {
    private const val WATCH = "hunter_watch_ids"
    private const val SAMPLES = "hunter_limit_samples"

    fun watched(c: Context): Set<String> {
        val raw = com.swarmdeck.Store.p(c).getString(WATCH, "") ?: ""
        return raw.split(',').map { it.trim() }.filter { it.isNotEmpty() }.toSet()
    }

    fun setWatched(c: Context, id: String, on: Boolean) {
        val s = watched(c).toMutableSet()
        if (on) s.add(id) else s.remove(id)
        com.swarmdeck.Store.p(c).edit().putString(WATCH, s.joinToString(",")).apply()
    }

    fun isWatched(c: Context, id: String) = id in watched(c)

    /** Record a sample of (rpd, rpm) for trend charts. Keeps last ~40 per id. */
    fun sample(c: Context, id: String, rpd: Int, rpm: Int) {
        val root = try {
            JSONObject(com.swarmdeck.Store.p(c).getString(SAMPLES, "{}") ?: "{}")
        } catch (_: Exception) { JSONObject() }
        val arr = root.optJSONArray(id) ?: JSONArray()
        arr.put(JSONObject().put("ts", System.currentTimeMillis()).put("rpd", rpd).put("rpm", rpm))
        while (arr.length() > 40) arr.remove(0)
        root.put(id, arr)
        com.swarmdeck.Store.p(c).edit().putString(SAMPLES, root.toString()).apply()
    }

    fun samples(c: Context, id: String): List<Triple<Long, Int, Int>> {
        val root = try {
            JSONObject(com.swarmdeck.Store.p(c).getString(SAMPLES, "{}") ?: "{}")
        } catch (_: Exception) { return emptyList() }
        val arr = root.optJSONArray(id) ?: return emptyList()
        val out = ArrayList<Triple<Long, Int, Int>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(Triple(o.optLong("ts"), o.optInt("rpd"), o.optInt("rpm")))
        }
        return out
    }
}

/** Human-readable setup steps for a provider (copy to clipboard). Always leaves signup to the user. */
object SetupSteps {
    fun forResource(r: Resource): String = buildString {
        appendLine("Setup steps for ${r.name} (${r.provider})")
        appendLine("1. Open the official page: ${r.officialUrl}")
        if (r.docsUrl.isNotBlank()) appendLine("2. Docs / pricing: ${r.docsUrl}")
        if (r.signupUrl.isNotBlank()) appendLine("3. Signup URL (you do this yourself): ${r.signupUrl}")
        else appendLine("3. Create an account only on the official site if required — SwarmDeck never signs up for you.")
        if (r.apiBase.isNotBlank()) appendLine("4. API base: ${r.apiBase}")
        if (r.quotas.isNotEmpty()) appendLine("5. Noted quotas: ${r.quotas.joinToString("; ")}")
        if (r.restrictions.isNotEmpty()) appendLine("6. Restrictions: ${r.restrictions.joinToString("; ")}")
        appendLine("7. Paste your key into SwarmDeck Settings → API profile. Keep keys off screenshots.")
    }
}
