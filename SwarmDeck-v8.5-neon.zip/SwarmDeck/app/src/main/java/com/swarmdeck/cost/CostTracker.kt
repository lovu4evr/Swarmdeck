package com.swarmdeck.cost

import android.content.Context
import com.swarmdeck.Store
import org.json.JSONArray
import org.json.JSONObject

/**
 * Local token / cost accounting per agent and mission.
 * Costs are estimates from user-configured rates (USD per 1M tokens); default 0 = track tokens only.
 */
object CostTracker {
    private const val KEY = "cost_log_v1"
    private const val BUDGET_KEY = "cost_budget_usd_month"
    private const val RATE_IN = "cost_rate_in_per_m"
    private const val RATE_OUT = "cost_rate_out_per_m"

    data class Entry(
        val ts: Long,
        val agent: String,
        val mission: String,
        val inTok: Int,
        val outTok: Int,
        val usd: Double
    )

    fun setRates(c: Context, inPerM: Double, outPerM: Double, budgetUsd: Double) {
        Store.p(c).edit()
            .putString(RATE_IN, inPerM.toString())
            .putString(RATE_OUT, outPerM.toString())
            .putString(BUDGET_KEY, budgetUsd.toString())
            .apply()
    }

    fun rates(c: Context): Triple<Double, Double, Double> {
        val p = Store.p(c)
        return Triple(
            p.getString(RATE_IN, "0")?.toDoubleOrNull() ?: 0.0,
            p.getString(RATE_OUT, "0")?.toDoubleOrNull() ?: 0.0,
            p.getString(BUDGET_KEY, "0")?.toDoubleOrNull() ?: 0.0
        )
    }

    fun record(c: Context, agent: String, mission: String, inTok: Int, outTok: Int) {
        val (rin, rout, _) = rates(c)
        val usd = inTok / 1_000_000.0 * rin + outTok / 1_000_000.0 * rout
        val arr = load(c)
        arr.put(JSONObject()
            .put("ts", System.currentTimeMillis())
            .put("agent", agent)
            .put("mission", mission)
            .put("in", inTok)
            .put("out", outTok)
            .put("usd", usd))
        while (arr.length() > 2000) arr.remove(0)
        Store.p(c).edit().putString(KEY, arr.toString()).apply()
    }

    fun monthUsd(c: Context): Double {
        val start = monthStart()
        return entries(c).filter { it.ts >= start }.sumOf { it.usd }
    }

    fun budgetAlert(c: Context): String? {
        val (_, _, budget) = rates(c)
        if (budget <= 0) return null
        val used = monthUsd(c)
        return if (used >= budget) "Monthly budget \$${"%.2f".format(budget)} reached (used \$${"%.2f".format(used)})." else null
    }

    fun entries(c: Context): List<Entry> {
        val arr = load(c)
        val out = ArrayList<Entry>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(
                Entry(
                    o.optLong("ts"),
                    o.optString("agent"),
                    o.optString("mission"),
                    o.optInt("in"),
                    o.optInt("out"),
                    o.optDouble("usd")
                )
            )
        }
        return out
    }

    private fun load(c: Context): JSONArray =
        try { JSONArray(Store.p(c).getString(KEY, "[]") ?: "[]") } catch (_: Exception) { JSONArray() }

    private fun monthStart(): Long {
        val cal = java.util.Calendar.getInstance()
        cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
        cal.set(java.util.Calendar.HOUR_OF_DAY, 0)
        cal.set(java.util.Calendar.MINUTE, 0)
        cal.set(java.util.Calendar.SECOND, 0)
        cal.set(java.util.Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }
}
