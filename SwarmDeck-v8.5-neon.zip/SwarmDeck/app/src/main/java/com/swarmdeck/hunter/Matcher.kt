package com.swarmdeck.hunter

/** What MATRIX (or the user) needs a model or service for. */
data class Need(
    val task: String = "",
    val categories: Set<Category> = setOf(Category.AI_API, Category.INFERENCE, Category.OPEN_LLM, Category.LOCAL_MODEL),
    val preferLocal: Boolean = true,
    val deviceRamMb: Int = 0,                 // 0 = unknown
    val minContext: Int = 0,
    val maxLatencyMs: Long = 0L,              // 0 = no limit
    val priority: String = "balanced",        // balanced | quality | speed | limits
    val excludeProviders: Set<String> = emptySet(),
    val allowUnverified: Boolean = false
)

data class Scored(val r: Resource, val score: Double, val reasons: List<String>)

data class Recommendation(val primary: Scored?, val fallbacks: List<Scored>, val notes: List<String>)

/**
 * Chooses among catalogued free options. Rules, in order:
 *  1. Only usable records are candidates: VERIFIED, or CHANGED/OUTDATED with a penalty. Expired, discontinued and unreachable never are.
 *  2. Local models are preferred when the device can hold them (about 0.6 GB per billion parameters at 4-bit, plus 1 GB).
 *  3. Hosted options score quality, measured latency and known limits, weighted by the stated priority.
 *  4. Fallbacks come from different providers, and one offline option is included when a feasible one exists.
 * All figures are estimates from public data; they are shown with their reasons so the user can judge them.
 */
object Matcher {
    private fun weights(p: String): Triple<Double, Double, Double> = when (p.lowercase()) {
        "quality" -> Triple(0.65, 0.10, 0.25)
        "speed" -> Triple(0.25, 0.50, 0.25)
        "limits" -> Triple(0.25, 0.10, 0.65)
        else -> Triple(0.40, 0.20, 0.40)
    }

    fun localNeedMb(r: Resource): Int {
        val b = ParamSize.billions(r.name + " " + r.models.joinToString(" "))
        return if (b > 0.0) (b * 600.0 + 1000.0).toInt() else 0
    }

    private fun providerLimits(all: List<Resource>, r: Resource): Pair<Int, Int> {
        if (r.rpm > 0 || r.rpd > 0) return r.rpm to r.rpd
        val sib = all.filter { it.provider == r.provider && it.id != r.id && (it.rpm > 0 || it.rpd > 0) }
        val rpm = sib.map { it.rpm }.filter { it > 0 }.minOrNull() ?: 0
        val rpd = sib.map { it.rpd }.filter { it > 0 }.minOrNull() ?: 0
        return rpm to rpd
    }

    private fun ago(ts: Long, now: Long): String {
        val d = (now - ts) / (24L * 3600 * 1000)
        return if (d <= 0) "today" else "${d}d ago"
    }

    fun score(all: List<Resource>, r: Resource, need: Need, now: Long): Scored? {
        if (r.category !in need.categories) return null
        if (r.provider.lowercase() in need.excludeProviders.map { it.lowercase() }) return null
        val eff = r.effective(now)
        val reasons = ArrayList<String>()
        var bonus = 0.0
        when (eff) {
            VStatus.VERIFIED -> { bonus += 1.0; reasons.add("verified free" + (if (r.lastVerified > 0) " (checked ${ago(r.lastVerified, now)})" else "")) }
            VStatus.CHANGED -> { bonus -= 1.0; reasons.add("policy recently changed: re-check before relying on it") }
            VStatus.OUTDATED -> { bonus -= 1.5; reasons.add("verification is older than 30 days") }
            VStatus.UNVERIFIED -> { if (!need.allowUnverified) return null; bonus -= 3.0; reasons.add("not verified yet") }
            else -> return null                                   // expired, unreachable, discontinued
        }
        val quality = if (r.quality > 0.0) r.quality else 4.0
        var latency = if (r.local) 8.0 else if (r.latencyMs > 0) (10.0 - r.latencyMs / 150.0).coerceIn(0.0, 10.0) else 5.0
        if (need.maxLatencyMs > 0 && !r.local && r.latencyMs > need.maxLatencyMs) return null
        if (r.local) {
            val mb = localNeedMb(r)
            if (mb > 0 && need.deviceRamMb > 0 && mb > need.deviceRamMb * 0.6) return null
            if (mb > 0 && need.deviceRamMb == 0 && mb > 4000) return null     // unknown RAM: only small models
            if (need.preferLocal) { bonus += 2.5; reasons.add("runs offline on this device" + (if (mb > 0) " (needs about ${mb / 1000.0} GB)" else "")) }
            else reasons.add("runs offline")
        }
        if (need.minContext > 0) {
            if (r.contextLen in 1 until need.minContext) return null
            if (r.contextLen == 0) { bonus -= 0.5; reasons.add("context size unknown") }
        }
        if (r.contextLen > 0) reasons.add("context ${r.contextLen / 1000}k")
        val (rpm, rpd) = providerLimits(all, r)
        val limit = when {
            r.local -> 10.0
            rpd > 0 -> (Math.log10(rpd + 1.0) * 2.5).coerceIn(0.0, 10.0)
            rpm > 0 -> (Math.log10(rpm * 60.0 * 8 + 1.0) * 2.5).coerceIn(0.0, 10.0)
            else -> 3.0
        }
        if (!r.local) {
            if (rpm > 0 || rpd > 0) reasons.add("limit about " + listOfNotNull(if (rpm > 0) "$rpm/min" else null, if (rpd > 0) "$rpd/day" else null).joinToString(", ") + " (lowest figure on the official page)")
            else reasons.add("limits not verified")
            if (r.latencyMs > 0) reasons.add("responded in ${r.latencyMs} ms")
        }
        if (r.needsCard == true) { bonus -= 0.5; reasons.add("a payment card is requested at signup") }
        if (r.expiresAt > 0 && r.expiresAt - now < 30L * 24 * 3600 * 1000) { bonus -= 1.0; reasons.add("free access ends soon") }
        val (wq, wl, wm) = weights(need.priority)
        return Scored(r, quality * wq + latency * wl + limit * wm + bonus, reasons)
    }

    fun recommend(all: List<Resource>, need: Need, now: Long, fallbackCount: Int = 2): Recommendation {
        val scored = all.mapNotNull { score(all, it, need, now) }.sortedByDescending { it.score }
        val notes = ArrayList<String>()
        if (scored.isEmpty()) {
            notes.add("No usable free option matches. Run `hunt: scan` then `hunt: verify`, or relax the need (for example allow unverified entries).")
            return Recommendation(null, emptyList(), notes)
        }
        val primary = scored.first()
        val chosen = ArrayList<Scored>()
        val seen = HashSet<String>()
        seen.add(primary.r.provider.lowercase())
        for (s in scored.drop(1)) {
            if (chosen.size >= fallbackCount) break
            if (s.r.provider.lowercase() in seen) continue
            seen.add(s.r.provider.lowercase()); chosen.add(s)
        }
        // Keep one offline option as the last line of defence when the primary needs the internet.
        if (!primary.r.local && chosen.none { it.r.local }) {
            val offline = scored.firstOrNull { it.r.local && it.r.provider.lowercase() !in seen }
            if (offline != null) { if (chosen.size >= fallbackCount && chosen.isNotEmpty()) chosen.removeAt(chosen.size - 1); chosen.add(offline) }
        }
        if (primary.r.status == VStatus.UNVERIFIED) notes.add("The top choice is not verified yet.")
        return Recommendation(primary, chosen, notes)
    }

    /** Provider [failed] became unavailable: recommend again without it. */
    fun fallbackAfterFailure(all: List<Resource>, need: Need, failed: String, now: Long): Recommendation =
        recommend(all, need.copy(excludeProviders = need.excludeProviders + failed.lowercase()), now)

    /** Model names that can be called on the API the user has already configured (same host), best first. Used for router fallbacks. */
    fun modelsForEndpoint(all: List<Resource>, endpointUrl: String, now: Long, limit: Int): List<String> {
        val host = UrlSafety.hostOf(endpointUrl)
        if (host.isEmpty()) return emptyList()
        return all.filter { !it.local && it.apiBase.isNotEmpty() && it.models.isNotEmpty() && UrlSafety.hostOf(it.apiBase) == host && it.effective(now) == VStatus.VERIFIED }
            .sortedByDescending { it.quality }
            .flatMap { it.models }
            .distinct()
            .take(limit)
    }

    fun describe(s: Scored): String {
        val r = s.r
        val what = if (r.models.isNotEmpty() && r.name != r.models.first()) "${r.provider} · ${r.name}" else "${r.provider} · ${r.models.firstOrNull() ?: r.name}"
        return "**$what** (score ${"%.1f".format(s.score)}): " + s.reasons.joinToString("; ")
    }
}
