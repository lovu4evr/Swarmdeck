package com.swarmdeck.billing

/** Pure helpers (no Android types) so they can be unit-tested. */
object ProLogic {
    /** How long a previously verified subscription keeps working without being re-verified (offline grace). */
    const val GRACE_MS = 72L * 60 * 60 * 1000

    /**
     * Cached entitlement is trusted only while it is fresh. A verification time in the future means the clock was
     * moved back, so the cache is rejected. A successful Play query always overrides the cache in both directions.
     */
    fun cachedEntitled(wasPro: Boolean, verifiedAt: Long, now: Long): Boolean =
        wasPro && verifiedAt > 0L && verifiedAt <= now && now - verifiedAt <= GRACE_MS

    /** ISO-8601 billing period from Play ("P1M", "P1Y", "P7D") to a short label ("month", "year", "7 days"). */
    fun periodLabel(iso: String): String {
        val m = Regex("^P(\\d+)([DWMY])$").find(iso) ?: return iso
        val n = m.groupValues[1].toIntOrNull() ?: return iso
        val unit = when (m.groupValues[2]) { "D" -> "day"; "W" -> "week"; "M" -> "month"; else -> "year" }
        return if (n == 1) unit else "$n ${unit}s"
    }

    const val LOCAL_DAYS = 30
    const val DAY_MS = 24L * 60 * 60 * 1000

    /** Personal-mode subscription window. start in the future means the clock was moved back, so it is rejected. */
    fun localActive(start: Long, until: Long, now: Long): Boolean = start > 0L && start <= now && now < until

    /** New expiry when subscribing or renewing: renewing early adds to the remaining time instead of losing it. */
    fun extendUntil(currentUntil: Long, now: Long, days: Int = LOCAL_DAYS): Long =
        maxOf(currentUntil, now) + days * DAY_MS

    fun serialize(pro: Boolean, verifiedAt: Long): String = "${if (pro) 1 else 0}|$verifiedAt"

    /** Returns (pro, verifiedAt) or null when the stored value is missing or damaged. */
    fun parse(s: String): Pair<Boolean, Long>? {
        val parts = s.split("|")
        if (parts.size != 2) return null
        val at = parts[1].toLongOrNull() ?: return null
        return when (parts[0]) { "1" -> true to at; "0" -> false to at; else -> null }
    }
}
