package com.swarmdeck.ui

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import com.swarmdeck.ACC2
import com.swarmdeck.Bus
import com.swarmdeck.COLORS
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.Voice
import com.swarmdeck.ui.viz.SwarmLayout
import kotlin.math.max
import kotlin.math.sqrt

enum class OrbState { IDLE, LISTENING, THINKING, SPEAKING }

/** Reads Compose state, so calling it inside a composable makes the caller update live. */
fun currentOrbState(): OrbState = when {
    Voice.speaking -> OrbState.SPEAKING
    Voice.listening -> OrbState.LISTENING
    Bus.running -> OrbState.THINKING
    else -> OrbState.IDLE
}

/**
 * Floating holographic orb: glowing gold core, tilted counter-rotating rings, hologram scanlines, and one satellite per
 * active agent connected to the core by data packets. Listening = expanding cream waves, thinking = fast rings + packets.
 */
@Composable
fun HoloOrb(state: OrbState, agents: List<String>, modifier: Modifier = Modifier) {
    val inf = rememberInfiniteTransition(label = "orb")
    val t by inf.animateFloat(0f, 3600f, infiniteRepeatable(tween(3_600_000, easing = LinearEasing)), label = "t")
    val slow by inf.animateFloat(0.94f, 1.06f, infiniteRepeatable(tween(2200, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "slow")
    val fast by inf.animateFloat(0.88f, 1.12f, infiniteRepeatable(tween(520, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "fast")
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }

    Canvas(modifier) {
        val c = center
        val pulse = when (state) {
            OrbState.SPEAKING -> fast
            OrbState.THINKING -> (slow + fast) / 2f
            else -> slow
        }
        val speed = if (state == OrbState.THINKING) 3f else 1f
        val core = size.minDimension * 0.17f * pulse * (if (state == OrbState.LISTENING) 1.15f else 1f)
        val tint = if (state == OrbState.LISTENING) CREAM else GOLD

        // outer glow
        drawCircle(
            Brush.radialGradient(listOf(tint.copy(alpha = 0.40f), Color.Transparent), center = c, radius = core * 4.2f),
            radius = core * 4.2f, center = c
        )

        // hologram scanlines inside a disc
        val bigR = core * 3f
        var y = c.y - bigR
        while (y <= c.y + bigR) {
            val dy = y - c.y
            val hw = sqrt(max(bigR * bigR - dy * dy, 0f))
            drawLine(tint.copy(alpha = 0.05f), Offset(c.x - hw, y), Offset(c.x + hw, y), strokeWidth = 1f)
            y += 7f
        }
        val sweep = c.y - bigR + ((t * 0.5f * speed) % 1f) * (bigR * 2f)
        val sdy = sweep - c.y
        val shw = sqrt(max(bigR * bigR - sdy * sdy, 0f))
        drawLine(tint.copy(alpha = 0.28f), Offset(c.x - shw, sweep), Offset(c.x + shw, sweep), strokeWidth = 2f)

        // tilted counter-rotating rings
        for (k in 0..2) {
            val rx = core * (2.0f + k * 0.9f)
            val ry = rx * (0.28f + 0.14f * k)
            val dir = if (k % 2 == 0) 1f else -1f
            rotate(degrees = dir * t * speed * (12f + 7f * k), pivot = c) {
                drawOval(
                    tint.copy(alpha = 0.55f - 0.12f * k),
                    topLeft = Offset(c.x - rx, c.y - ry),
                    size = Size(rx * 2f, ry * 2f),
                    style = Stroke(width = 1.6f)
                )
            }
        }

        // listening waves
        if (state == OrbState.LISTENING) {
            for (w in 0..2) {
                val f = ((t * 0.7f) + w / 3f) % 1f
                drawCircle(CREAM.copy(alpha = (1f - f) * 0.35f), radius = core * (1.4f + f * 3f), center = c, style = Stroke(2f))
            }
        }

        // core sphere
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White, tint, Color(0xFF8A5A00)),
                center = Offset(c.x - core * 0.3f, c.y - core * 0.3f), radius = core * 1.4f
            ),
            radius = core, center = c
        )

        // agent satellites + data packets
        val sats = SwarmLayout.satellites(agents.size, t * (if (state == OrbState.THINKING) 1.8f else 1f), size.minDimension * 0.42f)
        sats.forEachIndexed { i, s ->
            val p = Offset(c.x + s.x, c.y + s.y)
            val col = COLORS[i % COLORS.size]
            drawLine(col.copy(alpha = 0.10f + 0.12f * s.depth), c, p, strokeWidth = 1.2f)
            if (state == OrbState.THINKING || state == OrbState.SPEAKING) {
                val f = ((t * 0.6f) + i * 0.17f) % 1f
                drawCircle(col, 3f + 2f * s.depth, Offset(c.x + (p.x - c.x) * f, c.y + (p.y - c.y) * f))
            }
            drawCircle(col.copy(alpha = 0.25f), (7f + 8f * s.depth) * 1.8f, p)
            drawCircle(col, 4f + 5f * s.depth, p)
            if (s.depth > 0.45f) {
                paint.color = col.copy(alpha = 0.85f).toArgb()
                paint.textSize = 11.dp.toPx()
                drawContext.canvas.nativeCanvas.drawText(agents[i].take(12), p.x + 12f, p.y - 10f, paint)
            }
        }
    }
}

/** Small pulsing orb used as the entry point to the immersive view. */
@Composable
fun MiniOrb(modifier: Modifier = Modifier, onClick: () -> Unit) {
    val inf = rememberInfiniteTransition(label = "mini")
    val p by inf.animateFloat(0.85f, 1.1f, infiniteRepeatable(tween(1800, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "p")
    Canvas(modifier.size(40.dp).pointerInput(Unit) { detectTapGestures { onClick() } }) {
        val half = size.minDimension / 2f
        val r = size.minDimension * 0.26f * p
        drawCircle(Brush.radialGradient(listOf(GOLD.copy(alpha = 0.5f), Color.Transparent), center = center, radius = half), radius = half)
        drawCircle(
            Brush.radialGradient(
                listOf(Color.White, GOLD, Color(0xFF8A5A00)),
                center = Offset(center.x - r * 0.3f, center.y - r * 0.3f), radius = r * 1.4f
            ),
            radius = r
        )
        drawCircle(ACC2.copy(alpha = 0.6f), radius = r * 1.7f, style = Stroke(1.2f))
    }
}
