package com.swarmdeck

import android.content.Context
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.net.URLEncoder

/** Web search with several backends and automatic fallback, so one blocked provider doesn't break research. */
object Search {
    private val JSON = "application/json".toMediaType()
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Mobile Safari/537.36"

    private fun getHtml(run: Run, url: String): String =
        Net.call(run, Request.Builder().url(url).header("User-Agent", UA).header("Accept-Language", "en").build()).use { r ->
            if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
            (r.body?.string() ?: "").take(600_000)
        }

    private fun tavily(run: Run, q: String, key: String): List<Triple<String, String, String>> {
        val body = JSONObject().put("api_key", key).put("query", q).put("max_results", 6)
        val j = Net.json(run, Request.Builder().url("https://api.tavily.com/search").post(body.toString().toRequestBody(JSON)).build())
        val a = j.optJSONArray("results") ?: return emptyList()
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.optString("title"), o.optString("url"), o.optString("content").take(300)) }
    }

    private fun brave(run: Run, q: String, key: String): List<Triple<String, String, String>> {
        val j = Net.json(run, Request.Builder().url("https://api.search.brave.com/res/v1/web/search?count=6&q=" + enc(q)).header("X-Subscription-Token", key).header("Accept", "application/json").build())
        val a = j.optJSONObject("web")?.optJSONArray("results") ?: return emptyList()
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.optString("title"), o.optString("url"), Parse.stripHtml(o.optString("description"), 300)) }
    }

    private fun serper(run: Run, q: String, key: String): List<Triple<String, String, String>> {
        val body = JSONObject().put("q", q).put("num", 6)
        val j = Net.json(run, Request.Builder().url("https://google.serper.dev/search").header("X-API-KEY", key).post(body.toString().toRequestBody(JSON)).build())
        val a = j.optJSONArray("organic") ?: return emptyList()
        return (0 until a.length()).map { val o = a.getJSONObject(it); Triple(o.optString("title"), o.optString("link"), o.optString("snippet").take(300)) }
    }

    private fun searx(run: Run, q: String, base0: String): List<Triple<String, String, String>> {
        val base = base0.trim().trimEnd('/')
        if (!base.startsWith("https://")) return emptyList()
        val j = Net.json(run, Request.Builder().url("$base/search?format=json&q=" + enc(q)).header("User-Agent", UA).build())
        val a = j.optJSONArray("results") ?: return emptyList()
        return (0 until minOf(a.length(), 6)).map { val o = a.getJSONObject(it); Triple(o.optString("title"), o.optString("url"), o.optString("content").take(300)) }
    }

    fun search(c: Context, run: Run, q: String): String {
        if (q.isBlank()) return "Empty query"
        val p = Store.p(c)
        val provider = p.getString("search_provider", "auto") ?: "auto"
        val key = Vault.dec(p.getString("search_key_enc", "") ?: "")
        var results: List<Triple<String, String, String>> = emptyList()
        var used = ""
        fun attempt(name: String, f: () -> List<Triple<String, String, String>>) {
            if (results.isNotEmpty()) return
            try {
                val r = f()
                if (r.isNotEmpty()) { results = r; used = name }
            } catch (e: CancelledException) {
                throw e
            } catch (e: Exception) {
            }
        }
        if (provider == "tavily" && key.isNotEmpty()) attempt("Tavily") { tavily(run, q, key) }
        if (provider == "brave" && key.isNotEmpty()) attempt("Brave") { brave(run, q, key) }
        if (provider == "serper" && key.isNotEmpty()) attempt("Serper") { serper(run, q, key) }
        if (provider == "searxng") attempt("SearXNG") { searx(run, q, p.getString("searx_url", "") ?: "") }
        attempt("DuckDuckGo") { Parse.parseDdg(getHtml(run, "https://html.duckduckgo.com/html/?q=" + enc(q))) }
        attempt("DuckDuckGo Lite") { Parse.parseDdgLite(getHtml(run, "https://lite.duckduckgo.com/lite/?q=" + enc(q))) }
        if (results.isEmpty()) {
            return try {
                Bus.think("Search APIs blocked - using the live browser")
                LiveBrowser.open(c, "https://duckduckgo.com/html/?q=" + enc(q))
                LiveBrowser.read().take(4000)
            } catch (e: CancelledException) {
                throw e
            } catch (e: Exception) {
                "No results (search was blocked). Add a search API key in Settings > Search."
            }
        }
        return "[untrusted web results via $used]\n" + results.joinToString("\n") { "- ${it.first}\n  ${it.second}\n  ${it.third}" }
    }
}
