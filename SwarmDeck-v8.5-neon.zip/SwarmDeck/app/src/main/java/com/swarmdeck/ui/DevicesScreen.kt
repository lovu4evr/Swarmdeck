package com.swarmdeck.ui

import android.app.Activity
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MUTED
import com.swarmdeck.clearColors
import com.swarmdeck.device.DeviceCmd
import com.swarmdeck.device.DeviceStore
import com.swarmdeck.device.PairedDevice
import com.swarmdeck.glass
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Pair and manage computers. Pairing here keeps the one-time code out of the chat history. */
@Composable
fun DevicesScreen(act: Activity, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var devices by remember { mutableStateOf(DeviceStore.list(act)) }
    var status by remember { mutableStateOf<Map<String, String>>(emptyMap()) }
    var msg by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var addr by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun ping(d: PairedDevice) {
        scope.launch {
            status = status + (d.name to "checking…")
            val r = withContext(Dispatchers.IO) { DeviceCmd.pingText(d) }
            status = status + (d.name to r)
        }
    }

    LaunchedEffect(Unit) { devices.forEach { ping(it) } }

    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState())) {
        Text("DEVICES", color = GOLD, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text(
            "Control your laptop or desktop from here. Run companion/swarmdeck_companion.py on it (same Wi-Fi), then pair below. " +
                "Every action asks you first, and the volume kill switch pauses the computer too.",
            color = MUTED, fontSize = 12.sp
        )
        Spacer(Modifier.height(14.dp))

        if (devices.isEmpty()) {
            Text("No computers paired yet.", color = CREAM, fontSize = 14.sp)
        }
        for (d in devices) {
            Column(Modifier.fillMaxWidth().padding(bottom = 10.dp).glass(RoundedCornerShape(16.dp)).padding(14.dp)) {
                Text(d.name + "  ·  " + d.os, color = CREAM, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                Text(d.host + ":" + d.port + "   " + (status[d.name] ?: ""), color = MUTED, fontSize = 12.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    TextButton({ ping(d) }) { Text("Ping", color = GOLD) }
                    TextButton({
                        scope.launch {
                            msg = withContext(Dispatchers.IO) { DeviceCmd.stopText(act, d.name) }
                        }
                    }) { Text("Stop", color = GOLD) }
                    TextButton({
                        DeviceStore.remove(act, d.name)
                        devices = DeviceStore.list(act)
                    }) { Text("Remove", color = MUTED) }
                }
            }
        }

        Spacer(Modifier.height(8.dp))
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(14.dp)) {
            Text("Pair a computer", color = GOLD, fontSize = 14.sp, fontWeight = FontWeight.Bold)
            Text("The companion window shows the address and an 8-character code (valid 10 minutes).", color = MUTED, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            TextField(name, { name = it }, Modifier.fillMaxWidth(), colors = clearColors(), singleLine = true, label = { Text("Name (e.g. Laptop)", color = MUTED) })
            TextField(addr, { addr = it }, Modifier.fillMaxWidth(), colors = clearColors(), singleLine = true, label = { Text("Address (e.g. 192.168.1.5:8765)", color = MUTED) })
            TextField(code, { code = it }, Modifier.fillMaxWidth(), colors = clearColors(), singleLine = true, label = { Text("Pairing code", color = MUTED) })
            Spacer(Modifier.height(10.dp))
            Button(
                onClick = {
                    if (!busy) {
                        busy = true
                        scope.launch {
                            val r = withContext(Dispatchers.IO) { DeviceCmd.pair(act, name, addr, code) }
                            busy = false
                            msg = r
                            if (r.startsWith("Paired")) {
                                name = ""
                                addr = ""
                                code = ""
                                devices = DeviceStore.list(act)
                            }
                        }
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = GOLD, contentColor = Color.Black),
                modifier = Modifier.align(Alignment.End)
            ) { Text(if (busy) "Pairing…" else "Pair") }
        }
        if (msg.isNotBlank()) {
            Spacer(Modifier.height(10.dp))
            Text(msg, color = CREAM, fontSize = 13.sp)
        }
        Spacer(Modifier.height(10.dp))
        TextButton(onBack) { Text("Back to chat", color = MUTED) }
    }
}
