package com.swarmdeck.guard

import com.swarmdeck.device.DeviceRules
import org.json.JSONObject

enum class Risk { SAFE, NOTICE, CONFIRM, BLOCK }

data class GuardCtx(val strict: Boolean = false, val fileExists: Boolean = false, val oldSize: Long = 0L)

data class Assessment(
    val risk: Risk,
    val reasons: List<String> = emptyList(),
    val title: String = "",
    val preview: String = ""
)

/**
 * Zero-Trust classifier: decides, per tool call, whether it runs silently, is logged, needs a fresh approval, or is blocked outright.
 * BLOCK can never be approved away. Tools that already ask the user themselves (phone/browser actions, video) are only
 * checked for secrets so the user is not asked twice. Pure JVM.
 */
object RiskClassifier {
    val READ_ONLY = setOf(
        "current_time", "memory_search", "graph_recall", "resource_search", "resource_match", "resource_dashboard", "device_list", "file_list", "file_read", "browser_read", "browser_scroll", "browser_back",
        "browser_forward", "browser_reload", "browser_wait", "browser_extract_tables", "browser_screenshot",
        "browser_takeover_start", "browser_takeover_end", "phone_screen"
    )
    val SELF_GATED = setOf("phone_action", "browser_click", "browser_type", "browser_select", "browser_check", "generate_video")

    private val BAD_EXT = setOf(
        "apk", "dex", "so", "jar", "sh", "bash", "bat", "cmd", "exe", "dll", "bin", "elf", "msi", "scr", "vbs", "ps1"
    )
    private val JS_BAD = Regex(
        "\\bfetch\\s*\\(|XMLHttpRequest|WebSocket|sendBeacon|\\bimport\\s*\\(|document\\.cookie|localStorage|sessionStorage|importScripts",
        RegexOption.IGNORE_CASE
    )
    private val PY_BAD = Regex(
        "\\bimport\\s+js\\b|\\bfrom\\s+js\\b|pyodide\\.http|\\burllib\\b|\\brequests\\b|\\bsocket\\b|\\bsubprocess\\b|os\\.system|\\bopen_url\\b|\\bfetch\\b|XMLHttpRequest",
        RegexOption.IGNORE_CASE
    )
    private val URL_CREDS = Regex("://[^/@\\s]+@")

    fun assess(tool: String, a: JSONObject, ctx: GuardCtx = GuardCtx()): Assessment {
        return when (tool) {
            "memory_save" -> memorySave(a, ctx)
            "file_write" -> fileWrite(a, ctx)
            "run_code" -> runCode(a, ctx)
            "web_fetch", "browser_open" -> url(a.optString("url"), ctx)
            "web_search" -> egress(a.optString("query"), "Search query", ctx)
            "phone_action", "browser_type" -> typed(a)
            "device_screen" -> deviceScreen(a)
            "device_act" -> deviceAct(a)
            "generate_image", "generate_audio" -> generated(tool, a, ctx)
            else -> {
                if (tool in READ_ONLY || tool in SELF_GATED) {
                    Assessment(Risk.SAFE)
                } else if (ctx.strict) {
                    Assessment(
                        Risk.CONFIRM, listOf("strict mode: every other action needs approval"),
                        "Run tool $tool", "Arguments: " + SecretScan.redact(a.toString().take(200))
                    )
                } else {
                    Assessment(Risk.NOTICE, listOf("unrecognized tool"))
                }
            }
        }
    }

    fun blockMessage(a: Assessment): String =
        "BLOCKED by Zero-Trust: " + a.reasons.joinToString("; ") +
            ". This action will not run and cannot be approved. Do not retry or work around it; tell the user what you wanted to do and why it was blocked."

    fun approvalDetail(a: Assessment): String =
        "⚠ " + a.reasons.joinToString("; ") + (if (a.preview.isNotBlank()) "\n\n" + a.preview else "")

    private fun block(reason: String) = Assessment(Risk.BLOCK, listOf(reason))

    private fun memorySave(a: JSONObject, ctx: GuardCtx): Assessment {
        val key = a.optString("key")
        val value = a.optString("value")
        val kinds = SecretScan.kinds(key + "\n" + value)
        if (kinds.isNotEmpty()) return block("memory is not a password manager: the text contains $kinds")
        if (ctx.strict) {
            return Assessment(
                Risk.CONFIRM, listOf("strict mode: saving to memory needs approval"),
                "Save to memory: " + key.take(60), key.take(100) + ": " + value.take(200)
            )
        }
        return Assessment(Risk.NOTICE, listOf("memory save"))
    }

    private fun fileWrite(a: JSONObject, ctx: GuardCtx): Assessment {
        val path = a.optString("path").trim()
        if (path.isEmpty()) return block("empty file path")
        val segs = path.replace('\\', '/').split('/').filter { it.isNotEmpty() }
        if (segs.isEmpty()) return block("empty file path")
        if (segs.any { it == ".." }) return block("path traversal (..) is not allowed")
        if (segs.any { it != "." && it.startsWith(".") }) return block("hidden files and folders are not allowed")
        val ext = segs.last().substringAfterLast('.', "").lowercase()
        if (ext in BAD_EXT) return block("executable or installer file type .$ext cannot be written")
        val content = a.optString("content")
        val kinds = SecretScan.kinds(content)
        val why = ArrayList<String>()
        if (ctx.fileExists) why.add("overwrites an existing file")
        if (kinds.isNotEmpty()) why.add("content contains $kinds")
        if (ctx.strict) why.add("strict mode")
        if (why.isEmpty()) return Assessment(Risk.NOTICE, listOf("new file"))
        val head = if (ctx.fileExists) "Overwrites ${ctx.oldSize} B with ${content.length} chars" else "New file, ${content.length} chars"
        return Assessment(Risk.CONFIRM, why, "Write file: " + path.take(60), "$head\n---\n" + SecretScan.redact(content.take(200)))
    }

    private fun runCode(a: JSONObject, ctx: GuardCtx): Assessment {
        val lang = a.optString("language").lowercase().trim()
        val code = a.optString("code")
        if ((lang == "js" || lang == "javascript") && JS_BAD.containsMatchIn(code)) {
            return block("the JavaScript tries to reach the network or browser storage")
        }
        if ((lang == "python" || lang == "py") && PY_BAD.containsMatchIn(code)) {
            return block("the Python code tries to reach the network, the system or the JS bridge")
        }
        if (ctx.strict) {
            return Assessment(Risk.CONFIRM, listOf("strict mode: running code needs approval"), "Run $lang code", SecretScan.redact(code.take(200)))
        }
        return Assessment(Risk.NOTICE, listOf("sandboxed code run"))
    }

    private fun urlProblem(u: String): String? {
        val kinds = SecretScan.kinds(u)
        if (kinds.isNotEmpty()) return "the URL contains $kinds and would leak it"
        if (URL_CREDS.containsMatchIn(u)) return "the URL embeds credentials"
        if (u.substringAfter('?', "").length > 300) return "a very long query string looks like data smuggling"
        return null
    }

    private fun url(u: String, ctx: GuardCtx): Assessment {
        val problem = urlProblem(u)
        if (problem != null) return block(problem)
        if (ctx.strict) {
            return Assessment(Risk.CONFIRM, listOf("strict mode: network access needs approval"), "Open " + u.take(80), u.take(200))
        }
        return Assessment(Risk.SAFE)
    }

    private fun egress(text: String, what: String, ctx: GuardCtx): Assessment {
        val kinds = SecretScan.kinds(text)
        if (kinds.isNotEmpty()) return block("$what contains $kinds and would leak it")
        if (text.length > 400) return block("$what is unusually long and looks like data smuggling")
        if (ctx.strict) {
            return Assessment(Risk.CONFIRM, listOf("strict mode: network access needs approval"), "Search the web", text.take(200))
        }
        return Assessment(Risk.SAFE)
    }

    private fun typed(a: JSONObject): Assessment {
        val kinds = SecretScan.kinds(a.optString("text"))
        if (kinds.isNotEmpty()) return block("typing $kinds is never allowed; enter it yourself")
        return Assessment(Risk.SAFE)
    }

    private fun generated(tool: String, a: JSONObject, ctx: GuardCtx): Assessment {
        val text = if (tool == "generate_audio") a.optString("text") else a.optString("prompt")
        val kinds = SecretScan.kinds(text)
        if (kinds.isNotEmpty()) return block("the request contains $kinds and would be sent to a media service")
        if (ctx.strict) {
            return Assessment(Risk.CONFIRM, listOf("strict mode: media generation needs approval"), "Run $tool", text.take(200))
        }
        return Assessment(Risk.NOTICE, listOf("media generation"))
    }

    private fun deviceScreen(a: JSONObject): Assessment {
        val dev = a.optString("device").trim()
        if (dev.isEmpty()) return block("no device name given")
        return Assessment(
            Risk.CONFIRM,
            listOf("a screenshot of your computer \"$dev\" is sent to the AI model and may show private content"),
            "Look at the screen of $dev", ""
        )
    }

    /** Every computer action needs a fresh approval; secrets, dangerous shortcuts, shells and bad URLs are blocked outright. */
    private fun deviceAct(a: JSONObject): Assessment {
        val dev = a.optString("device").trim()
        if (dev.isEmpty()) return block("no device name given")
        val action = a.optString("action").lowercase().trim()
        val built = DeviceRules.buildArgs(action, a)
        val args = built.first ?: return block(built.second ?: "invalid arguments")
        if (action in DeviceRules.QUIET) return Assessment(Risk.SAFE)

        val text = when (action) {
            "type", "clipboard_set" -> args.optString("text")
            "open_url" -> args.optString("url")
            else -> ""
        }
        if (action == "type" || action == "clipboard_set") {
            val kinds = SecretScan.kinds(text)
            if (kinds.isNotEmpty()) return block("sending $kinds to a computer is never allowed; enter it yourself")
        }
        if (action == "open_url") {
            val problem = urlProblem(text)
            if (problem != null) return block(problem)
        }
        val what = when (action) {
            "screenshot" -> "take a screenshot"
            "mouse_move" -> "move the mouse to (" + args.optInt("x") + ", " + args.optInt("y") + ")"
            "click" -> (if (args.optBoolean("double")) "double-" else "") + args.optString("button", "left") + "-click at (" + args.optInt("x") + ", " + args.optInt("y") + ")"
            "scroll" -> "scroll " + args.optInt("amount")
            "type" -> "type " + text.length + " characters"
            "key" -> "press " + args.optString("combo")
            "open_url" -> "open " + text.take(60)
            "open_app" -> "open the app " + args.optString("name")
            "clipboard_get" -> "read the clipboard"
            else -> "set the clipboard"
        }
        val preview = when (action) {
            "type", "clipboard_set" -> SecretScan.redact(text.take(120))
            "open_url" -> text.take(120)
            "key" -> args.optString("combo")
            "open_app" -> args.optString("name")
            else -> ""
        }
        val why = ArrayList<String>()
        why.add("controls your computer \"$dev\"")
        if (action == "clipboard_get") why.add("reads the clipboard, which may contain private data")
        return Assessment(Risk.CONFIRM, why, "$dev: $what", preview)
    }
}
