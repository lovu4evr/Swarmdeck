package com.swarmdeck.ui

import android.app.Activity
import androidx.activity.compose.BackHandler
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.swarmdeck.Brain
import com.swarmdeck.Bus
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MUTED
import com.swarmdeck.Registry
import com.swarmdeck.Voice
import com.swarmdeck.clearColors
import com.swarmdeck.glass
import com.swarmdeck.memgraph.GNode
import com.swarmdeck.memgraph.GraphHub
import com.swarmdeck.memgraph.Suggestion
import com.swarmdeck.nameOf
import com.swarmdeck.sendMessage
import com.swarmdeck.userName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs

private val PANELS = listOf("SWARM", "MISSION", "MEMORY", "BRIEFING")

/** Horizontal swipes switch views, vertical swipes open/close the keyboard bar. Children that consume the drag (scroll, pan) win. */
private fun Modifier.swipes(onLeft: () -> Unit, onRight: () -> Unit, onUp: () -> Unit, onDown: () -> Unit): Modifier =
    pointerInput(Unit) {
        var acc = Offset.Zero
        detectDragGestures(
            onDragStart = { acc = Offset.Zero },
            onDragEnd = {
                if (abs(acc.x) > abs(acc.y)) {
                    if (acc.x < -140f) onLeft() else if (acc.x > 140f) onRight()
                } else {
                    if (acc.y < -140f) onUp() else if (acc.y > 140f) onDown()
                }
            }
        ) { change, amount ->
            change.consume()
            acc += amount
        }
    }

private fun toggleVoice(act: Activity) {
    if (Voice.continuous) Voice.stopContinuous() else Voice.startContinuous(act)
}

/**
 * Full-screen, gesture-and-voice-first command view: tap the orb to talk, hold it to stop, swipe left/right between
 * Swarm / Mission / Memory / Briefing, swipe up to type. Only one tiny button (exit).
 */
@Composable
fun ImmersiveScreen(act: Activity, onExit: () -> Unit) {
    var panel by rememberSaveable { mutableStateOf(0) }
    var showInput by remember { mutableStateOf(false) }
    var picked by remember { mutableStateOf<GNode?>(null) }

    DisposableEffect(Unit) {
        val w = act.window
        val ctl = WindowCompat.getInsetsController(w, w.decorView)
        ctl?.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        ctl?.hide(WindowInsetsCompat.Type.systemBars())
        onDispose { ctl?.show(WindowInsetsCompat.Type.systemBars()) }
    }
    BackHandler { if (showInput) showInput = false else onExit() }

    fun go(d: Int) {
        panel = (panel + d).coerceIn(0, PANELS.size - 1)
    }

    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color(0xFF010101), Color(0xFF0A0703), Color(0xFF020202))))
            .swipes({ go(1) }, { go(-1) }, { showInput = true }, { showInput = false })
    ) {
        Box(
            Modifier.align(Alignment.Center).size(520.dp)
                .background(Brush.radialGradient(listOf(Color(0x22F5B301), Color.Transparent)))
        )

        Crossfade(panel, Modifier.fillMaxSize(), label = "panel") { p ->
            when (p) {
                0 -> SwarmPanel(act)
                1 -> Box(Modifier.fillMaxSize().padding(top = 64.dp, bottom = 130.dp, start = 22.dp, end = 22.dp)) {
                    MissionTimeline(Bus.mission, Bus.running, Bus.missionObjective, Modifier.fillMaxSize())
                }
                2 -> Box(Modifier.fillMaxSize().padding(top = 64.dp, bottom = 130.dp)) {
                    MemoryGraphView(Modifier.fillMaxSize(), compact = true, onSelect = { picked = it })
                    val pk = picked
                    if (pk != null) {
                        Column(Modifier.align(Alignment.BottomCenter).padding(12.dp).glass(RoundedCornerShape(14.dp)).padding(12.dp)) {
                            Text(pk.label, color = GOLD, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                            if (pk.detail.isNotBlank()) Text(pk.detail.take(160), color = CREAM, fontSize = 12.sp)
                        }
                    }
                }
                else -> Box(Modifier.fillMaxSize().padding(top = 64.dp, bottom = 130.dp)) { BriefingPanel(act) { panel = 0 } }
            }
        }

        // header: exit + current view name
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Default.Close, "Exit", tint = CREAM.copy(alpha = 0.6f), modifier = Modifier.size(26.dp).clickable { onExit() })
            Spacer(Modifier.weight(1f))
            Text(PANELS[panel], color = GOLD, fontSize = 13.sp, fontWeight = FontWeight.Black, letterSpacing = 4.sp)
            Spacer(Modifier.weight(1f))
            Text(if (Bus.running) "● LIVE" else "      ", color = GOLD, fontSize = 11.sp)
        }

        // bottom: live caption + page dots (also swipeable, so views can be switched while the graph is panning)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().navigationBarsPadding()
                .swipes({ go(1) }, { go(-1) }, { showInput = true }, { showInput = false })
                .padding(horizontal = 24.dp, vertical = 18.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Caption()
            Spacer(Modifier.size(14.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                for (i in PANELS.indices) {
                    Box(
                        Modifier.size(if (i == panel) 9.dp else 6.dp).clip(CircleShape)
                            .background(if (i == panel) GOLD else MUTED.copy(alpha = 0.4f))
                    )
                }
            }
        }

        if (showInput) {
            InputBar(
                act,
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().imePadding().navigationBarsPadding().padding(12.dp)
            ) {
                showInput = false
                panel = 0
            }
        }
    }
}

@Composable
private fun SwarmPanel(act: Activity) {
    val state = currentOrbState()
    val agents = Bus.subAgents.map { nameOf(it) }.ifEmpty { Registry.all().take(6).map { it.name } }
    Box(Modifier.fillMaxSize(), Alignment.Center) {
        HoloOrb(
            state, agents,
            Modifier.size(340.dp).pointerInput(Unit) {
                detectTapGestures(
                    onTap = { toggleVoice(act) },
                    onLongPress = { if (Bus.running) Brain.stopAll("Orb long-press") else Voice.stopSpeaking() }
                )
            }
        )
    }
}

@Composable
private fun Caption() {
    val last = Bus.turns.lastOrNull { !it.user }?.text.orEmpty()
    val text = when {
        Voice.listening && Voice.partial.isNotBlank() -> "“" + Voice.partial + "”"
        Bus.running -> Bus.stream.takeLast(200).ifBlank { Bus.status }
        last.isNotBlank() -> last.take(220)
        else -> "Tap the orb to talk · hold to stop · swipe for views · swipe up to type"
    }
    Text(text, color = CREAM, fontSize = 14.sp, textAlign = TextAlign.Center, maxLines = 4, modifier = Modifier.fillMaxWidth())
}

@Composable
private fun InputBar(act: Activity, modifier: Modifier, onDone: () -> Unit) {
    var txt by remember { mutableStateOf("") }
    fun send() {
        if (txt.isNotBlank()) {
            sendMessage(act, txt)
            txt = ""
            onDone()
        }
    }
    Row(modifier.glass(RoundedCornerShape(26.dp)), verticalAlignment = Alignment.CenterVertically) {
        TextField(
            txt, { txt = it }, Modifier.weight(1f), colors = clearColors(), singleLine = true,
            placeholder = { Text("Type to your swarm…", color = MUTED) },
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
            keyboardActions = KeyboardActions(onSend = { send() })
        )
        IconButton(onClick = { send() }) { Icon(Icons.Default.Send, null, tint = GOLD) }
    }
}

@Composable
private fun BriefingPanel(act: Activity, done: () -> Unit) {
    var items by remember { mutableStateOf<List<Suggestion>?>(null) }
    LaunchedEffect(Unit) { items = withContext(Dispatchers.Default) { GraphHub.suggestions(act) } }
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    val greet = if (hour < 12) "Good morning" else if (hour < 17) "Good afternoon" else "Good evening"
    Column(Modifier.fillMaxSize().padding(horizontal = 22.dp)) {
        Text(greet + ", " + userName(act), color = GOLD, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.size(4.dp))
        Text("What needs you today. Tap an item to hand it to your agents.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.size(14.dp))
        val l = items
        if (l == null) {
            Text("Reading your goals and decisions…", color = MUTED, fontSize = 13.sp)
        } else if (l.isEmpty()) {
            Text("All clear. Your goals are on track and no decisions are waiting for review.", color = CREAM, fontSize = 14.sp)
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(l) { s ->
                    val dot = when (s.level) {
                        1 -> Color(0xFFFF6B6B)
                        2 -> GOLD
                        else -> CREAM
                    }
                    Row(
                        Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp))
                            .clickable {
                                sendMessage(act, s.action)
                                done()
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(10.dp).clip(CircleShape).background(dot))
                        Spacer(Modifier.size(12.dp))
                        Text(s.title, color = CREAM, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
