package com.swarmdeck.billing

import android.content.Context
import android.content.pm.ApplicationInfo
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.swarmdeck.Store
import com.swarmdeck.Turn
import com.swarmdeck.Vault

/** Everything that is locked behind the SwarmDeck Pro subscription. */
enum class ProFeature(val title: String, val blurb: String) {
    MISSIONS("Autonomous Missions", "Give a goal and your agents plan and execute it step by step, with pause and resume."),
    ALL_AGENTS("All-Agents + Deep mode", "Run every agent at once and use up to 6 specialists per question with careful reasoning."),
    DEVICES("Multi-device control", "Pair laptops and desktops; the Desk Operator works on them under Zero-Trust approval."),
    MEMGRAPH("Memory Graph & Decisions", "Force-directed map of facts, goals and decisions, plus graph-aware recall for your agents."),
    IMMERSIVE("Immersive mode", "Full-screen holographic orb, swipe pages, voice-first control."),
    MARKET("Agent Market", "Create, import and share custom agents."),
    SWARMLAB("Swarm Lab", "Parallel simulations, the agent factory and self-evolving agents.")
}

/**
 * Entitlement state. The source of truth is Google Play (see [BillingManager]); this object only caches the last
 * verified answer (encrypted with the Keystore-backed Vault) so the app works offline for a short grace period.
 * A successful Play query always overrides the cache, so cancelled or refunded subscriptions are revoked.
 */
object Pro {
    const val PRODUCT_ID = "swarmdeck_pro"      // subscription id in Play Console
    const val PLAN_MONTHLY = "monthly"          // base plan ids
    const val PLAN_YEARLY = "yearly"

    private const val KEY_STATE = "pro_state_enc"
    private const val KEY_DEBUG = "pro_debug_override"
    private const val KEY_LOCAL = "pro_local_enc"

    /** Personal-mode plan (debug builds only): shown price and period. No money is collected. */
    const val LOCAL_PRICE = "₹500"
    const val LOCAL_DAYS = ProLogic.LOCAL_DAYS
    @Volatile private var memLocalStart = 0L
    @Volatile private var memLocalUntil = 0L

    /** Compose-observable flag for the UI. Engine code should call [isActive] instead. */
    var active by mutableStateOf(false)
        private set

    @Volatile private var memPro = false
    @Volatile private var memAt = 0L

    fun isDebuggable(c: Context): Boolean = (c.applicationContext.applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE) != 0

    fun load(c: Context) { active = isActive(c) }

    fun isActive(c: Context): Boolean {
        val now = System.currentTimeMillis()
        // Testing switch: only honoured in debuggable builds, never in a release build.
        if (isDebuggable(c) && Store.p(c).getBoolean(KEY_DEBUG, false)) return true
        if (isDebuggable(c) && localActive(c)) return true
        if (ProLogic.cachedEntitled(memPro, memAt, now)) return true
        val raw = try { Vault.dec(Store.p(c).getString(KEY_STATE, "") ?: "") } catch (_: Exception) { "" }
        val st = ProLogic.parse(raw) ?: return false
        return ProLogic.cachedEntitled(st.first, st.second, now)
    }

    /** Called by [BillingManager] with the result of a successful Play query / purchase. */
    fun record(c: Context, entitled: Boolean) {
        val now = System.currentTimeMillis()
        memPro = entitled; memAt = now
        val enc = Vault.enc(ProLogic.serialize(entitled, now))
        if (enc.isNotEmpty()) Store.p(c).edit().putString(KEY_STATE, enc).apply()
        active = isActive(c)
    }

    /** (startedAt, until) of the personal-mode subscription, or null. */
    fun localState(c: Context): Pair<Long, Long>? {
        if (!isDebuggable(c)) return null
        if (memLocalUntil > 0L) return memLocalStart to memLocalUntil
        val raw = try { Vault.dec(Store.p(c).getString(KEY_LOCAL, "") ?: "") } catch (_: Exception) { "" }
        val parts = raw.split("|")
        if (parts.size != 2) return null
        val s = parts[0].toLongOrNull() ?: return null
        val u = parts[1].toLongOrNull() ?: return null
        return s to u
    }

    fun localActive(c: Context): Boolean {
        val st = localState(c) ?: return false
        return ProLogic.localActive(st.first, st.second, System.currentTimeMillis())
    }

    fun localUntil(c: Context): Long = if (localActive(c)) (localState(c)?.second ?: 0L) else 0L

    /** Subscribe or renew the personal-mode plan for [LOCAL_DAYS] more days. Debug builds only. */
    fun startLocal(c: Context) {
        if (!isDebuggable(c)) return
        val now = System.currentTimeMillis()
        val cur = localState(c)
        val running = cur != null && ProLogic.localActive(cur.first, cur.second, now)
        val start = if (running) cur!!.first else now
        val until = ProLogic.extendUntil(if (running) cur!!.second else 0L, now)
        memLocalStart = start; memLocalUntil = until
        val enc = Vault.enc("$start|$until")
        if (enc.isNotEmpty()) Store.p(c).edit().putString(KEY_LOCAL, enc).apply()
        active = isActive(c)
    }

    fun cancelLocal(c: Context) {
        memLocalStart = 0L; memLocalUntil = 0L
        Store.p(c).edit().remove(KEY_LOCAL).apply()
        active = isActive(c)
    }

    fun setDebugOverride(c: Context, on: Boolean) {
        if (!isDebuggable(c)) return
        Store.p(c).edit().putBoolean(KEY_DEBUG, on).apply()
        active = isActive(c)
    }

    fun debugOverride(c: Context): Boolean = isDebuggable(c) && Store.p(c).getBoolean(KEY_DEBUG, false)

    /** Null when the feature is unlocked, otherwise a ready-made chat reply that explains the lock. */
    fun gate(c: Context, f: ProFeature): Turn? = if (isActive(c)) null else Turn(false, lockedText(f))

    fun lockedText(f: ProFeature): String =
        "🔒 ${f.title} is a SwarmDeck Pro feature.\n${f.blurb}\n\nOpen the menu → SwarmDeck Pro to subscribe or restore your purchase."

    /** Agent tools that belong to a Pro feature (checked in Tools.exec so agents cannot bypass the UI lock). */
    fun featureForTool(name: String): ProFeature? = when (name) {
        "device_list", "device_screen", "device_act" -> ProFeature.DEVICES
        "graph_recall" -> ProFeature.MEMGRAPH
        else -> null
    }
}
