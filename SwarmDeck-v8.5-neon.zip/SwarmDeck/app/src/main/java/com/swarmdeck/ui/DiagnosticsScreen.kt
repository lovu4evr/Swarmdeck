package com.swarmdeck.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.*
import com.swarmdeck.util.CrashLog
import com.swarmdeck.work.HunterMonitorWorker

@Composable
fun DiagnosticsScreen(act: Activity, onBack: () -> Unit) {
    var logOn by remember { mutableStateOf(CrashLog.isEnabled(act)) }
    var recent by remember { mutableStateOf(CrashLog.recent(act)) }
    val scroll = rememberScrollState()
    Column(
        Modifier.fillMaxSize().verticalScroll(scroll).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Diagnostics", color = GOLD, fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Text("Local-only error log. Nothing is sent off this device unless you later enable a cloud path.", color = MUTED, fontSize = 12.sp)
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Record crashes & errors", color = CREAM, modifier = Modifier.weight(1f))
            Switch(logOn, {
                logOn = it
                CrashLog.setEnabled(act, it)
            })
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = {
                recent = CrashLog.recent(act)
            }) { Text("Refresh", color = CREAM) }
            OutlinedButton(onClick = {
                CrashLog.clear(act)
                recent = "(cleared)"
            }) { Text("Clear", color = CREAM) }
            OutlinedButton(onClick = {
                val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                cm.setPrimaryClip(ClipData.newPlainText("swarmdeck-log", recent))
                Toast.makeText(act, "Copied", Toast.LENGTH_SHORT).show()
            }) { Text("Copy", color = CREAM) }
        }
        Text("WorkManager: hunter monitor", color = GOLD, fontSize = 14.sp)
        Text(
            if (com.swarmdeck.hunter.HunterMonitor.enabled(act)) "Scheduled (Wi‑Fi + battery not low)"
            else "Not enabled — use Resource Hunter → Daily monitoring",
            color = MUTED, fontSize = 12.sp
        )
        Text("Recent errors", color = GOLD, fontSize = 14.sp)
        Text(recent, color = CREAM, fontSize = 11.sp, fontFamily = androidx.compose.ui.text.font.FontFamily.Monospace)
        TextButton(onClick = onBack) { Text("Back", color = GOLD) }
    }
}
