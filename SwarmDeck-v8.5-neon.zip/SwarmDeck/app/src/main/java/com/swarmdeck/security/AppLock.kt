package com.swarmdeck.security

import android.content.Context
import android.content.SharedPreferences
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.swarmdeck.Vault
import com.swarmdeck.core.AppSettings
import org.json.JSONObject

/**
 * App Lock (PIN + Biometric) + Paranoid Mode foundation
 * SwarmDeck 5.3
 */
object AppLock {

    private const val PREF = "swarmdeck_lock_v1"
    private const val KEY_SETTINGS = "settings_enc"
    private const val KEY_PIN_HASH = "pin_hash"
    private const val KEY_UNLOCKED_UNTIL = "unlocked_until"

    private const val UNLOCK_DURATION_MS = 5 * 60 * 1000L // 5 minutes soft unlock

    fun settings(c: Context): AppSettings {
        val raw = Vault.dec(prefs(c).getString(KEY_SETTINGS, "") ?: "")
        if (raw.isBlank()) return AppSettings()
        return try {
            val o = JSONObject(raw)
            AppSettings(
                paranoidMode = o.optBoolean("paranoidMode", false),
                appLockEnabled = o.optBoolean("appLockEnabled", false),
                biometricLock = o.optBoolean("biometricLock", true),
                maxToolCallsPerRun = o.optInt("maxToolCallsPerRun", 80),
                autoCritic = o.optBoolean("autoCritic", true),
                memoryEnabled = o.optBoolean("memoryEnabled", true),
                semanticMemory = o.optBoolean("semanticMemory", false),
                theme = o.optString("theme", "gold"),
                voiceFullDuplex = o.optBoolean("voiceFullDuplex", false)
            )
        } catch (_: Exception) {
            AppSettings()
        }
    }

    fun saveSettings(c: Context, s: AppSettings) {
        val o = JSONObject().apply {
            put("paranoidMode", s.paranoidMode)
            put("appLockEnabled", s.appLockEnabled)
            put("biometricLock", s.biometricLock)
            put("maxToolCallsPerRun", s.maxToolCallsPerRun)
            put("autoCritic", s.autoCritic)
            put("memoryEnabled", s.memoryEnabled)
            put("semanticMemory", s.semanticMemory)
            put("theme", s.theme)
            put("voiceFullDuplex", s.voiceFullDuplex)
        }
        prefs(c).edit().putString(KEY_SETTINGS, Vault.enc(o.toString())).apply()
    }

    fun isLockEnabled(c: Context): Boolean = settings(c).appLockEnabled

    fun isUnlocked(c: Context): Boolean {
        if (!isLockEnabled(c)) return true
        val until = prefs(c).getLong(KEY_UNLOCKED_UNTIL, 0L)
        return System.currentTimeMillis() < until
    }

    fun markUnlocked(c: Context) {
        prefs(c).edit().putLong(KEY_UNLOCKED_UNTIL, System.currentTimeMillis() + UNLOCK_DURATION_MS).apply()
    }

    fun lockNow(c: Context) {
        prefs(c).edit().putLong(KEY_UNLOCKED_UNTIL, 0L).apply()
    }

    fun hasPin(c: Context): Boolean = !prefs(c).getString(KEY_PIN_HASH, "").isNullOrBlank()

    fun setPin(c: Context, pin: String) {
        // Simple salted hash (for real production use Android Keystore + stronger KDF)
        val hash = (pin + "swarmdeck_salt_v1").hashCode().toString()
        prefs(c).edit().putString(KEY_PIN_HASH, hash).apply()
    }

    fun verifyPin(c: Context, pin: String): Boolean {
        val stored = prefs(c).getString(KEY_PIN_HASH, "") ?: return false
        val hash = (pin + "swarmdeck_salt_v1").hashCode().toString()
        return stored == hash
    }

    fun canUseBiometric(c: Context): Boolean {
        val bm = BiometricManager.from(c)
        return bm.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL) ==
                BiometricManager.BIOMETRIC_SUCCESS
    }

    fun showBiometricPrompt(
        activity: FragmentActivity,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                markUnlocked(activity)
                onSuccess()
            }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                onError(errString.toString())
            }
            override fun onAuthenticationFailed() {
                onError("Authentication failed")
            }
        })

        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Unlock SwarmDeck")
            .setSubtitle("Confirm it's you")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
            .build()

        prompt.authenticate(info)
    }

    /** In Paranoid Mode almost everything needs confirmation */
    fun requiresConfirmation(c: Context, action: String): Boolean {
        val s = settings(c)
        if (!s.paranoidMode) return false
        val sensitive = setOf(
            "shell", "phone_action", "file_write", "generate_video",
            "browser_click", "run_code", "memory_save"
        )
        return action.lowercase() in sensitive || action.contains("delete") || action.contains("rm")
    }

    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences(PREF, Context.MODE_PRIVATE)
}
