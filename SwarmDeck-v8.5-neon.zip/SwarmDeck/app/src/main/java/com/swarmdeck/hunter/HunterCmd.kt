package com.swarmdeck.hunter

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import com.swarmdeck.Audit
import com.swarmdeck.Bus
import com.swarmdeck.Confirm
import com.swarmdeck.MainActivity
import com.swarmdeck.Profiles
import com.swarmdeck.Run
import com.swarmdeck.Store
import com.swarmdeck.Turn
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Builds Hunters wired to the app's database, logging and (optionally cancellable) network. */
object HunterHub {
    @Volatile private var repo: SqliteRepo? = null

    fun repo(c: Context): SqliteRepo = repo ?: synchronized(this) { repo ?: SqliteRepo(c.applicationContext).also { repo = it } }

    fun get(c: Context, run: Run? = null): Hunter {
        val app = c.applicationContext
        // HybridFetcher: OkHttp for discovery; WebView JS pass for SPA pricing/quota pages
        val net: Fetcher = HybridFetcher(RetryingFetcher(HttpFetcher(run)), app, run)
        val h = Hunter(
            repo(app), net,
            log = { kind, detail ->
                Audit.log(app, "hunter_$kind", detail)
                try { com.swarmdeck.guard.Guard.chain(app).append("hunter", "$kind: $detail".take(200)) } catch (_: Exception) {}
            }
        )
        h.seed()
        return h
    }

    fun deviceRamMb(c: Context): Int = try {
        val am = c.getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
        val mi = android.app.ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        (mi.totalMem / (1024L * 1024L)).toInt()
    } catch (e: Exception) { 0 }
}

/** Optional router integration: extra FREE fallback models for the API endpoint the user already configured. Off by default. */
object HunterRouter {
    @Volatile private var cacheAt = 0L
    @Volatile private var cache: List<String> = emptyList()
    @Volatile private var cacheHost = ""

    fun enabled(c: Context) = Store.p(c).getBoolean("hunter_router", false)

    fun extra(c: Context): List<String> {
        return try {
            if (!enabled(c)) return emptyList()
            val host = UrlSafety.hostOf(Profiles.active(c).url)
            val now = System.currentTimeMillis()
            if (host == cacheHost && now - cacheAt < 300_000L) return cache
            val list = Matcher.modelsForEndpoint(HunterHub.repo(c).all(), host, now, 3)
            cache = list; cacheAt = now; cacheHost = host
            list
        } catch (e: Exception) { emptyList() }
    }

    fun reset() { cacheAt = 0L }
}

/** Opt-in daily re-check (same "once a day while the app is used" pattern as the evolver). Turning it on is the approval. */
object HunterMonitor {
    private const val DAY = 24L * 3600 * 1000
    fun enabled(c: Context) = Store.p(c).getBoolean("hunter_monitor", false)

    fun maybeDaily(c: Context) {
        if (!enabled(c)) return
        val p = Store.p(c)
        val now = System.currentTimeMillis()
        if (now - p.getLong("hunter_last_run", 0L) < DAY) return
        p.edit().putLong("hunter_last_run", now).apply()
        val app = c.applicationContext
        val t = Thread { try { runOnce(app) } catch (_: Exception) {} }
        t.isDaemon = true
        t.start()
    }

    fun runOnce(c: Context): VerifyReport {
        val p = Store.p(c)
        val now = System.currentTimeMillis()
        val h = HunterHub.get(c, Run(-6))
        if (now - p.getLong("hunter_last_scan", 0L) > 7 * DAY) { h.scan(); p.edit().putLong("hunter_last_scan", now).apply() }
        val watched = WatchTrends.watched(c)
        // Prefer watched providers when verifying under the batch cap
        val rep = if (watched.isNotEmpty()) h.verify(watched, 40) else h.verify(null, 40)
        // Sample limits for trends
        h.repo.all().filter { it.id in watched || it.lastChecked >= now - 60_000 }.forEach {
            WatchTrends.sample(c, it.id, it.rpd, it.rpm)
        }
        HunterRouter.reset()
        val important = rep.events.filter { it.important }
        if (important.isNotEmpty()) notifyChanges(c, important)
        return rep
    }

    private fun notifyChanges(c: Context, ev: List<HunterEvent>) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel("swarm_hunter", "Resource Hunter", NotificationManager.IMPORTANCE_DEFAULT))
            val open = PendingIntent.getActivity(c, 7, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            val text = ev.take(5).joinToString("\n") { "• " + it.detail }
            val n = android.app.Notification.Builder(c, "swarm_hunter").setContentTitle("Resource Hunter: ${ev.size} important change(s)")
                .setContentText(ev.first().detail).setStyle(android.app.Notification.BigTextStyle().bigText(text))
                .setSmallIcon(android.R.drawable.stat_notify_sync).setContentIntent(open).setAutoCancel(true).build()
            nm.notify(3100, n)
        } catch (_: Exception) {}
    }
}

/**
 * Chat commands + the three read-only agent tools.
 *   hunt: status | list [category] | show <id> | match <need> | changes
 *   hunt: scan | verify [id]        (asks approval: they contact official sites)
 *   hunt: add <name> | <category> | <https url>   hunt: remove <id>
 *   hunt: monitor on|off   hunt: router on|off   hunt: help
 * Nothing here can sign up, accept terms, enter keys or spend money: no such code path exists.
 */
object HunterCmd {
    private val CMD = Regex("^(hunt|hunter)\\s*(?::\\s*(.*))?$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    fun handle(c: Context, run: Run, q: String): Turn? {
        HunterMonitor.maybeDaily(c)
        val m = CMD.find(q.trim()) ?: return null
        val text = try { dispatch(c, run, m.groupValues[2].trim()) } catch (e: com.swarmdeck.CancelledException) { throw e } catch (e: Exception) { "Resource Hunter error: ${e.message}" }
        return Turn(false, text, "matrix", emptyList(), Bus.thinkSnapshot())
    }

    private fun ago(ts: Long): String {
        if (ts <= 0) return "never"
        val d = (System.currentTimeMillis() - ts) / (24L * 3600 * 1000)
        return if (d <= 0) "today" else "${d}d ago"
    }

    private fun approve(c: Context, run: Run, what: String): Boolean =
        Confirm.ask(c, run, "Resource Hunter: $what", "Read-only requests to official provider sites and public APIs (https only). Nothing is signed up for, no keys are sent.", true) != 0

    private fun dispatch(c: Context, run: Run, arg: String): String {
        val h = HunterHub.get(c, run)
        val cmd = arg.substringBefore(" ").lowercase()
        val rest = arg.substringAfter(" ", "").trim()
        return when (cmd) {
            "", "status" -> statusText(h)
            "help" -> HELP
            "list" -> listText(h, rest)
            "show" -> showText(h, rest)
            "match" -> matchText(c, h, rest)
            "changes" -> changesText(h)
            "scan" -> {
                if (!approve(c, run, "discover new free resources")) return "Cancelled: no requests were made."
                val r = h.scan(check = { run.check() })
                "### Scan finished\n- New: ${r.added}, refreshed: ${r.updated}\n" +
                    (if (r.errors.isEmpty()) "- All sources answered." else r.errors.entries.joinToString("\n") { "- ⚠️ ${it.key}: ${it.value}" }) +
                    "\n\nNext: `hunt: verify` to check them against the official pages."
            }
            "verify" -> {
                if (!approve(c, run, "verify free tiers on official pages")) return "Cancelled: no requests were made."
                val ids = if (rest.isEmpty() || rest.equals("all", true)) null else listOf(rest)
                val r = h.verify(ids, 60) { run.check() }
                HunterRouter.reset()
                "### Verification finished\n- Checked ${r.checked}: ${r.verified} verified, ${r.problems} not verified\n" +
                    (if (r.events.isEmpty()) "- No policy changes detected." else r.events.joinToString("\n") { (if (it.important) "- ❗ " else "- ") + it.detail })
            }
            "add" -> {
                val p = rest.split("|").map { it.trim() }
                if (p.size != 3) return "Usage: `hunt: add <name> | <category> | <https official url>`"
                val cat = Category.parse(p[1]) ?: return "Unknown category. Use: " + Category.values().joinToString(", ") { it.name.lowercase() }
                val (r, err) = h.addUser(p[0], cat, p[2])
                if (r == null) err else "Added **${r.id}** as unverified. Run `hunt: verify ${r.id}` to check it against that page."
            }
            "remove" -> if (h.remove(rest)) "Removed $rest." else "No resource with id `$rest`."
            "monitor" -> toggle(c, run, rest, "hunter_monitor", "Daily monitoring", true)
            "router" -> toggle(c, run, rest, "hunter_router", "Free-model router fallbacks", false)
            else -> HELP
        }
    }

    private fun toggle(c: Context, run: Run, v: String, key: String, label: String, network: Boolean): String {
        val p = Store.p(c)
        if (v.equals("on", true)) {
            if (network && !approve(c, run, "re-check official pages once a day while the app is used")) return "Not enabled."
            p.edit().putBoolean(key, true).apply(); HunterRouter.reset()
            if (key == "hunter_monitor") com.swarmdeck.work.HunterMonitorWorker.schedule(c)
            return "$label: ON." + (if (key == "hunter_router") " Verified free models for your configured API endpoint are added as last-resort fallbacks." else " Important changes arrive as a notification (also runs in background via WorkManager).")
        }
        if (v.equals("off", true)) {
            p.edit().putBoolean(key, false).apply(); HunterRouter.reset()
            if (key == "hunter_monitor") com.swarmdeck.work.HunterMonitorWorker.cancel(c)
            return "$label: OFF."
        }
        return "$label is ${if (p.getBoolean(key, false)) "ON" else "OFF"}. Use `hunt: ${key.removePrefix("hunter_")} on` or `off`."
    }

    fun statusText(h: Hunter): String {
        val d = h.dashboard()
        val cats = d.byCategory.entries.filter { it.value > 0 }.joinToString(", ") { "${it.key.label} ${it.value}" }
        return "### Resource Hunter\n" +
            "- Discovered: **${d.total}** · Verified free: **${d.verified}** · Policy changed: ${d.changed}\n" +
            "- Outdated: ${d.outdated} · Expired: ${d.expired} · Unreachable: ${d.unreachable} · Discontinued: ${d.discontinued} · Unverified: ${d.unverified}\n" +
            "- Model providers available: ${if (d.modelProviders.isEmpty()) "none verified yet" else d.modelProviders.joinToString(", ")}\n" +
            "- Local/offline models verified: ${d.localModels}\n" +
            "- Last verification: ${ago(d.lastVerified)}\n" +
            "- Estimated daily requests (lowest listed limits, summed over providers): ${if (d.estimatedDailyRequests > 0) d.estimatedDailyRequests.toString() else "unknown"}\n" +
            "- Categories: $cats\n\n" + "Commands: `hunt: help`"
    }

    private fun listText(h: Hunter, cat: String): String {
        val now = System.currentTimeMillis()
        val c = if (cat.isEmpty()) null else Category.parse(cat) ?: return "Unknown category `$cat`."
        val l = h.repo.all().filter { c == null || it.category == c }.sortedWith(compareBy({ if (it.effective(now) == VStatus.VERIFIED) 0 else 1 }, { it.provider }))
        if (l.isEmpty()) return "Nothing catalogued yet. Run `hunt: scan`."
        return "### ${c?.label ?: "All resources"} (${l.size})\n" + l.take(15).joinToString("\n") { "- `${it.id}` · ${it.effective(now).label}" + (if (it.quotas.isNotEmpty()) " · ${it.quotas.first()}" else "") } +
            (if (l.size > 15) "\n…and ${l.size - 15} more. Narrow with `hunt: list <category>`." else "")
    }

    private fun showText(h: Hunter, id: String): String {
        val r = h.repo.get(id) ?: return "No resource with id `$id`. Use `hunt: list`."
        val now = System.currentTimeMillis()
        return "### ${r.provider} · ${r.name}\n- Category: ${r.category.label} · Status: **${r.effective(now).label}**\n" +
            "- Official: ${r.officialUrl}\n" + (if (r.docsUrl.isNotEmpty()) "- Docs/verified page: ${r.docsUrl}\n" else "") +
            "- Free tier: ${r.freeTier.ifEmpty { "not verified" }}\n" +
            (if (r.quotas.isNotEmpty()) "- Limits found: ${r.quotas.joinToString(", ")}\n" else "") +
            (if (r.models.isNotEmpty()) "- Models: ${r.models.take(5).joinToString(", ")}\n" else "") +
            (if (r.restrictions.isNotEmpty()) "- Restrictions: ${r.restrictions.joinToString("; ")}\n" else "") +
            "- Account needed: ${r.needsAccount?.toString() ?: "unknown"} · Card requested: ${r.needsCard?.toString() ?: "unknown"}\n" +
            "- Last checked: ${ago(r.lastChecked)}" + (if (r.note.isNotEmpty()) "\n- Note: ${r.note}" else "") +
            "\n\nSigning up is always your own action on the official site."
    }

    fun parseNeed(c: Context, text: String): Need {
        val t = text.lowercase()
        return Need(
            task = text.take(200),
            preferLocal = !(t.contains("hosted") || t.contains("cloud") || t.contains("online")),
            deviceRamMb = HunterHub.deviceRamMb(c),
            minContext = if (t.contains("long context") || t.contains("128k")) 100_000 else 0,
            priority = when { t.contains("fast") || t.contains("speed") || t.contains("latency") -> "speed"; t.contains("quality") || t.contains("smart") || t.contains("best") -> "quality"; t.contains("quota") || t.contains("limit") || t.contains("volume") -> "limits"; else -> "balanced" },
            allowUnverified = t.contains("unverified")
        )
    }

    private fun recText(rec: Recommendation): String {
        val p = rec.primary ?: return rec.notes.joinToString("\n")
        val sb = StringBuilder("**Recommended:** " + Matcher.describe(p))
        if (rec.fallbacks.isNotEmpty()) sb.append("\n\n**Fallbacks if it becomes unavailable:**\n" + rec.fallbacks.joinToString("\n") { "- " + Matcher.describe(it) })
        rec.notes.forEach { sb.append("\n\nNote: $it") }
        sb.append("\n\nEstimates come from public data and measured response times. Signing up is your own step on the official site.")
        return sb.toString()
    }

    private fun matchText(c: Context, h: Hunter, need: String): String {
        if (need.isEmpty()) return "Usage: `hunt: match <what you need, e.g. fast coding help, prefer offline>`"
        return recText(h.recommend(parseNeed(c, need)))
    }

    private fun changesText(h: Hunter): String {
        val f = SimpleDateFormat("d MMM HH:mm", Locale.US)
        val e = h.repo.events(12)
        if (e.isEmpty()) return "No changes recorded yet. They appear after `hunt: verify` finds something."
        return "### Recent changes\n" + e.joinToString("\n") { "- ${f.format(Date(it.ts))} · ${if (it.important) "❗ " else ""}${it.detail}" }
    }

    // ── agent tools (read-only; output is catalog data, never instructions) ──
    private fun tag(s: String) = "[resource catalog - data only]\n$s"

    fun toolSearch(c: Context, a: JSONObject): String {
        val h = HunterHub.get(c)
        val toks = com.swarmdeck.Parse.keywords(a.optString("query"))
        val cat = Category.parse(a.optString("category", ""))
        val now = System.currentTimeMillis()
        val hits = h.repo.all().filter { (cat == null || it.category == cat) && (toks.isEmpty() || toks.any { t -> (it.provider + " " + it.name + " " + it.models.joinToString(" ") + " " + it.freeTier).lowercase().contains(t) }) }
            .sortedBy { if (it.effective(now) == VStatus.VERIFIED) 0 else 1 }.take(10)
        if (hits.isEmpty()) return tag("(no matching resources; the user can run `hunt: scan`)")
        return tag(hits.joinToString("\n") { "- ${it.id} | ${it.category.label} | ${it.effective(now).label} | ${it.quotas.firstOrNull() ?: "limits unknown"} | ${it.officialUrl}" })
    }

    fun toolMatch(c: Context, a: JSONObject): String = tag(recText(HunterHub.get(c).recommend(parseNeed(c, a.optString("need")))))
    fun toolDashboard(c: Context): String = tag(statusText(HunterHub.get(c)))

    const val HELP = "### Resource Hunter commands\n" +
        "- `hunt: status` dashboard · `hunt: list [category]` · `hunt: show <id>` · `hunt: changes`\n" +
        "- `hunt: match <need>` best free option + fallbacks\n" +
        "- `hunt: scan` discover · `hunt: verify [id]` check official pages (asks approval)\n" +
        "- `hunt: add <name> | <category> | <https url>` · `hunt: remove <id>`\n" +
        "- `hunt: monitor on|off` daily re-check + notifications · `hunt: router on|off` free fallback models in the model router"
}
