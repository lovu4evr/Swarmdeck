package com.swarmdeck.brain

import android.content.Context
import com.swarmdeck.Audit
import com.swarmdeck.Brain
import com.swarmdeck.Bus
import com.swarmdeck.Confirm
import com.swarmdeck.Llm
import com.swarmdeck.Registry
import com.swarmdeck.Run
import com.swarmdeck.Turn

/**
 * Chat entry points for the Phase 1 "brain" features. They are plain text commands so no UI rewrite is needed:
 *   sim: <task>        (or `sim 8: <task>`)  Parallel Reality Simulation, 2-10 approaches, best one wins
 *   factory: <goal>    design + self-test + (with your approval) deploy a new specialist agent
 *   factory: list | factory: remove <name>
 *   evolve: status | now | rollback <agent> | on | off
 */
object SwarmLab {
    private val SIM = Regex("^sim(?:ulate)?\\s*(\\d{1,2})?\\s*:", RegexOption.IGNORE_CASE)

    /** Returns a finished Turn when [q] is a brain command, or null so the normal pipeline continues. */
    fun handle(c: Context, run: Run, q: String, status: (String) -> Unit): Turn? {
        BrainStore.ensureLoaded(c)
        if (com.swarmdeck.billing.Pro.isActive(c)) Evolver.maybeDaily(c)
        val t = q.trim()
        val m = SIM.find(t)
        if (m != null) {
            com.swarmdeck.billing.Pro.gate(c, com.swarmdeck.billing.ProFeature.SWARMLAB)?.let { return it }
            val n = m.groupValues[1].toIntOrNull() ?: 5
            return simulate(c, run, t.substring(m.range.last + 1).trim(), n, status)
        }
        if (t.startsWith("factory:", true)) {
            com.swarmdeck.billing.Pro.gate(c, com.swarmdeck.billing.ProFeature.SWARMLAB)?.let { return it }
            return factory(c, run, t.substringAfter(":"), status)
        }
        if (t.startsWith("evolve", true) && (t.length == 6 || t[6] == ':')) {
            com.swarmdeck.billing.Pro.gate(c, com.swarmdeck.billing.ProFeature.SWARMLAB)?.let { return it }
            return evolve(c, run, t.substring(6).removePrefix(":"), status)
        }
        return null
    }

    private fun reply(text: String, winner: String = "", answers: List<Triple<String, String, Int>> = emptyList()) =
        Turn(false, text, winner, answers, Bus.thinkSnapshot())

    // ───────────────────────── Parallel Reality Simulation ─────────────────────────
    private fun simulate(c: Context, run: Run, task: String, n0: Int, status: (String) -> Unit): Turn {
        if (task.isBlank()) return reply("Usage: `sim: <task>` or `sim 8: <task>` (2-${Simulator.MAX_N} parallel approaches).")
        val n = n0.coerceIn(Simulator.MIN_N, Simulator.MAX_N)
        if (n > 6 && Confirm.ask(c, run, "Run $n parallel approaches", "This makes about ${n + 1} model calls and may cost money.", true) == 0) {
            return reply("Cancelled. Nothing was run.")
        }
        val strategies = Simulator.pick(n)
        Bus.think("Simulating $n parallel realities…")
        status("Simulating $n approaches…")
        Bus.ui { Bus.subAgents = strategies.map { it.label } }
        val res = Simulator.run(
            task, n,
            solve = { s ->
                run.check()
                Bus.think("${s.label} approach running…")
                Llm.chat(c, run, "agent", s.directive + Brain.suf(), task)
            },
            judge = { tk, cands ->
                run.check()
                Bus.think("Judge comparing ${cands.size} results…")
                status("Judging…")
                Llm.chat(c, run, "verify", Simulator.JUDGE_SYS, Simulator.judgeUser(tk, cands))
            }
        )
        run.check()
        val best = res.best ?: return reply("All $n approaches failed. Check your connection or model settings and try again.")
        val answers = res.all.map { Triple(it.label, if (it.id == best.id) it.text else "(discarded)", res.scores[it.id] ?: 0) }
        val sc = res.scores[best.id]
        val foot = "\n\n_Best of ${res.all.size} parallel approaches: **${best.label}**" + (if (sc != null) " ($sc/10)" else "") + ". The others were discarded._"
        Audit.log(c, "sim", "n=$n winner=${best.label}")
        Bus.think("Winner: ${best.label}")
        return reply(best.text.trim() + foot, best.label, answers)
    }

    // ───────────────────────── Agent Factory ─────────────────────────
    private fun factory(c: Context, run: Run, arg: String, status: (String) -> Unit): Turn {
        val a = arg.trim()
        if (a.isEmpty() || a.equals("list", true)) {
            val l = BrainStore.factorySpecs()
            return if (l.isEmpty()) reply("No factory agents yet. Try `factory: an agent that reviews my cover letters`.")
            else reply("### Factory agents\n" + l.joinToString("\n") { "- **${it.name}**: ${it.role} (tools: ${if (it.tools.isEmpty()) "none" else it.tools.joinToString()})" } +
                "\n\nRemove one with `factory: remove <name>`.")
        }
        if (a.startsWith("remove", true)) {
            val name = a.substring(6).trim()
            val id = AgentFactory.idFor(name)
            if (BrainStore.factorySpecs().none { AgentFactory.idFor(it.name) == id }) return reply("No factory agent called \"$name\".")
            BrainStore.removeFactory(c, id)
            Bus.ui { Registry.version++ }
            return reply("Removed $name.")
        }
        if (BrainStore.factorySpecs().size >= AgentFactory.MAX_AGENTS) return reply("Factory is full (${AgentFactory.MAX_AGENTS} agents). Remove one first.")

        Bus.think("Agent Factory: designing…")
        status("Designing agent…")
        val ask: (String, String) -> String = { sys, user -> run.check(); Llm.chat(c, run, "head", sys, user) }
        val act: (String, String) -> String = { sys, user -> run.check(); Llm.chat(c, run, "agent", sys + Brain.suf(), user) }
        val rep = AgentFactory.buildAndTrain(a, ask, act)
            ?: return reply("I couldn't design a valid agent from that. Describe the job more concretely (what it does, for whom, in what format).")
        run.check()
        val pct = (rep.passRate * 100).toInt()
        val toolTxt = if (rep.spec.tools.isEmpty()) "none (text only)" else rep.spec.tools.joinToString()
        val body = "### ${rep.spec.name}\n${rep.spec.role}\n\n**Self-test:** $pct% passed after ${rep.rounds} round(s)\n**Tools:** $toolTxt\n\n" +
            rep.log.joinToString("\n") { "- $it" }
        if (!rep.passed) return reply("$body\n\n❌ Not deployed: it failed its own tests. Rephrase the goal and try again.")
        val id = AgentFactory.idFor(rep.spec.name)
        if (Registry.get(id) != null) return reply("$body\n\nAn agent with this name already exists. Pick a different goal wording.")
        status("Waiting for your approval…")
        val ok = Confirm.ask(c, run, "Deploy new agent: ${rep.spec.name}", "Passed $pct% of its tests. Tools: $toolTxt.", rep.spec.tools.isNotEmpty())
        if (ok == 0) return reply("$body\n\n⏸ Not deployed (you declined).")
        if (!BrainStore.addFactory(c, rep.spec)) return reply("$body\n\nCould not deploy (limit reached or duplicate).")
        Bus.ui { Registry.version++ }
        Bus.think("Deployed ${rep.spec.name}")
        return reply("$body\n\n✅ Deployed. It is now part of your swarm and can be picked automatically.")
    }

    // ───────────────────────── Evolution commands ─────────────────────────
    private fun evolve(c: Context, run: Run, arg: String, status: (String) -> Unit): Turn {
        val a = arg.trim()
        return when {
            a.isEmpty() || a.equals("status", true) -> reply(Evolver.statusText(c))
            a.equals("now", true) -> {
                status("Evolving agents…")
                reply(Evolver.runOnce(c, run, true))
            }
            a.equals("on", true) || a.equals("off", true) -> {
                com.swarmdeck.Store.p(c).edit().putBoolean("evolve_auto", a.equals("on", true)).apply()
                reply("Daily auto-evolution is now ${a.lowercase()}.")
            }
            a.startsWith("rollback", true) -> {
                val name = a.substring(8).trim()
                val target = Registry.all().firstOrNull { it.name.equals(name, true) || it.id.equals(name, true) }
                if (target == null) reply("No agent called \"$name\".")
                else if (BrainStore.rollback(c, target.id)) reply("${target.name} is back on its previous prompt.")
                else reply("${target.name} has nothing to roll back.")
            }
            else -> reply("Usage: `evolve: status`, `evolve: now`, `evolve: rollback <agent>`, `evolve: on|off`")
        }
    }
}
