package com.swarmdeck

import android.annotation.SuppressLint
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

/** Real Python on-device via Pyodide (WebAssembly) inside an isolated WebView. First run downloads ~10 MB and needs internet. */
object PyRunner {
    private const val HTML = "<html><body><script src=\"https://cdn.jsdelivr.net/pyodide/v0.26.4/full/pyodide.js\"></script><script>" +
        "window.runPy=async function(code){try{if(!window.__py){window.__py=await loadPyodide();}var out=[];" +
        "window.__py.setStdout({batched:function(s){out.push(s)}});window.__py.setStderr({batched:function(s){out.push(s)}});" +
        "var r=await window.__py.runPythonAsync(code);if(r!==undefined&&r!==null){out.push(String(r))}return out.join('\\n');}catch(e){return 'Error: '+e.message;}};" +
        "</script></body></html>"

    @SuppressLint("SetJavaScriptEnabled", "JavascriptInterface")
    fun run(c: Context, code: String): String {
        val main = Handler(Looper.getMainLooper())
        val f = CompletableFuture<String>()
        var holder: WebView? = null
        main.post {
            try {
                val w = WebView(c.applicationContext)
                holder = w
                w.settings.javaScriptEnabled = true
                w.settings.domStorageEnabled = true
                w.settings.allowFileAccess = false
                w.settings.allowContentAccess = false
                w.addJavascriptInterface(object { @JavascriptInterface fun done(s: String) { f.complete(s) } }, "Android")
                w.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(v: WebView, url: String?) {
                        v.evaluateJavascript("window.runPy(" + JSONObject.quote(code) + ").then(function(r){Android.done(String(r))})", null)
                    }
                }
                w.loadDataWithBaseURL("https://cdn.jsdelivr.net/", HTML, "text/html", "utf-8", null)
            } catch (e: Throwable) {
                f.complete("Error: ${e.message}")
            }
        }
        val r = try { f.get(90, TimeUnit.SECONDS) } catch (e: Exception) { "Timed out (the first Python run downloads ~10 MB - check internet and try again)" }
        main.post { try { holder?.destroy() } catch (_: Exception) {} }
        return r.ifEmpty { "(no output)" }.take(6000)
    }
}
