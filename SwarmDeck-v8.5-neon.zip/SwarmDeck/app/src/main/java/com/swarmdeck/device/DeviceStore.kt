package com.swarmdeck.device

import android.content.Context
import com.swarmdeck.Store
import com.swarmdeck.Vault

/** Paired computers. The derived key is stored encrypted; the pairing code itself is never stored. */
object DeviceStore {
    private const val K = "devices_enc"
    const val MAX = 8

    fun list(c: Context): List<PairedDevice> = DevicesJson.fromJson(Vault.dec(Store.p(c).getString(K, "") ?: ""))

    fun any(c: Context): Boolean = list(c).isNotEmpty()

    fun find(c: Context, name: String): PairedDevice? = list(c).firstOrNull { it.name.equals(name.trim(), true) }

    private fun save(c: Context, l: List<PairedDevice>) {
        Store.p(c).edit().putString(K, Vault.enc(DevicesJson.toJson(l))).apply()
    }

    @Synchronized
    fun add(c: Context, d: PairedDevice): Boolean {
        val l = list(c)
        if (l.size >= MAX || l.any { it.name.equals(d.name, true) }) return false
        save(c, l + d)
        return true
    }

    @Synchronized
    fun remove(c: Context, name: String): Boolean {
        val l = list(c)
        val keep = l.filter { !it.name.equals(name.trim(), true) }
        if (keep.size == l.size) return false
        save(c, keep)
        return true
    }
}
