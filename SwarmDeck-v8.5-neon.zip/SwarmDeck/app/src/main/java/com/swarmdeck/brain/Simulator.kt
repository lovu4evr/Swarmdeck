package com.swarmdeck.brain

import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

data class Strategy(val label: String, val directive: String)
data class Candidate(val id: Int, val label: String, val text: String, val error: Boolean)
data class SimResult(val best: Candidate?, val scores: Map<Int, Int>, val all: List<Candidate>)

/**
 * Parallel Reality Simulation: run N different approaches to the same task at once,
 * let a judge score them, keep the best, discard the rest. Pure JVM (solve/judge are injected).
 */
object Simulator {
    val STRATEGIES: List<Strategy> = listOf(
        Strategy("Direct", "Take the most direct, minimal approach that fully solves the task."),
        Strategy("Rigorous", "Be rigorous: state assumptions, work step by step and verify each claim."),
        Strategy("Contrarian", "Challenge the obvious approach and develop the strongest unconventional alternative."),
        Strategy("Risk-first", "Start from what could go wrong (failure modes, edge cases, reversibility), then solve it safely."),
        Strategy("Outcome-first", "Optimize for what the user will actually do next with the answer; be concrete and actionable."),
        Strategy("Frugal", "Find the cheapest, fastest path and cut everything that is not essential."),
        Strategy("First-principles", "Rebuild the solution from first principles instead of reusing standard patterns."),
        Strategy("Prior-art", "Reuse proven, well-known patterns and best practices, and say why they fit."),
        Strategy("Red-team", "Draft a solution, attack it as a skeptic, then return the hardened final version."),
        Strategy("Teacher", "Solve it and explain the key reasoning so the user can verify and learn.")
    )

    const val MIN_N = 2
    val MAX_N: Int get() = STRATEGIES.size

    val JUDGE_SYS =
        "You are an impartial judge. You get a TASK and several candidate answers produced by different approaches. " +
            "Score each 0-10 for correctness, usefulness and safety. Reply with exactly two lines:\n" +
            "SCORES: id=score, id=score\nWINNER: id"

    fun pick(n: Int): List<Strategy> = STRATEGIES.take(n.coerceIn(MIN_N, MAX_N))

    fun judgeUser(task: String, cands: List<Candidate>): String =
        "TASK:\n${task.take(2000)}\n\n" + cands.joinToString("\n\n") { "[${it.id}] (${it.label})\n${it.text.take(2500)}" }

    /** Parses "SCORES: 1=8, 2=5" and "WINNER: 1". Falls back to the highest score if the winner line is missing or invalid. */
    fun parseJudge(out: String, ids: Collection<Int>): Pair<Map<Int, Int>, Int?> {
        val scoreLine = out.lines().firstOrNull { it.trim().startsWith("SCORES", true) }
        val src = if (scoreLine != null) scoreLine.substringAfter(":", scoreLine) else out
        val scores = LinkedHashMap<Int, Int>()
        Regex("(\\d+)\\s*[=:]\\s*(\\d{1,2})").findAll(src).forEach { m ->
            val id = m.groupValues[1].toIntOrNull()
            val sc = m.groupValues[2].toIntOrNull()
            if (id != null && sc != null && id in ids) scores[id] = sc.coerceIn(0, 10)
        }
        val w = Regex("WINNER\\s*[=:]?\\s*#?(\\d+)", RegexOption.IGNORE_CASE).find(out)?.groupValues?.get(1)?.toIntOrNull()
        val winner = if (w != null && w in ids) w else scores.maxByOrNull { it.value }?.key
        return scores to winner
    }

    fun run(
        task: String,
        n: Int,
        solve: (Strategy) -> String,
        judge: (String, List<Candidate>) -> String,
        parallel: Int = 4,
        timeoutSec: Long = 170
    ): SimResult {
        val strategies = pick(n)
        val pool = Executors.newFixedThreadPool(parallel.coerceIn(1, 8))
        val cands = try {
            val jobs = strategies.mapIndexed { i, s -> Triple(i + 1, s, pool.submit(Callable<String> { solve(s) })) }
            val deadline = System.currentTimeMillis() + timeoutSec * 1000
            jobs.map { (id, s, f) ->
                val left = (deadline - System.currentTimeMillis()).coerceAtLeast(1000L)
                val r = try {
                    f.get(left, TimeUnit.MILLISECONDS)
                } catch (e: Exception) {
                    f.cancel(true)
                    "ERR:" + (e.message ?: e.javaClass.simpleName)
                }
                Candidate(id, s.label, r, r.startsWith("ERR:") || r.isBlank())
            }
        } finally {
            pool.shutdownNow()
        }
        val ok = cands.filter { !it.error }
        if (ok.isEmpty()) return SimResult(null, emptyMap(), cands)
        if (ok.size == 1) return SimResult(ok[0], mapOf(ok[0].id to 5), cands)
        val out = try { judge(task, ok) } catch (e: Exception) { "" }
        val (scores, win) = parseJudge(out, ok.map { it.id })
        val best = ok.firstOrNull { it.id == win } ?: ok[0]
        return SimResult(best, scores, cands)
    }
}
