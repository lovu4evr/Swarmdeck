package com.swarmdeck.work

import android.content.Context
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.swarmdeck.hunter.HunterMonitor
import java.util.concurrent.TimeUnit

/**
 * Foundation background work: runs Hunter verify (and optional light scan) when the app is closed.
 * Constraints: unmetered network preferred, not on low battery.
 */
class HunterMonitorWorker(
    appContext: Context,
    params: WorkerParameters
) : CoroutineWorker(appContext, params) {

    override suspend fun doWork(): Result {
        return try {
            // Re-use existing monitor path (verify + occasional scan). Runs only when constraints allow.
            if (HunterMonitor.enabled(applicationContext)) {
                HunterMonitor.runOnce(applicationContext)
            }
            Result.success()
        } catch (e: Exception) {
            com.swarmdeck.util.CrashLog.record(applicationContext, "HunterMonitorWorker", e)
            Result.retry()
        }
    }

    companion object {
        const val UNIQUE_NAME = "hunter_monitor_periodic"

        fun schedule(context: Context, intervalHours: Long = 12) {
            val constraints = Constraints.Builder()
                .setRequiredNetworkType(NetworkType.UNMETERED) // Wi-Fi only preference
                .setRequiresBatteryNotLow(true)
                .build()

            val request = PeriodicWorkRequestBuilder<HunterMonitorWorker>(
                intervalHours, TimeUnit.HOURS
            )
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context.applicationContext).enqueueUniquePeriodicWork(
                UNIQUE_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
        }

        fun cancel(context: Context) {
            WorkManager.getInstance(context.applicationContext).cancelUniqueWork(UNIQUE_NAME)
        }
    }
}
