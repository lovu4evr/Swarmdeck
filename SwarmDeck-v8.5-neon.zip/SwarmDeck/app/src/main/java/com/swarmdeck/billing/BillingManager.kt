package com.swarmdeck.billing

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.android.billingclient.api.AcknowledgePurchaseParams
import com.android.billingclient.api.BillingClient
import com.android.billingclient.api.BillingClientStateListener
import com.android.billingclient.api.BillingFlowParams
import com.android.billingclient.api.BillingResult
import com.android.billingclient.api.PendingPurchasesParams
import com.android.billingclient.api.ProductDetails
import com.android.billingclient.api.Purchase
import com.android.billingclient.api.PurchasesUpdatedListener
import com.android.billingclient.api.QueryProductDetailsParams
import com.android.billingclient.api.QueryPurchasesParams
import com.android.billingclient.api.acknowledgePurchase
import com.android.billingclient.api.queryProductDetails
import com.android.billingclient.api.queryPurchasesAsync
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlin.coroutines.resume

data class ProPlan(val basePlanId: String, val price: String, val period: String, val offerToken: String, val trial: String?)

/** Thin wrapper around Google Play Billing (subscriptions). Real purchases only work for installs from Google Play. */
object BillingManager : PurchasesUpdatedListener {
    private var appCtx: Context? = null
    private var client: BillingClient? = null
    private var details: ProductDetails? = null
    private val connectLock = Mutex()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)

    var plans by mutableStateOf<List<ProPlan>>(emptyList())
        private set
    var status by mutableStateOf("")
        private set
    var loading by mutableStateOf(false)
        private set

    fun init(c: Context) {
        if (client != null) return
        val ctx = c.applicationContext
        appCtx = ctx
        client = BillingClient.newBuilder(ctx)
            .setListener(this)
            .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
            .build()
        scope.launch { loadProducts(); refresh() }
    }

    private suspend fun awaitReady(): Boolean = connectLock.withLock {
        val cl = client ?: return@withLock false
        if (cl.isReady) return@withLock true
        suspendCancellableCoroutine<Boolean> { cont ->
            cl.startConnection(object : BillingClientStateListener {
                override fun onBillingSetupFinished(r: BillingResult) {
                    if (r.responseCode != BillingClient.BillingResponseCode.OK) status = friendly(r)
                    if (cont.isActive) cont.resume(r.responseCode == BillingClient.BillingResponseCode.OK)
                }
                override fun onBillingServiceDisconnected() { if (cont.isActive) cont.resume(false) }
            })
        }
    }

    suspend fun loadProducts() {
        loading = true
        try {
            val cl = client ?: return
            if (!awaitReady()) return
            val product = QueryProductDetailsParams.Product.newBuilder()
                .setProductId(Pro.PRODUCT_ID).setProductType(BillingClient.ProductType.SUBS).build()
            val res = cl.queryProductDetails(QueryProductDetailsParams.newBuilder().setProductList(listOf(product)).build())
            if (res.billingResult.responseCode != BillingClient.BillingResponseCode.OK) { status = friendly(res.billingResult); return }
            val pd = res.productDetailsList?.firstOrNull()
            details = pd
            plans = buildPlans(pd)
            status = if (pd == null) "Subscription '${Pro.PRODUCT_ID}' was not found. Create it in Play Console and install the app from Google Play." else ""
        } finally { loading = false }
    }

    private fun buildPlans(pd: ProductDetails?): List<ProPlan> =
        pd?.subscriptionOfferDetails.orEmpty().groupBy { it.basePlanId }.mapNotNull { (base, offers) ->
            // Prefer the offer with the most pricing phases (free trial / intro price), Play only returns offers the user can get.
            val o = offers.maxByOrNull { it.pricingPhases.pricingPhaseList.size } ?: return@mapNotNull null
            val phases = o.pricingPhases.pricingPhaseList
            val rec = phases.lastOrNull() ?: return@mapNotNull null
            val trial = phases.firstOrNull { it.priceAmountMicros == 0L }?.let { ProLogic.periodLabel(it.billingPeriod) }
            ProPlan(base, rec.formattedPrice, ProLogic.periodLabel(rec.billingPeriod), o.offerToken, trial)
        }.sortedBy { if (it.basePlanId == Pro.PLAN_MONTHLY) 0 else 1 }

    fun buy(act: Activity, plan: ProPlan) {
        val pd = details
        val cl = client
        if (pd == null || cl == null) { status = "Plans are not loaded yet. Check your connection and tap Retry."; return }
        val p = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(pd).setOfferToken(plan.offerToken).build()
        val r = cl.launchBillingFlow(act, BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(p)).build())
        if (r.responseCode != BillingClient.BillingResponseCode.OK) status = friendly(r)
    }

    override fun onPurchasesUpdated(r: BillingResult, list: MutableList<Purchase>?) {
        when (r.responseCode) {
            BillingClient.BillingResponseCode.OK -> scope.launch { handle(list.orEmpty(), authoritative = false) }
            BillingClient.BillingResponseCode.USER_CANCELED -> status = "Purchase cancelled."
            BillingClient.BillingResponseCode.ITEM_ALREADY_OWNED -> scope.launch { refresh() }
            else -> status = friendly(r)
        }
    }

    /** Authoritative check against Google Play. Grants, keeps or revokes Pro. */
    suspend fun refresh() {
        val cl = client ?: return
        if (!awaitReady()) return                       // offline/unavailable: keep the cached state (grace period)
        val res = cl.queryPurchasesAsync(QueryPurchasesParams.newBuilder().setProductType(BillingClient.ProductType.SUBS).build())
        if (res.billingResult.responseCode != BillingClient.BillingResponseCode.OK) { status = friendly(res.billingResult); return }
        handle(res.purchasesList, authoritative = true)
    }

    fun refreshAsync() { scope.launch { refresh() } }

    fun restore() { status = "Checking Google Play…"; scope.launch { refresh(); if (status == "Checking Google Play…") status = if (Pro.active) "Pro restored." else "No active subscription found (or Google Play could not be reached)." } }

    private suspend fun handle(list: List<Purchase>, authoritative: Boolean) {
        val ctx = appCtx ?: return
        val cl = client ?: return
        var entitled = false
        var pending = false
        for (p in list) {
            if (Pro.PRODUCT_ID !in p.products) continue
            when (p.purchaseState) {
                Purchase.PurchaseState.PURCHASED -> {
                    entitled = true
                    if (!p.isAcknowledged) {
                        // Unacknowledged purchases are refunded by Google after 3 days. A failure here is retried on the next refresh.
                        try { cl.acknowledgePurchase(AcknowledgePurchaseParams.newBuilder().setPurchaseToken(p.purchaseToken).build()) } catch (_: Exception) {}
                    }
                }
                Purchase.PurchaseState.PENDING -> pending = true
                else -> {}
            }
        }
        if (entitled) { Pro.record(ctx, true); status = "SwarmDeck Pro is active. Thank you!" }
        else if (authoritative) { Pro.record(ctx, false); if (pending) status = "Payment is pending. Pro unlocks when it completes." }
        else if (pending) status = "Payment is pending. Pro unlocks when it completes."
    }

    fun manageSubscription(c: Context) {
        val u = Uri.parse("https://play.google.com/store/account/subscriptions?sku=${Pro.PRODUCT_ID}&package=${c.packageName}")
        c.startActivity(Intent(Intent.ACTION_VIEW, u).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun friendly(r: BillingResult): String = when (r.responseCode) {
        BillingClient.BillingResponseCode.BILLING_UNAVAILABLE ->
            "Google Play Billing is not available. Purchases only work when the app is installed from Google Play (internal testing works), not from a sideloaded APK."
        BillingClient.BillingResponseCode.ITEM_UNAVAILABLE ->
            "This subscription is not available yet. In Play Console, activate '${Pro.PRODUCT_ID}' and install a build uploaded to a Play testing track."
        BillingClient.BillingResponseCode.DEVELOPER_ERROR ->
            "Billing configuration error. The app id, signing key and subscription id must match Play Console."
        BillingClient.BillingResponseCode.SERVICE_UNAVAILABLE, BillingClient.BillingResponseCode.SERVICE_DISCONNECTED ->
            "Google Play is not reachable right now. Check your connection and try again."
        BillingClient.BillingResponseCode.FEATURE_NOT_SUPPORTED -> "Subscriptions are not supported on this device."
        else -> "Billing error (${r.responseCode}). ${r.debugMessage}".trim()
    }
}
