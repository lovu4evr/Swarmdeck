package com.swarmdeck.hunter

import android.content.Context
import com.swarmdeck.Db
import org.json.JSONObject

/** Persistence boundary. [SqliteRepo] is the real database; [MemoryRepo] has identical behaviour for tests. */
interface ResourceRepo {
    fun all(): List<Resource>
    fun get(id: String): Resource?
    fun put(r: Resource)
    fun delete(id: String): Boolean
    fun addEvent(e: HunterEvent)
    fun events(limit: Int): List<HunterEvent>
}

class MemoryRepo : ResourceRepo {
    private val map = LinkedHashMap<String, Resource>()
    private val ev = ArrayList<HunterEvent>()

    @Synchronized override fun all(): List<Resource> = map.values.toList()
    @Synchronized override fun get(id: String): Resource? = map[id]
    @Synchronized override fun put(r: Resource) { map[r.id] = r }
    @Synchronized override fun delete(id: String): Boolean = map.remove(id) != null
    @Synchronized override fun addEvent(e: HunterEvent) { ev.add(e); while (ev.size > MAX_EVENTS) ev.removeAt(0) }
    @Synchronized override fun events(limit: Int): List<HunterEvent> = ev.takeLast(limit).reversed()

    companion object { const val MAX_EVENTS = 500 }
}

/** Resources live in the app's existing SQLite database (`swarm.db`, see [Db]): one row per resource, JSON body, indexed columns for filtering. */
class SqliteRepo(private val c: Context) : ResourceRepo {
    private fun db() = Db.get(c).writableDatabase

    init { ensureTables(c) }

    @Synchronized override fun all(): List<Resource> {
        val out = ArrayList<Resource>()
        db().rawQuery("SELECT body FROM resources ORDER BY provider, id", null).use { cur ->
            while (cur.moveToNext()) {
                try { out.add(Resource.fromJson(JSONObject(cur.getString(0) ?: ""))) } catch (_: Exception) { /* skip a corrupt row */ }
            }
        }
        return out
    }

    @Synchronized override fun get(id: String): Resource? {
        db().rawQuery("SELECT body FROM resources WHERE id=?", arrayOf(id)).use { cur ->
            if (!cur.moveToFirst()) return null
            return try { Resource.fromJson(JSONObject(cur.getString(0) ?: "")) } catch (_: Exception) { null }
        }
    }

    @Synchronized override fun put(r: Resource) {
        db().execSQL(
            "INSERT OR REPLACE INTO resources(id,provider,category,status,last_checked,body) VALUES(?,?,?,?,?,?)",
            arrayOf<Any?>(r.id, r.provider, r.category.name, r.status.name, r.lastChecked, r.toJson().toString())
        )
    }

    @Synchronized override fun delete(id: String): Boolean {
        val had = get(id) != null
        db().execSQL("DELETE FROM resources WHERE id=?", arrayOf<Any?>(id))
        return had
    }

    @Synchronized override fun addEvent(e: HunterEvent) {
        val d = db()
        d.execSQL("INSERT INTO resource_events(ts,rid,kind,detail,important) VALUES(?,?,?,?,?)", arrayOf<Any?>(e.ts, e.rid, e.kind, e.detail, if (e.important) 1 else 0))
        d.execSQL("DELETE FROM resource_events WHERE id NOT IN (SELECT id FROM resource_events ORDER BY id DESC LIMIT ${MemoryRepo.MAX_EVENTS})")
    }

    @Synchronized override fun events(limit: Int): List<HunterEvent> {
        val out = ArrayList<HunterEvent>()
        db().rawQuery("SELECT ts,rid,kind,detail,important FROM resource_events ORDER BY id DESC LIMIT ?", arrayOf(limit.toString())).use { cur ->
            while (cur.moveToNext()) out.add(HunterEvent(cur.getLong(0), cur.getString(1) ?: "", cur.getString(2) ?: "", cur.getString(3) ?: "", cur.getInt(4) == 1))
        }
        return out
    }

    companion object {
        /** Also called by [Db] so the tables exist on fresh installs and after upgrades. */
        fun ensureTables(c: Context) {
            val d = Db.get(c).writableDatabase
            d.execSQL(CREATE_RESOURCES)
            d.execSQL(CREATE_EVENTS)
        }

        const val CREATE_RESOURCES = "CREATE TABLE IF NOT EXISTS resources(id TEXT PRIMARY KEY, provider TEXT, category TEXT, status TEXT, last_checked INTEGER, body TEXT)"
        const val CREATE_EVENTS = "CREATE TABLE IF NOT EXISTS resource_events(id INTEGER PRIMARY KEY AUTOINCREMENT, ts INTEGER, rid TEXT, kind TEXT, detail TEXT, important INTEGER)"
    }
}

/** How a freshly discovered record is combined with what is already stored. Discovery never erases verification work. */
object Merge {
    fun merge(old: Resource?, incoming: Resource): Resource {
        if (old == null) return incoming
        val fromApi = incoming.source != "seed" && incoming.status == VStatus.VERIFIED
        val base = old.copy(
            provider = old.provider.ifBlank { incoming.provider },
            officialUrl = if (old.source == "user") old.officialUrl else incoming.officialUrl.ifBlank { old.officialUrl },
            docsUrl = old.docsUrl.ifBlank { incoming.docsUrl },
            signupUrl = old.signupUrl.ifBlank { incoming.signupUrl },
            apiBase = old.apiBase.ifBlank { incoming.apiBase },
            models = (old.models + incoming.models).distinct(),
            restrictions = (old.restrictions + incoming.restrictions).distinct(),
            contextLen = if (incoming.contextLen > 0) incoming.contextLen else old.contextLen,
            quality = if (incoming.quality > 0.0) incoming.quality else old.quality,
            needsAccount = incoming.needsAccount ?: old.needsAccount,
            local = old.local || incoming.local,
            firstSeen = if (old.firstSeen > 0) old.firstSeen else incoming.firstSeen
        )
        return if (fromApi) base.copy(
            status = VStatus.VERIFIED, failCount = 0, lastChecked = incoming.lastChecked, lastVerified = incoming.lastVerified,
            evidence = incoming.evidence, freeTier = incoming.freeTier.ifBlank { old.freeTier }, note = ""
        ) else base
    }
}

data class Dashboard(
    val total: Int,
    val verified: Int,
    val changed: Int,
    val outdated: Int,
    val expired: Int,
    val unreachable: Int,
    val discontinued: Int,
    val unverified: Int,
    val modelProviders: List<String>,
    val byCategory: Map<Category, Int>,
    val lastVerified: Long,
    val limits: List<String>,
    val estimatedDailyRequests: Long,
    val localModels: Int
)

object DashboardCalc {
    fun compute(all: List<Resource>, now: Long): Dashboard {
        val eff = all.map { it to it.effective(now) }
        fun n(s: VStatus) = eff.count { it.second == s }
        val usable = eff.filter { it.second == VStatus.VERIFIED || it.second == VStatus.CHANGED }.map { it.first }
        val providers = usable.filter { it.category.isModelSource && !it.local }.map { it.provider }.distinct().sorted()
        val limits = usable.filter { it.quotas.isNotEmpty() }
            .sortedBy { it.provider }
            .take(8)
            .map { "${it.provider}: ${it.quotas.first()}" }
        // Provider-level limits only (items that carry the quota themselves), lowest figure found = conservative estimate.
        val daily = usable.filter { it.rpd > 0 && it.category.isModelSource }.groupBy { it.provider }.values.sumOf { g -> g.minOf { it.rpd }.toLong() }
        return Dashboard(
            total = all.size,
            verified = n(VStatus.VERIFIED),
            changed = n(VStatus.CHANGED),
            outdated = n(VStatus.OUTDATED),
            expired = n(VStatus.EXPIRED),
            unreachable = n(VStatus.UNREACHABLE),
            discontinued = n(VStatus.DISCONTINUED),
            unverified = n(VStatus.UNVERIFIED),
            modelProviders = providers,
            byCategory = Category.values().associate { c -> c to all.count { it.category == c } },
            lastVerified = all.maxOfOrNull { it.lastVerified } ?: 0L,
            limits = limits,
            estimatedDailyRequests = daily,
            localModels = all.count { it.local && it.category == Category.LOCAL_MODEL && it.effective(now) == VStatus.VERIFIED }
        )
    }
}
