package com.swarmdeck.device

import android.content.Context
import android.util.Base64
import com.swarmdeck.Audit
import com.swarmdeck.Bus
import com.swarmdeck.Run
import com.swarmdeck.Turn
import org.json.JSONObject

/**
 * Chat commands (the Devices screen uses the same functions):
 *   device | device: list
 *   device: pair <name> <host:port> <code>
 *   device: ping <name> | device: remove <name> | device: stop [name]
 * `desk: <task>` sends a task to the Desk Operator agent.
 */
object DeviceCmd {
    private val CMD = Regex("^devices?\\s*(?::\\s*(.*))?$", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

    fun handle(c: Context, run: Run, q: String): Turn? {
        val m = CMD.find(q.trim()) ?: return null
        com.swarmdeck.billing.Pro.gate(c, com.swarmdeck.billing.ProFeature.DEVICES)?.let { return it }
        val arg = m.groupValues[1].trim()
        val low = arg.lowercase()
        val text = when {
            arg.isEmpty() || low == "list" -> listText(c)
            low.startsWith("pair ") -> {
                val p = arg.substring(5).trim().split(Regex("\\s+"))
                if (p.size != 3) "Usage: `device: pair <name> <host:port> <code>`  (pairing from the Devices screen keeps the code out of your chat history)"
                else pair(c, p[0], p[1], p[2])
            }
            low.startsWith("ping ") -> pingByName(c, arg.substring(5))
            low.startsWith("remove ") -> if (DeviceStore.remove(c, arg.substring(7))) "Removed." else "No such device."
            low == "stop" || low.startsWith("stop ") -> stopText(c, arg.substring(4).trim())
            else -> "Usage: `device: list`, `device: pair <name> <host:port> <code>`, `device: ping <name>`, `device: stop [name]`, `device: remove <name>`"
        }
        return Turn(false, text, "", emptyList(), Bus.thinkSnapshot())
    }

    fun listText(c: Context): String {
        val l = DeviceStore.list(c)
        if (l.isEmpty()) return "No computers paired yet. Run companion/swarmdeck_companion.py on your laptop, then open **Devices** in the menu to pair it."
        return "### Devices\n" + l.joinToString("\n") { "- **${it.name}** (${it.os}) ${it.host}:${it.port}" } +
            "\n\nGive a task with `desk: <what to do>`. Every action asks you first."
    }

    fun pingText(d: PairedDevice): String {
        val r = DeviceClient.call(d, "ping", JSONObject(), 6000)
        if (!r.ok) return "offline: " + r.error
        return if (r.data?.optBoolean("paused") == true) "online, PAUSED (type resume on the computer)" else "online"
    }

    private fun pingByName(c: Context, name: String): String {
        val d = DeviceStore.find(c, name) ?: return "No device called \"${name.trim()}\"."
        return "${d.name}: " + pingText(d)
    }

    /** Pauses the companion(s) until the user types `resume` on the computer. */
    fun stopText(c: Context, name: String): String {
        val targets = if (name.isBlank()) DeviceStore.list(c) else listOfNotNull(DeviceStore.find(c, name))
        if (targets.isEmpty()) return "Nothing to stop."
        return targets.joinToString("\n") {
            val r = DeviceClient.halt(it)
            if (r.ok) "${it.name}: paused. Type `resume` in its companion window to continue." else "${it.name}: ${r.error}"
        }
    }

    /** Called from the global kill switch; never blocks the caller. */
    fun haltAllAsync() {
        val c = Bus.app ?: return
        try {
            if (!DeviceStore.any(c)) return
        } catch (_: Exception) {
            return
        }
        val t = Thread {
            try {
                for (d in DeviceStore.list(c)) DeviceClient.halt(d)
            } catch (_: Exception) {
            }
        }
        t.isDaemon = true
        t.start()
    }

    fun pair(c: Context, nameRaw: String, endpoint: String, codeRaw: String): String {
        val name = nameRaw.trim()
        if (!Regex("[A-Za-z0-9 _-]{2,20}").matches(name)) return "The name must be 2-20 letters, digits, spaces, - or _."
        val ep = DeviceRules.parseEndpoint(endpoint) ?: return "Enter the address as host:port, for example 192.168.1.5:8765."
        val host = ep.first
        val port = ep.second
        if (!DeviceRules.isPrivateHost(host)) {
            return "Only addresses on your own network are allowed (192.168.x.x, 10.x.x.x, 172.16-31.x.x, 100.x Tailscale, *.local)."
        }
        if (DeviceStore.find(c, name) != null) return "A device called $name already exists."
        if (DeviceStore.list(c).size >= DeviceStore.MAX) return "You can pair up to ${DeviceStore.MAX} computers. Remove one first."
        val code = DeviceCrypto.normalizeCode(codeRaw)
        if (code.length != 8) return "The pairing code has 8 characters (shown in the companion window)."

        val info = try {
            DeviceClient.info(host, port)
        } catch (e: Exception) {
            return "Cannot reach $host:$port (${e.message}). Is the companion running, and are both devices on the same network?"
        }
        val salt = try {
            Base64.decode(info.getString("salt"), Base64.DEFAULT)
        } catch (_: Exception) {
            return "That device did not answer like a SwarmDeck companion."
        }
        if (info.optBoolean("paired")) return "That computer is already paired with a phone. Restart its companion with --pair to show a new code."

        val key = DeviceCrypto.deriveKey(code, salt)
        val dev = PairedDevice(name, host, port, DeviceCrypto.hex(key), info.optString("os", "?").take(20), System.currentTimeMillis())
        val r = DeviceClient.call(dev, "ping", JSONObject(), 8000)
        if (!r.ok) return "Pairing failed: ${r.error}. Check the code (it expires after 10 minutes) or restart the companion with --pair."
        if (!DeviceStore.add(c, dev)) return "Could not save the device."
        Audit.log(c, "device", "paired $name")
        val gui = if (info.optBoolean("gui")) "" else "\nNote: install `pip install pyautogui pillow` on the computer for screenshots, mouse and keyboard."
        return "Paired with $name (${dev.os}).$gui\nTry: `desk: open notepad and type hello`. Every action asks you first."
    }
}
