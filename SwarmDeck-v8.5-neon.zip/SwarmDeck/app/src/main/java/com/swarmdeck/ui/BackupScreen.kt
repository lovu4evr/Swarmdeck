package com.swarmdeck.ui

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.*
import com.swarmdeck.backup.Backup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BackupScreen(act: Activity, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var status by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("Backup & restore", color = GOLD, fontSize = 22.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
        Text(
            "Creates a local ZIP of preferences (Vault-encrypted strings) and swarm.db. " +
                "Keep the file private. Cloud upload is not included.",
            color = MUTED, fontSize = 12.sp
        )
        Button(
            onClick = {
                if (busy) return@Button
                busy = true
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        val f = Backup.defaultExportFile(act)
                        Backup.export(act, f)
                    }
                    status = r.fold({ "Exported: ${it.absolutePath}" }, { "Export failed: ${it.message}" })
                    busy = false
                    Toast.makeText(act, status.take(80), Toast.LENGTH_LONG).show()
                }
            },
            enabled = !busy
        ) { Text(if (busy) "Working…" else "Export backup") }

        Text(
            "Restore replaces current prefs and database from the newest swarmdeck-backup-*.zip in app external files.",
            color = MUTED, fontSize = 12.sp
        )
        Button(
            onClick = {
                if (busy) return@Button
                busy = true
                scope.launch {
                    val r = withContext(Dispatchers.IO) {
                        val dir = act.getExternalFilesDir(null) ?: act.filesDir
                        val f = dir.listFiles()?.filter { it.name.startsWith("swarmdeck-backup-") && it.extension == "zip" }
                            ?.maxByOrNull { it.lastModified() }
                        if (f == null) Result.failure(IllegalStateException("No backup file found"))
                        else Backup.import(act, f)
                    }
                    status = r.fold({ it }, { "Import failed: ${it.message}" })
                    busy = false
                    Toast.makeText(act, status.take(80), Toast.LENGTH_LONG).show()
                }
            },
            enabled = !busy
        ) { Text("Restore latest backup") }

        if (status.isNotEmpty()) Text(status, color = CREAM, fontSize = 12.sp)
        TextButton(onClick = onBack) { Text("Back", color = GOLD) }
    }
}
