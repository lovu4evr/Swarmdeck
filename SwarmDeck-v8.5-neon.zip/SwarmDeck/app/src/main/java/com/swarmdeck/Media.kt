package com.swarmdeck

import android.content.ContentValues
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.URLEncoder
import java.security.SecureRandom
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import javax.crypto.Cipher
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec
import javax.crypto.spec.SecretKeySpec

val MEDIA_TOOLS = setOf("generate_image", "generate_video", "generate_audio")

object MediaCfg {
    fun dir(c: Context): File = File(c.filesDir, "media").apply { mkdirs() }
    fun base(c: Context): String {
        val b = (Store.p(c).getString("media_base", "") ?: "").trim()
        return if (b.isNotEmpty()) b.trimEnd('/') else Profiles.active(c).url.trim().trimEnd('/')
    }
    fun key(c: Context): String {
        val k = Vault.dec(Store.p(c).getString("media_key_enc", "") ?: "")
        return if (k.isNotEmpty()) k else Profiles.active(c).key
    }
    fun repKey(c: Context): String = Vault.dec(Store.p(c).getString("replicate_key_enc", "") ?: "")
}

object Net {
    private val BLOCKED = setOf("localhost", "0.0.0.0", "metadata.google.internal", "metadata")

    fun hostBlocked(host: String): Boolean {
        val h = host.lowercase().trim('.')
        if (h in BLOCKED || h.endsWith(".local") || h.endsWith(".internal") || h.endsWith(".localhost") || h.startsWith("127.")) return true
        val p = h.split(".")
        if (p.size == 4 && p.all { it.toIntOrNull() != null }) {
            val a = p[0].toInt(); val b = p[1].toInt()
            if (a == 10 || (a == 192 && b == 168) || (a == 172 && b in 16..31) || (a == 169 && b == 254)) return true
        }
        return false
    }

    fun urlOk(u: String): Boolean = try {
        val host = java.net.URI(u).host
        u.startsWith("https://") && host != null && !hostBlocked(host)
    } catch (e: Exception) {
        false
    }

    fun call(run: Run, req: Request): okhttp3.Response {
        val call = Llm.http.newCall(req)
        run.calls.add(call)
        try { return call.execute() } finally { run.calls.remove(call) }
    }

    fun json(run: Run, req: Request): JSONObject = call(run, req).use { r ->
        val t = r.body?.string() ?: ""
        if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}: ${t.take(200)}")
        JSONObject(t)
    }

    fun bytes(run: Run, req: Request, maxBytes: Long = 80_000_000): ByteArray = call(run, req).use { r ->
        if (!r.isSuccessful) throw IllegalStateException("HTTP ${r.code}")
        val ins = r.body?.byteStream() ?: throw IllegalStateException("Empty response")
        val bo = ByteArrayOutputStream()
        val buf = ByteArray(16384)
        var tot = 0L
        while (true) {
            run.check()
            val n = ins.read(buf)
            if (n < 0) break
            tot += n
            if (tot > maxBytes) throw IllegalStateException("File too large")
            bo.write(buf, 0, n)
        }
        bo.toByteArray()
    }

    fun download(run: Run, url: String, dest: File) {
        if (!urlOk(url)) throw IllegalStateException("Blocked download URL")
        dest.writeBytes(bytes(run, Request.Builder().url(url).header("User-Agent", "SwarmDeck").build()))
    }
}

object Replicate {
    private val JSON = "application/json".toMediaType()

    /** Runs any Replicate model and returns the first output URL. */
    fun run(c: Context, run: Run, model: String, input: JSONObject, maxSec: Int): String {
        val key = MediaCfg.repKey(c)
        if (key.isEmpty()) throw IllegalStateException("Add your Replicate API key in Settings > Media")
        val auth = "Bearer $key"
        val body = JSONObject().put("input", input)
        val rb = if (model.contains(":")) {
            body.put("version", model.substringAfter(":"))
            Request.Builder().url("https://api.replicate.com/v1/predictions")
        } else Request.Builder().url("https://api.replicate.com/v1/models/$model/predictions")
        var j = Net.json(run, rb.header("Authorization", auth).header("Prefer", "wait=30").post(body.toString().toRequestBody(JSON)).build())
        var waited = 0
        while (true) {
            val st = j.optString("status")
            if (st == "succeeded") {
                val o = j.opt("output")
                val url = when (o) {
                    is String -> o
                    is JSONArray -> if (o.length() > 0) o.getString(0) else ""
                    else -> ""
                }
                if (url.isEmpty()) throw IllegalStateException("The model returned no output")
                return url
            }
            if (st == "failed" || st == "canceled") throw IllegalStateException(j.optString("error", "prediction failed"))
            run.check()
            if (waited > maxSec) throw IllegalStateException("Timed out waiting for the model")
            try { Thread.sleep(3000) } catch (_: InterruptedException) {}
            run.check()
            waited += 3
            val get = j.getJSONObject("urls").getString("get")
            if (!get.startsWith("https://api.replicate.com/")) throw IllegalStateException("Unexpected poll URL")
            j = Net.json(run, Request.Builder().url(get).header("Authorization", auth).get().build())
        }
    }
}

object MediaGen {
    private val JSON = "application/json".toMediaType()
    private fun p(c: Context) = Store.p(c)
    private fun stamp() = System.currentTimeMillis().toString(36)
    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun capped(run: Run): String? {
        run.mediaCalls++
        return if (run.mediaCalls > 8) "Media generation limit (8) reached for this run." else null
    }

    private fun dims(size: String): Pair<Int, Int> {
        val m = Regex("(\\d{3,4})x(\\d{3,4})").find(size)
        if (m != null) return m.groupValues[1].toInt().coerceIn(256, 1536) to m.groupValues[2].toInt().coerceIn(256, 1536)
        return when (size.lowercase()) {
            "portrait" -> 768 to 1024
            "landscape" -> 1024 to 768
            else -> 1024 to 1024
        }
    }

    fun image(c: Context, run: Run, prompt: String, size: String): String {
        capped(run)?.let { return it }
        if (prompt.isBlank()) return "Empty prompt"
        val prov = p(c).getString("img_provider", "pollinations") ?: "pollinations"
        val model = (p(c).getString("img_model", "") ?: "").trim()
        val (w, h) = dims(size)
        Bus.think("Generating image ($prov)…")
        Bus.ui { Bus.status = "Generating image…" }
        return try {
            val dir = MediaCfg.dir(c)
            val file: File
            if (prov == "openai") {
                val base = MediaCfg.base(c)
                Parse.urlProblem(base)?.let { return it }
                val sz = if (w == h) "1024x1024" else if (h > w) "1024x1536" else "1536x1024"
                val body = JSONObject().put("model", model.ifEmpty { "gpt-image-1" }).put("prompt", prompt.take(3000)).put("size", sz).put("n", 1)
                val j = Net.json(run, Request.Builder().url("$base/images/generations").header("Authorization", "Bearer " + MediaCfg.key(c)).post(body.toString().toRequestBody(JSON)).build())
                val d = j.getJSONArray("data").getJSONObject(0)
                file = File(dir, "img_${stamp()}.png")
                if (d.has("b64_json") && !d.isNull("b64_json")) file.writeBytes(Base64.decode(d.getString("b64_json"), Base64.DEFAULT))
                else Net.download(run, d.getString("url"), file)
            } else if (prov == "replicate") {
                val url = Replicate.run(c, run, model.ifEmpty { "black-forest-labs/flux-schnell" }, JSONObject().put("prompt", prompt.take(2000)), 150)
                file = File(dir, "img_${stamp()}.webp")
                Net.download(run, url, file)
            } else {
                val url = "https://image.pollinations.ai/prompt/${enc(prompt.take(700))}?width=$w&height=$h&model=${model.ifEmpty { "flux" }}&nologo=true&seed=${(0..99999).random()}"
                file = File(dir, "img_${stamp()}.jpg")
                Net.download(run, url, file)
            }
            run.media.add("media/" + file.name)
            Audit.log(c, "generate_image", "$prov: ${prompt.take(80)}")
            "Image generated ($prov) and shown in the chat automatically. Do not paste any link or path."
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            "Image generation failed: ${e.message}"
        }
    }

    fun video(c: Context, run: Run, prompt: String, seconds: Int): String {
        capped(run)?.let { return it }
        if (prompt.isBlank()) return "Empty prompt"
        val prov = p(c).getString("vid_provider", "openai") ?: "openai"
        val model = (p(c).getString("vid_model", "") ?: "").trim()
        if (Confirm.ask(c, run, "Generate video: \"${prompt.take(60)}\"", "Uses your $prov account (may cost money) and takes 1-3 minutes.", true) == 0) return "DENIED by the user. Do not retry."
        Bus.think("Generating video ($prov) - this can take minutes…")
        Bus.ui { Bus.status = "Generating video… (1-3 min)" }
        return try {
            val f = File(MediaCfg.dir(c), "vid_${stamp()}.mp4")
            if (prov == "replicate") {
                val url = Replicate.run(c, run, model.ifEmpty { "minimax/video-01" }, JSONObject().put("prompt", prompt.take(2000)), 420)
                Net.download(run, url, f)
            } else {
                val base = MediaCfg.base(c)
                Parse.urlProblem(base)?.let { return it }
                val auth = "Bearer " + MediaCfg.key(c)
                val secs = if (seconds >= 12) "12" else if (seconds >= 8) "8" else "4"
                val body = JSONObject().put("model", model.ifEmpty { "sora-2" }).put("prompt", prompt.take(2000)).put("seconds", secs).put("size", "720x1280")
                var j = Net.json(run, Request.Builder().url("$base/videos").header("Authorization", auth).post(body.toString().toRequestBody(JSON)).build())
                val id = j.getString("id")
                var waited = 0
                while (true) {
                    val st = j.optString("status")
                    if (st == "completed") break
                    if (st == "failed" || st == "cancelled") throw IllegalStateException(j.optJSONObject("error")?.optString("message") ?: "video $st")
                    run.check()
                    if (waited > 420) throw IllegalStateException("Timed out waiting for the video")
                    try { Thread.sleep(5000) } catch (_: InterruptedException) {}
                    run.check()
                    waited += 5
                    j = Net.json(run, Request.Builder().url("$base/videos/$id").header("Authorization", auth).get().build())
                }
                f.writeBytes(Net.bytes(run, Request.Builder().url("$base/videos/$id/content").header("Authorization", auth).get().build()))
            }
            run.media.add("media/" + f.name)
            Audit.log(c, "generate_video", "$prov: ${prompt.take(80)}")
            "Video generated ($prov) and shown in the chat automatically. Do not paste any link or path."
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            "Video generation failed: ${e.message}"
        }
    }

    fun audio(c: Context, run: Run, text: String, kind: String, voice: String): String {
        capped(run)?.let { return it }
        if (text.isBlank()) return "Empty text"
        Bus.think("Generating audio…")
        Bus.ui { Bus.status = "Generating audio…" }
        return try {
            val dir = MediaCfg.dir(c)
            val f: File
            if (kind.lowercase() == "music") {
                val model = (p(c).getString("mus_model", "") ?: "").trim().ifEmpty { "meta/musicgen" }
                val url = Replicate.run(c, run, model, JSONObject().put("prompt", text.take(500)).put("duration", 10), 240)
                f = File(dir, "aud_${stamp()}.mp3")
                Net.download(run, url, f)
            } else if ((p(c).getString("aud_provider", "device") ?: "device") == "openai") {
                val base = MediaCfg.base(c)
                Parse.urlProblem(base)?.let { return it }
                val body = JSONObject().put("model", (p(c).getString("aud_model", "") ?: "").trim().ifEmpty { "tts-1" })
                    .put("input", text.take(4000)).put("voice", voice.ifEmpty { "alloy" }).put("response_format", "mp3")
                f = File(dir, "aud_${stamp()}.mp3")
                f.writeBytes(Net.bytes(run, Request.Builder().url("$base/audio/speech").header("Authorization", "Bearer " + MediaCfg.key(c)).post(body.toString().toRequestBody(JSON)).build()))
            } else {
                f = File(dir, "aud_${stamp()}.wav")
                if (!deviceTts(c, text, f)) return "Device text-to-speech could not create the file (is a TTS engine installed?)"
            }
            run.media.add("media/" + f.name)
            Audit.log(c, "generate_audio", "$kind: ${text.take(80)}")
            "Audio generated and shown in the chat automatically. Do not paste any link or path."
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            "Audio generation failed: ${e.message}"
        }
    }

    /** Offline text-to-speech straight into a WAV file using the phone's own TTS engine. */
    private fun deviceTts(c: Context, text: String, file: File): Boolean {
        val ready = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        var tts: TextToSpeech? = null
        Handler(Looper.getMainLooper()).post {
            tts = TextToSpeech(c.applicationContext) { st -> ok.set(st == TextToSpeech.SUCCESS); ready.countDown() }
        }
        ready.await(8, TimeUnit.SECONDS)
        val t = tts ?: return false
        try {
            if (!ok.get()) return false
            val done = CountDownLatch(1)
            val success = AtomicBoolean(false)
            t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(id: String?) {}
                override fun onDone(id: String?) { success.set(true); done.countDown() }
                @Deprecated("Deprecated in Java")
                override fun onError(id: String?) { done.countDown() }
            })
            if (t.synthesizeToFile(text.take(3000), null, file, "swarmgen") != TextToSpeech.SUCCESS) return false
            done.await(60, TimeUnit.SECONDS)
            return success.get() && file.length() > 0
        } finally {
            try { t.shutdown() } catch (_: Exception) {}
        }
    }
}

object Gallery {
    fun save(c: Context, f: File): String {
        if (Build.VERSION.SDK_INT < 29) return "Saving to the gallery needs Android 10+"
        return try {
            val ext = f.extension.lowercase()
            val isVid = ext == "mp4" || ext == "webm"
            val isAud = ext == "wav" || ext == "mp3" || ext == "ogg"
            val mime = when (ext) { "mp4" -> "video/mp4"; "webm" -> "video/webm"; "wav" -> "audio/wav"; "mp3" -> "audio/mpeg"; "ogg" -> "audio/ogg"; "png" -> "image/png"; "webp" -> "image/webp"; else -> "image/jpeg" }
            val coll = if (isVid) MediaStore.Video.Media.EXTERNAL_CONTENT_URI else if (isAud) MediaStore.Audio.Media.EXTERNAL_CONTENT_URI else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
            val folder = if (isVid) "Movies" else if (isAud) "Music" else "Pictures"
            val v = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, f.name)
                put(MediaStore.MediaColumns.MIME_TYPE, mime)
                put(MediaStore.MediaColumns.RELATIVE_PATH, "$folder/SwarmDeck")
            }
            val uri = c.contentResolver.insert(coll, v) ?: return "Could not save"
            c.contentResolver.openOutputStream(uri)?.use { out -> f.inputStream().use { it.copyTo(out) } }
            "Saved to $folder/SwarmDeck"
        } catch (e: Exception) {
            "Save failed: ${e.message}"
        }
    }
}

object PhoneVision {
    /** If enabled, grabs a screenshot so a vision-capable model can SEE the screen (Android 11+). */
    fun attach(c: Context, run: Run) {
        if (!Store.p(c).getBoolean("phone_vision", false)) return
        PhoneControl.inst?.screenshot()?.let { run.pendingImage = it }
    }
}

/** Passphrase encryption for backups (PBKDF2 + AES-GCM). */
object Crypt {
    private fun b64(b: ByteArray) = Base64.encodeToString(b, Base64.NO_WRAP)
    private fun key(pass: String, salt: ByteArray): SecretKeySpec {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return SecretKeySpec(f.generateSecret(PBEKeySpec(pass.toCharArray(), salt, 120000, 256)).encoded, "AES")
    }

    fun encrypt(text: String, pass: String): String {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.ENCRYPT_MODE, key(pass, salt))
        val ct = c.doFinal(text.toByteArray(Charsets.UTF_8))
        return JSONObject().put("enc", 1).put("salt", b64(salt)).put("iv", b64(c.iv)).put("ct", b64(ct)).toString()
    }

    fun isEncrypted(json: String) = json.trimStart().startsWith("{\"enc\"")

    fun decrypt(json: String, pass: String): String {
        if (pass.isBlank()) throw IllegalArgumentException("This backup is encrypted - enter the passphrase")
        val o = JSONObject(json)
        val c = Cipher.getInstance("AES/GCM/NoPadding")
        c.init(Cipher.DECRYPT_MODE, key(pass, Base64.decode(o.getString("salt"), Base64.NO_WRAP)), GCMParameterSpec(128, Base64.decode(o.getString("iv"), Base64.NO_WRAP)))
        return String(c.doFinal(Base64.decode(o.getString("ct"), Base64.NO_WRAP)), Charsets.UTF_8)
    }
}
