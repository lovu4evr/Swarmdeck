package com.swarmdeck.ui

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MUTED
import com.swarmdeck.Store
import com.swarmdeck.glass
import com.swarmdeck.hunter.CatalogIo
import com.swarmdeck.hunter.Category
import com.swarmdeck.hunter.Dashboard
import com.swarmdeck.hunter.HunterCmd
import com.swarmdeck.hunter.HunterEvent
import com.swarmdeck.hunter.HunterHub
import com.swarmdeck.hunter.HunterRouter
import com.swarmdeck.hunter.Matcher
import com.swarmdeck.hunter.Need
import com.swarmdeck.hunter.Recommendation
import com.swarmdeck.hunter.Resource
import com.swarmdeck.hunter.SetupSteps
import com.swarmdeck.hunter.VStatus
import com.swarmdeck.hunter.WatchTrends
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private class HunterData(val dash: Dashboard, val items: List<Resource>, val events: List<HunterEvent>, val rec: Recommendation)

private fun statusColor(s: VStatus): Color = when (s) {
    VStatus.VERIFIED -> Color(0xFF6FCF97)
    VStatus.CHANGED -> Color(0xFFFFC93C)
    VStatus.UNVERIFIED, VStatus.OUTDATED -> MUTED
    else -> Color(0xFFFF8A8A)
}

/** Resource Hunter dashboard. Buttons here are user actions, so they count as the approval for read-only requests. */
@Composable
fun HunterScreen(act: Activity, onBack: () -> Unit) {
    val scope = rememberCoroutineScope()
    var data by remember { mutableStateOf<HunterData?>(null) }
    var msg by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var filter by remember { mutableStateOf<Category?>(null) }
    var openId by remember { mutableStateOf("") }
    var monitor by remember { mutableStateOf(Store.p(act).getBoolean("hunter_monitor", false)) }
    var router by remember { mutableStateOf(HunterRouter.enabled(act)) }

    fun load() {
        scope.launch {
            data = withContext(Dispatchers.IO) {
                val h = HunterHub.get(act)
                val all = h.repo.all()
                HunterData(h.dashboard(), all, h.repo.events(8), Matcher.recommend(all, Need(deviceRamMb = HunterHub.deviceRamMb(act)), System.currentTimeMillis()))
            }
        }
    }

    fun work(label: String, f: () -> String) {
        if (busy) return
        busy = true; msg = label
        scope.launch {
            msg = try { withContext(Dispatchers.IO) { f() } } catch (e: Exception) { "Failed: ${e.message}" }
            busy = false
            load()
        }
    }

    LaunchedEffect(Unit) { load() }

    Column(Modifier.fillMaxSize().padding(14.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("RESOURCE HUNTER", color = GOLD, fontSize = 18.sp, fontWeight = FontWeight.Black)
        Text("Finds and verifies legitimate free resources on official pages. Read-only: it never signs up, accepts terms, enters keys or spends money.", color = MUTED, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button({ work("Discovering…") { val r = HunterHub.get(act).scan(); "Scan done: ${r.added} new, ${r.updated} refreshed" + (if (r.errors.isEmpty()) "" else ", ${r.errors.size} source error(s): " + r.errors.entries.joinToString { it.key }) } }, Modifier.weight(1f), enabled = !busy) { Text("Scan", fontSize = 13.sp) }
            Button({ work("Verifying on official pages…") { val r = HunterHub.get(act).verify(null, 60); HunterRouter.reset(); "Checked ${r.checked}: ${r.verified} verified, ${r.events.size} event(s)" } }, Modifier.weight(1f), enabled = !busy) { Text("Verify", fontSize = 13.sp) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            OutlinedButton({
                work("Exporting catalog…") {
                    val f = CatalogIo.defaultFile(act)
                    f.writeText(CatalogIo.exportJson(HunterHub.get(act).repo, includeEvents = true))
                    "Exported ${f.absolutePath}"
                }
            }, Modifier.weight(1f), enabled = !busy) { Text("Export catalog", fontSize = 12.sp) }
            OutlinedButton({
                work("Importing catalog…") {
                    val f = CatalogIo.defaultFile(act)
                    if (!f.exists()) {
                        "No file at ${f.name}"
                    } else {
                        val (a, u) = CatalogIo.importJson(HunterHub.get(act).repo, f.readText())
                        "Import: $a added, $u updated"
                    }
                }
            }, Modifier.weight(1f), enabled = !busy) { Text("Import catalog", fontSize = 12.sp) }
        }
        if (msg.isNotEmpty()) Text(msg, color = CREAM, fontSize = 12.sp)

        val d = data
        if (d == null) { Text("Loading…", color = MUTED); return@Column }

        // Section 1: numbers. Two columns on normal phones, one on very narrow screens.
        val cards = listOf(
            "Discovered" to d.dash.total.toString(), "Verified free" to d.dash.verified.toString(),
            "Model providers" to d.dash.modelProviders.size.toString(), "Local models" to d.dash.localModels.toString(),
            "Expired" to (d.dash.expired + d.dash.discontinued).toString(), "Outdated" to d.dash.outdated.toString()
        )
        BoxWithConstraints(Modifier.fillMaxWidth()) {
            val cols = if (maxWidth < 340.dp) 1 else 2
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                cards.chunked(cols).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        row.forEach { (k, v) ->
                            Column(Modifier.weight(1f).glass(RoundedCornerShape(16.dp)).padding(12.dp)) {
                                Text(v, color = GOLD, fontSize = 22.sp, fontWeight = FontWeight.Black)
                                Text(k, color = MUTED, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }
        Text("Last verification: " + (if (d.dash.lastVerified > 0) java.text.SimpleDateFormat("d MMM yyyy HH:mm", java.util.Locale.US).format(java.util.Date(d.dash.lastVerified)) else "never") +
            (if (d.dash.estimatedDailyRequests > 0) "  ·  est. ${d.dash.estimatedDailyRequests} requests/day (lowest listed limits)" else ""), color = MUTED, fontSize = 11.sp)

        // Section 2 (separate): alerts and the fallback plan.
        Text("ALERTS & FALLBACK PLAN", color = GOLD, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            val rec = d.rec
            if (rec.primary == null) Text(rec.notes.firstOrNull() ?: "No usable option yet.", color = MUTED, fontSize = 12.sp)
            else {
                Text("Best now: " + rec.primary.r.provider + " · " + (rec.primary.r.models.firstOrNull() ?: rec.primary.r.name), color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                rec.fallbacks.forEach { Text("If it fails → " + it.r.provider + " · " + (it.r.models.firstOrNull() ?: it.r.name) + (if (it.r.local) " (offline)" else ""), color = MUTED, fontSize = 12.sp) }
            }
            if (d.events.isEmpty()) Text("No policy changes recorded.", color = MUTED, fontSize = 12.sp)
            d.events.forEach { Text((if (it.important) "❗ " else "• ") + it.detail, color = if (it.important) Color(0xFFFFC93C) else MUTED, fontSize = 12.sp) }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Daily monitoring + notifications", color = CREAM, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(monitor, {
                    monitor = it
                    Store.p(act).edit().putBoolean("hunter_monitor", it).apply()
                    if (it) com.swarmdeck.work.HunterMonitorWorker.schedule(act)
                    else com.swarmdeck.work.HunterMonitorWorker.cancel(act)
                })
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Add verified free models to the model router as fallbacks", color = CREAM, fontSize = 12.sp, modifier = Modifier.weight(1f))
                Switch(router, { router = it; Store.p(act).edit().putBoolean("hunter_router", it).apply(); HunterRouter.reset() })
            }
        }

        // Section 3: catalog.
        Text("CATALOG", color = GOLD, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            TextButton({ filter = null }) { Text("All", color = if (filter == null) GOLD else MUTED, fontSize = 12.sp) }
            Category.values().forEach { c ->
                val n = d.dash.byCategory[c] ?: 0
                if (n > 0) TextButton({ filter = c }) { Text("${c.label} $n", color = if (filter == c) GOLD else MUTED, fontSize = 12.sp) }
            }
        }
        val now = System.currentTimeMillis()
        d.items.filter { filter == null || it.category == filter }.sortedWith(compareBy({ if (it.effective(now) == VStatus.VERIFIED) 0 else 1 }, { it.provider })).take(60).forEach { r ->
            val st = r.effective(now)
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).clickable { openId = if (openId == r.id) "" else r.id }.padding(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(r.provider + " · " + r.name, color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
                    Text(st.label, color = statusColor(st), fontSize = 11.sp)
                }
                Text(r.category.label + (if (r.quotas.isNotEmpty()) " · " + r.quotas.first() else ""), color = MUTED, fontSize = 11.sp)
                if (openId == r.id) {
                    Spacer(Modifier.height(6.dp))
                    if (r.freeTier.isNotEmpty()) Text(r.freeTier, color = CREAM, fontSize = 12.sp)
                    if (r.restrictions.isNotEmpty()) Text("Restrictions: " + r.restrictions.joinToString("; "), color = MUTED, fontSize = 11.sp)
                    Text("Account: ${r.needsAccount ?: "unknown"} · Card: ${r.needsCard ?: "unknown"}", color = MUTED, fontSize = 11.sp)
                    if (r.note.isNotEmpty()) Text(r.note, color = Color(0xFFFFC93C), fontSize = 11.sp)
                    // Trend samples (rpd history)
                    val samples = WatchTrends.samples(act, r.id)
                    if (samples.isNotEmpty()) {
                        val spark = samples.takeLast(12).joinToString(" ") { s ->
                            val v = s.second
                            when {
                                v <= 0 -> "·"
                                v < 100 -> "▁"
                                v < 1000 -> "▂"
                                v < 5000 -> "▃"
                                v < 20000 -> "▅"
                                else -> "▇"
                            }
                        }
                        Text("Limit trend (rpd): $spark", color = MUTED, fontSize = 11.sp)
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text("Watch this provider", color = CREAM, fontSize = 12.sp, modifier = Modifier.weight(1f))
                        var watched by remember(r.id) { mutableStateOf(WatchTrends.isWatched(act, r.id)) }
                        Switch(watched, {
                            watched = it
                            WatchTrends.setWatched(act, r.id, it)
                        })
                    }
                    OutlinedButton({ act.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(r.officialUrl))) }, Modifier.fillMaxWidth()) { Text("Open official site (you sign up yourself)", fontSize = 12.sp) }
                    OutlinedButton({
                        val text = SetupSteps.forResource(r)
                        val cm = act.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        cm.setPrimaryClip(ClipData.newPlainText("setup", text))
                        Toast.makeText(act, "Setup steps copied", Toast.LENGTH_SHORT).show()
                    }, Modifier.fillMaxWidth()) { Text("Copy setup steps", fontSize = 12.sp) }
                    TextButton({
                        work("Verifying ${r.id}…") {
                            val rep = HunterHub.get(act).verify(listOf(r.id), 1)
                            val fresh = HunterHub.get(act).repo.get(r.id)
                            if (fresh != null) WatchTrends.sample(act, fresh.id, fresh.rpd, fresh.rpm)
                            "Checked ${r.id}: " + (fresh?.status?.label ?: "?") + " (${rep.events.size} event(s))"
                        }
                    }) { Text("Re-verify this one", fontSize = 12.sp) }
                }
            }
        }
        TextButton(onBack) { Text("Back to chat", color = MUTED) }
    }
}
