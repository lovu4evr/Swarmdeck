package com.swarmdeck.ui

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.platform.LocalContext
import com.swarmdeck.ACC2
import com.swarmdeck.CREAM
import com.swarmdeck.GOLD
import com.swarmdeck.MUTED
import com.swarmdeck.glass
import com.swarmdeck.memgraph.EdgeKind
import com.swarmdeck.memgraph.GNode
import com.swarmdeck.memgraph.GraphHub
import com.swarmdeck.memgraph.MemGraph
import com.swarmdeck.memgraph.NodeType
import com.swarmdeck.sendMessage
import com.swarmdeck.ui.viz.ForceLayout
import com.swarmdeck.ui.viz.P2
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.min

private val DECISION_COLOR = Color(0xFF8FD3FF)

private fun nodeColor(t: NodeType): Color = when (t) {
    NodeType.FACT -> CREAM
    NodeType.GOAL -> ACC2
    NodeType.DECISION -> DECISION_COLOR
    NodeType.TOPIC -> MUTED
}

/** Layout space is 1000 x 1000; this maps it to the screen with pan + zoom. */
private fun toScreen(p: P2, w: Float, h: Float, scale: Float, off: Offset): Offset {
    val fit = min(w, h) / 1000f * scale
    return Offset(w / 2f + (p.x - 500f) * fit + off.x, h / 2f + (p.y - 500f) * fit + off.y)
}

/** Interactive memory graph: force layout (computed off the main thread), pinch-zoom, drag-pan, tap a node to light up its links. */
@Composable
fun MemoryGraphView(
    modifier: Modifier = Modifier,
    compact: Boolean = false,
    refreshKey: Int = 0,
    onSelect: (GNode?) -> Unit = {}
) {
    val ctx = LocalContext.current
    var graph by remember { mutableStateOf<MemGraph?>(null) }
    var pos by remember { mutableStateOf<Map<String, P2>>(emptyMap()) }
    var selected by remember { mutableStateOf<String?>(null) }
    var scale by remember { mutableStateOf(1f) }
    var off by remember { mutableStateOf(Offset.Zero) }
    val paint = remember { android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG) }

    LaunchedEffect(refreshKey) {
        val built = withContext(Dispatchers.Default) {
            val g = GraphHub.build(ctx)
            val p = ForceLayout.layout(
                g.nodes.map { it.id }, g.edges.map { it.a to it.b }, 1000f, 1000f,
                if (g.nodes.size > 200) 60 else 120
            )
            g to p
        }
        graph = built.first
        pos = built.second
        selected = null
        onSelect(null)
    }

    Box(modifier) {
        val g = graph
        if (g == null) {
            Text("Building your memory graph…", color = MUTED, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center))
        } else if (g.nodes.isEmpty()) {
            Text(
                "Nothing here yet. Save memories, add goals or record decisions with `decide: ...` and the graph grows.",
                color = MUTED, fontSize = 13.sp, modifier = Modifier.align(Alignment.Center).padding(24.dp)
            )
        } else {
            Canvas(
                Modifier.fillMaxSize()
                    .pointerInput(Unit) {
                        detectTransformGestures { _, pan, zoom, _ ->
                            scale = (scale * zoom).coerceIn(0.5f, 5f)
                            off += pan
                        }
                    }
                    .pointerInput(g, pos) {
                        detectTapGestures { tap ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            var best: String? = null
                            var bd = 36f * 36f
                            for (n in g.nodes) {
                                val p = pos[n.id] ?: continue
                                val s = toScreen(p, w, h, scale, off)
                                val dx = s.x - tap.x
                                val dy = s.y - tap.y
                                val d = dx * dx + dy * dy
                                if (d < bd) {
                                    bd = d
                                    best = n.id
                                }
                            }
                            selected = best
                            onSelect(best?.let { g.node(it) })
                        }
                    }
            ) {
                val w = size.width
                val h = size.height
                val sel = selected
                val neigh = if (sel != null) g.neighbors(sel).map { it.id }.toSet() else emptySet()
                paint.color = Color.White.copy(alpha = 0.9f).toArgb()
                paint.textSize = 11.dp.toPx()

                for (e in g.edges) {
                    val a = pos[e.a] ?: continue
                    val b = pos[e.b] ?: continue
                    val hot = sel != null && (e.a == sel || e.b == sel)
                    val col = when (e.kind) {
                        EdgeKind.SERVES -> ACC2
                        EdgeKind.RELATED -> GOLD
                        EdgeKind.ABOUT -> MUTED
                    }
                    val base = when (e.kind) {
                        EdgeKind.SERVES -> 0.55f
                        EdgeKind.RELATED -> 0.28f
                        EdgeKind.ABOUT -> 0.12f
                    }
                    val alpha = if (hot) 0.9f else if (sel != null) 0.06f else base
                    drawLine(col.copy(alpha = alpha), toScreen(a, w, h, scale, off), toScreen(b, w, h, scale, off), strokeWidth = if (hot) 2.5f else 1.2f)
                }
                for (n in g.nodes) {
                    val p = pos[n.id] ?: continue
                    val s = toScreen(p, w, h, scale, off)
                    val isSel = n.id == sel
                    val dim = sel != null && !isSel && n.id !in neigh
                    val col = nodeColor(n.type)
                    val r = (4f + 2.2f * n.weight).coerceAtMost(14f) * (if (scale < 1f) 0.8f else 1f)
                    if (n.type == NodeType.TOPIC) {
                        drawCircle(col.copy(alpha = if (dim) 0.15f else 0.6f), r, s, style = Stroke(1.5f))
                    } else {
                        drawCircle(col.copy(alpha = if (dim) 0.12f else 0.22f), r * 2.2f, s)
                        drawCircle(col.copy(alpha = if (dim) 0.25f else 1f), r, s)
                    }
                    if (isSel) drawCircle(Color.White, r + 5f, s, style = Stroke(2f))
                    val showLabel = isSel || (sel != null && n.id in neigh) || scale > 1.8f ||
                        (!compact && (n.type == NodeType.GOAL || n.type == NodeType.DECISION))
                    if (showLabel) drawContext.canvas.nativeCanvas.drawText(n.label.take(22), s.x + r + 6f, s.y + 4f, paint)
                }
            }
        }
    }
}

/** Full page: the graph, a legend, and a detail card for the selected node. */
@Composable
fun MemoryGraphScreen(act: Activity, onBack: () -> Unit) {
    var refresh by remember { mutableStateOf(0) }
    var sel by remember { mutableStateOf<GNode?>(null) }
    Column(Modifier.fillMaxSize().padding(12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("MEMORY GRAPH", color = GOLD, fontSize = 18.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            IconButton({ refresh++ }) { Icon(Icons.Default.Refresh, null, tint = GOLD) }
        }
        Text("Pinch to zoom, drag to move, tap a node to see how it connects.", color = MUTED, fontSize = 12.sp)
        Spacer(Modifier.size(6.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Legend("Fact", CREAM)
            Legend("Goal", ACC2)
            Legend("Decision", DECISION_COLOR)
            Legend("Topic", MUTED)
        }
        Spacer(Modifier.size(8.dp))
        MemoryGraphView(
            Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(18.dp)).background(Color(0xFF050403)),
            compact = false, refreshKey = refresh, onSelect = { sel = it }
        )
        val s = sel
        if (s != null) {
            Spacer(Modifier.size(8.dp))
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(14.dp)) {
                Text(s.type.name + " · " + s.label, color = nodeColor(s.type), fontSize = 14.sp, fontWeight = FontWeight.Bold)
                if (s.detail.isNotBlank()) Text(s.detail, color = CREAM, fontSize = 13.sp)
                TextButton({
                    sendMessage(act, "Using my memory graph, tell me what matters about: " + s.label)
                    onBack()
                }) { Text("Ask my agents about this", color = GOLD) }
            }
        }
    }
}

@Composable
private fun Legend(label: String, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(9.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(5.dp))
        Text(label, color = MUTED, fontSize = 11.sp)
    }
}
