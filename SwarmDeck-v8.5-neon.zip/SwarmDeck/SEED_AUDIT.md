# Seed URL audit (2026-11-24)

HTTP checks against `SeedCatalog` official URLs:

| Status | URL | Notes |
|--------|-----|--------|
| OK 200 | Most AI API, hosting, DB, local model seeds | |
| Fixed | `https://github.com/marketplace/models` → `https://github.com/marketplace?type=models` | Old path 404 |
| Timeout | `https://dumps.wikimedia.org/` | Transient network; left as-is (historical archive) |

Re-run audit after major provider moves. Verification still marks unreachable seeds at runtime.
