# SwarmDeck 8.3-pack — progress

## Shipped in 8.2-foundation + 8.3-pack

### Navigation
- [x] Navigation Compose: `ui/nav/Routes.kt` + `AppShell` NavHost
- [x] New routes: diagnostics, backup, privacy, local_models, onboarding
- [x] Sidebar NAV list expanded; Root uses AppShell

### Tests
- [x] CI unit tests blocking + lint step
- [x] ResourceRepoTest, CatalogIoTest
- [ ] Full Robolectric SqliteRepo (dependency added; needs runner config on CI)

### Hunter
- [x] Seed URL audit (`SEED_AUDIT.md`); GitHub Models URL fixed
- [x] Catalog export/import JSON
- [x] Copy setup steps
- [x] Watch provider + limit trend samples + sparkline
- [x] WorkManager monitor with Wi-Fi + battery constraints

### Security / trust / polish
- [x] CrashLog + Diagnostics screen
- [x] Encrypted local backup/restore (ZIP of prefs + DB)
- [x] Privacy policy draft (screen + assets/PRIVACY_POLICY.txt)
- [x] Onboarding (4 steps)
- [x] Hindi strings first pass (`values-hi`)
- [x] a11y string resources (content descriptions)
- [x] Local-model manager screen (RAM-aware links)
- [x] Multi-provider failover with cooldown (`ProviderFailover`)
- [x] Cost/token tracking (`CostTracker` wired from Stats)
- [x] Pro engine gates already in Brain/Tools/SwarmLab (unchanged, verified)

## Still open
- [x] JS headless quota extraction (WebViewFetcher / HybridFetcher)
- Full on-device GGUF runtime
- Agent eval harness, plugins, tablet layouts, widgets/QS tiles
