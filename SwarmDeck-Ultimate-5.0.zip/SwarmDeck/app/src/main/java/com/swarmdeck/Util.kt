package com.swarmdeck

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONObject
import java.io.File
import java.security.KeyStore
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.atomic.AtomicInteger
import java.util.concurrent.atomic.AtomicLong
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** AES-256-GCM using the Android Keystore. Secrets and stored content never touch disk in plaintext. */
object Vault {
    private const val ALIAS = "swarmdeck_key_v1"
    private var cached: SecretKey? = null

    @Synchronized
    private fun key(): SecretKey? {
        cached?.let { return it }
        return try {
            val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val existing = ks.getKey(ALIAS, null) as? SecretKey
            val k = existing ?: KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore").apply {
                init(
                    KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                        .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                        .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                        .setKeySize(256).build()
                )
            }.generateKey()
            cached = k
            k
        } catch (e: Exception) {
            null
        }
    }

    /** Encrypt. Fails closed: returns empty string if Keystore is unavailable (never stores plaintext). */
    fun enc(s: String): String {
        if (s.isEmpty()) return s
        val k = key() ?: run {
            android.util.Log.e("Vault", "Keystore unavailable — refusing to store plaintext")
            return ""
        }
        return try {
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.ENCRYPT_MODE, k)
            val ct = c.doFinal(s.toByteArray(Charsets.UTF_8))
            "e:" + Base64.encodeToString(c.iv + ct, Base64.NO_WRAP)
        } catch (e: Exception) {
            android.util.Log.e("Vault", "Encrypt failed", e)
            ""
        }
    }

    fun dec(s: String): String {
        if (s.startsWith("p:")) return s.substring(2)
        if (!s.startsWith("e:")) return s // legacy plaintext value
        return try {
            val raw = Base64.decode(s.substring(2), Base64.NO_WRAP)
            val k = key() ?: return ""
            val c = Cipher.getInstance("AES/GCM/NoPadding")
            c.init(Cipher.DECRYPT_MODE, k, GCMParameterSpec(128, raw, 0, 12))
            String(c.doFinal(raw, 12, raw.size - 12), Charsets.UTF_8)
        } catch (e: Exception) {
            ""
        }
    }
}

/** Append-only audit trail. Lines are encrypted with Vault when possible. */
object Audit {
    @Synchronized
    fun log(c: Context, kind: String, detail: String) {
        try {
            val f = File(c.filesDir, "audit.log")
            if (f.length() > 300_000) {
                val keep = f.readLines().takeLast(800)
                f.writeText(keep.joinToString("\n") + "\n")
            }
            val ts = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date())
            val line = "$ts [$kind] ${detail.replace('\n', ' ').take(280)}"
            val stored = Vault.enc(line).ifEmpty { line }   // fall back only for the log line itself if keystore dead
            f.appendText(stored + "\n")
        } catch (_: Exception) {
        }
    }

    fun tail(c: Context, n: Int = 40): String {
        return try {
            val f = File(c.filesDir, "audit.log")
            if (!f.exists()) "(empty)"
            else f.readLines().takeLast(n).joinToString("\n") { line ->
                if (line.startsWith("e:") || line.startsWith("p:")) Vault.dec(line).ifEmpty { "[encrypted]" } else line
            }
        } catch (_: Exception) { "(error reading audit)" }
    }
}


object Stats {
    private val calls = AtomicInteger()
    private val tokens = AtomicLong()

    fun add(u: JSONObject?) {
        calls.incrementAndGet()
        val t = u?.optLong("total_tokens", 0L) ?: 0L
        tokens.addAndGet(t)
        Bus.ui { Bus.calls = calls.get(); Bus.tokens = tokens.get() }
    }

    fun reset() {
        calls.set(0); tokens.set(0)
        Bus.ui { Bus.calls = 0; Bus.tokens = 0L }
    }
}
