package com.swarmdeck

import android.Manifest
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat

// ── LIQUID GLASS THEME: midnight navy + cream + champagne ──
val BG1 = Color(0xFF050B1A)
val BG2 = Color(0xFF0A162F)
val EDGE = Color(0x55E8E4D9)
val ACC = Color(0xFF3B82F6)
val ACC2 = Color(0xFF60A5FA)
val CREAM = Color(0xFFF5F0E6)
val GOLD = Color(0xFFE8D5A3)
val MUTED = Color(0xFFB8B0A0)
val COLORS = listOf(Color(0xFF3B82F6), Color(0xFF60A5FA), Color(0xFF93C5FD), Color(0xFF2563EB), Color(0xFF38BDF8), Color(0xFF818CF8), Color(0xFFF5F0E6), Color(0xFFE8D5A3))
val SHAPE = RoundedCornerShape(24.dp)

fun Modifier.glass(shape: Shape = SHAPE): Modifier = this
    .clip(shape)
    .background(Brush.linearGradient(listOf(Color(0x28F5F0E6), Color(0x18FFFFFF), Color(0x12A5C8FF))), shape)
    .border(1.1.dp, EDGE, shape)

fun colorOf(id: String) = COLORS[Registry.all().indexOfFirst { it.id == id }.coerceAtLeast(0) % COLORS.size]

@Composable
fun clearColors() = TextFieldDefaults.colors(
    focusedContainerColor = Color.Transparent, unfocusedContainerColor = Color.Transparent,
    focusedIndicatorColor = Color.Transparent, unfocusedIndicatorColor = Color.Transparent,
    focusedTextColor = CREAM, unfocusedTextColor = CREAM, cursorColor = ACC2
)

fun copyText(c: Context, t: String) {
    (c.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("swarm", t))
    Toast.makeText(c, "Copied", Toast.LENGTH_SHORT).show()
}

/** Single entry point used by the send button AND by hands-free voice. */
fun sendMessage(c: Context, text: String) {
    val q = text.trim()
    if (q.isEmpty() || Bus.running) return
    Bus.turns.add(Turn(true, q))
    Bus.persist(c)
    Bus.running = true
    Bus.status = "Starting…"
    Bus.stream = ""
    ContextCompat.startForegroundService(c.applicationContext, Intent(c.applicationContext, AgentService::class.java).putExtra("goal", q))
}

fun resumeMission(c: Context) {
    if (Bus.running) return
    Bus.running = true
    Bus.status = "Resuming mission…"
    Bus.stream = ""
    ContextCompat.startForegroundService(c.applicationContext, Intent(c.applicationContext, AgentService::class.java).putExtra("resume", true))
}

fun newChat(c: Context) {
    if (Bus.running) return
    Bus.persist(c)
    Hist.newChat(c)
    Bus.turns.clear()
    Registry.reset()
    Bus.mission = emptyList()
}

class MainActivity : ComponentActivity() {
    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        Bus.app = applicationContext
        if (Bus.turns.isEmpty()) Bus.turns.addAll(Hist.load(this))
        Voice.onFinal = { q -> sendMessage(applicationContext, q) }
        Voice.attach(this)
        Voice.init(this)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = ACC, background = BG1, surface = BG2)) { App(this) } }
    }

    override fun onStart() { super.onStart(); Bus.activity = java.lang.ref.WeakReference(this); LiveBrowser.rehost(); Voice.onActivityStart(this) }
    override fun onStop() { super.onStop(); Voice.onActivityStop() }
    override fun onDestroy() { super.onDestroy(); LiveBrowser.release(); if (isFinishing) Voice.release() }
}

@Composable
fun Backdrop(content: @Composable BoxScope.() -> Unit) {
    Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(BG1, BG2, Color(0xFF071022))))) {
        Box(Modifier.offset((-100).dp, (-60).dp).size(480.dp).background(Brush.radialGradient(listOf(Color(0x443B82F6), Color.Transparent))))
        Box(Modifier.align(Alignment.BottomEnd).offset(100.dp, 80.dp).size(420.dp).background(Brush.radialGradient(listOf(Color(0x3360A5FA), Color.Transparent))))
        Box(Modifier.align(Alignment.Center).size(300.dp).background(Brush.radialGradient(listOf(Color(0x12F5F0E6), Color.Transparent))))
        content()
    }
}

@Composable
fun App(act: Activity) {
    var entered by remember { mutableStateOf(Store.p(act).getBoolean("entered", false)) }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    val micPerm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {}
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33) notif.launch(Manifest.permission.POST_NOTIFICATIONS)
        micPerm.launch(Manifest.permission.RECORD_AUDIO)
    }
    Backdrop { if (!entered) Login(act) { entered = true } else Main(act) { entered = false } }
    Bus.confirm?.let { ConfirmDialog(it) }
}

@Composable
fun ConfirmDialog(req: ConfirmReq) {
    AlertDialog(
        onDismissRequest = { Confirm.answer(req.id, 0) },
        containerColor = BG2,
        title = { Text(if (req.risky) "⚠ Sensitive action" else "Approve phone action", color = CREAM) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(req.title, color = GOLD, fontWeight = FontWeight.Bold)
                Text(req.detail, color = MUTED, fontSize = 13.sp)
                Button({ Confirm.answer(req.id, 1) }, Modifier.fillMaxWidth()) { Text("Allow once") }
                if (!req.risky) OutlinedButton({ Confirm.answer(req.id, 2) }, Modifier.fillMaxWidth()) { Text("Allow safe actions this run") }
                OutlinedButton({ Confirm.answer(req.id, 0) }, Modifier.fillMaxWidth()) { Text("Deny", color = Color(0xFFFF8A8A)) }
                Text("Tip: press Volume Down 3× to stop the agent instantly.", color = MUTED, fontSize = 11.sp)
            }
        },
        confirmButton = {}
    )
}

@Composable
fun Login(act: Activity, done: () -> Unit) {
    var name by remember { mutableStateOf(Store.p(act).getString("name", "") ?: "") }
    Box(Modifier.fillMaxSize().padding(28.dp), Alignment.Center) {
        Column(Modifier.glass().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(Icons.Default.Hub, null, tint = ACC2, modifier = Modifier.size(72.dp))
            Spacer(Modifier.height(12.dp))
            Text("SWARMDECK", fontSize = 32.sp, fontWeight = FontWeight.Bold, color = CREAM, letterSpacing = 2.sp)
            Text("V4.1  ·  Autonomous Agent", fontSize = 14.sp, color = ACC2, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(6.dp))
            Text("Missions · Memory · Hands-free Voice · Tools", color = MUTED, textAlign = TextAlign.Center, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("No account needed. Everything stays on this device; your key is encrypted.", color = MUTED, textAlign = TextAlign.Center, fontSize = 12.sp)
            Spacer(Modifier.height(20.dp))
            OutlinedTextField(name, { name = it }, Modifier.fillMaxWidth(), label = { Text("Your name (optional)") }, singleLine = true)
            Spacer(Modifier.height(16.dp))
            Button(
                { Store.p(act).edit().putBoolean("entered", true).putString("name", name.trim()).apply(); done() },
                Modifier.fillMaxWidth().height(54.dp),
                colors = ButtonDefaults.buttonColors(containerColor = ACC, contentColor = CREAM),
                shape = RoundedCornerShape(16.dp)
            ) { Text("Enter SwarmDeck", fontWeight = FontWeight.SemiBold) }
        }
    }
}

@Composable
fun Main(act: Activity, out: () -> Unit) {
    var tab by remember { mutableIntStateOf(0) }
    val tabs = listOf("Chat" to Icons.Default.Chat, "Agents" to Icons.Default.Groups, "Memory" to Icons.Default.Memory, "Terminal" to Icons.Default.Terminal, "Settings" to Icons.Default.Settings)
    Scaffold(containerColor = Color.Transparent, bottomBar = {
        Box(Modifier.padding(12.dp).glass(RoundedCornerShape(28.dp))) {
            NavigationBar(containerColor = Color.Transparent) {
                tabs.forEachIndexed { i, (n, ic) -> NavigationBarItem(tab == i, { tab = i }, { Icon(ic, n) }, label = { Text(n, fontSize = 10.sp) }) }
            }
        }
    }) { p ->
        Box(Modifier.padding(p).fillMaxSize()) {
            when (tab) { 0 -> ChatTab(act); 1 -> AgentsTab(act); 2 -> MemoryTab(act); 3 -> TermTab(act); else -> SettingsTab(act, out) }
        }
    }
}

@Composable
fun ChatTab(c: Context) {
    var input by remember { mutableStateOf("") }
    var mode by remember { mutableStateOf(Store.p(c).getString("mode", "auto") ?: "auto") }
    var showChats by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    val ls = rememberLazyListState()
    val mic = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?.let { input = if (input.isBlank()) it else "$input $it" }
    }
    val savedMission = remember(Bus.running, Bus.turns.size, tick) { if (Bus.running) null else Mission.saved(c) }
    LaunchedEffect(Bus.turns.size, Bus.status, Bus.stream.length / 40) {
        val n = ls.layoutInfo.totalItemsCount
        if (n > 0) ls.scrollToItem(n - 1)
    }
    fun send() { val q = input.trim(); if (q.isNotEmpty() && !Bus.running) { input = ""; sendMessage(c, q) } }

    if (showChats) ChatsDialog(c) { showChats = false }

    Column(Modifier.fillMaxSize().padding(horizontal = 14.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("SwarmDeck 4.1", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                Text("${Bus.calls} calls · ${Bus.tokens} tokens", color = MUTED, fontSize = 10.sp)
            }
            IconButton({ showChats = true }) { Icon(Icons.Default.History, "Chats", tint = ACC2) }
            IconButton({ newChat(c) }) { Icon(Icons.Default.Add, "New chat", tint = ACC2) }
        }
        Row(Modifier.padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("auto" to "🧠 Auto", "fast" to "⚡ Fast", "all" to "🌐 All", "mission" to "🎯 Mission").forEach { (m, l) ->
                FilterChip(mode == m, { mode = m; Store.p(c).edit().putString("mode", m).apply() }, { Text(l) })
            }
        }
        LazyColumn(Modifier.weight(1f), state = ls) {
            if (Bus.turns.isEmpty() && !Bus.running) item {
                Column(Modifier.padding(vertical = 24.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Ask anything.", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    Text("The Head Agent picks experts, they work in parallel (with real tools), and the Ultimate Agent streams the best answer.", color = Color.LightGray)
                    listOf("Research the latest news about open-source LLMs", "Explain blockchain simply", "Mission: plan and write a 3-day study schedule to a file").forEach { s ->
                        OutlinedButton({ input = s }, Modifier.fillMaxWidth()) { Text(s) }
                    }
                }
            }
            if (savedMission != null) item {
                Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Unfinished mission", color = GOLD, fontWeight = FontWeight.Bold)
                    Text(savedMission.first.take(120), color = CREAM, fontSize = 13.sp)
                    Text("${savedMission.second.count { it.status == "DONE" }}/${savedMission.second.size} steps done", color = MUTED, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button({ resumeMission(c) }) { Text("Resume") }
                        OutlinedButton({ Mission.clear(c); tick++ }) { Text("Discard") }
                    }
                }
            }
            items(Bus.turns) { t -> Bubble(c, t) }
            if (Bus.running && Bus.stream.isNotEmpty()) item { Bubble(c, Turn(false, Bus.stream), live = true) }
            if (Bus.liveActive) item { LiveCard() }
            if (Bus.running) item {
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(Modifier.size(16.dp), strokeWidth = 2.dp, color = ACC2)
                        Spacer(Modifier.width(10.dp))
                        Text(Bus.status.ifEmpty { "Thinking…" }, color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        if (Bus.mission.isNotEmpty()) IconButton({ Bus.missionPaused = !Bus.missionPaused }) {
                            Icon(if (Bus.missionPaused) Icons.Default.PlayArrow else Icons.Default.Pause, "Pause/Resume mission", tint = GOLD)
                        }
                    }
                    if (Bus.subAgents.isNotEmpty()) {
                        Spacer(Modifier.height(6.dp))
                        Text("Sub-agents: " + Bus.subAgents.joinToString(" · "), color = ACC2, fontSize = 11.sp)
                    }
                    if (Bus.mission.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Text("Mission: ${Bus.missionObjective.take(80)}", color = GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        Bus.mission.forEach { s ->
                            val ic = when (s.status) { "DONE" -> "✓"; "BLOCKED" -> "✗"; "RUNNING" -> "▶"; "RETRY" -> "↻"; else -> "○" }
                            Text("$ic ${s.text.take(90)}", color = if (s.status == "DONE") Color(0xFF34D399) else if (s.status == "BLOCKED") Color(0xFFFF8A8A) else CREAM, fontSize = 12.sp)
                        }
                    }
                    if (Bus.thinking.isNotEmpty()) {
                        Spacer(Modifier.height(8.dp))
                        Bus.thinking.takeLast(5).forEach { Text("› $it", color = MUTED, fontSize = 11.sp) }
                    }
                }
            }
        }
        if (Voice.continuous && (Voice.listening || Voice.partial.isNotEmpty())) {
            Text("🎤 " + Voice.partial.ifEmpty { "Listening…" }, color = Color(0xFF34D399), fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        } else if (Voice.continuous && Voice.speaking) {
            Text("🔊 Speaking… tap the speaker to interrupt", color = GOLD, fontSize = 12.sp, modifier = Modifier.padding(start = 8.dp))
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 10.dp).glass(RoundedCornerShape(28.dp)), verticalAlignment = Alignment.CenterVertically) {
            TextField(
                input, { input = it }, Modifier.weight(1f), placeholder = { Text("Message SwarmDeck…") }, maxLines = 4, colors = clearColors(),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send), keyboardActions = KeyboardActions(onSend = { send() })
            )
            if (Voice.speaking) IconButton({ Voice.stopSpeaking() }) { Icon(Icons.Default.VolumeOff, "Stop speaking", tint = GOLD) }
            IconButton({
                if (Voice.continuous) {
                    Voice.stopContinuous(); Toast.makeText(c, "Hands-free voice OFF", Toast.LENGTH_SHORT).show()
                } else {
                    Voice.startContinuous(c as Activity); Toast.makeText(c, "Hands-free voice ON - just talk", Toast.LENGTH_SHORT).show()
                }
            }) { Icon(if (Voice.continuous) Icons.Default.GraphicEq else Icons.Default.RecordVoiceOver, "Hands-free voice", tint = if (Voice.continuous) Color(0xFF34D399) else ACC2) }
            IconButton({
                try {
                    mic.launch(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM))
                } catch (e: Exception) { Toast.makeText(c, "Voice input isn't available", Toast.LENGTH_SHORT).show() }
            }) { Icon(Icons.Default.Mic, "Push to talk", tint = ACC2) }
            if (Bus.running) IconButton({ Brain.stopAll("Stop button") }) { Icon(Icons.Default.Stop, "Stop", tint = Color(0xFFFF6B6B)) }
            else IconButton({ send() }) { Icon(Icons.Default.Send, "Send", tint = ACC) }
        }
    }
}

@Composable
fun ChatsDialog(c: Context, close: () -> Unit) {
    var list by remember { mutableStateOf(Hist.list(c)) }
    AlertDialog(
        onDismissRequest = close, containerColor = BG2,
        title = { Text("Chats", color = CREAM) },
        text = {
            LazyColumn(Modifier.heightIn(max = 380.dp)) {
                if (list.isEmpty()) item { Text("No saved chats yet.", color = MUTED) }
                items(list) { ci ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        TextButton({
                            if (!Bus.running) {
                                Bus.persist(c); Hist.setCurrent(c, ci.id)
                                Bus.turns.clear(); Bus.turns.addAll(Hist.load(c, ci.id)); close()
                            }
                        }, Modifier.weight(1f)) { Text(ci.title.ifEmpty { "(untitled)" }, maxLines = 1, color = CREAM) }
                        IconButton({
                            if (!Bus.running) {
                                val wasCurrent = ci.id == Hist.currentId(c)
                                Hist.delete(c, ci.id)
                                if (wasCurrent) newChat(c)
                                list = Hist.list(c)
                            }
                        }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFFF8A8A)) }
                    }
                }
            }
        },
        confirmButton = { TextButton(close) { Text("Close") } }
    )
}

@Composable
fun Bubble(c: Context, t: Turn, live: Boolean = false) {
    var open by remember { mutableStateOf(false) }
    var think by remember { mutableStateOf(false) }
    val sh = if (t.user) RoundedCornerShape(22.dp, 22.dp, 6.dp, 22.dp) else RoundedCornerShape(22.dp, 22.dp, 22.dp, 6.dp)
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = if (t.user) Arrangement.End else Arrangement.Start) {
        Column(Modifier.widthIn(max = 340.dp).glass(sh).background(if (t.user) ACC.copy(alpha = 0.35f) else Color.Transparent, sh).padding(14.dp)) {
            if (!t.user) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.AutoAwesome, null, tint = ACC2, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(6.dp))
                    Text(if (live) "Ultimate Agent · writing…" else "Ultimate Agent", color = ACC2, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    if (t.winner.isNotEmpty() && t.winner != "mission") { Spacer(Modifier.width(8.dp)); Text("⭐ ${nameOf(t.winner)}", color = GOLD, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(6.dp))
            }
            if (t.user) SelectionContainer { Text(t.text, color = Color.White, fontSize = 15.sp) }
            else SelectionContainer { MdText(c, t.text) }
            if (!t.user && t.missionSteps.isNotEmpty()) {
                Spacer(Modifier.height(8.dp))
                HorizontalDivider(color = EDGE)
                Text("Mission steps", color = GOLD, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(top = 6.dp))
                t.missionSteps.forEach { Text(it, color = Color(0xFFCBD5E1), fontSize = 12.sp) }
            }
            if (!t.user && !live) {
                Row {
                    TextButton({ copyText(c, t.text) }) { Text("Copy") }
                    TextButton({ c.startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, t.text), "Share").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Share") }
                    TextButton({
                        Bus.background { Memory.save(c, "From chat: " + t.text.take(40), t.text.take(1500)) }
                        Toast.makeText(c, "Saved to memory", Toast.LENGTH_SHORT).show()
                    }) { Text("Save") }
                }
                Row {
                    if (t.answers.size > 1) TextButton({ open = !open }) { Text("Agents (${t.answers.size})") }
                    if (t.thinking.isNotEmpty()) TextButton({ think = !think }) { Text("Thinking") }
                }
                if (think) t.thinking.forEach { Text("› $it", color = MUTED, fontSize = 11.sp) }
                if (open) t.answers.forEach { (id, s, n) ->
                    HorizontalDivider(color = EDGE, modifier = Modifier.padding(vertical = 6.dp))
                    Text(nameOf(id) + (if (n > 0) "  ·  $n/10" else ""), color = colorOf(id), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text(s, color = Color(0xFFCBD5E1), fontSize = 13.sp)
                }
            }
        }
    }
}
