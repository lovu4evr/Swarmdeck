package com.swarmdeck

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.CopyOnWriteArrayList
import java.util.concurrent.Executors

data class Turn(
    val user: Boolean,
    val text: String,
    val winner: String = "",
    val answers: List<Triple<String, String, Int>> = emptyList(),
    val thinking: List<String> = emptyList(),
    val missionSteps: List<String> = emptyList()
)

data class MStep(val text: String, val status: String, val result: String = "")
data class MemoryItem(val id: String, val key: String, val value: String, val tags: String, val ts: Long, val pinned: Boolean)
data class ChatInfo(val id: String, val title: String, val ts: Long)
data class Profile(val name: String, val url: String, val key: String)

/** Shared UI/state bus. All Compose state is mutated on the main thread via [ui]. */
object Bus {
    var app: Context? = null
    val turns = mutableStateListOf<Turn>()
    var running by mutableStateOf(false)
    var status by mutableStateOf("")
    var stream by mutableStateOf("")
    val thinking = mutableStateListOf<String>()
    private val thinkLog = CopyOnWriteArrayList<String>()
    var subAgents by mutableStateOf<List<String>>(emptyList())
    var mission by mutableStateOf<List<MStep>>(emptyList())
    var missionObjective by mutableStateOf("")
    var missionPaused by mutableStateOf(false)
    var confirm by mutableStateOf<ConfirmReq?>(null)
    var liveActive by mutableStateOf(false)
    var liveShot by mutableStateOf<androidx.compose.ui.graphics.ImageBitmap?>(null)
    var liveUrl by mutableStateOf("")
    var liveNote by mutableStateOf("")
    var activity: java.lang.ref.WeakReference<android.app.Activity>? = null
    var calls by mutableIntStateOf(0)
    var tokens by mutableLongStateOf(0L)

    private val h = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()

    fun ui(f: () -> Unit) {
        if (Looper.myLooper() == Looper.getMainLooper()) f() else h.post { f() }
    }

    fun think(msg: String) {
        thinkLog.add(msg)
        ui { thinking.add(msg); while (thinking.size > 50) thinking.removeAt(0) }
    }

    fun thinkSnapshot(): List<String> = thinkLog.toList().takeLast(50)

    fun clearThinking() {
        thinkLog.clear()
        ui { thinking.clear(); subAgents = emptyList(); stream = ""; liveActive = false; liveShot = null; liveNote = "" }
    }

    fun persist(c: Context) {
        val snap = turns.toList()
        val ctx = c.applicationContext
        val id = Hist.currentId(ctx)
        io.execute { try { Hist.save(ctx, snap, id) } catch (e: Exception) { android.util.Log.w("Bus", "persist failed", e) } }
    }

    fun add(c: Context, t: Turn) = ui { turns.add(t); persist(c) }
    fun background(f: () -> Unit) = io.execute { try { f() } catch (_: Exception) {} }
}

object Store {
    fun p(c: Context) = c.applicationContext.getSharedPreferences("swarm", Context.MODE_PRIVATE)
}

object Profiles {
    private fun load(c: Context): MutableList<Profile> {
        val p = Store.p(c)
        val out = ArrayList<Profile>()
        try {
            val raw = Vault.dec(p.getString("profiles_enc", "") ?: "")
            if (raw.isNotEmpty()) {
                val a = JSONArray(raw)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out.add(Profile(o.getString("n"), o.getString("u"), o.getString("k")))
                }
            }
        } catch (_: Exception) {
        }
        // Migrate the old plaintext single-endpoint settings once.
        val legacyUrl = p.getString("url", "") ?: ""
        if (out.isEmpty() && legacyUrl.isNotBlank()) {
            out.add(Profile("Default", legacyUrl, p.getString("key", "") ?: ""))
            write(c, out)
            p.edit().putString("profile", "Default").apply()
        }
        if (p.contains("key") || p.contains("idToken") || p.contains("url")) {
            p.edit().remove("key").remove("idToken").remove("url").apply()
        }
        return out
    }

    private fun write(c: Context, l: List<Profile>) {
        val a = JSONArray()
        l.forEach { a.put(JSONObject().put("n", it.name).put("u", it.url).put("k", it.key)) }
        Store.p(c).edit().putString("profiles_enc", Vault.enc(a.toString())).apply()
    }

    @Synchronized fun all(c: Context): List<Profile> = load(c)

    @Synchronized fun active(c: Context): Profile {
        val l = load(c)
        val n = Store.p(c).getString("profile", "") ?: ""
        return l.firstOrNull { it.name == n } ?: l.firstOrNull() ?: Profile("Default", "", "")
    }

    @Synchronized fun save(c: Context, pr: Profile) {
        val l = load(c)
        val i = l.indexOfFirst { it.name == pr.name }
        if (i >= 0) l[i] = pr else l.add(pr)
        write(c, l)
        Store.p(c).edit().putString("profile", pr.name).apply()
    }

    @Synchronized fun setActive(c: Context, name: String) {
        Store.p(c).edit().putString("profile", name).apply()
    }

    @Synchronized fun delete(c: Context, name: String) {
        val l = load(c).filter { it.name != name }
        write(c, l)
        if (Store.p(c).getString("profile", "") == name) Store.p(c).edit().putString("profile", l.firstOrNull()?.name ?: "").apply()
    }
}

class Db(ctx: Context) : SQLiteOpenHelper(ctx.applicationContext, "swarm.db", null, 2) {
    override fun onCreate(d: SQLiteDatabase) {
        d.execSQL("CREATE TABLE chats(id TEXT PRIMARY KEY, title TEXT, ts INTEGER, body TEXT)")
        d.execSQL("CREATE TABLE mem(id TEXT PRIMARY KEY, k TEXT, v TEXT, tags TEXT, ts INTEGER, pinned INTEGER)")
    }

    override fun onUpgrade(d: SQLiteDatabase, o: Int, n: Int) {
        // Future-safe: only additive changes. Never drop user data.
        if (o < 2) {
            // placeholder for v2 schema additions (none yet)
        }
    }

    companion object {
        @Volatile private var inst: Db? = null
        fun get(c: Context): Db = inst ?: synchronized(this) { inst ?: Db(c).also { inst = it } }
    }
}

object Hist {
    fun currentId(c: Context): String {
        val p = Store.p(c)
        return p.getString("chat_id", null) ?: UUID.randomUUID().toString().also { p.edit().putString("chat_id", it).apply() }
    }

    fun newChat(c: Context): String = UUID.randomUUID().toString().also { Store.p(c).edit().putString("chat_id", it).apply() }
    fun setCurrent(c: Context, id: String) = Store.p(c).edit().putString("chat_id", id).apply()

    fun title(l: List<Turn>): String = l.firstOrNull { it.user }?.text?.take(40) ?: "New chat"

    fun toJson(l: List<Turn>): String {
        val a = JSONArray()
        l.takeLast(100).forEach { t ->
            val x = JSONArray()
            t.answers.forEach { (i, s, n) -> x.put(JSONObject().put("i", i).put("s", s).put("n", n)) }
            val k = JSONArray(); t.thinking.forEach { k.put(it) }
            val m = JSONArray(); t.missionSteps.forEach { m.put(it) }
            a.put(JSONObject().put("u", t.user).put("t", t.text).put("w", t.winner).put("a", x).put("k", k).put("m", m))
        }
        return a.toString()
    }

    fun fromJson(s: String): List<Turn> = try {
        val a = JSONArray(s)
        (0 until a.length()).map {
            val o = a.getJSONObject(it)
            val x = o.optJSONArray("a") ?: JSONArray()
            val k = o.optJSONArray("k") ?: JSONArray()
            val m = o.optJSONArray("m") ?: JSONArray()
            Turn(
                o.getBoolean("u"), o.getString("t"), o.optString("w", ""),
                (0 until x.length()).map { j -> x.getJSONObject(j).let { q -> Triple(q.getString("i"), q.getString("s"), q.optInt("n", 0)) } },
                (0 until k.length()).map { j -> k.getString(j) },
                (0 until m.length()).map { j -> m.getString(j) }
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    @Synchronized fun upsert(c: Context, id: String, title: String, ts: Long, turns: List<Turn>) {
        Db.get(c).writableDatabase.execSQL(
            "INSERT OR REPLACE INTO chats(id,title,ts,body) VALUES(?,?,?,?)",
            arrayOf<Any?>(id, Vault.enc(title), ts, Vault.enc(toJson(turns)))
        )
    }

    @Synchronized fun save(c: Context, l: List<Turn>, id: String = currentId(c)) {
        if (l.none { it.user }) {
            Db.get(c).writableDatabase.execSQL("DELETE FROM chats WHERE id=?", arrayOf<Any?>(id))
            return
        }
        upsert(c, id, title(l), System.currentTimeMillis(), l)
    }

    @Synchronized fun load(c: Context, id: String = currentId(c)): List<Turn> {
        Db.get(c).readableDatabase.rawQuery("SELECT body FROM chats WHERE id=?", arrayOf(id)).use { cur ->
            return if (cur.moveToFirst()) fromJson(Vault.dec(cur.getString(0) ?: "")) else emptyList()
        }
    }

    @Synchronized fun list(c: Context): List<ChatInfo> {
        val out = ArrayList<ChatInfo>()
        Db.get(c).readableDatabase.rawQuery("SELECT id,title,ts FROM chats ORDER BY ts DESC", null).use { cur ->
            while (cur.moveToNext()) out.add(ChatInfo(cur.getString(0), Vault.dec(cur.getString(1) ?: ""), cur.getLong(2)))
        }
        return out
    }

    @Synchronized fun delete(c: Context, id: String) {
        Db.get(c).writableDatabase.execSQL("DELETE FROM chats WHERE id=?", arrayOf<Any?>(id))
    }
}

object Memory {
    private const val CAP = 5000
    private var cache: MutableList<MemoryItem>? = null

    @Synchronized private fun items(c: Context): MutableList<MemoryItem> {
        cache?.let { return it }
        val db = Db.get(c).writableDatabase
        // one-time migration from the old 200-item SharedPreferences store
        val p = Store.p(c)
        val legacy = p.getString("memory", null)
        if (legacy != null) {
            try {
                val a = JSONArray(legacy)
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    db.execSQL(
                        "INSERT OR IGNORE INTO mem(id,k,v,tags,ts,pinned) VALUES(?,?,?,?,?,0)",
                        arrayOf<Any?>(o.getString("id"), Vault.enc(o.getString("key")), Vault.enc(o.getString("value")), o.optString("tags", ""), o.optLong("ts", 0L))
                    )
                }
            } catch (_: Exception) {
            }
            p.edit().remove("memory").apply()
        }
        val out = ArrayList<MemoryItem>()
        db.rawQuery("SELECT id,k,v,tags,ts,pinned FROM mem ORDER BY ts DESC", null).use { cur ->
            while (cur.moveToNext()) {
                out.add(MemoryItem(cur.getString(0), Vault.dec(cur.getString(1) ?: ""), Vault.dec(cur.getString(2) ?: ""), cur.getString(3) ?: "", cur.getLong(4), cur.getInt(5) == 1))
            }
        }
        cache = out
        return out
    }

    @Synchronized fun all(c: Context): List<MemoryItem> = items(c).toList()

    @Synchronized fun save(c: Context, key: String, value: String, tags: String = "", pinned: Boolean = false, id: String? = null, ts: Long = System.currentTimeMillis()): MemoryItem {
        val list = items(c)
        val k = key.trim().take(120)
        val v = value.trim().take(2000)
        list.firstOrNull { it.key == k && it.value == v }?.let { return it }
        val t = tags.ifBlank { Parse.keywords("$k $v").take(6).joinToString(",") }
        val m = MemoryItem(id ?: UUID.randomUUID().toString().take(8), k, v, t, ts, pinned)
        Db.get(c).writableDatabase.execSQL(
            "INSERT OR REPLACE INTO mem(id,k,v,tags,ts,pinned) VALUES(?,?,?,?,?,?)",
            arrayOf<Any?>(m.id, Vault.enc(m.key), Vault.enc(m.value), m.tags, m.ts, if (m.pinned) 1 else 0)
        )
        list.removeAll { it.id == m.id }
        list.add(0, m)
        while (list.size > CAP) {
            val victim = list.lastOrNull { !it.pinned } ?: break
            list.remove(victim)
            Db.get(c).writableDatabase.execSQL("DELETE FROM mem WHERE id=?", arrayOf<Any?>(victim.id))
        }
        return m
    }

    @Synchronized fun delete(c: Context, id: String) {
        items(c).removeAll { it.id == id }
        Db.get(c).writableDatabase.execSQL("DELETE FROM mem WHERE id=?", arrayOf<Any?>(id))
    }

    @Synchronized fun setPinned(c: Context, id: String, pinned: Boolean) {
        val list = items(c)
        val i = list.indexOfFirst { it.id == id }
        if (i >= 0) list[i] = list[i].copy(pinned = pinned)
        Db.get(c).writableDatabase.execSQL("UPDATE mem SET pinned=? WHERE id=?", arrayOf<Any?>(if (pinned) 1 else 0, id))
    }

    /** Keyword-scored search (not a raw substring match of the whole question). */
    @Synchronized fun search(c: Context, q: String, limit: Int = 6): List<MemoryItem> {
        val toks = Parse.keywords(q)
        if (toks.isEmpty()) return emptyList()
        val now = System.currentTimeMillis()
        return items(c).map { m ->
            val key = m.key.lowercase(); val value = m.value.lowercase(); val tags = m.tags.lowercase()
            var s = 0
            for (t in toks) {
                if (tags.contains(t)) s += 3
                if (key.contains(t)) s += 2
                if (value.contains(t)) s += 1
            }
            if (s > 0) {
                if (m.pinned) s += 2
                if (now - m.ts < 7L * 24 * 3600 * 1000) s += 1
            }
            m to s
        }.filter { it.second > 0 }.sortedByDescending { it.second }.take(limit).map { it.first }
    }
}

object Backup {
    fun export(c: Context): String {
        val o = JSONObject().put("app", "SwarmDeck").put("version", 2)
        val mem = JSONArray()
        Memory.all(c).forEach {
            mem.put(JSONObject().put("id", it.id).put("key", it.key).put("value", it.value).put("tags", it.tags).put("ts", it.ts).put("pinned", it.pinned))
        }
        val chats = JSONArray()
        Hist.list(c).forEach { ci ->
            chats.put(JSONObject().put("id", ci.id).put("title", ci.title).put("ts", ci.ts).put("turns", JSONArray(Hist.toJson(Hist.load(c, ci.id)))))
        }
        return o.put("memory", mem).put("chats", chats).toString(2)
    }

    fun import(c: Context, json: String): String {
        val o = JSONObject(json)
        var m = 0; var ch = 0
        val mem = o.optJSONArray("memory") ?: JSONArray()
        for (i in 0 until mem.length()) {
            val x = mem.getJSONObject(i)
            Memory.save(c, x.getString("key"), x.getString("value"), x.optString("tags", ""), x.optBoolean("pinned", false), x.optString("id", "").ifBlank { null }, x.optLong("ts", System.currentTimeMillis()))
            m++
        }
        val chats = o.optJSONArray("chats") ?: JSONArray()
        for (i in 0 until chats.length()) {
            val x = chats.getJSONObject(i)
            Hist.upsert(c, x.getString("id"), x.optString("title", "Imported"), x.optLong("ts", System.currentTimeMillis()), Hist.fromJson(x.getJSONArray("turns").toString()))
            ch++
        }
        return "Imported $m memories, $ch chats"
    }
}
