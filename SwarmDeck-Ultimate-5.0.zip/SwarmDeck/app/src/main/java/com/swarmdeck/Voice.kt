package com.swarmdeck

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.widget.Toast
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import java.lang.ref.WeakReference
import java.util.Locale

/**
 * Hands-free voice loop: listen -> auto-send after silence -> agent runs -> speak answer ->
 * (mic muted while speaking, so it never hears itself) -> listen again.
 */
object Voice {
    private var tts: TextToSpeech? = null
    @Volatile private var ready = false
    private var rec: SpeechRecognizer? = null
    private var act: WeakReference<Activity>? = null
    private val main = Handler(Looper.getMainLooper())

    var continuous by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var speaking by mutableStateOf(false)
    var partial by mutableStateOf("")
    var onFinal: ((String) -> Unit)? = null

    fun attach(a: Activity) { act = WeakReference(a) }

    fun init(ctx: Context) {
        if (tts != null) return
        tts = TextToSpeech(ctx.applicationContext) { st ->
            if (st == TextToSpeech.SUCCESS) {
                ready = true
                tts?.language = Locale.getDefault()
                tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(id: String?) { main.post { speaking = true; destroyRec() } }
                    override fun onDone(id: String?) { main.post { speaking = false; resumeSoon() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(id: String?) { main.post { speaking = false; resumeSoon() } }
                })
            }
        }
    }

    /** Speaks [text]; returns false when TTS is unavailable. Safe to call from any thread. */
    fun speak(text: String): Boolean {
        val s = text.take(400).trim()
        if (!ready || s.isEmpty()) return false
        main.post { destroyRec() }
        return tts?.speak(s, TextToSpeech.QUEUE_FLUSH, null, "swarm-" + System.nanoTime()) == TextToSpeech.SUCCESS
    }

    fun stopSpeaking() {
        try { tts?.stop() } catch (_: Exception) {}
        main.post { speaking = false }
    }

    /** Called on the main thread when a run finishes. */
    fun afterRun(answer: String?) {
        val ctx = Bus.app
        val wantSpeech = ctx != null && Store.p(ctx).getBoolean("tts", true)
        if (answer != null && wantSpeech && speak(Parse.plain(answer))) return
        resumeSoon()
    }

    private fun resumeSoon() {
        main.postDelayed({ if (continuous && !Bus.running && !speaking) listen() }, 450)
    }

    fun startContinuous(a: Activity) {
        attach(a)
        continuous = true
        listen()
    }

    fun stopContinuous() {
        continuous = false
        listening = false
        partial = ""
        destroyRec()
    }

    fun onActivityStop() { destroyRec(); listening = false }
    fun onActivityStart(a: Activity) { attach(a); if (continuous) resumeSoon() }

    fun release() {
        stopContinuous()
        stopSpeaking()
        try { tts?.shutdown() } catch (_: Exception) {}
        tts = null
        ready = false
    }

    private fun toast(a: Activity, m: String) = Toast.makeText(a, m, Toast.LENGTH_SHORT).show()

    private fun destroyRec() {
        try { rec?.destroy() } catch (_: Exception) {}
        rec = null
        listening = false
    }

    private fun listen() {
        val a = act?.get() ?: return
        if (!continuous || speaking || Bus.running || (listening && rec != null)) return
        if (ContextCompat.checkSelfPermission(a, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            continuous = false; toast(a, "Microphone permission needed"); return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(a)) {
            continuous = false; toast(a, "Speech recognition not available on this device"); return
        }
        destroyRec()
        rec = SpeechRecognizer.createSpeechRecognizer(a).also { it.setRecognitionListener(listener) }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 1600L)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { rec?.startListening(i) } catch (e: Exception) { continuous = false; toast(a, "Mic error: ${e.message}") }
    }

    private fun handle(text: String?) {
        if (text.isNullOrBlank()) { resumeSoon(); return }
        var t: String = text
        val wake = Bus.app?.let { Store.p(it).getString("wake", "") }?.trim().orEmpty()
        if (wake.isNotEmpty()) {
            if (!t.startsWith(wake, true)) { resumeSoon(); return }
            t = t.substring(wake.length).trimStart(',', ' ', '.', ':')
        }
        if (t.isBlank()) { resumeSoon(); return }
        onFinal?.invoke(t)
        resumeSoon()
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { listening = true; partial = "" }
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() { listening = false }
        override fun onError(error: Int) {
            listening = false
            main.post { destroyRec() }
            if (!continuous) return
            if (error == SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS) { continuous = false; return }
            val delay = if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1200L else 400L
            main.postDelayed({ if (continuous && !Bus.running && !speaking) listen() }, delay)
        }
        override fun onResults(results: Bundle?) {
            listening = false
            val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()?.trim()
            partial = ""
            main.post { destroyRec() }
            handle(text)
        }
        override fun onPartialResults(partialResults: Bundle?) {
            partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull() ?: ""
        }
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }
}
