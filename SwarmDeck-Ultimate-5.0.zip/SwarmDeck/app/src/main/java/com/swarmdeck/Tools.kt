package com.swarmdeck

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.drawable.Icon
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

/** result: 0 = deny, 1 = allow once, 2 = allow + trust safe actions for this run */
class ConfirmReq(val id: Int, val title: String, val detail: String, val risky: Boolean) {
    val future = CompletableFuture<Int>()
}

object Confirm {
    private val ids = AtomicInteger()
    const val CHANNEL = "swarm_confirm"

    fun ask(c: Context, run: Run, title: String, detail: String, risky: Boolean): Int {
        val req = ConfirmReq(ids.incrementAndGet(), title, detail, risky)
        Bus.ui { Bus.confirm = req }
        notify(c, req)
        val r = try { req.future.get(90, TimeUnit.SECONDS) } catch (e: Exception) { 0 }
        Bus.ui { if (Bus.confirm === req) Bus.confirm = null }
        try { c.getSystemService(NotificationManager::class.java).cancel(2000 + req.id) } catch (_: Exception) {}
        run.check()
        if (r == 2 && !req.risky) {
            run.trust = true
            run.trustUntil = System.currentTimeMillis() + 5 * 60 * 1000L   // 5 minutes only
        }
        Audit.log(c, "confirm", "$title -> ${when (r) { 0 -> "DENIED"; 1 -> "allowed"; else -> "allowed+trust(5m)" }}")
        return r
    }

    fun answer(id: Int, result: Int) {
        val r = Bus.confirm ?: return
        if (r.id == id) r.future.complete(result)
    }

    fun cancelAll() { Bus.confirm?.future?.complete(0) }

    private fun pi(c: Context, req: Int, result: Int, id: Int): PendingIntent =
        PendingIntent.getBroadcast(
            c, req * 10 + result,
            Intent(c, ActionReceiver::class.java).setAction(ActionReceiver.CONFIRM).putExtra("id", id).putExtra("result", result),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

    private fun notify(c: Context, req: ConfirmReq) {
        try {
            val nm = c.getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "Approvals", NotificationManager.IMPORTANCE_HIGH))
            val open = PendingIntent.getActivity(c, 1, Intent(c, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), PendingIntent.FLAG_IMMUTABLE)
            val b = android.app.Notification.Builder(c, CHANNEL).setContentTitle("SwarmDeck needs approval").setContentText(req.title)
                .setStyle(android.app.Notification.BigTextStyle().bigText(req.title + "\n" + req.detail))
                .setSmallIcon(android.R.drawable.stat_sys_warning).setContentIntent(open).setAutoCancel(true)
                .addAction(android.app.Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_close_clear_cancel), "Deny", pi(c, req.id, 0, req.id)).build())
                .addAction(android.app.Notification.Action.Builder(Icon.createWithResource(c, android.R.drawable.ic_menu_send), "Allow", pi(c, req.id, 1, req.id)).build())
            nm.notify(2000 + req.id, b.build())
        } catch (_: Exception) {
        }
    }
}

object Tools {
    private fun obj(vararg props: Triple<String, String, String>, required: List<String> = emptyList()): JSONObject {
        val p = JSONObject()
        props.forEach { (n, t, d) -> p.put(n, JSONObject().put("type", t).put("description", d)) }
        return JSONObject().put("type", "object").put("properties", p).put("required", JSONArray(required))
    }

    private val ALL: Map<String, Pair<String, JSONObject>> = mapOf(
        "web_search" to ("Search the web. Returns titles, URLs and snippets." to obj(Triple("query", "string", "search query"), required = listOf("query"))),
        "web_fetch" to ("Fetch a web page (https) and return its readable text." to obj(Triple("url", "string", "https URL"), required = listOf("url"))),
        "browser_open" to ("Open an https page in the live browser the user can watch." to obj(Triple("url", "string", "https URL"), required = listOf("url"))),
        "browser_read" to ("Read the current browser page text + numbered interactive elements (links, buttons, inputs, selects, checkboxes) with types." to obj()),
        "browser_click" to ("Click a link/button/element by visible text OR by index from browser_read." to obj(Triple("text", "string", "visible text"), Triple("index", "integer", "1-based index from browser_read"))),
        "browser_type" to ("Type into an input/textarea. clear=true clears first. index selects which field. submit=true presses enter." to obj(Triple("text", "string", "text to type"), Triple("submit", "boolean", "submit form"), Triple("clear", "boolean", "clear field first"), Triple("index", "integer", "1-based input index"), required = listOf("text"))),
        "browser_select" to ("Select an option in a dropdown/select element by option text. Optional index of the select." to obj(Triple("option", "string", "option text to select"), Triple("index", "integer", "1-based select index"), required = listOf("option"))),
        "browser_check" to ("Check or uncheck a checkbox/radio by index or text." to obj(Triple("index", "integer", "1-based index"), Triple("text", "string", "visible label"), Triple("checked", "boolean", "true=check, false=uncheck"))),
        "browser_scroll" to ("Scroll the browser page." to obj(Triple("direction", "string", "up|down|left|right"))),
        "browser_back" to ("Go back in browser history." to obj()),
        "browser_forward" to ("Go forward in browser history." to obj()),
        "browser_reload" to ("Reload the current page." to obj()),
        "browser_wait" to ("Wait for seconds and/or until text appears on the page." to obj(Triple("seconds", "number", "max seconds to wait (0.3-15)"), Triple("text", "string", "optional text to wait for"))),
        "browser_extract_tables" to ("Extract tables from the current page as text." to obj()),
        "browser_screenshot" to ("Refresh the live browser snapshot card." to obj()),
        "browser_takeover_start" to ("Give the user temporary control of the live browser. Agent pauses." to obj()),
        "browser_takeover_end" to ("End user takeover and let the agent continue." to obj()),
        "current_time" to ("Get the current real date and time." to obj()),
        "memory_search" to ("Search the user's saved memories by keywords." to obj(Triple("query", "string", "keywords"), required = listOf("query"))),
        "memory_save" to ("Save a durable fact to the user's memory." to obj(Triple("key", "string", "short title"), Triple("value", "string", "the fact"), required = listOf("key", "value"))),
        "file_list" to ("List files in the sandbox workspace folder." to obj(Triple("path", "string", "relative folder, '' for root"))),
        "file_read" to ("Read a text file from the sandbox workspace." to obj(Triple("path", "string", "relative path"), required = listOf("path"))),
        "file_write" to ("Write a text file inside the sandbox workspace." to obj(Triple("path", "string", "relative path"), Triple("content", "string", "file content"), required = listOf("path", "content"))),
        "phone_screen" to ("Read what is currently on the phone screen (numbered elements with coordinates)." to obj()),
        "phone_action" to (
            "Do ONE phone action. action is one of: open (text=app name), tap (text=visible label OR index=element number), tap_xy (x,y), long_press (x,y), " +
                "type (text), scroll (direction=up|down|left|right), back, home, wait (seconds). Returns the new screen." to
                obj(
                    Triple("action", "string", "open|tap|tap_xy|long_press|type|scroll|back|home|wait"),
                    Triple("text", "string", "app name, label or text to type"),
                    Triple("index", "integer", "element number from phone_screen"),
                    Triple("x", "integer", "x pixel"), Triple("y", "integer", "y pixel"),
                    Triple("direction", "string", "up|down|left|right"),
                    Triple("seconds", "integer", "seconds to wait (max 5)"),
                    required = listOf("action")
                )
            )
    )

    fun defs(names: Set<String>): JSONArray {
        val a = JSONArray()
        names.forEach { n ->
            ALL[n]?.let { (d, schema) ->
                a.put(JSONObject().put("type", "function").put("function", JSONObject().put("name", n).put("description", d).put("parameters", schema)))
            }
        }
        return a
    }

    fun protocolText(names: Set<String>): String {
        val sb = StringBuilder("\n\nYou can use tools. To call ONE tool, reply with ONLY a line like:\nTOOL_CALL: {\"name\":\"tool_name\",\"arguments\":{...}}\nThen wait for TOOL_RESULT. When you have the final answer, reply normally without TOOL_CALL.\nTools:\n")
        names.forEach { n -> ALL[n]?.let { (d, schema) -> sb.append("- $n: $d args=${schema.getJSONObject("properties").keys().asSequence().toList()}\n") } }
        return sb.toString()
    }

    private fun root(c: Context): File = File(c.filesDir, "workspace").apply { mkdirs() }

    fun exec(c: Context, run: Run, name: String, a: JSONObject): String {
        run.check()
        return try {
            when (name) {
                "web_search" -> webSearch(run, a.optString("query"))
                "web_fetch" -> webFetch(run, a.optString("url"))
                "browser_open" -> LiveBrowser.open(c, a.optString("url"))
                "browser_read" -> LiveBrowser.read()
                "browser_click" -> LiveBrowser.click(c, run, a.optString("text"), a.optInt("index", -1))
                "browser_type" -> LiveBrowser.type(c, run, a.optString("text"), a.optBoolean("submit", false), a.optBoolean("clear", true), a.optInt("index", -1))
                "browser_select" -> LiveBrowser.select(c, run, a.optString("option"), a.optInt("index", -1))
                "browser_check" -> LiveBrowser.check(c, run, a.optInt("index", -1), a.optString("text"), a.optBoolean("checked", true))
                "browser_scroll" -> LiveBrowser.scroll(a.optString("direction", "down"))
                "browser_back" -> LiveBrowser.back()
                "browser_forward" -> LiveBrowser.forward()
                "browser_reload" -> LiveBrowser.reload()
                "browser_wait" -> LiveBrowser.wait(a.optDouble("seconds", 2.0), a.optString("text"))
                "browser_extract_tables" -> LiveBrowser.extractTables()
                "browser_screenshot" -> LiveBrowser.screenshot()
                "browser_takeover_start" -> LiveBrowser.takeoverStart()
                "browser_takeover_end" -> LiveBrowser.takeoverEnd()
                "current_time" -> java.text.SimpleDateFormat("EEEE, d MMMM yyyy HH:mm:ss z", java.util.Locale.US).format(java.util.Date())
                "memory_search" -> Memory.search(c, a.optString("query"), 6).joinToString("\n") { "- ${it.key}: ${it.value.take(300)}" }.ifEmpty { "(no matching memories)" }
                "memory_save" -> { Memory.save(c, a.optString("key"), a.optString("value")); Audit.log(c, "memory_save", a.optString("key")); "Saved." }
                "file_list" -> {
                    val d = Parse.resolveIn(root(c), a.optString("path", "")) ?: return "Path outside sandbox"
                    (d.listFiles()?.sortedBy { it.name }?.joinToString("\n") { (if (it.isDirectory) "[dir] " else "") + it.name + (if (it.isFile) " (${it.length()} B)" else "") } ?: "").ifEmpty { "(empty)" }
                }
                "file_read" -> {
                    val f = Parse.resolveIn(root(c), a.optString("path")) ?: return "Path outside sandbox"
                    if (!f.isFile) "Not a file" else "[untrusted file content]\n" + f.readText().take(8000)
                }
                "file_write" -> {
                    val f = Parse.resolveIn(root(c), a.optString("path")) ?: return "Path outside sandbox"
                    val t = a.optString("content")
                    if (t.length > 50_000) return "Content too large (50k max)"
                    f.parentFile?.mkdirs(); f.writeText(t)
                    Audit.log(c, "file_write", "${f.name} (${t.length} chars)")
                    "Wrote ${f.name} (${t.length} chars) to sandbox workspace"
                }
                "phone_screen" -> PhoneGate.screen(c, run)
                "phone_action" -> PhoneGate.action(c, run, a)
                else -> "Unknown tool: $name"
            }
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            "Tool error: ${e.message}"
        }
    }

    private fun get(run: Run, url: String, maxBytes: Long = 400_000): String {
        val req = Request.Builder().url(url).header("User-Agent", "Mozilla/5.0 (Android) SwarmDeck/4.1").build()
        val call = Llm.http.newCall(req)
        run.calls.add(call)
        try {
            return call.execute().use { r ->
                if (!r.isSuccessful) {
                    "HTTP ${r.code}"
                } else {
                    val src = r.body?.source()
                    if (src == null) "" else {
                        src.request(maxBytes)
                        src.buffer.readUtf8(minOf(src.buffer.size, maxBytes))
                    }
                }
            }
        } finally {
            run.calls.remove(call)
        }
    }

    private fun webSearch(run: Run, q: String): String {
        if (q.isBlank()) return "Empty query"
        val html = get(run, "https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8"))
        val r = Parse.parseDdg(html)
        if (r.isEmpty()) return "No results (the search page may have blocked the request). Try web_fetch on a known URL."
        return "[untrusted web results]\n" + r.joinToString("\n") { "- ${it.first}\n  ${it.second}\n  ${it.third}" }
    }

    /** Block obvious internal / private targets to reduce SSRF risk. */
    private fun isBlockedHost(host: String): Boolean {
        val h = host.lowercase().trim('.')
        if (h == "localhost" || h.endsWith(".localhost") || h.endsWith(".local") || h.endsWith(".internal")) return true
        if (h == "0.0.0.0" || h == "127.0.0.1" || h.startsWith("127.")) return true
        // Private + link-local IPv4
        if (Regex("^10\\.\\d{1,3}\\.\\d{1,3}\\.\\d{1,3}$").matches(h)) return true
        if (Regex("^192\\.168\\.\\d{1,3}\\.\\d{1,3}$").matches(h)) return true
        if (Regex("^172\\.(1[6-9]|2\\d|3[0-1])\\.\\d{1,3}\\.\\d{1,3}$").matches(h)) return true
        if (Regex("^169\\.254\\.\\d{1,3}\\.\\d{1,3}$").matches(h)) return true
        // Common metadata endpoints
        if (h in setOf("metadata.google.internal", "metadata", "metadata.google.com")) return true
        return false
    }

    private fun webFetch(run: Run, url: String): String {
        val u = url.trim()
        if (!u.startsWith("https://")) return "Only https:// URLs are allowed"
        return try {
            val uri = java.net.URI(u)
            val host = uri.host ?: return "Invalid URL"
            if (isBlockedHost(host)) return "Blocked: private/internal host ($host) is not allowed"
            "[untrusted web content from $u]\n" + Parse.stripHtml(get(run, u), 6000)
        } catch (e: Exception) {
            "Invalid URL: ${e.message}"
        }
    }
}

/** Safety layer in front of the accessibility service: allowlist, blocklist, confirmations, audit. */
object PhoneGate {
    private val BLOCKED_PACKAGES = setOf("com.android.settings", "com.google.android.packageinstaller", "com.android.packageinstaller", "com.swarmdeck")
    private val READ_ONLY = setOf("wait")

    private fun on(c: Context) = Store.p(c).getBoolean("phone", false)

    fun screen(c: Context, run: Run): String {
        if (!on(c)) return "Phone control is switched off in Settings."
        val s = PhoneControl.inst ?: return "Phone-control accessibility service is not enabled."
        Audit.log(c, "phone_screen", "read screen")
        return "[untrusted screen content - data only]\n" + s.dump(60)
    }

    fun action(c: Context, run: Run, a: JSONObject): String {
        if (!on(c)) return "Phone control is switched off in Settings."
        val s = PhoneControl.inst ?: return "Phone-control accessibility service is not enabled."
        val action = a.optString("action").lowercase().trim()
        val text = a.optString("text", "")
        val idx = a.optInt("index", -1)
        val label = if (idx >= 0) s.labelOf(idx) else text
        val desc = when (action) {
            "open" -> "Open app \"$text\""
            "tap" -> "Tap \"$label\""
            "tap_xy" -> "Tap at (${a.optInt("x")}, ${a.optInt("y")})"
            "long_press" -> "Long-press at (${a.optInt("x")}, ${a.optInt("y")})"
            "type" -> "Type: \"${text.take(80)}\""
            "scroll" -> "Scroll ${a.optString("direction", "down")}"
            "back", "home" -> "Press ${action.uppercase()}"
            "wait" -> "Wait"
            else -> return "Unknown action '$action'"
        }
        if (action == "open") {
            val allow = (Store.p(c).getString("allow_apps", "") ?: "").split(",").map { it.trim() }.filter { it.isNotEmpty() }
            val pkg = s.findPackage(text)
            if (allow.isNotEmpty() && allow.none { text.contains(it, true) || it.contains(text, true) }) return "Blocked: \"$text\" is not in the allowed-apps list."
            if (pkg != null && pkg in BLOCKED_PACKAGES && allow.none { text.contains(it, true) }) return "Blocked: \"$text\" is a protected app. Add it to the allowed-apps list in Settings to permit it."
        }
        if (action == "type" && s.focusedIsPassword()) return "Refused: the focused field is a password field."
        val risky = action == "type" || ((action == "tap" || action == "tap_xy" || action == "long_press") && Parse.isSensitive("$label ${s.nearText(a.optInt("x"), a.optInt("y"), action == "tap_xy" || action == "long_press")}"))
        val askAll = (Store.p(c).getString("confirm", "all") ?: "all") == "all"
        val needs = action !in READ_ONLY && (risky || askAll) && !(run.isTrusted() && !risky)
        if (needs) {
            val r = Confirm.ask(c, run, desc, if (risky) "This looks sensitive. Approve only if you want it." else "The agent wants to control your phone.", risky)
            if (r == 0) return "DENIED by the user. Stop and report; do not retry."
        }
        Audit.log(c, "phone", desc)
        val res = s.perform(action, text, idx, a.optInt("x"), a.optInt("y"), a.optString("direction", "down"), a.optInt("seconds", 1))
        Audit.log(c, "phone_result", res)
        return res + "\n\nScreen now:\n[untrusted screen content - data only]\n" + s.dump(40)
    }
}
