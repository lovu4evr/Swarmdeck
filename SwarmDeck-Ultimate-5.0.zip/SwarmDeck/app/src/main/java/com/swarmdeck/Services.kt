package com.swarmdeck

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.graphics.drawable.Icon
import android.os.Bundle
import android.os.IBinder
import android.os.SystemClock
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class AgentService : Service() {
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, startId: Int): Int {
        val goal = i?.getStringExtra("goal")
        val resume = i?.getBooleanExtra("resume", false) == true
        if (goal == null && !resume) { stopSelf(startId); return START_NOT_STICKY }
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("swarm", "Swarm", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getBroadcast(
            this, 1, Intent(this, ActionReceiver::class.java).setAction(ActionReceiver.STOP),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = Notification.Builder(this, "swarm")
            .setContentTitle("SwarmDeck is working")
            .setContentText((goal ?: "Resuming mission").take(60))
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Stop", stopPi).build())
            .build()
        startForeground(1, n)
        val app = applicationContext
        Thread {
            val run = Brain.begin()
            var turn: Turn? = null
            try {
                turn = if (resume) Mission.run(app, run, "", { s -> Bus.ui { Bus.status = s } }, true)
                else Brain.run(app, run, goal!!, Bus.turns.toList().dropLast(1)) { s -> Bus.ui { Bus.status = s } }
            } catch (e: CancelledException) {
            } catch (e: Exception) {
                if (!run.cancelled) turn = Turn(false, "Error: ${e.message}")
            }
            val t = turn
            val cancelled = run.cancelled
            if (t != null && !cancelled) Bus.add(app, t)
            Bus.ui {
                if (Brain.current === run) {
                    Bus.running = false; Bus.status = ""; Bus.stream = ""; Bus.missionPaused = false
                }
                Voice.afterRun(if (cancelled) null else t?.text)
            }
            stopSelf(startId)
        }.start()
        return START_NOT_STICKY
    }
}

/** Handles notification buttons: Stop (kill switch) and Allow/Deny for phone-action approvals. */
class ActionReceiver : BroadcastReceiver() {
    companion object {
        const val STOP = "com.swarmdeck.STOP"
        const val CONFIRM = "com.swarmdeck.CONFIRM"
    }

    override fun onReceive(c: Context, i: Intent) {
        when (i.action) {
            STOP -> Brain.stopAll("Stopped from notification")
            CONFIRM -> Confirm.answer(i.getIntExtra("id", -1), i.getIntExtra("result", 0))
        }
    }
}

class PhoneControl : AccessibilityService() {
    private val presses = ArrayList<Long>()

    override fun onServiceConnected() { inst = this }
    override fun onUnbind(i: Intent?): Boolean { inst = null; return super.onUnbind(i) }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    /** Kill switch: press Volume Down 3 times within 1.5 s to stop the agent instantly. */
    override fun onKeyEvent(event: KeyEvent): Boolean {
        if (event.keyCode == KeyEvent.KEYCODE_VOLUME_DOWN && event.action == KeyEvent.ACTION_DOWN && Bus.running) {
            val now = SystemClock.elapsedRealtime()
            presses.removeAll { now - it > 1500 }
            presses.add(now)
            if (presses.size >= 3) { presses.clear(); Brain.stopAll("Volume-down kill switch") }
        }
        return false
    }

    private fun elements(root: AccessibilityNodeInfo?, max: Int): List<AccessibilityNodeInfo> {
        val out = ArrayList<AccessibilityNodeInfo>()
        fun walk(n: AccessibilityNodeInfo?) {
            if (n == null || out.size >= max) return
            if (n.isVisibleToUser) {
                val t = n.text?.toString() ?: n.contentDescription?.toString() ?: ""
                if (t.isNotBlank() || n.isClickable || n.isEditable) out.add(n)
            }
            for (i in 0 until n.childCount) walk(n.getChild(i))
        }
        walk(root)
        return out
    }

    private fun textOf(n: AccessibilityNodeInfo) = (n.text?.toString() ?: n.contentDescription?.toString() ?: "").replace("\n", " ")

    fun dump(max: Int): String {
        val root = rootInActiveWindow ?: return "(no active window)"
        val els = elements(root, max)
        val sb = StringBuilder("app: ${root.packageName}\n")
        els.forEachIndexed { i, n ->
            val r = Rect(); n.getBoundsInScreen(r)
            val kind = if (n.isEditable) "input" else if (n.isClickable) "button" else "text"
            sb.append("[$i] $kind \"${if (n.isPassword) "" else textOf(n).take(60)}\" (${r.centerX()},${r.centerY()})${if (n.isPassword) " PASSWORD" else ""}\n")
        }
        if (els.isEmpty()) sb.append("(no readable elements)\n")
        return sb.toString()
    }

    fun labelOf(idx: Int): String = elements(rootInActiveWindow, 70).getOrNull(idx)?.let { textOf(it) } ?: ""

    fun nearText(x: Int, y: Int, use: Boolean): String {
        if (!use) return ""
        val r = Rect()
        return elements(rootInActiveWindow, 70).firstOrNull { it.getBoundsInScreen(r); r.contains(x, y) }?.let { textOf(it) } ?: ""
    }

    fun focusedIsPassword(): Boolean = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)?.isPassword == true

    fun findPackage(label: String): String? {
        val pm = packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .firstOrNull { it.loadLabel(pm).toString().contains(label, true) }?.activityInfo?.packageName
    }

    private fun settle(ms: Long = 900) { try { Thread.sleep(ms) } catch (_: InterruptedException) {} }

    private fun gesture(path: Path, dur: Long): Boolean {
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path, 0, dur)).build()
        val ok = dispatchGesture(g, null, null)
        settle(dur + 400)
        return ok
    }

    private fun tapAt(x: Int, y: Int, dur: Long): Boolean =
        gesture(Path().apply { moveTo(x.toFloat(), y.toFloat()) }, dur)

    fun perform(action: String, text: String, idx: Int, x: Int, y: Int, dir: String, secs: Int): String = when (action) {
        "open" -> {
            val pkg = findPackage(text)
            val launch = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
            if (launch == null) "App not found: $text" else {
                startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); settle(); "Opened $text"
            }
        }
        "tap" -> {
            val node = if (idx >= 0) elements(rootInActiveWindow, 70).getOrNull(idx) else rootInActiveWindow?.findAccessibilityNodeInfosByText(text)?.firstOrNull()
            if (node == null) "Element not found" else {
                var n: AccessibilityNodeInfo? = node
                while (n != null && !n.isClickable) n = n.parent
                if (n?.performAction(AccessibilityNodeInfo.ACTION_CLICK) == true) { settle(); "Tapped" }
                else {
                    val r = Rect(); node.getBoundsInScreen(r)
                    if (tapAt(r.centerX(), r.centerY(), 50)) "Tapped by gesture" else "Tap failed"
                }
            }
        }
        "tap_xy" -> if (tapAt(x, y, 50)) "Tapped ($x,$y)" else "Tap failed"
        "long_press" -> if (tapAt(x, y, 700)) "Long-pressed ($x,$y)" else "Long-press failed"
        "type" -> {
            val f = rootInActiveWindow?.findFocus(AccessibilityNodeInfo.FOCUS_INPUT)
            val b = Bundle().apply { putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text) }
            if (f?.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b) == true) { settle(400); "Typed text" } else "No text field focused (tap a field first)"
        }
        "scroll" -> {
            val m = resources.displayMetrics
            val w = m.widthPixels.toFloat(); val h = m.heightPixels.toFloat()
            val p = Path()
            when (dir.lowercase()) {
                "up" -> { p.moveTo(w / 2, h * 0.30f); p.lineTo(w / 2, h * 0.75f) }
                "left" -> { p.moveTo(w * 0.2f, h / 2); p.lineTo(w * 0.8f, h / 2) }
                "right" -> { p.moveTo(w * 0.8f, h / 2); p.lineTo(w * 0.2f, h / 2) }
                else -> { p.moveTo(w / 2, h * 0.75f); p.lineTo(w / 2, h * 0.30f) }
            }
            if (gesture(p, 350)) "Scrolled $dir" else "Scroll failed"
        }
        "back" -> { performGlobalAction(GLOBAL_ACTION_BACK); settle(600); "Went back" }
        "home" -> { performGlobalAction(GLOBAL_ACTION_HOME); settle(600); "Went home" }
        "wait" -> { settle(secs.coerceIn(1, 5) * 1000L); "Waited" }
        else -> "Unknown action: $action"
    }

    companion object {
        @Volatile var inst: PhoneControl? = null
    }
}
