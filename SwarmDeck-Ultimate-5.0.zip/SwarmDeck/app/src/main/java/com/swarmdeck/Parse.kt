package com.swarmdeck

import org.json.JSONObject
import java.io.File

/** Pure-Kotlin helpers (no Android dependencies) so they can be unit-tested on the JVM. */
data class MdBlock(val code: Boolean, val lang: String, val text: String)
data class Meta(val answer: String, val scores: Map<String, Int>, val winner: String?)
data class Verdict(val kind: String, val reason: String)

object Parse {
    private val STOP = setOf(
        "the", "and", "for", "with", "that", "this", "what", "how", "can", "you", "are", "was", "have", "has",
        "not", "but", "from", "about", "your", "please", "tell", "give", "make", "want", "need", "would", "could",
        "should", "into", "when", "where", "which", "who", "why", "does", "did", "them", "they", "then", "than",
        "will", "just", "also", "any", "all", "its", "our", "out", "get", "got", "let"
    )

    fun keywords(q: String): List<String> =
        Regex("[\\p{L}\\p{N}_]+").findAll(q.lowercase()).map { it.value }
            .filter { it.length >= 3 && it !in STOP }.distinct().take(12).toList()

    /** Parse "AGENTS: a, b, c" from the head agent, keeping only valid ids, in order of mention. */
    fun parseAgents(out: String, valid: Collection<String>, max: Int): List<String> {
        val line = out.lines().firstOrNull { it.contains("AGENTS", true) } ?: out
        val after = if (line.contains(":")) line.substringAfter(":") else line
        return valid.mapNotNull { id ->
            Regex("\\b" + Regex.escape(id) + "\\b").find(after)?.let { id to it.range.first }
        }.sortedBy { it.second }.map { it.first }.take(max)
    }

    fun parseNewAgent(out: String): Triple<String, String, String>? {
        val l = out.lines().firstOrNull { it.trim().startsWith("NEW_AGENT:", true) } ?: return null
        val bits = l.substringAfter(":").split("|").map { it.trim() }
        if (bits.size < 3) return null
        return Triple(bits[0], bits[1], bits.drop(2).joinToString(" | "))
    }

    private val BAD_AGENT = listOf(
        "ignore previous", "ignore all", "system prompt", "disregard", "jailbreak", "phone", "operator",
        "action:", "tool_call", "password", "sudo", "exfiltrat", "api key", "apikey"
    )

    /** Validate/sanitize a model-proposed specialist. Returns null if it should be rejected. */
    fun cleanAgent(name: String, role: String, prompt: String): Triple<String, String, String>? {
        val n = name.replace(Regex("[^A-Za-z0-9 ]"), "").trim().take(20)
        if (n.length < 2) return null
        val r = role.replace(Regex("[\\r\\n]+"), " ").trim().take(80)
        val p = prompt.replace(Regex("[\\r\\n]+"), " ").trim().take(300)
        if (r.isEmpty() || p.length < 10) return null
        val low = "$n $r $p".lowercase()
        if (BAD_AGENT.any { low.contains(it) }) return null
        return Triple(n, r, p)
    }

    fun parseSteps(plan: String, max: Int = 8): List<String> =
        plan.lines().map { it.trim().replace("**", "") }
            .filter { Regex("^\\d+[.)]\\s*.+").matches(it) }
            .map { it.replace(Regex("^\\d+[.)]\\s*"), "").trim() }
            .take(max)

    fun parseMeta(full: String): Meta {
        val i = full.indexOf("###META")
        if (i < 0) return Meta(full.trim(), emptyMap(), null)
        val meta = full.substring(i)
        val scores = Regex("([A-Za-z0-9_]+)\\s*:\\s*(\\d{1,2})")
            .findAll(meta.substringBefore("winner"))
            .associate { it.groupValues[1] to it.groupValues[2].toInt() }
        val w = Regex("winner\\s*=\\s*([A-Za-z0-9_]+)").find(meta)?.groupValues?.get(1)
        return Meta(full.substring(0, i).trim(), scores, w)
    }

    /** Hide the META trailer (and a partially streamed marker) from live text. */
    fun stripMeta(s: String): String {
        val marker = "###META"
        val i = s.indexOf(marker)
        if (i >= 0) return s.substring(0, i).trimEnd()
        for (k in minOf(marker.length - 1, s.length) downTo 1) {
            if (s.endsWith(marker.substring(0, k))) return s.substring(0, s.length - k).trimEnd()
        }
        return s
    }

    /** Fallback tool protocol: a line "TOOL_CALL: {"name":"x","arguments":{...}}". */
    fun parseToolCall(text: String): Pair<String, JSONObject>? {
        val i = text.indexOf("TOOL_CALL:")
        if (i < 0) return null
        val s = text.indexOf('{', i)
        if (s < 0) return null
        var depth = 0
        var inStr = false
        var esc = false
        for (k in s until text.length) {
            val ch = text[k]
            if (inStr) {
                if (esc) esc = false else if (ch == '\\') esc = true else if (ch == '"') inStr = false
            } else if (ch == '"') {
                inStr = true
            } else if (ch == '{') {
                depth++
            } else if (ch == '}') {
                depth--
                if (depth == 0) {
                    return try {
                        val o = JSONObject(text.substring(s, k + 1))
                        val name = o.optString("name")
                        if (name.isEmpty()) null else name to (o.optJSONObject("arguments") ?: JSONObject())
                    } catch (e: Exception) {
                        null
                    }
                }
            }
        }
        return null
    }

    fun parseVerdict(t: String): Verdict {
        val m = Regex("(PASS|RETRY|REPLAN|BLOCKED)\\s*:?\\s*(.*)", RegexOption.IGNORE_CASE).find(t.trim())
            ?: return Verdict("PASS", "")
        return Verdict(m.groupValues[1].uppercase(), m.groupValues[2].trim().take(200))
    }

    private val RISKY = Regex(
        "\\b(pay|payment|purchase|buy|order|checkout|transfer|delete|remove|uninstall|install|reset|sign out|log out|" +
            "logout|confirm|submit|post|publish|send|call|dial|allow|grant|unlock|bank|wallet|password|pin|otp|cvv|" +
            "accessibility|permission|permissions)\\b", RegexOption.IGNORE_CASE
    )

    fun isSensitive(s: String) = RISKY.containsMatchIn(s)

    fun splitMd(text: String): List<MdBlock> {
        val out = ArrayList<MdBlock>()
        val buf = StringBuilder()
        var inCode = false
        var lang = ""
        for (line in text.lines()) {
            if (line.trimStart().startsWith("```")) {
                if (inCode) {
                    out.add(MdBlock(true, lang, buf.toString().trimEnd('\n')))
                    buf.clear()
                    inCode = false
                } else {
                    if (buf.isNotEmpty()) {
                        out.add(MdBlock(false, "", buf.toString().trimEnd('\n')))
                        buf.clear()
                    }
                    inCode = true
                    lang = line.trim().removePrefix("```").trim()
                }
            } else buf.appendLine(line)
        }
        if (buf.isNotEmpty()) out.add(MdBlock(inCode, if (inCode) lang else "", buf.toString().trimEnd('\n')))
        return out
    }

    /** Text suitable for text-to-speech. */
    fun plain(t: String): String =
        t.replace(Regex("```[\\s\\S]*?```"), " code block. ")
            .replace(Regex("\\[(.*?)]\\(.*?\\)"), "\$1")
            .replace(Regex("[*#_`>|]+"), "")
            .replace(Regex("\\s+"), " ").trim()

    fun urlProblem(u: String): String? {
        val s = u.trim()
        if (s.isEmpty()) return "Set API base URL in Settings"
        if (s.startsWith("https://")) return null
        if (s.startsWith("http://")) {
            val host = s.removePrefix("http://").substringBefore("/").substringBefore(":")
            return if (host in setOf("localhost", "127.0.0.1", "10.0.2.2")) null
            else "Plain http:// is blocked for security. Use https:// (or localhost)."
        }
        return "URL must start with https://"
    }

    /** Resolve [rel] inside [root]; null if it would escape the sandbox. */
    fun resolveIn(root: File, rel: String): File? {
        val r = root.canonicalFile
        val f = File(r, rel.trim().trimStart('/')).canonicalFile
        return if (f == r || f.path.startsWith(r.path + File.separator)) f else null
    }

    fun stripHtml(h: String, max: Int = 6000): String {
        val s = h.replace(Regex("(?is)<(script|style|noscript|svg)[^>]*>.*?</\\1>"), " ")
            .replace(Regex("(?s)<!--.*?-->"), " ")
            .replace(Regex("(?s)<[^>]+>"), " ")
            .replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&#39;", "'").replace("&nbsp;", " ")
            .replace(Regex("\\s+"), " ").trim()
        return s.take(max)
    }

    fun parseDdg(html: String): List<Triple<String, String, String>> {
        val link = Regex("(?s)<a[^>]*class=\"result__a\"[^>]*href=\"([^\"]+)\"[^>]*>(.*?)</a>")
        val snip = Regex("(?s)class=\"result__snippet\"[^>]*>(.*?)</a>")
        val snips = snip.findAll(html).map { stripHtml(it.groupValues[1], 300) }.toList()
        val res = ArrayList<Triple<String, String, String>>()
        link.findAll(html).forEachIndexed { i, m ->
            var u = m.groupValues[1]
            val q = Regex("uddg=([^&]+)").find(u)
            if (q != null) u = java.net.URLDecoder.decode(q.groupValues[1], "UTF-8")
            if (u.startsWith("//")) u = "https:$u"
            res.add(Triple(stripHtml(m.groupValues[2], 150), u, snips.getOrElse(i) { "" }))
        }
        return res.take(6)
    }
}
