package com.swarmdeck

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Real mission engine: plan -> execute each step with tools -> verify -> retry / replan / block.
 * State is persisted so an unfinished mission can be resumed after the app is closed.
 */
object Mission {
    private const val KEY = "mission_enc"
    private const val BUDGET = 40

    fun saved(c: Context): Pair<String, List<MStep>>? = try {
        val raw = Vault.dec(Store.p(c).getString(KEY, "") ?: "")
        if (raw.isEmpty()) null else {
            val o = JSONObject(raw)
            val a = o.getJSONArray("steps")
            val steps = (0 until a.length()).map { a.getJSONObject(it).let { s -> MStep(s.getString("t"), s.getString("s"), s.optString("r", "")) } }
            if (steps.all { it.status == "DONE" }) null else o.getString("obj") to steps
        }
    } catch (e: Exception) {
        null
    }

    fun clear(c: Context) { Store.p(c).edit().remove(KEY).apply() }

    private fun persist(c: Context, obj: String, steps: List<MStep>) {
        val a = JSONArray()
        steps.forEach { a.put(JSONObject().put("t", it.text).put("s", it.status).put("r", it.result)) }
        Store.p(c).edit().putString(KEY, Vault.enc(JSONObject().put("obj", obj).put("steps", a).toString())).apply()
    }

    private fun toolsFor(step: String): Set<String> {
        val base = WEB_TOOLS + MEM_TOOLS + FILE_TOOLS
        return if (step.uppercase().contains("[PHONE]")) base + PHONE_TOOLS else base
    }

    private fun icon(s: String) = when (s) { "DONE" -> "✓"; "BLOCKED" -> "✗"; "SKIPPED" -> "–"; "RUNNING", "RETRY" -> "…"; else -> "○" }

    fun run(c: Context, run: Run, objective: String, status: (String) -> Unit, resume: Boolean): Turn {
        var obj = objective
        var steps: MutableList<MStep>
        if (resume) {
            val s = saved(c) ?: return Turn(false, "No saved mission to resume.")
            obj = s.first
            steps = s.second.map { if (it.status == "DONE") it else it.copy(status = "PENDING") }.toMutableList()
        } else {
            status("Planning mission…")
            Bus.think("Building mission plan…")
            val plan = Llm.chat(
                c, run, "agent",
                "You are Mission Controller. Break the objective into 3-8 concrete sequential steps. Each step must be doable with tools (web research, sandbox files, memory) or by reasoning. " +
                    "Tag a step [PHONE] only if it needs controlling the phone, [WEB] if it needs web research. Reply with a numbered list only.", obj
            )
            val texts = Parse.parseSteps(plan).ifEmpty { listOf(obj) }
            steps = texts.map { MStep(it, "PENDING") }.toMutableList()
        }
        fun publish() {
            val snap = steps.toList()
            persist(c, obj, snap)
            Bus.ui { Bus.mission = snap; Bus.missionObjective = obj }
        }
        publish()
        Bus.think("Mission has ${steps.size} steps")

        var calls = 0
        var replans = 0
        var idx = 0
        var halted = false
        while (idx < steps.size && !halted) {
            run.check()
            while (Bus.missionPaused) {
                status("Mission paused")
                try { Thread.sleep(300) } catch (_: InterruptedException) {}
                run.check()
            }
            if (steps[idx].status == "DONE") { idx++; continue }
            if (calls >= BUDGET) {
                steps[idx] = steps[idx].copy(status = "BLOCKED", result = "Call budget reached"); publish(); break
            }
            val step = steps[idx]
            steps[idx] = step.copy(status = "RUNNING"); publish()
            status("Step ${idx + 1}/${steps.size}: ${step.text.take(60)}")
            Bus.think("Step ${idx + 1}: ${step.text.take(80)}")

            var feedback = ""
            var attempt = 0
            var result = ""
            var outcome = Verdict("PASS", "")
            while (true) {
                attempt++
                val prior = steps.take(idx).filter { it.status == "DONE" }.joinToString("\n") { "- ${it.text}: ${it.result}" }
                val tools = toolsFor(step.text)
                val sys = "You are executing ONE step of a mission.\nObjective: $obj\nCompleted so far:\n${prior.ifEmpty { "(nothing yet)" }}\n\n" +
                    "Do ONLY this step now: ${step.text}\nUse tools when needed. Return a concise result (facts found, file names, outcome). " +
                    "If you cannot complete it, say exactly what blocked you." + Brain.suf()
                result = Brain.toolLoop(c, run, "agent", sys, emptyList(), "Execute the step.$feedback", tools, if ("phone_action" in tools) 12 else 6)
                calls += 3
                val raw = Llm.chat(
                    c, run, "verify",
                    "You verify mission steps. Reply with ONE line: PASS | RETRY: <what to fix> | REPLAN: <why the plan must change> | BLOCKED: <why it is impossible>.",
                    "Step: ${step.text}\n\nResult:\n${result.take(1500)}"
                )
                calls++
                outcome = Parse.parseVerdict(raw)
                if (outcome.kind == "RETRY" && attempt < 3) {
                    feedback = "\n\nPrevious attempt problem: ${outcome.reason}. Fix it."
                    steps[idx] = steps[idx].copy(status = "RETRY"); publish()
                    Bus.think("Retry step ${idx + 1}: ${outcome.reason}")
                    continue
                }
                break
            }
            when (outcome.kind) {
                "PASS" -> { steps[idx] = steps[idx].copy(status = "DONE", result = result.take(600)); idx++ }
                "REPLAN" -> {
                    if (replans < 2) {
                        replans++
                        Bus.think("Replanning: ${outcome.reason}")
                        val done = steps.take(idx).filter { it.status == "DONE" }.joinToString("\n") { "- ${it.text}: ${it.result.take(150)}" }
                        val np = Llm.chat(
                            c, run, "agent",
                            "You are Mission Controller. Re-plan the REMAINING steps (max 6) as a numbered list only. Tag [PHONE]/[WEB] where needed.",
                            "Objective: $obj\nDone:\n${done.ifEmpty { "(nothing)" }}\nProblem: ${outcome.reason}\nLast result: ${result.take(400)}"
                        )
                        calls++
                        val nt = Parse.parseSteps(np, 6)
                        if (nt.isEmpty()) { steps[idx] = steps[idx].copy(status = "BLOCKED", result = outcome.reason); halted = true }
                        else steps = (steps.take(idx) + nt.map { MStep(it, "PENDING") }).toMutableList()
                    } else {
                        steps[idx] = steps[idx].copy(status = "BLOCKED", result = "Replan limit: ${outcome.reason}"); halted = true
                    }
                }
                else -> { steps[idx] = steps[idx].copy(status = "BLOCKED", result = "${result.take(300)} (${outcome.reason})"); halted = true }
            }
            publish()
        }

        run.check()
        status("Writing mission report…")
        val log = steps.joinToString("\n") { "${it.status}: ${it.text}\n${it.result}" }
        val report = try {
            Brain.streamTo(
                c, run, "synth",
                "Write the final mission report for the user in markdown, in the language of the objective: what was achieved, key results, and anything blocked or needing the user's action. Be concise and honest about failures." + Brain.suf(),
                "Objective: $obj\n\nStep log:\n$log", emptyList()
            )
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            "Mission finished with errors:\n$log"
        }
        if (steps.all { it.status == "DONE" }) clear(c) else persist(c, obj, steps)
        Bus.think("Mission complete")
        return Turn(false, report, "mission", emptyList(), Bus.thinkSnapshot(), steps.map { "${icon(it.status)} ${it.text}" })
    }
}
