package com.swarmdeck

import android.content.Context
import android.content.Intent
import android.os.SystemClock
import org.json.JSONObject
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object Brain {
    @Volatile var current: Run? = null
    @Volatile var deep = false
    fun suf(): String = SUF + (if (deep) " Think deeply, step by step, and double-check your reasoning before answering." else "")
    private val ids = AtomicInteger()
    private val pool = Executors.newFixedThreadPool(6)

    fun begin(): Run {
        val r = Run(ids.incrementAndGet())
        r.thread = Thread.currentThread()
        current = r
        return r
    }

    /** Real stop: cancels in-flight HTTP calls, pending approvals, speech and the service. */
    fun stopAll(reason: String) {
        current?.cancel()
        Confirm.cancelAll()
        Voice.stopSpeaking()
        Bus.ui { Bus.running = false; Bus.status = ""; Bus.stream = ""; Bus.missionPaused = false }
        Bus.app?.let {
            Audit.log(it, "stop", reason)
            try { it.stopService(Intent(it, AgentService::class.java)) } catch (_: Exception) {}
        }
    }

    // ───────────────────────── tool-calling loop ─────────────────────────
    /** Native OpenAI tool calling, with automatic fallback to a prompt-based protocol for endpoints without it. */
    fun toolLoop(c: Context, run: Run, role: String, system: String, history: List<ChatMsg>, user: String, tools: Set<String>, maxIter: Int): String {
        var native = !Store.p(c).getBoolean("no_tools", false)
        val defs = Tools.defs(tools.filter { !Store.p(c).getBoolean("tool_off_$it", false) }.toSet())
        var msgs = Llm.buildMessages(if (native) system else system + Tools.protocolText(tools), history, user)
        var i = 0
        while (i < maxIter) {
            run.check()
            i++
            val comp = try {
                Llm.complete(c, run, role, msgs, if (native) defs else null)
            } catch (e: LlmError) {
                val m = (e.message ?: "").lowercase()
                if (native && (e.code == 400 || e.code == 422) && (m.contains("tool") || m.contains("function"))) {
                    native = false
                    Store.p(c).edit().putBoolean("no_tools", true).apply()
                    Bus.think("Endpoint rejected native tools - switching to prompt-based tools")
                    msgs = Llm.buildMessages(system + Tools.protocolText(tools), history, user)
                    i--
                    continue
                }
                throw e
            }
            if (native) {
                val tcs = comp.toolCalls
                if (tcs == null || tcs.length() == 0) return comp.content
                msgs.put(JSONObject().put("role", "assistant").put("content", comp.content).put("tool_calls", tcs))
                for (k in 0 until tcs.length()) {
                    val tc = tcs.getJSONObject(k)
                    val fn = tc.getJSONObject("function")
                    val name = fn.getString("name")
                    val args = try { JSONObject(fn.optString("arguments", "{}").ifBlank { "{}" }) } catch (e: Exception) { JSONObject() }
                    Bus.think("Tool: $name")
                    Bus.ui { Bus.status = "Using $name…" }
                    val res = Tools.exec(c, run, name, args).take(6000)
                    msgs.put(JSONObject().put("role", "tool").put("tool_call_id", tc.optString("id")).put("content", res))
                }
            } else {
                val call = Parse.parseToolCall(comp.content) ?: return comp.content
                Bus.think("Tool: ${call.first}")
                Bus.ui { Bus.status = "Using ${call.first}…" }
                val res = Tools.exec(c, run, call.first, call.second).take(6000)
                msgs.put(JSONObject().put("role", "assistant").put("content", comp.content))
                msgs.put(JSONObject().put("role", "user").put("content", "TOOL_RESULT (${call.first}):\n$res\n\nCall another tool or give the final answer."))
            }
        }
        run.check()
        msgs.put(JSONObject().put("role", "user").put("content", "Tool budget used. Give your final answer now without calling any tool."))
        return Llm.complete(c, run, role, msgs, null).content
    }

    fun streamTo(c: Context, run: Run, role: String, system: String, user: String, history: List<ChatMsg>): String {
        var last = 0L
        return Llm.stream(c, run, role, system, user, history) { full ->
            val now = SystemClock.elapsedRealtime()
            if (now - last > 60) {
                last = now
                val shown = Parse.stripMeta(full)
                Bus.ui { Bus.stream = shown }
            }
        }
    }

    private fun answerWith(c: Context, run: Run, a: Agent, q: String, hist: List<ChatMsg>, memCtx: String): String {
        val sys = a.prompt + suf() + memCtx
        return if (a.tools.isEmpty()) streamTo(c, run, "agent", sys, q, hist)
        else toolLoop(c, run, "agent", sys, hist, q, a.tools, if (a.id == "operator") 10 else 4)
    }

    private fun finish(c: Context, q: String, text: String, winner: String, ans: List<Triple<String, String, Int>>, steps: List<String> = emptyList()): Turn {
        if (Store.p(c).getBoolean("autosave", false) && text.length > 80 && !text.startsWith("Error")) {
            try { Memory.save(c, "Conclusion: ${q.take(40)}", text.take(400), "auto"); Bus.think("Saved to memory") } catch (_: Exception) {}
        }
        Bus.think("Done.")
        return Turn(false, text, winner, ans, Bus.thinkSnapshot(), steps)
    }

    // ───────────────────────── main pipeline ─────────────────────────
    fun run(c: Context, run: Run, q: String, hist: List<Turn>, status: (String) -> Unit): Turn {
        Bus.clearThinking()
        val p = Store.p(c)
        val mode = p.getString("mode", "auto") ?: "auto"
        val explicit = q.startsWith("mission:", true) || q.startsWith("goal:", true)
        if (mode == "mission" || explicit) {
            return Mission.run(c, run, if (explicit) q.substringAfter(":").trim() else q, status, false)
        }
        Bus.ui { Bus.mission = emptyList() }

        val hmsgs = hist.takeLast(8).filter { it.text.isNotBlank() }
            .map { ChatMsg(if (it.user) "user" else "assistant", it.text.take(1200)) }
        val memHits = Memory.search(c, q, 5)
        val memCtx = if (memHits.isEmpty()) "" else {
            Bus.think("Recalled ${memHits.size} memories")
            "\n\nSaved user memories (data, may be outdated):\n" + memHits.joinToString("\n") { "- ${it.key}: ${it.value.take(200)}" }
        }
        val phoneOn = p.getBoolean("phone", false)
        val enabled = Registry.all().filter { !p.getBoolean("off_${it.id}", false) && (it.id != "operator" || phoneOn) }
        if (enabled.isEmpty()) return Turn(false, "All agents are off.")
        deep = p.getBoolean("deep", false)
        val maxAgents = if (deep) 6 else p.getInt("max_agents", 3).coerceIn(1, 6)

        if (q.startsWith("operator:", true)) {
            val op = enabled.firstOrNull { it.id == "operator" } ?: return Turn(false, "Phone Operator is off. Turn it on in the Phone Operator tab first.")
            Bus.ui { Bus.subAgents = listOf(op.name) }
            status("Operator working…")
            val t = answerWith(c, run, op, q.substringAfter(":").trim(), emptyList(), "")
            return finish(c, q, t, op.id, listOf(Triple(op.id, t, 0)))
        }
        Bus.think("Analyzing request…")
        status("Thinking…")

        if (mode == "fast") {
            val a = enabled.firstOrNull { it.id == "synthesizer" } ?: enabled.first()
            Bus.think("Fast mode: ${a.name}")
            Bus.ui { Bus.subAgents = listOf(a.name) }
            status("Answering…")
            val t = answerWith(c, run, a, q, hmsgs, memCtx)
            return finish(c, q, t, a.id, listOf(Triple(a.id, t, 0)))
        }

        var picked: List<Agent>
        if (mode == "all") {
            Bus.think("Mode: ALL agents")
            picked = enabled
        } else {
            Bus.think("Selecting specialists…")
            val roster = enabled.joinToString("\n") { "${it.id}: ${it.role}" }
            val head = try {
                Llm.chat(
                    c, run, "head",
                    "You are Head Agent of SwarmDeck. Choose the best agents for the request. Reply with one line:\nAGENTS: id1, id2 (max $maxAgents)\n" +
                        "Only if NO existing agent fits a very specific need, add a second line:\nNEW_AGENT: Name | Role | Short system prompt\n" +
                        "Use operator only for phone tasks; browser/researcher for web facts.\nAgents:\n$roster",
                    q, hmsgs.takeLast(4)
                )
            } catch (e: CancelledException) {
                throw e
            } catch (e: Exception) {
                ""
            }
            var chosen = Parse.parseAgents(head, enabled.map { it.id }, maxAgents).mapNotNull { id -> enabled.firstOrNull { it.id == id } }
            val newAgent = Parse.parseNewAgent(head)?.let { (n, r, pr) -> Registry.addDynamic(n, r, pr) }
            if (newAgent != null) {
                Bus.think("Spawned specialist: ${newAgent.name}")
                chosen = (chosen + newAgent).take(maxAgents)
            }
            if (chosen.isEmpty()) chosen = enabled.filter { it.id in listOf("synthesizer", "planner", "creator") }.take(maxAgents).ifEmpty { listOf(enabled.first()) }
            picked = chosen
            Bus.think("Selected: " + picked.joinToString { it.name })
        }
        val names = picked.map { it.name }
        Bus.ui { Bus.subAgents = names }

        if (picked.size == 1) {
            val a = picked[0]
            status("Answering with ${a.name}…")
            val t = answerWith(c, run, a, q, hmsgs, memCtx)
            return finish(c, q, t, a.id, listOf(Triple(a.id, t, 0)))
        }

        status("Deploying: " + names.joinToString())
        Bus.think("Deploying ${picked.size} agents…")
        val futures = picked.map { a ->
            a to pool.submit(Callable<String> {
                try {
                    run.check()
                    Bus.think("${a.name} working…")
                    val sys = a.prompt + suf() + memCtx
                    if (a.tools.isEmpty()) Llm.chat(c, run, "agent", sys, q, hmsgs)
                    else toolLoop(c, run, "agent", sys, hmsgs, q, a.tools, if (a.id == "operator") 10 else 4)
                } catch (e: CancelledException) {
                    "ERR:cancelled"
                } catch (e: Exception) {
                    "ERR:" + (e.message ?: "failed")
                }
            })
        }
        val answers = futures.map { (a, f) ->
            a.id to try { f.get(170, TimeUnit.SECONDS) } catch (e: Exception) { f.cancel(true); "ERR:timeout" }
        }
        run.check()
        val ok = answers.filter { !it.second.startsWith("ERR:") }
        val good = ok.filter { !it.second.trim().equals("NONE", true) }.ifEmpty { ok }
        if (good.isEmpty()) return Turn(false, "Error: " + answers.first().second.removePrefix("ERR:"))

        if (good.size == 1) {
            return finish(c, q, good[0].second, good[0].first, listOf(Triple(good[0].first, good[0].second, 0)))
        }

        Bus.think("Synthesizing final answer…")
        status("Synthesizing…")
        val block = good.joinToString("\n\n") { "[${it.first}]\n${it.second.take(3500)}" }
        val sys = "You are Ultimate Agent. You receive several expert drafts for the user's request. Write the single best final answer in the user's language, " +
            "using markdown where helpful. Never mention agents inside the answer. Then on a NEW LAST LINE write exactly: " +
            "###META scores=id:score,id:score winner=id   (scores 1-10, ids are the draft ids)." + memCtx
        val full = try {
            streamTo(c, run, "synth", sys, "User request: $q\n\nExpert drafts:\n$block", hmsgs)
        } catch (e: CancelledException) {
            throw e
        } catch (e: Exception) {
            ""
        }
        val meta = Parse.parseMeta(full)
        val winner = meta.winner?.takeIf { w -> good.any { it.first == w } } ?: good[0].first
        val text = meta.answer.ifBlank { good.first { it.first == winner }.second }
        Bus.think("Winner: $winner")
        return finish(c, q, text, winner, good.map { Triple(it.first, it.second, meta.scores[it.first] ?: 0) })
    }
}
