package com.swarmdeck

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import java.io.File
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

object Term {
    val lines = mutableStateListOf("SwarmDeck terminal. Type help.")
    private var cwd: File? = null
    private val runIds = AtomicInteger(9000)

    // Only these base commands are allowed without confirmation.
    private val SAFE = setOf(
        "ls", "pwd", "date", "uname", "whoami", "id", "df", "du", "free", "uptime",
        "cat", "head", "tail", "wc", "echo", "printf", "env", "printenv",
        "find", "grep", "which", "file", "stat", "realpath", "basename", "dirname",
        "sleep", "true", "false", "test", "[", "mkdir", "touch", "cp", "mv", "rm",
        "ps", "top", "ping", "curl", "wget"
    )

    fun out(s: String) {
        Bus.ui {
            lines.add(s)
            while (lines.size > 400) lines.removeAt(0)
        }
    }

    fun exec(c: Context, cmd: String) {
        val t = cmd.trim()
        if (t.isEmpty()) return
        out("$ $t")
        Audit.log(c, "terminal", t.take(200))
        when {
            t == "clear" -> Bus.ui { lines.clear() }
            t == "help" -> out(
                "Built-ins: help · clear · agents · status · history · stats · audit · memory [q] · ask <q> · cd <dir>\n" +
                    "Safe shell (auto): ls pwd date uname df cat head tail echo find grep …\n" +
                    "Other shell commands require confirmation and are still limited (no network redirects, 15s timeout)."
            )
            t == "agents" -> out(Registry.all().joinToString("\n") {
                "${it.name} — ${it.role}" +
                    (if (Store.p(c).getBoolean("off_${it.id}", false)) " (off)" else "") +
                    (if (it.dynamic) " (dynamic)" else "")
            })
            t == "history" -> out("${Bus.turns.size} chat messages in this chat, ${Hist.list(c).size} chats saved")
            t == "stats" -> out("LLM calls: ${Bus.calls}   tokens: ${Bus.tokens}")
            t == "audit" -> out(Audit.tail(c, 40))
            t == "status" -> {
                val p = Store.p(c)
                val pr = Profiles.active(c)
                out(
                    "Profile: ${pr.name}\nAPI: ${pr.url}\nModel: ${p.getString("model", "auto")}\n" +
                        "Mode: ${p.getString("mode", "auto")}\nPhone control: ${if (p.getBoolean("phone", false)) "on" else "off"}, " +
                        "service ${if (PhoneControl.inst != null) "connected" else "not connected"}\nMemories: ${Memory.all(c).size}"
                )
            }
            t == "memory" || t.startsWith("memory ") -> {
                val q = t.removePrefix("memory").trim()
                val r = if (q.isEmpty()) Memory.all(c).take(10) else Memory.search(c, q, 10)
                out(if (r.isEmpty()) "(nothing found)" else r.joinToString("\n") { "• ${it.key}: ${it.value.take(120)}" })
            }
            t.startsWith("ask ") -> {
                if (Bus.running) {
                    out("Agent is busy with a chat request.")
                    return
                }
                out("…asking the swarm")
                val run = Run(runIds.incrementAndGet())
                Thread {
                    run.thread = Thread.currentThread()
                    try {
                        val r = Brain.run(c, run, t.removePrefix("ask ").trim(), Bus.turns.toList()) {}
                        out(r.text)
                    } catch (e: Exception) {
                        out("Error: ${e.message}")
                    }
                }.start()
            }
            t.startsWith("cd ") -> {
                val a = t.substring(3).trim()
                val base = (cwd ?: c.filesDir).canonicalFile
                val d = File(if (a.startsWith("/")) a else base.path + "/" + a).canonicalFile
                if (!d.path.startsWith(c.filesDir.canonicalPath) &&
                    !d.path.startsWith("/sdcard") &&
                    !d.path.startsWith("/storage")
                ) {
                    out("cd: restricted to app sandbox / storage for safety")
                } else if (d.isDirectory) {
                    cwd = d
                    out(d.path)
                } else {
                    out("cd: no such directory")
                }
            }
            else -> {
                val baseCmd = t.split(Regex("\\s+|\\||&|;")).firstOrNull { it.isNotBlank() }?.substringAfterLast('/') ?: ""
                if (baseCmd in SAFE) {
                    Thread { out(shell(c, t)) }.start()
                } else {
                    Thread {
                        val run = Run(runIds.incrementAndGet())
                        val ok = Confirm.ask(c, run, "Run shell: ${t.take(60)}", "Non-whitelisted command. Allow once?", true)
                        if (ok == 0) out("DENIED")
                        else out(shell(c, t))
                    }.start()
                }
            }
        }
    }

    private fun shell(c: Context, cmd: String): String {
        return try {
            val lower = cmd.lowercase()
            if ("rm -rf /" in lower || "mkfs" in lower || "fork-bomb" in lower || "dd if=" in lower) {
                return "Blocked: dangerous pattern detected"
            }
            val p = ProcessBuilder("sh", "-c", cmd)
                .directory(cwd ?: c.filesDir)
                .redirectErrorStream(true)
                .start()
            val buf = StringBuilder()
            val rd = Thread {
                p.inputStream.bufferedReader().use { r ->
                    var l = r.readLine()
                    while (l != null && buf.length < 6000) {
                        buf.appendLine(l)
                        l = r.readLine()
                    }
                }
            }
            rd.start()
            if (!p.waitFor(15, TimeUnit.SECONDS)) {
                p.destroyForcibly()
                buf.append("\n[timed out after 15s]")
            }
            rd.join(1000)
            buf.toString().trimEnd().ifEmpty { "(no output)" }
        } catch (e: Exception) {
            "error: ${e.message}"
        }
    }
}
