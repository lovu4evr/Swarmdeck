package com.swarmdeck

import android.content.Context
import android.content.Intent
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

// ───────── Markdown ─────────
fun inlineMd(s: String): AnnotatedString = buildAnnotatedString {
    var i = 0
    for (m in Regex("\\*\\*(.+?)\\*\\*|`([^`]+)`").findAll(s)) {
        append(s.substring(i, m.range.first))
        if (m.groupValues[1].isNotEmpty()) withStyle(SpanStyle(fontWeight = FontWeight.Bold)) { append(m.groupValues[1]) }
        else withStyle(SpanStyle(fontFamily = FontFamily.Monospace, background = Color(0x33FFFFFF))) { append(m.groupValues[2]) }
        i = m.range.last + 1
    }
    append(s.substring(i))
}

@Composable
fun MdText(c: Context, text: String, color: Color = Color.White, size: TextUnit = 15.sp) {
    val blocks = remember(text) { Parse.splitMd(text) }
    Column(verticalArrangement = Arrangement.spacedBy(3.dp)) {
        blocks.forEach { b ->
            if (b.code) CodeBlock(c, b) else b.text.lines().forEach { line ->
                val t = line.trimEnd()
                val num = Regex("^\\s*(\\d+[.)])\\s+(.*)").find(t)
                when {
                    t.isBlank() -> Spacer(Modifier.height(4.dp))
                    t.startsWith("#") -> Text(inlineMd(t.trimStart('#').trim()), color = GOLD, fontSize = size, fontWeight = FontWeight.Bold)
                    Regex("^\\s*[-*•]\\s+.*").matches(t) -> Row {
                        Text("•  ", color = ACC2, fontSize = size)
                        Text(inlineMd(t.trimStart().drop(1).trim()), color = color, fontSize = size, modifier = Modifier.weight(1f))
                    }
                    num != null -> Row {
                        Text(num.groupValues[1] + "  ", color = ACC2, fontSize = size)
                        Text(inlineMd(num.groupValues[2]), color = color, fontSize = size, modifier = Modifier.weight(1f))
                    }
                    else -> Text(inlineMd(t), color = color, fontSize = size)
                }
            }
        }
    }
}

@Composable
fun CodeBlock(c: Context, b: MdBlock) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color(0x66000000)).padding(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(b.lang.ifEmpty { "code" }, color = GOLD, fontSize = 11.sp, modifier = Modifier.weight(1f))
            TextButton({ copyText(c, b.text) }) { Text("Copy", fontSize = 12.sp) }
        }
        Text(b.text, color = Color(0xFFE2E8F0), fontFamily = FontFamily.Monospace, fontSize = 12.sp, modifier = Modifier.horizontalScroll(rememberScrollState()))
    }
}

// ───────── Agents ─────────
@Composable
fun AgentsTab(c: Context) {
    val p = Store.p(c)
    val v = Registry.version
    val agents = remember(v) { Registry.all() }
    LazyColumn(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { Text("Agents (${agents.size})", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
        item { Text("Specialists with tools are marked 🔧. Dynamic ones are session-only and have no tools.", color = MUTED, fontSize = 12.sp) }
        items(agents) { a ->
            var on by remember(a.id) { mutableStateOf(!p.getBoolean("off_${a.id}", false)) }
            Row(Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(12.dp).clip(RoundedCornerShape(6.dp)).background(colorOf(a.id)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(a.name + (if (a.tools.isNotEmpty()) " 🔧" else "") + (if (a.dynamic) " · dynamic" else ""), color = Color.White, fontWeight = FontWeight.Bold)
                    Text(a.role, color = MUTED, fontSize = 12.sp)
                }
                if (a.dynamic) IconButton({ Registry.remove(a.id) }) { Icon(Icons.Default.Delete, "Remove", tint = Color(0xFFFF8A8A)) }
                Switch(on, { on = it; p.edit().putBoolean("off_${a.id}", !it).apply() })
            }
        }
    }
}

// ───────── Memory ─────────
@Composable
fun MemoryTab(c: Context) {
    var q by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var adding by remember { mutableStateOf(false) }
    val items = remember(q, tick) {
        if (q.isBlank()) Memory.all(c).sortedWith(compareByDescending<MemoryItem> { it.pinned }.thenByDescending { it.ts })
        else Memory.search(c, q, 50)
    }
    if (adding) {
        var k by remember { mutableStateOf("") }
        var vv by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { adding = false }, containerColor = BG2, title = { Text("Add memory", color = CREAM) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedTextField(k, { k = it }, label = { Text("Title") }); OutlinedTextField(vv, { vv = it }, label = { Text("Fact") }) } },
            confirmButton = { TextButton({ if (k.isNotBlank() && vv.isNotBlank()) { Memory.save(c, k, vv); tick++; adding = false } }) { Text("Save") } },
            dismissButton = { TextButton({ adding = false }) { Text("Cancel") } }
        )
    }
    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Memory (${Memory.all(c).size})", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton({ adding = true }) { Icon(Icons.Default.Add, "Add", tint = ACC2) }
        }
        OutlinedTextField(q, { q = it }, Modifier.fillMaxWidth(), placeholder = { Text("Search memories…") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
        Text("Stored encrypted on this device. Agents can search it and save to it.", color = MUTED, fontSize = 11.sp)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            if (items.isEmpty()) item { Text("Nothing here yet. Use Save under an answer, or ask the agent to remember something.", color = MUTED) }
            items(items) { m ->
                var exp by remember(m.id) { mutableStateOf(false) }
                Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton({ exp = !exp }, Modifier.weight(1f)) { Text(m.key, color = CREAM, maxLines = 1, fontWeight = FontWeight.Bold) }
                        IconButton({ Memory.setPinned(c, m.id, !m.pinned); tick++ }) { Icon(Icons.Default.PushPin, "Pin", tint = if (m.pinned) GOLD else MUTED) }
                        IconButton({ Memory.delete(c, m.id); tick++ }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFFF8A8A)) }
                    }
                    Text(if (exp) m.value else m.value.take(120), color = Color(0xFFCBD5E1), fontSize = 13.sp)
                }
            }
        }
    }
}

// ───────── Terminal ─────────
@Composable
fun TermTab(c: Context) {
    var cmd by remember { mutableStateOf("") }
    val ls = rememberLazyListState()
    LaunchedEffect(Term.lines.size) { if (Term.lines.isNotEmpty()) ls.scrollToItem(Term.lines.size - 1) }
    Column(Modifier.fillMaxSize().padding(14.dp)) {
        Text("Terminal", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        LazyColumn(Modifier.weight(1f).fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(10.dp), state = ls) {
            items(Term.lines) { Text(it, color = Color(0xFF34D399), fontFamily = FontFamily.Monospace, fontSize = 12.sp) }
        }
        Row(Modifier.padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(cmd, { cmd = it }, Modifier.weight(1f), placeholder = { Text("command…") }, singleLine = true)
            IconButton({ val x = cmd; cmd = ""; Term.exec(c, x) }) { Icon(Icons.Default.Send, "Run", tint = ACC) }
        }
    }
}

// ───────── Settings ─────────
@Composable
fun PrefField(c: Context, key: String, label: String, def: String = "", secret: Boolean = false) {
    val p = Store.p(c)
    var v by remember(key) { mutableStateOf(p.getString(key, def) ?: def) }
    OutlinedTextField(v, { v = it; p.edit().putString(key, it).apply() }, Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true)
}

@Composable
fun PrefSwitch(c: Context, key: String, label: String, def: Boolean) {
    val p = Store.p(c)
    var v by remember(key) { mutableStateOf(p.getBoolean(key, def)) }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = CREAM, modifier = Modifier.weight(1f), fontSize = 14.sp)
        Switch(v, { v = it; p.edit().putBoolean(key, it).apply() })
    }
}

@Composable
fun Sec(t: String) = Text(t, color = GOLD, fontWeight = FontWeight.Bold, fontSize = 15.sp, modifier = Modifier.padding(top = 10.dp))

@Composable
fun SettingsTab(c: Context) {
    val p = Store.p(c)
    val scope = rememberCoroutineScope()
    var profs by remember { mutableStateOf(Profiles.all(c)) }
    val act = remember { Profiles.active(c) }
    var pname by remember { mutableStateOf(act.name) }
    var purl by remember { mutableStateOf(act.url) }
    var pkey by remember { mutableStateOf(act.key) }
    var msg by remember { mutableStateOf("") }
    var maxA by remember { mutableIntStateOf(p.getInt("max_agents", 3)) }
    var confirm by remember { mutableStateOf(p.getString("confirm", "all") ?: "all") }
    var showAudit by remember { mutableStateOf(false) }
    val exp = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            msg = try { c.contentResolver.openOutputStream(uri)?.use { it.write(Backup.export(c).toByteArray()) }; "Exported (unencrypted file - keep it safe)" } catch (e: Exception) { "Export failed: ${e.message}" }
        }
    }
    val imp = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch(Dispatchers.IO) {
            msg = try { Backup.import(c, c.contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }) } catch (e: Exception) { "Import failed: ${e.message}" }
        }
    }
    if (showAudit) AlertDialog(
        onDismissRequest = { showAudit = false }, containerColor = BG2, title = { Text("Audit log", color = CREAM) },
        text = { Text(Audit.tail(c, 80), color = Color(0xFF34D399), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.verticalScroll(rememberScrollState())) },
        confirmButton = { TextButton({ showAudit = false }) { Text("Close") } }
    )
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Settings", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)

        Sec("API profile (key stored encrypted)")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            profs.forEach { pr ->
                FilterChip(pr.name == pname, { pname = pr.name; purl = pr.url; pkey = pr.key; Profiles.setActive(c, pr.name) }, { Text(pr.name) })
            }
        }
        OutlinedTextField(pname, { pname = it }, Modifier.fillMaxWidth(), label = { Text("Profile name") }, singleLine = true)
        OutlinedTextField(purl, { purl = it }, Modifier.fillMaxWidth(), label = { Text("API base URL (https://…/v1)") }, singleLine = true)
        OutlinedTextField(pkey, { pkey = it }, Modifier.fillMaxWidth(), label = { Text("API key") }, singleLine = true)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button({
                val bad = Parse.urlProblem(purl)
                if (bad != null || pname.isBlank()) msg = bad ?: "Name required" else {
                    Profiles.save(c, Profile(pname.trim(), purl.trim(), pkey.trim())); profs = Profiles.all(c)
                    msg = "Saved. Testing…"
                    scope.launch(Dispatchers.IO) { msg = try { "Test OK: " + Llm.chat(c, Run(-2), "agent", "Reply with the single word OK.", "ping").take(40) } catch (e: Exception) { "Test failed: ${e.message}" } }
                }
            }) { Text("Save & test") }
            OutlinedButton({ Profiles.delete(c, pname); profs = Profiles.all(c); val a = Profiles.active(c); pname = a.name; purl = a.url; pkey = a.key }) { Text("Delete") }
        }
        if (msg.isNotEmpty()) Text(msg, color = ACC2, fontSize = 12.sp)

        Sec("Models (real routing)")
        PrefField(c, "model", "Main model", "auto")
        PrefField(c, "model_head", "Cheap model for planning/verifying (optional)")
        PrefField(c, "model_synth", "Strong model for final answer (optional)")
        PrefField(c, "model_fb", "Fallback models, comma separated")
        Text("Max agents per message: $maxA", color = CREAM, fontSize = 13.sp)
        Slider(maxA.toFloat(), { maxA = it.roundToInt(); p.edit().putInt("max_agents", maxA).apply() }, valueRange = 1f..6f, steps = 4)
        PrefSwitch(c, "no_tools", "Endpoint has no native tool calling (use prompt tools)", false)
        PrefField(c, "price_m", "Price per 1M tokens (for cost estimate)")
        val price = (p.getString("price_m", "") ?: "").toDoubleOrNull() ?: 0.0
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("${Bus.calls} calls · ${Bus.tokens} tokens" + (if (price > 0) " · ≈ ${"%.4f".format(Bus.tokens / 1e6 * price)}" else ""), color = MUTED, fontSize = 12.sp, modifier = Modifier.weight(1f))
            TextButton({ Stats.reset() }) { Text("Reset") }
        }

        Sec("Voice")
        PrefSwitch(c, "tts", "Speak answers aloud", true)
        PrefField(c, "wake", "Wake word (blank = always listen in hands-free)")

        Sec("Memory")
        PrefSwitch(c, "autosave", "Auto-save conclusions to memory", false)

        Sec("Phone control")
        PrefSwitch(c, "phone", "Allow Operator agent to control the phone", false)
        Button({ c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) { Text("Open accessibility settings") }
        Text(if (PhoneControl.inst != null) "Service: connected" else "Service: not connected", color = MUTED, fontSize = 12.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(confirm == "all", { confirm = "all"; p.edit().putString("confirm", "all").apply() }, { Text("Ask every action") })
            FilterChip(confirm == "risky", { confirm = "risky"; p.edit().putString("confirm", "risky").apply() }, { Text("Ask only risky") })
        }
        PrefField(c, "allow_apps", "Allowed apps, comma separated (blank = any except protected)")
        Text("Screen text is sent to your API endpoint while the Operator works. Settings/installer apps are blocked unless allowlisted. Kill switch: Volume Down ×3, or the notification Stop button.", color = MUTED, fontSize = 11.sp)
        OutlinedButton({ showAudit = true }) { Text("View audit log") }

        Sec("Data")
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton({ exp.launch("swarmdeck-backup.json") }) { Text("Export") }
            OutlinedButton({ imp.launch(arrayOf("application/json", "*/*")) }) { Text("Import") }
        }
        OutlinedButton({ newChat(c); Toast.makeText(c, "Started a new chat", Toast.LENGTH_SHORT).show() }) { Text("New chat") }
        Text("SwarmDeck 5.0", color = MUTED, fontSize = 11.sp)
        Spacer(Modifier.height(24.dp))
    }
}

// ───────── Live browser card (like "Gemini is using the browser") ─────────
@Composable
fun LiveCard() {
    var full by remember { mutableStateOf(false) }
    if (full) LiveDialog { full = false }
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Language, null, tint = ACC2)
            Spacer(Modifier.width(8.dp))
            Text(if (Bus.running) "SwarmDeck is using the browser…" else "Last browser session", color = CREAM, fontWeight = FontWeight.Bold)
        }
        val shot = Bus.liveShot
        if (shot != null) Image(shot, "Live browser", Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).border(1.dp, EDGE, RoundedCornerShape(12.dp)), contentScale = ContentScale.FillWidth)
        else Text("Loading preview…", color = MUTED, fontSize = 12.sp)
        if (Bus.liveUrl.isNotEmpty()) Text(Bus.liveUrl, color = MUTED, fontSize = 11.sp, maxLines = 1)
        if (Bus.liveNote.isNotEmpty()) Text("› " + Bus.liveNote, color = GOLD, fontSize = 12.sp)
        Button({ full = true }, Modifier.fillMaxWidth()) { Text("View live") }
    }
}

@Composable
fun LiveDialog(close: () -> Unit) {
    Dialog(onDismissRequest = close, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(Modifier.fillMaxSize().background(BG1).padding(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(Bus.liveUrl.take(60), color = CREAM, fontSize = 12.sp, maxLines = 1, modifier = Modifier.weight(1f))
                TextButton({ if (LiveBrowser.takeover) LiveBrowser.takeoverEnd() else LiveBrowser.takeoverStart() }) { Text(if (LiveBrowser.takeover) "Resume agent" else "Take control", color = GOLD) }
                TextButton(close) { Text("Close") }
            }
            AndroidView(factory = { ctx -> LiveBrowser.attach(ctx) }, modifier = Modifier.weight(1f).fillMaxWidth(), onRelease = { LiveBrowser.detach() })
        }
    }
}

// ───────── Audit dialog ─────────
@Composable
fun AuditDialog(c: Context, close: () -> Unit) {
    AlertDialog(
        onDismissRequest = close, containerColor = BG2, title = { Text("Audit log", color = CREAM) },
        text = { Text(Audit.tail(c, 80), color = Color(0xFF34D399), fontSize = 11.sp, fontFamily = FontFamily.Monospace, modifier = Modifier.verticalScroll(rememberScrollState())) },
        confirmButton = { TextButton(close) { Text("Close", color = GOLD) } }
    )
}

// ───────── Tools page ─────────
private val TOOL_GROUPS: List<Pair<String, List<Pair<String, String>>>> = listOf(
    "🌐 Web" to listOf("web_search" to "Search the web", "web_fetch" to "Fetch page text (https only)", "current_time" to "Real date & time"),
    "🧭 Live browser" to listOf(
        "browser_open" to "Open a page", "browser_read" to "Read page + elements", "browser_click" to "Click by text/index",
        "browser_type" to "Type into fields (asks you)", "browser_select" to "Pick dropdown option", "browser_check" to "Tick checkbox/radio",
        "browser_scroll" to "Scroll page", "browser_back" to "Back", "browser_forward" to "Forward", "browser_reload" to "Reload",
        "browser_wait" to "Wait for text/seconds", "browser_extract_tables" to "Extract tables", "browser_screenshot" to "Refresh live preview",
        "browser_takeover_start" to "Hand control to you", "browser_takeover_end" to "Take control back"
    ),
    "🧠 Memory & files" to listOf("memory_search" to "Search memory", "memory_save" to "Save to memory", "file_list" to "List sandbox files", "file_read" to "Read sandbox file", "file_write" to "Write sandbox file")
)

@Composable
fun ToolsTab(c: Context) {
    val p = Store.p(c)
    var live by remember { mutableStateOf(false) }
    var tick by remember { mutableIntStateOf(0) }
    if (live) LiveDialog { live = false }
    val files = remember(tick) { java.io.File(c.filesDir, "workspace").listFiles()?.sortedBy { it.name } ?: emptyList() }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Tools", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Text("Switch off any tool you don't want agents to use. Phone control lives in the Phone Operator page.", color = MUTED, fontSize = 12.sp)
        Button({ live = true }, Modifier.fillMaxWidth()) { Icon(Icons.Default.Language, null); Spacer(Modifier.width(8.dp)); Text("Open live browser") }
        TOOL_GROUPS.forEach { (title, list) ->
            Sec(title)
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                list.forEach { (id, desc) ->
                    var on by remember(id) { mutableStateOf(!p.getBoolean("tool_off_$id", false)) }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(id, color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            Text(desc, color = MUTED, fontSize = 11.sp)
                        }
                        Switch(on, { on = it; p.edit().putBoolean("tool_off_$id", !it).apply() })
                    }
                }
            }
        }
        Sec("📁 Sandbox files (${files.size})")
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            if (files.isEmpty()) Text("No files yet. Ask Coder or a mission to save something.", color = MUTED, fontSize = 12.sp)
            files.forEach { f ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text((if (f.isDirectory) "📂 " else "📄 ") + f.name + (if (f.isFile) "  (${f.length()} B)" else ""), color = CREAM, fontSize = 12.sp, modifier = Modifier.weight(1f))
                    if (f.isFile) TextButton({ copyText(c, try { f.readText().take(20000) } catch (e: Exception) { "" }) }) { Text("Copy", color = ACC2, fontSize = 12.sp) }
                    IconButton({ f.deleteRecursively(); tick++ }) { Icon(Icons.Default.Delete, "Delete", tint = Color(0xFFFF8A8A)) }
                }
            }
            TextButton({ tick++ }) { Text("Refresh", color = GOLD) }
        }
        Spacer(Modifier.height(20.dp))
    }
}

// ───────── Phone Operator page ─────────
@Composable
fun PhoneTab(c: Context, goto: (String) -> Unit) {
    val p = Store.p(c)
    var confirm by remember { mutableStateOf(p.getString("confirm", "all") ?: "all") }
    var cmd by remember { mutableStateOf("") }
    var showAudit by remember { mutableStateOf(false) }
    var on by remember { mutableStateOf(p.getBoolean("phone", false)) }
    if (showAudit) AuditDialog(c) { showAudit = false }
    val connected = PhoneControl.inst != null
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Phone Operator", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Allow Operator to control this phone", color = CREAM, modifier = Modifier.weight(1f), fontSize = 14.sp)
                Switch(on, { on = it; p.edit().putBoolean("phone", it).apply() })
            }
            Text(if (connected) "● Accessibility service connected" else "○ Accessibility service NOT connected", color = if (connected) Color(0xFF34D399) else Color(0xFFFF8A8A), fontSize = 12.sp)
            Button({ c.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }, Modifier.fillMaxWidth()) { Text("Open accessibility settings") }
        }
        Sec("Tell the Operator what to do")
        OutlinedTextField(cmd, { cmd = it }, Modifier.fillMaxWidth(), placeholder = { Text("e.g. Open Calculator and compute 25×4") }, minLines = 2)
        Button({
            if (!on) Toast.makeText(c, "Turn on 'Allow Operator' first", Toast.LENGTH_SHORT).show()
            else if (!connected) Toast.makeText(c, "Enable the accessibility service first", Toast.LENGTH_LONG).show()
            else if (cmd.isBlank() || Bus.running) Toast.makeText(c, if (Bus.running) "Agent is busy" else "Type a command", Toast.LENGTH_SHORT).show()
            else { sendMessage(c, "operator: ${cmd.trim()}"); cmd = ""; goto("chat") }
        }, Modifier.fillMaxWidth()) { Text("Run Operator") }
        Sec("Safety")
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            FilterChip(confirm == "all", { confirm = "all"; p.edit().putString("confirm", "all").apply() }, { Text("Ask every action") })
            FilterChip(confirm == "risky", { confirm = "risky"; p.edit().putString("confirm", "risky").apply() }, { Text("Ask only risky") })
        }
        PrefField(c, "allow_apps", "Allowed apps, comma separated (blank = any except protected)")
        Text("Every action needs your approval (dialog or notification). Passwords are never typed. Settings/installer apps are blocked unless allowlisted. Kill switch: press Volume Down 3×, or tap Stop in the notification. Screen text is sent to your API endpoint while the Operator works.", color = MUTED, fontSize = 11.sp)
        OutlinedButton({ showAudit = true }, Modifier.fillMaxWidth()) { Text("View audit log") }
        Spacer(Modifier.height(20.dp))
    }
}

// ───────── Profile page ─────────
@Composable
fun ProfileTab(c: Context) {
    val p = Store.p(c)
    var name by remember { mutableStateOf(p.getString("name", "") ?: "") }
    val chats = remember(Bus.turns.size) { Hist.list(c).size }
    val mems = remember(Bus.turns.size) { Memory.all(c).size }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
        BotAvatar(96)
        Text(userName(c), color = GOLD, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField(name, { name = it; p.edit().putString("name", it.trim()).apply() }, Modifier.fillMaxWidth(), label = { Text("Your name (used in greetings)") }, singleLine = true)
        Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Saved chats" to "$chats", "Memories" to "$mems", "LLM calls" to "${Bus.calls}", "Tokens used" to "${Bus.tokens}", "Active API profile" to Profiles.active(c).name).forEach { (k, v) ->
                Row { Text(k, color = MUTED, modifier = Modifier.weight(1f), fontSize = 13.sp); Text(v, color = CREAM, fontSize = 13.sp, fontWeight = FontWeight.SemiBold) }
            }
        }
        Text("SwarmDeck V5.0 · Autonomous God Mode", color = MUTED, fontSize = 11.sp)
    }
}
