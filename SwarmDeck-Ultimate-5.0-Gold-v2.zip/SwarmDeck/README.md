# SwarmDeck Ultimate Edition 5.0 (Gold UI)

UI: gold/black "God Mode" design - splash screen, slide-out sidebar (Chat, Agents, Memory, Terminal, Tools, Phone Operator, Settings, Profile), Head Agent card with mode dropdown, quick buttons (Quick Mission, Think Deep, Create Agent, More).


Android multi-agent assistant (Kotlin + Jetpack Compose). Local-first: chats and memory live in an on-device SQLite DB, encrypted with an Android-Keystore AES-GCM key; API keys are stored encrypted.

## Setup
1. Open in Android Studio (or push to GitHub → Actions builds the APK).
2. Open the app → Enter (no account). Settings → add an OpenAI-compatible endpoint (https://…/v1) + key → Save & test.

## What's new in 5.0 Ultimate

### Security hardening
- **Vault fails closed**: if Android Keystore is unavailable, data is **not** stored in plaintext (no more silent `p:` fallback).
- **Audit log encrypted** with Vault when possible.
- **Trust is time-scoped**: "Allow + trust" now lasts only **5 minutes**, not the whole run.
- **web_fetch SSRF protection**: blocks private/reserved IPs, localhost, link-local, cloud metadata hosts.
- **Terminal hardened**:
  - Whitelist of safe commands runs freely.
  - Everything else requires explicit confirmation.
  - Dangerous patterns (`rm -rf /`, `mkfs`, fork bombs…) are blocked.
  - `cd` restricted toward app sandbox / storage.
  - `ask` from terminal now uses a proper cancellable `Run`.

### Live browser (from 4.2)
- `browser_back` / `forward` / `reload`
- `browser_wait` (seconds + text)
- Click by **index or text**
- Rich `browser_read` (numbered elements + types)
- `browser_select`, `browser_check`
- Improved typing (clear + index)
- Table extraction, screenshot refresh, manual takeover mode
- Full real internet (HTTPS)

### Data layer
- Database version 2 with non-destructive `onUpgrade` (future schema changes won't wipe data).
- Critical persistence failures are logged instead of fully silent.

### Still local-first
- No Google login, no cloud account required.
- Phone control, memory, missions, multi-agent swarm, voice, etc. remain as in 4.x.

## Limits (honest)
- First build may need small Android Studio / Gradle sync fixes (no wrapper shipped).
- web_search still scrapes DuckDuckGo HTML (fragile).
- Phone control uses accessibility service → sideloading only; Play Store will likely reject it.
- targetSdk 34 — fine for sideload, not for new Play uploads.
- Full-page stitched screenshots not implemented (visible area only).
- Export files remain plaintext (by design for portability).

## Quick test prompts
```
Open https://example.com and list interactive elements by index
```
```
Search the web for current Bitcoin price then open the most reliable source
```
```
Start a mission: research the top 3 open-source LLM frameworks and summarize differences
```
